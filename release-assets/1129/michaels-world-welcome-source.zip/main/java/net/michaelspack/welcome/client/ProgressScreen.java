package net.michaelspack.welcome.client;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.michaelspack.welcome.ProgressSnapshot;
import org.lwjgl.glfw.GLFW;

final class ProgressScreen extends Screen {
    private static final int INK = 0xff151d2b;
    private static final int INSET = 0xff202b3f;
    private static final int LINE = 0xff43506a;
    private static final int GOLD = 0xfff2cc79;
    private static final int TEXT = 0xfff0ebe1;
    private static final int MUTED = 0xffb8c4d6;
    private static final int EARNED = 0xffa2dfaa;
    private static final int ROW_HEIGHT = 15;
    private static final int MILESTONE_LINE_HEIGHT = 11;
    private static final int MILESTONE_HEADING = 15;
    private static final int PLAYER_HEADING = 30;
    private static final int SECTION_GAP = 7;
    private static final int SCROLLBAR_WIDTH = 5;
    private static final String[] HEADERS = {"Diamond", "Nether", "Netherite", "End", "Mobs", "Deaths"};
    private static final String[] SUBHEADERS = {"armor", "", "armor", "", "killed", ""};

    private final ProgressSnapshot snapshot;
    private List<FormattedCharSequence> milestones;
    private int left;
    private int top;
    private int panelWidth;
    private int panelHeight;
    private int milestonesTop;
    private int playersTop;
    private int nameWidth;
    private final int[] statEdges = new int[HEADERS.length + 1];
    private final ScrollArea milestoneRows = new ScrollArea();
    private final ScrollArea playerRows = new ScrollArea();
    private ScrollArea activeScroll = playerRows;
    private ScrollArea draggedScroll;

    ProgressScreen(ProgressSnapshot snapshot) {
        super(Component.literal("World Progress"));
        this.snapshot = snapshot;
    }

    @Override
    protected void init() {
        draggedScroll = null;
        panelWidth = Math.min(456, width - 16);
        panelHeight = Math.min(252, height - 16);
        left = (width - panelWidth) / 2;
        top = (height - panelHeight) / 2;
        milestonesTop = top + 46;
        int bodyBottom = top + panelHeight - 34;
        int contentWidth = panelWidth - 24;
        layoutColumns(contentWidth);
        milestones = font.split(snapshot.milestones(), contentWidth - 13);
        int room = Math.max(0, bodyBottom - milestonesTop - SECTION_GAP);
        int milestoneContent = milestones.size() * MILESTONE_LINE_HEIGHT;
        int playerMinimum = PLAYER_HEADING + Math.min(3, snapshot.players().size()) * ROW_HEIGHT;
        int milestoneMinimum = MILESTONE_HEADING + MILESTONE_LINE_HEIGHT;
        int milestoneLimit = Math.min(room * 2 / 3, Math.max(milestoneMinimum, room - playerMinimum));
        int milestoneBottom = milestonesTop + Math.min(MILESTONE_HEADING + milestoneContent, milestoneLimit);
        milestoneRows.layout(milestonesTop + MILESTONE_HEADING, milestoneBottom, milestoneContent);
        playersTop = milestoneBottom + SECTION_GAP;
        playerRows.layout(playersTop + PLAYER_HEADING, bodyBottom, snapshot.players().size() * ROW_HEIGHT);
        addRenderableWidget(new CloseButton(Button.builder(Component.literal("× Close"), button -> onClose())
                .bounds(width / 2 - 49, top + panelHeight - 27, 98, 20)));
    }

    private void layoutColumns(int contentWidth) {
        int idealStatsWidth = 0;
        for (int i = 0; i < HEADERS.length; i++) {
            idealStatsWidth += Math.max(font.width(HEADERS[i]), font.width(SUBHEADERS[i])) + 6;
            statEdges[i + 1] = idealStatsWidth;
        }
        nameWidth = Math.min(104, Math.max(contentWidth / 6, contentWidth - idealStatsWidth));
        int statsWidth = contentWidth - nameWidth;
        for (int i = 1; i < statEdges.length; i++) {
            statEdges[i] = statsWidth >= idealStatsWidth
                    ? statEdges[i] + (statsWidth - idealStatsWidth) * i / HEADERS.length
                    : statEdges[i] * statsWidth / idealStatsWidth;
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.fill(left, top, left + panelWidth, top + panelHeight, LINE);
        graphics.fill(left + 1, top + 1, left + panelWidth - 1, top + panelHeight - 1, INK);
        graphics.hLine(left + 5, left + panelWidth - 6, top + 3, GOLD);
        graphics.drawCenteredString(font, title, width / 2, top + 10, GOLD);
        graphics.drawCenteredString(font, "World age · " + snapshot.age(), width / 2, top + 22, MUTED);
        graphics.drawCenteredString(font, snapshot.dragonStatus(), width / 2, top + 33, MUTED);

        int x = left + 10;
        int right = left + panelWidth - 10;
        graphics.fill(x, milestonesTop, right - 2, milestoneRows.bottom, INSET);
        graphics.drawString(font, "Server milestones", x + 5, milestonesTop + 4, TEXT, false);
        graphics.enableScissor(x, milestoneRows.top, right, milestoneRows.bottom);
        for (int i = milestoneRows.offset / MILESTONE_LINE_HEIGHT; i < milestones.size(); i++) {
            int y = milestoneRows.top + i * MILESTONE_LINE_HEIGHT - milestoneRows.offset;
            if (y >= milestoneRows.bottom) {
                break;
            }
            graphics.drawString(font, milestones.get(i), x + 5, y, MUTED, false);
        }
        graphics.disableScissor();
        graphics.drawString(font, "Player stats", x, playersTop, TEXT, false);
        drawHeaders(graphics, x, playersTop + 13);
        graphics.enableScissor(x, playerRows.top, right, playerRows.bottom);
        String hoveredName = drawRows(graphics, x, mouseX, mouseY);
        graphics.disableScissor();
        milestoneRows.drawScrollbar(graphics, scrollbarX());
        playerRows.drawScrollbar(graphics, scrollbarX());
        super.render(graphics, mouseX, mouseY, partialTick);
        if (hoveredName != null) {
            graphics.renderTooltip(font, Component.literal(hoveredName), mouseX, mouseY);
        }
    }

    private void drawHeaders(GuiGraphics graphics, int x, int y) {
        graphics.drawString(font, "Player", x + 3, y + 3, MUTED, false);
        for (int i = 0; i < HEADERS.length; i++) {
            int center = columnCenter(x, i);
            int labelWidth = statEdges[i + 1] - statEdges[i] - 2;
            String label = fit(HEADERS[i], labelWidth);
            if (SUBHEADERS[i].isEmpty()) {
                graphics.drawCenteredString(font, label, center, y + 3, MUTED);
            } else {
                graphics.drawCenteredString(font, label, center, y - 1, MUTED);
                graphics.drawCenteredString(font, fit(SUBHEADERS[i], labelWidth), center, y + 8, MUTED);
            }
        }
    }

    private String drawRows(GuiGraphics graphics, int x, int mouseX, int mouseY) {
        String hovered = null;
        for (int i = playerRows.offset / ROW_HEIGHT; i < snapshot.players().size(); i++) {
            int y = playerRows.top + i * ROW_HEIGHT - playerRows.offset;
            if (y >= playerRows.bottom) {
                break;
            }
            var row = snapshot.players().get(i);
            graphics.hLine(x, left + panelWidth - 13, y, LINE);
            String displayName = fit(row.name(), nameWidth - 5);
            graphics.drawString(font, displayName, x + 3, y + 4, TEXT, false);
            if (!displayName.equals(row.name()) && mouseX >= x && mouseX < x + nameWidth
                    && mouseY >= Math.max(y, playerRows.top) && mouseY < Math.min(y + ROW_HEIGHT, playerRows.bottom)) {
                hovered = row.name();
            }
            drawMark(graphics, x, y, 0, row.diamondArmor());
            drawMark(graphics, x, y, 1, row.nether());
            drawMark(graphics, x, y, 2, row.netheriteArmor());
            drawMark(graphics, x, y, 3, row.end());
            graphics.drawCenteredString(font, Integer.toString(row.mobsKilled()), columnCenter(x, 4), y + 4, TEXT);
            graphics.drawCenteredString(font, Integer.toString(row.deaths()), columnCenter(x, 5), y + 4, TEXT);
        }
        return hovered;
    }

    private String fit(String text, int maxWidth) {
        if (font.width(text) <= maxWidth) {
            return text;
        }
        int ellipsis = font.width("…");
        return maxWidth < ellipsis ? "" : font.plainSubstrByWidth(text, maxWidth - ellipsis) + "…";
    }

    private int columnCenter(int x, int column) {
        return x + nameWidth + (statEdges[column] + statEdges[column + 1]) / 2;
    }

    private void drawMark(GuiGraphics graphics, int x, int y, int column, boolean earned) {
        graphics.drawCenteredString(font, earned ? "✓" : "—", columnCenter(x, column), y + 4, earned ? EARNED : MUTED);
    }

    private ScrollArea scrollAt(double x, double y) {
        if (x >= left + 10 && x < left + panelWidth - 4) {
            if (y >= milestonesTop && y < milestoneRows.bottom) {
                return milestoneRows;
            }
            if (y >= playersTop && y < playerRows.bottom) {
                return playerRows;
            }
        }
        return null;
    }

    private int scrollbarX() {
        return left + panelWidth - SCROLLBAR_WIDTH - 4;
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        var area = scrollAt(x, y);
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && area != null && x >= scrollbarX() - 1
                && area.beginDrag(y)) {
            draggedScroll = area;
            activeScroll = area;
            return true;
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && draggedScroll != null) {
            draggedScroll.dragTo(y);
            return true;
        }
        return super.mouseDragged(x, y, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && draggedScroll != null) {
            draggedScroll = null;
            return true;
        }
        return super.mouseReleased(x, y, button);
    }

    @Override
    public void mouseMoved(double x, double y) {
        var area = scrollAt(x, y);
        if (area != null) {
            activeScroll = area;
        }
        super.mouseMoved(x, y);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        var area = scrollAt(mouseX, mouseY);
        if (area == null) {
            return super.mouseScrolled(mouseX, mouseY, delta);
        }
        activeScroll = area;
        return area.move((int) Math.round(-delta * ROW_HEIGHT * 2));
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        return switch (key) {
            case GLFW.GLFW_KEY_UP -> activeScroll.move(-ROW_HEIGHT);
            case GLFW.GLFW_KEY_DOWN -> activeScroll.move(ROW_HEIGHT);
            case GLFW.GLFW_KEY_PAGE_UP -> activeScroll.move(-activeScroll.height());
            case GLFW.GLFW_KEY_PAGE_DOWN -> activeScroll.move(activeScroll.height());
            default -> super.keyPressed(key, scanCode, modifiers);
        };
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static final class ScrollArea {
        private int top;
        private int bottom;
        private int contentHeight;
        private int offset;
        private double grabOffset;

        void layout(int top, int bottom, int contentHeight) {
            this.top = top;
            this.bottom = Math.max(top, bottom);
            this.contentHeight = contentHeight;
            move(0);
        }

        int height() {
            return bottom - top;
        }

        private int maxScroll() {
            return Math.max(0, contentHeight - height());
        }

        boolean move(int amount) {
            int next = Mth.clamp(offset + amount, 0, maxScroll());
            boolean moved = offset != next;
            offset = next;
            return moved;
        }

        private int thumbHeight() {
            int track = height();
            return Mth.clamp(track * track / contentHeight, Math.min(track, 9), track);
        }

        private int thumbTop() {
            return top + (height() - thumbHeight()) * offset / maxScroll();
        }

        boolean beginDrag(double y) {
            if (y < top || y >= bottom || maxScroll() == 0 || height() == thumbHeight()) {
                return false;
            }
            int thumbTop = thumbTop();
            int thumbHeight = thumbHeight();
            grabOffset = y >= thumbTop && y < thumbTop + thumbHeight ? y - thumbTop : thumbHeight / 2.0;
            dragTo(y);
            return true;
        }

        void dragTo(double y) {
            int travel = height() - thumbHeight();
            offset = Mth.clamp((int) Math.round((y - top - grabOffset) * maxScroll() / travel), 0, maxScroll());
        }

        void drawScrollbar(GuiGraphics graphics, int x) {
            if (height() > 0 && maxScroll() > 0) {
                int y = thumbTop();
                graphics.fill(x, top, x + SCROLLBAR_WIDTH, bottom, INSET);
                graphics.fill(x, y, x + SCROLLBAR_WIDTH, y + thumbHeight(), MUTED);
            }
        }
    }

    private static final class CloseButton extends Button {
        private CloseButton(Button.Builder builder) {
            super(builder);
        }

        @Override
        protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            int x = getX();
            int y = getY();
            graphics.fill(x, y, x + width, y + height, isHoveredOrFocused() ? TEXT : GOLD);
            graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, isHoveredOrFocused() ? 0xfff5d997 : 0xffe9c679);
            int textWidth = Minecraft.getInstance().font.width(getMessage());
            graphics.drawString(Minecraft.getInstance().font, getMessage(), x + (width - textWidth) / 2,
                    y + (height - 8) / 2, INK, false);
        }
    }
}
