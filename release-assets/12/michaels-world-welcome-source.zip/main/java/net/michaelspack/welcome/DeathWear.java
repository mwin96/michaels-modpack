package net.michaelspack.welcome;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.TridentItem;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.registries.ForgeRegistries;

/** Dying costs durability on worn gear, held items and hotbar weapons. Items stop at 1 durability. */
final class DeathWear {
    private static final double LOSS = 0.30;

    private DeathWear() {}

    static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player instanceof FakePlayer) {
            return;
        }
        boolean worn = false;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            worn |= wear(player.getItemBySlot(slot));
        }
        for (int slot = 0; slot < Inventory.getSelectionSize(); slot++) {
            if (slot != player.getInventory().selected && isWeapon(player.getInventory().getItem(slot))) {
                worn |= wear(player.getInventory().getItem(slot));
            }
        }
        if (worn) {
            player.sendSystemMessage(Component.literal("Your equipped gear and hotbar weapons lost 30% durability.")
                    .withStyle(ChatFormatting.RED));
        }
    }

    private static boolean isWeapon(ItemStack stack) {
        if (stack.getItem() instanceof ProjectileWeaponItem || stack.getItem() instanceof TridentItem) {
            return true;
        }
        if (stack.getItem() instanceof DiggerItem && !(stack.getItem() instanceof AxeItem)) {
            return false;
        }
        return stack.getAttributeModifiers(EquipmentSlot.MAINHAND).containsKey(Attributes.ATTACK_DAMAGE);
    }

    private static boolean wear(ItemStack stack) {
        var id = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (stack.isEmpty() || !stack.isDamageableItem() || (id != null && id.getNamespace().equals("artifacts"))) {
            return false;
        }
        int damaged = Math.min(stack.getDamageValue() + (int) Math.ceil(stack.getMaxDamage() * LOSS), stack.getMaxDamage() - 1);
        if (damaged <= stack.getDamageValue()) {
            return false;
        }
        stack.setDamageValue(damaged);
        return true;
    }
}
