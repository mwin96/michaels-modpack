package net.michaelspack.welcome.client;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.michaelspack.welcome.WorldWelcome;

/** The one-time 1.1 goal popup. It draws over the World Progress screen and returns to it when closed. */
final class IntroScreen extends Screen {
    // Animation atlas: FRAMES frames of FRAME_W x FRAME_H stacked vertically.
    static final ResourceLocation FRAMES_TEXTURE = new ResourceLocation(WorldWelcome.ID, "textures/gui/intro_railgun.png");
    static final ResourceLocation RECIPE_TEXTURE = new ResourceLocation(WorldWelcome.ID, "textures/gui/intro_recipe.png");
    static final int FRAMES = IntroMedia.FRAMES;
    static final int FRAME_W = IntroMedia.FRAME_W;
    static final int FRAME_H = IntroMedia.FRAME_H;
    static final int FRAME_MS = IntroMedia.FRAME_MS;
    static final int RECIPE_W = IntroMedia.RECIPE_W;
    static final int RECIPE_H = IntroMedia.RECIPE_H;

    private static final int INK = 0xff151d2b;
    private static final int INSET = 0xff202b3f;
    private static final int LINE = 0xff43506a;
    private static final int GOLD = 0xfff2cc79;
    private static final int TEXT = 0xfff0ebe1;
    private static final int MUTED = 0xffb8c4d6;

    private final ProgressScreen behind;
    private final Runnable onDismiss;
    private final long started = Util.getMillis();
    private int left;
    private int top;
    private int panelWidth;
    private int panelHeight;
    private int mediaTop;
    private int mediaHeight;
    private int gifWidth;
    private int recipeWidth;
    private int recipeHeight;
    private List<FormattedCharSequence> goal;
    private List<FormattedCharSequence> bosses;
    private boolean dismissed;

    IntroScreen(ProgressScreen behind, Runnable onDismiss) {
        super(Component.literal("Michael's Modpack 1.1"));
        this.behind = behind;
        this.onDismiss = onDismiss;
    }

    @Override
    protected void init() {
        if (behind != null) {
            behind.init(minecraft, width, height);
        }
        var texture = minecraft.getTextureManager().getTexture(FRAMES_TEXTURE);
        texture.setFilter(true, false);
        panelWidth = Math.min(420, width - 12);
        panelHeight = Math.min(262, height - 12);
        left = (width - panelWidth) / 2;
        top = (height - panelHeight) / 2;
        int textWidth = panelWidth - 28;
        goal = font.split(Component.literal("The goal of this modpack is to craft the Orbital Railgun.")
                .withStyle(ChatFormatting.YELLOW), textWidth);
        bosses = font.split(bossText(), textWidth);
        mediaTop = top + 26 + goal.size() * 10 + 4;
        int bossesHeight = 12 + bosses.size() * 10;
        int buttonsTop = top + panelHeight - 28;
        mediaHeight = Math.max(30, Math.min(120, buttonsTop - 6 - bossesHeight - 6 - mediaTop));
        int mediaWidth = panelWidth - 28 - 8;
        gifWidth = mediaHeight * FRAME_W / FRAME_H;
        recipeHeight = mediaHeight;
        recipeWidth = mediaHeight * RECIPE_W / RECIPE_H;
        if (gifWidth + recipeWidth > mediaWidth) {
            float shrink = mediaWidth / (float) (gifWidth + recipeWidth);
            gifWidth = (int) (gifWidth * shrink);
            recipeWidth = (int) (recipeWidth * shrink);
            mediaHeight = (int) (mediaHeight * shrink);
            recipeHeight = mediaHeight;
        }
        addRenderableWidget(Button.builder(Component.literal("Got it"), button -> onClose())
                .bounds(width / 2 - 49, buttonsTop + 3, 98, 20).build());
    }

    private static Component bossText() {
        return Component.empty()
                .append(Component.literal("Three bosses must die for its rarest parts:\n").withStyle(ChatFormatting.WHITE))
                .append(Component.literal("• Netherite Monstrosity").withStyle(ChatFormatting.GOLD))
                .append(Component.literal(" (Soul Blacksmith, in the Nether) drops the Monstrous Horn\n").withStyle(ChatFormatting.GRAY))
                .append(Component.literal("• Wither").withStyle(ChatFormatting.AQUA))
                .append(Component.literal(" drops the Nether Star\n").withStyle(ChatFormatting.GRAY))
                .append(Component.literal("• Ender Dragon").withStyle(ChatFormatting.LIGHT_PURPLE))
                .append(Component.literal(" drops the Dragon Heart, every time it dies").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        if (behind != null) {
            // The milestone popup stays visible underneath, dimmed and inert.
            behind.renderPanel(graphics, -1, -1, partialTick);
            graphics.fill(0, 0, width, height, 0xb0000000);
        }
        graphics.pose().pushPose();
        graphics.pose().translate(0, 0, 400);
        graphics.fill(left, top, left + panelWidth, top + panelHeight, GOLD);
        graphics.fill(left + 1, top + 1, left + panelWidth - 1, top + panelHeight - 1, INK);
        graphics.hLine(left + 5, left + panelWidth - 6, top + 3, GOLD);
        graphics.drawCenteredString(font, Component.literal("New in 1.1: the Orbital Railgun"), width / 2, top + 10, GOLD);
        int y = top + 24;
        for (var line : goal) {
            graphics.drawCenteredString(font, line, width / 2, y, TEXT);
            y += 10;
        }
        int mediaLeft = left + (panelWidth - gifWidth - recipeWidth - 8) / 2;
        long frame = ((Util.getMillis() - started) / FRAME_MS) % FRAMES;
        graphics.fill(mediaLeft - 1, mediaTop - 1, mediaLeft + gifWidth + 1, mediaTop + mediaHeight + 1, LINE);
        graphics.blit(FRAMES_TEXTURE, mediaLeft, mediaTop, gifWidth, mediaHeight,
                0, frame * FRAME_H, FRAME_W, FRAME_H, FRAME_W, FRAME_H * FRAMES);
        int recipeLeft = mediaLeft + gifWidth + 8;
        graphics.fill(recipeLeft - 1, mediaTop - 1, recipeLeft + recipeWidth + 1, mediaTop + recipeHeight + 1, LINE);
        graphics.blit(RECIPE_TEXTURE, recipeLeft, mediaTop, recipeWidth, recipeHeight,
                0, 0, RECIPE_W, RECIPE_H, RECIPE_W, RECIPE_H);
        y = mediaTop + mediaHeight + 7;
        graphics.fill(left + 10, y - 2, left + panelWidth - 10, y + 2 + bosses.size() * 10, INSET);
        for (var line : bosses) {
            graphics.drawString(font, line, left + 14, y, MUTED, false);
            y += 10;
        }
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.pose().popPose();
    }

    @Override
    public void onClose() {
        if (!dismissed) {
            dismissed = true;
            onDismiss.run();
        }
        minecraft.setScreen(behind);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
