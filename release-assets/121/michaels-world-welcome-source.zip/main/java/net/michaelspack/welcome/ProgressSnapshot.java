package net.michaelspack.welcome;

import java.util.List;
import net.minecraft.network.chat.Component;

public record ProgressSnapshot(String age, Component railgunStatus, Component milestones, List<Player> players) {
    public record Player(String name, boolean netherBoss, boolean wither, boolean dragon,
                         int mobsKilled, int deaths) {}
}
