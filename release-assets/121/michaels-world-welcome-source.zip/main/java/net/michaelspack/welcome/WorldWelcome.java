package net.michaelspack.welcome;

import java.time.Instant;
import java.time.format.DateTimeParseException;
import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EndPortalFrameBlock;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.player.AdvancementEvent;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

@Mod("michaels_world_welcome")
public final class WorldWelcome {
    public static final String ID = "michaels_world_welcome";
    private static final Logger LOG = LogUtils.getLogger();
    private static final String DATA_KEY = "michaels_world_welcome";
    private final ForgeConfigSpec.ConfigValue<String> createdUtc;

    private static final ResourceLocation RAILGUN = new ResourceLocation("orbital_railgun", "orbital_railgun");
    private static final ResourceLocation MONSTROSITY = new ResourceLocation("cataclysm", "netherite_monstrosity");
    private static final ResourceLocation OLD_MONSTROSITY = new ResourceLocation("cataclysm", "old_netherite_monstrosity");
    /** Players this close to a boss when it dies share the kill. */
    private static final double BOSS_CREDIT_RANGE = 128;
    private boolean tracksProgress;

    public WorldWelcome() {
        ProgressNetwork.register();
        DragonHeart.register(FMLJavaModLoadingContext.get().getModEventBus());
        // The Dragon Heart drop is gameplay, so it also runs in singleplayer.
        MinecraftForge.EVENT_BUS.addListener(this::onEntityLeave);
        MinecraftForge.EVENT_BUS.addListener(CombatBalance::onItemAttributes);
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST, DeathWear::onDeath);
        ForgeConfigSpec.Builder config = new ForgeConfigSpec.Builder();
        createdUtc = config.comment("UTC creation time for an existing world. Leave empty for a new world.")
                .define("createdUtc", "");
        // World Progress runs on the dedicated server. QA can opt a singleplayer install in with a marker file.
        boolean qaProgress = java.nio.file.Files.exists(net.minecraftforge.fml.loading.FMLPaths.CONFIGDIR.get()
                .resolve("michaels_world_welcome-qa-singleplayer-progress.txt"));
        if (FMLEnvironment.dist.isDedicatedServer() || qaProgress) {
            tracksProgress = true;
            ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, config.build());
            MinecraftForge.EVENT_BUS.addListener(this::onServerStarted);
            MinecraftForge.EVENT_BUS.addListener(this::onLogin);
            MinecraftForge.EVENT_BUS.addListener(this::onLogout);
            MinecraftForge.EVENT_BUS.addListener(this::onAdvancement);
            MinecraftForge.EVENT_BUS.addListener(this::onDimensionChange);
            MinecraftForge.EVENT_BUS.addListener(this::onEquipmentChange);
            MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST, this::onPortalFrameUse);
            MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST, this::onLivingDeath);
            MinecraftForge.EVENT_BUS.addListener(this::onItemCrafted);
            MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);
            MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST, this::onPlayerAttacked);
        }
    }

    private WorldProgress progress(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(WorldProgress::load, () -> {
            Instant created = Instant.now();
            if (!createdUtc.get().isBlank()) {
                try {
                    created = Instant.parse(createdUtc.get());
                } catch (DateTimeParseException e) {
                    LOG.warn("World welcome creation time is invalid. Using the time of this startup.");
                }
            }
            return new WorldProgress(created);
        }, DATA_KEY);
    }

    private void onServerStarted(ServerStartedEvent event) {
        MinecraftServer server = event.getServer();
        WorldProgress progress = progress(server);
        progress.importAdvancements(server.getWorldPath(LevelResource.PLAYER_ADVANCEMENTS_DIR), LOG);
        progress.loadStats(server, server.getWorldPath(LevelResource.PLAYER_STATS_DIR), LOG);
        progress.recoverNames(server.getProfileCache());
        updateDragonStatus(server, progress);
        LOG.info("World welcome ready. {}", progress.message(Instant.now()).getString().replace('\n', ' '));
    }

    private void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            MinecraftServer server = player.serverLevel().getServer();
            WorldProgress progress = progress(server);
            progress.rememberName(player.getUUID(), player.getGameProfile().getName());
            progress.visit(player.getUUID(), player.level().dimension());
            recordArmor(player, progress);
            updateDragonStatus(server, progress);
            Instant now = Instant.now();
            JoinGrace.start(player.getUUID());
            player.sendSystemMessage(progress.message(now));
            if (ProgressNetwork.supports(player)) {
                ProgressNetwork.send(player, progress.snapshot(server, now));
            }
        }
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("progress").executes(context -> {
            ServerPlayer player = context.getSource().getPlayerOrException();
            if (ProgressNetwork.supports(player)) {
                ProgressNetwork.send(player, progress(context.getSource().getServer())
                        .snapshot(context.getSource().getServer(), Instant.now()));
            }
            return 1;
        }));
    }

    private void onPlayerAttacked(LivingAttackEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && JoinGrace.active(player.getUUID())
                && !event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            event.setCanceled(true);
        }
    }

    private void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            progress(player.serverLevel().getServer()).rememberStats(player.getUUID(), player.getStats());
            JoinGrace.clear(player.getUUID());
        }
    }

    private void onAdvancement(AdvancementEvent.AdvancementEarnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            progress(player.serverLevel().getServer()).recordAdvancement(player.getUUID(),
                    event.getAdvancement().getId());
        }
    }

    private void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            progress(player.serverLevel().getServer()).visit(player.getUUID(), event.getTo());
        }
    }

    private void onEquipmentChange(LivingEquipmentChangeEvent event) {
        if (event.getSlot().getType() == EquipmentSlot.Type.ARMOR
                && event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            recordArmor(player, progress(player.serverLevel().getServer()));
        }
    }

    private static void recordArmor(ServerPlayer player, WorldProgress progress) {
        boolean netherite = true;
        for (ArmorItem.Type slot : ArmorItem.Type.values()) {
            var item = player.getItemBySlot(slot.getSlot()).getItem();
            if (!(item instanceof ArmorItem armor) || armor.getType() != slot
                    || armor.getDefense() < ArmorMaterials.DIAMOND.getDefenseForType(slot)
                    || armor.getToughness() < ArmorMaterials.DIAMOND.getToughness()) {
                return;
            }
            netherite &= armor.getMaterial() == ArmorMaterials.NETHERITE;
        }
        progress.recordDiamondGear(player.getUUID());
        if (netherite) {
            progress.recordNetheriteGear(player.getUUID());
        }
    }

    private void onPortalFrameUse(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getLevel() instanceof ServerLevel level) || !event.getItemStack().is(Items.ENDER_EYE)) {
            return;
        }
        var pos = event.getPos().immutable();
        var frame = level.getBlockState(pos);
        if (!frame.is(Blocks.END_PORTAL_FRAME) || frame.getValue(EndPortalFrameBlock.HAS_EYE)) {
            return;
        }
        MinecraftServer server = level.getServer();
        WorldProgress progress = progress(server);
        if (progress.hasOpenedPortal()) {
            return;
        }
        // This event precedes item use. Inspect the completed portal after vanilla places it.
        server.tell(new TickTask(server.getTickCount(), () -> {
            if (progress.hasOpenedPortal()) {
                return;
            }
            var pattern = EndPortalFrameBlock.getOrCreatePortalShape().find(level, pos);
            if (pattern != null && level.getBlockState(pattern.getFrontTopLeft().offset(-2, 0, -2)).is(Blocks.END_PORTAL)) {
                progress.recordPortalOpened();
                server.getPlayerList().broadcastSystemMessage(Component.literal("The End portal is open!").withStyle(ChatFormatting.LIGHT_PURPLE), false);
            }
        }));
    }

    private void onEntityLeave(EntityLeaveLevelEvent event) {
        // The Dragon's death animation ends with removal as KILLED; LivingDeathEvent is unreliable for it.
        if (event.getLevel() instanceof ServerLevel level && DragonHeart.isKilledDragon(event.getEntity())) {
            DragonHeart.drop(level, event.getEntity());
            if (tracksProgress) {
                creditBoss(level, event.getEntity(), null, WorldProgress.Boss.ENDER_DRAGON);
            }
        }
    }

    private void onLivingDeath(LivingDeathEvent event) {
        if (!(event.getEntity().level() instanceof ServerLevel level)) {
            return;
        }
        var type = ForgeRegistries.ENTITY_TYPES.getKey(event.getEntity().getType());
        WorldProgress.Boss boss = null;
        if (MONSTROSITY.equals(type) || OLD_MONSTROSITY.equals(type)) {
            boss = WorldProgress.Boss.NETHERITE_MONSTROSITY;
        } else if (event.getEntity().getType() == net.minecraft.world.entity.EntityType.WITHER) {
            boss = WorldProgress.Boss.WITHER;
        }
        if (boss != null) {
            creditBoss(level, event.getEntity(), event.getSource().getEntity(), boss);
        }
    }

    /** Credits the killer and every player fighting nearby, then announces each first-time kill. */
    private void creditBoss(ServerLevel level, Entity boss, Entity killer, WorldProgress.Boss which) {
        MinecraftServer server = level.getServer();
        WorldProgress progress = progress(server);
        var credited = new java.util.LinkedHashSet<ServerPlayer>();
        if (killer instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            credited.add(player);
        }
        for (ServerPlayer player : level.players()) {
            if (!(player instanceof FakePlayer) && !player.isSpectator()
                    && player.distanceToSqr(boss) <= BOSS_CREDIT_RANGE * BOSS_CREDIT_RANGE) {
                credited.add(player);
            }
        }
        var firsts = new java.util.ArrayList<String>();
        for (ServerPlayer player : credited) {
            progress.rememberName(player.getUUID(), player.getGameProfile().getName());
            if (progress.recordBossKill(which, player.getUUID())) {
                firsts.add(player.getGameProfile().getName());
            }
        }
        if (!firsts.isEmpty()) {
            String names = firsts.size() == 1 ? firsts.get(0)
                    : String.join(", ", firsts.subList(0, firsts.size() - 1)) + " and " + firsts.get(firsts.size() - 1);
            server.getPlayerList().broadcastSystemMessage(Component.literal(names + " killed " + which.title + "!")
                    .withStyle(ChatFormatting.GOLD), false);
        }
    }

    private void onItemCrafted(PlayerEvent.ItemCraftedEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)
                && RAILGUN.equals(ForgeRegistries.ITEMS.getKey(event.getCrafting().getItem()))) {
            MinecraftServer server = player.serverLevel().getServer();
            WorldProgress progress = progress(server);
            progress.rememberName(player.getUUID(), player.getGameProfile().getName());
            if (progress.recordRailgunCrafted(player.getUUID())) {
                server.getPlayerList().broadcastSystemMessage(Component.literal(player.getGameProfile().getName()
                        + " crafted the Orbital Railgun! The goal of michael's modpack is complete.")
                        .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), false);
            }
        }
    }

    private static void updateDragonStatus(MinecraftServer server, WorldProgress progress) {
        var end = server.getLevel(Level.END);
        if (end != null && end.getDragonFight() != null && end.getDragonFight().hasPreviouslyKilledDragon()) {
            progress.recordDragonDefeated();
        }
    }
}
