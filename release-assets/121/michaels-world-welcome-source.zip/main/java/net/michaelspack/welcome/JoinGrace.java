package net.michaelspack.welcome;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Short damage immunity after joining, so players can read the milestones. Server thread only. */
final class JoinGrace {
    private static final long READING_NANOS = 8_000_000_000L;
    /** Covers slow loading, and clients that never report in. */
    private static final long LOADING_LIMIT_NANOS = 60_000_000_000L;
    private static final Map<UUID, Long> DEADLINES = new HashMap<>();
    private static final Set<UUID> LOADING = new HashSet<>();

    private JoinGrace() {}

    static void start(UUID player) {
        DEADLINES.put(player, System.nanoTime() + LOADING_LIMIT_NANOS);
        LOADING.add(player);
    }

    /** The popup is open; the reading time starts now. Only the first report after a join counts. */
    static void popupOpened(UUID player) {
        if (LOADING.remove(player)) {
            DEADLINES.put(player, System.nanoTime() + READING_NANOS);
        }
    }

    static boolean active(UUID player) {
        Long deadline = DEADLINES.get(player);
        if (deadline == null) {
            return false;
        }
        if (System.nanoTime() - deadline >= 0) {
            clear(player);
            return false;
        }
        return true;
    }

    static void clear(UUID player) {
        DEADLINES.remove(player);
        LOADING.remove(player);
    }
}
