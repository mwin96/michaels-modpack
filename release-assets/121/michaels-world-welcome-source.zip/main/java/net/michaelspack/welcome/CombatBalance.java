package net.michaelspack.welcome;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.ItemAttributeModifierEvent;
import net.minecraftforge.registries.ForgeRegistries;

/** Applies the pack's melee damage table, keeping each weapon's normal tooltip line. */
final class CombatBalance {
    /** Vanilla's base weapon modifier id. Reusing it keeps damage on the item's green tooltip line. */
    private static final UUID BASE_ATTACK_DAMAGE = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");
    private static final Map<ResourceLocation, Double> BONUS = load();

    private CombatBalance() {}

    private static Map<ResourceLocation, Double> load() {
        Map<ResourceLocation, Double> bonus = new HashMap<>();
        try (InputStream stream = CombatBalance.class.getResourceAsStream("melee.properties")) {
            for (String line : new String(stream.readAllBytes(), StandardCharsets.UTF_8).split("\n")) {
                int split = line.indexOf('=');
                if (split > 0) {
                    bonus.put(new ResourceLocation(line.substring(0, split).trim()), Double.parseDouble(line.substring(split + 1).trim()));
                }
            }
        } catch (IOException e) {
            throw new IllegalStateException("Missing melee table", e);
        }
        return bonus;
    }

    static void onItemAttributes(ItemAttributeModifierEvent event) {
        if (event.getSlotType() != EquipmentSlot.MAINHAND) {
            return;
        }
        Double bonus = BONUS.get(ForgeRegistries.ITEMS.getKey(event.getItemStack().getItem()));
        if (bonus == null) {
            return;
        }
        double base = 0;
        for (AttributeModifier modifier : event.getOriginalModifiers().get(Attributes.ATTACK_DAMAGE)) {
            if (BASE_ATTACK_DAMAGE.equals(modifier.getId())) {
                base = modifier.getAmount();
                event.removeModifier(Attributes.ATTACK_DAMAGE, modifier);
            }
        }
        event.addModifier(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE, "Weapon modifier",
                base + bonus, AttributeModifier.Operation.ADDITION));
    }
}
