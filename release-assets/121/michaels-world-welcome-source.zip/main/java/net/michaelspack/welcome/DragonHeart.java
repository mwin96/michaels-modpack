package net.michaelspack.welcome;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.EndPodiumFeature;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The Ender Dragon's guaranteed drop. One appears on the exit portal pillar every time the Dragon dies. */
final class DragonHeart {
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, WorldWelcome.ID);
    static final RegistryObject<Item> ITEM = ITEMS.register("dragon_heart", () -> new Item(
            new Item.Properties().stacksTo(16).rarity(Rarity.EPIC).fireResistant()) {
        @Override
        public boolean isFoil(ItemStack stack) {
            return true;
        }

        @Override
        public void appendHoverText(ItemStack stack, Level level, List<Component> lines, TooltipFlag flag) {
            lines.add(Component.literal("Dropped every time the Ender Dragon dies.").withStyle(ChatFormatting.GRAY));
            lines.add(Component.literal("Used to craft the Orbital Railgun.").withStyle(ChatFormatting.DARK_PURPLE));
        }
    });

    private DragonHeart() {}

    static void register(IEventBus modBus) {
        ITEMS.register(modBus);
        modBus.addListener(DragonHeart::addToCreativeTab);
    }

    private static void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ITEM);
        }
    }

    static boolean isKilledDragon(Entity entity) {
        return entity.getType() == EntityType.ENDER_DRAGON && entity.getRemovalReason() == Entity.RemovalReason.KILLED;
    }

    /** Places the heart on top of the exit portal's bedrock pillar, where the Dragon Egg appears. */
    static void drop(ServerLevel level, Entity dragon) {
        BlockPos center = level.dimension() == Level.END
                ? level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, EndPodiumFeature.getLocation(BlockPos.ZERO))
                : dragon.blockPosition();
        var heart = new ItemEntity(level, center.getX() + 0.5, center.getY() + 0.25, center.getZ() + 0.5,
                new ItemStack(ITEM.get()), 0, 0.2, 0);
        heart.setUnlimitedLifetime();
        heart.setInvulnerable(true);
        heart.setGlowingTag(true);
        level.addFreshEntity(heart);
    }
}
