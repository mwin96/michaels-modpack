package net.michaelspack.welcome.client;

/** Sizes of the packaged 1.1 intro images. Generated alongside the textures. */
final class IntroMedia {
    static final int FRAMES = 54;
    static final int FRAME_W = 256;
    static final int FRAME_H = 144;
    static final int FRAME_MS = 125;
    static final int RECIPE_W = 250;
    static final int RECIPE_H = 112;

    private IntroMedia() {}
}
