package net.michaelspack.welcome.client;

import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.michaelspack.welcome.WorldWelcome;

/** Thunder normally carries for thousands of blocks. Here it fades out over about 128, near lightning you can see. */
@Mod.EventBusSubscriber(modid = WorldWelcome.ID, value = Dist.CLIENT)
public final class ThunderRange {
    private static final ResourceLocation THUNDER = SoundEvents.LIGHTNING_BOLT_THUNDER.getLocation();
    private static final float RANGE_VOLUME = 8f;
    private static final RandomSource RANDOM = RandomSource.create();

    private ThunderRange() {}

    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        var sound = event.getSound();
        if (sound != null && THUNDER.equals(sound.getLocation())) {
            event.setSound(new SimpleSoundInstance(SoundEvents.LIGHTNING_BOLT_THUNDER, sound.getSource(), RANGE_VOLUME,
                    0.8f + RANDOM.nextFloat() * 0.2f, RANDOM, sound.getX(), sound.getY(), sound.getZ()));
        }
    }
}
