package net.michaelspack.welcome.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.michaelspack.welcome.ProgressNetwork;
import net.michaelspack.welcome.ProgressSnapshot;
import net.michaelspack.welcome.WorldWelcome;

@Mod.EventBusSubscriber(modid = WorldWelcome.ID, value = Dist.CLIENT)
public final class ProgressClient {
    /** How long to wait for a World Progress snapshot before showing the 1.1 intro on its own. */
    private static final int INTRO_WAIT_TICKS = 60;
    private static ProgressSnapshot pending;
    private static int ticksInWorld;
    private static boolean introHandled;
    private static boolean popupReported;

    private ProgressClient() {}

    public static void receive(ProgressSnapshot snapshot) {
        pending = snapshot;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        var game = Minecraft.getInstance();
        if (event.phase != TickEvent.Phase.END || game.level == null || game.player == null) {
            return;
        }
        ticksInWorld++;
        if (game.screen != null || game.getOverlay() != null) {
            return;
        }
        if (pending != null) {
            var snapshot = pending;
            pending = null;
            var progress = new ProgressScreen(snapshot);
            game.setScreen(introNeeded(game) ? intro(game, progress) : progress);
            if (!popupReported) {
                popupReported = true;
                ProgressNetwork.reportPopupOpened();
            }
        } else if (ticksInWorld >= INTRO_WAIT_TICKS && introNeeded(game)) {
            // Singleplayer, or a server without World Progress: show the intro by itself.
            game.setScreen(intro(game, null));
        }
    }

    private static boolean introNeeded(Minecraft game) {
        return !introHandled && !IntroReceipt.hasSeen(game.player.getUUID());
    }

    private static IntroScreen intro(Minecraft game, ProgressScreen behind) {
        introHandled = true;
        var player = game.player.getUUID();
        return new IntroScreen(behind, () -> IntroReceipt.markSeen(player));
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        pending = null;
        ticksInWorld = 0;
        introHandled = false;
        popupReported = false;
    }
}
