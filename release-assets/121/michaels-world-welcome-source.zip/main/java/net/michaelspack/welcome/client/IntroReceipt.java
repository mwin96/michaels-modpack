package net.michaelspack.welcome.client;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import com.mojang.logging.LogUtils;
import net.minecraftforge.fml.loading.FMLPaths;

/**
 * Remembers, per Minecraft account on this install, that the 1.1 goal popup was dismissed.
 * The file is local only and is not managed by the pack updater.
 */
final class IntroReceipt {
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("michaels_world_welcome-intro-1.1.txt");
    private static Set<UUID> seen;

    private IntroReceipt() {}

    static synchronized boolean hasSeen(UUID player) {
        return load().contains(player);
    }

    static synchronized void markSeen(UUID player) {
        if (load().add(player)) {
            var text = new StringBuilder("# Accounts that have closed the 1.1 goal popup on this install.\n");
            seen.forEach(id -> text.append(id).append('\n'));
            try {
                Files.writeString(FILE, text, StandardCharsets.UTF_8);
            } catch (IOException e) {
                LogUtils.getLogger().warn("Could not save the 1.1 goal popup receipt.", e);
            }
        }
    }

    private static Set<UUID> load() {
        if (seen == null) {
            seen = new HashSet<>();
            try {
                if (Files.exists(FILE)) {
                    for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                        try {
                            if (!line.isBlank() && !line.startsWith("#")) {
                                seen.add(UUID.fromString(line.trim()));
                            }
                        } catch (IllegalArgumentException ignored) {
                            // Skip a damaged line and keep the rest.
                        }
                    }
                }
            } catch (IOException e) {
                LogUtils.getLogger().warn("Could not read the 1.1 goal popup receipt.", e);
            }
        }
        return seen;
    }
}
