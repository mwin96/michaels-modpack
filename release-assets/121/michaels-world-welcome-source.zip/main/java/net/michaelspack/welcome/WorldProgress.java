package net.michaelspack.welcome;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.players.GameProfileCache;
import net.minecraft.stats.ServerStatsCounter;
import net.minecraft.stats.Stats;
import net.minecraft.stats.StatsCounter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import org.slf4j.Logger;

final class WorldProgress extends SavedData {
    private static final String NETHERITE_ARMOR = "minecraft:nether/netherite_armor";
    private static final String NETHER_FORTRESS = "minecraft:nether/find_fortress";
    private static final String KILL_DRAGON = "minecraft:end/kill_dragon";
    private static final String OBTAIN_IRON_ARMOR = "minecraft:story/obtain_armor";
    private static final String ENCHANT_ITEM = "minecraft:story/enchant_item";
    private static final String KILL_MONSTROSITY = "cataclysm:kill_monstrosity";
    private static final String PLAYER_JSON = "[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\\.json";
    private final Instant created;
    private final Set<UUID> diamondGear = new HashSet<>();
    private final Set<UUID> ironGear = new HashSet<>();
    private final Set<UUID> enchantedAtTable = new HashSet<>();
    private final Set<UUID> netheriteGear = new HashSet<>();
    private final Set<UUID> fortress = new HashSet<>();
    private final Set<UUID> dragonSlayers = new HashSet<>();
    private final Set<UUID> nether = new HashSet<>();
    private final Set<UUID> end = new HashSet<>();
    private final Set<UUID> monstrositySlayers = new HashSet<>();
    private final Set<UUID> witherSlayers = new HashSet<>();
    private final Set<UUID> railgunCrafters = new HashSet<>();
    private final List<Set<UUID>> rankedMilestones = List.of(monstrositySlayers, witherSlayers, dragonSlayers);
    private UUID firstRailgunCrafter;
    private final Map<UUID, String> playerNames = new HashMap<>();
    private final Map<UUID, CombatStats> offlineStats = new HashMap<>();
    private boolean dragonDefeated;
    private boolean portalOpened;
    private boolean imported;
    private boolean importedExpandedMilestones;
    private boolean importedStarterMilestones;
    private boolean importedBossMilestones;

    WorldProgress(Instant created) {
        this.created = created;
    }

    static WorldProgress load(CompoundTag tag) {
        WorldProgress data = new WorldProgress(Instant.ofEpochMilli(tag.getLong("created")));
        readPlayers(tag.getList("diamondGear", Tag.TAG_INT_ARRAY), data.diamondGear);
        readPlayers(tag.getList("ironGear", Tag.TAG_INT_ARRAY), data.ironGear);
        readPlayers(tag.getList("enchantedAtTable", Tag.TAG_INT_ARRAY), data.enchantedAtTable);
        readPlayers(tag.getList("netheriteGear", Tag.TAG_INT_ARRAY), data.netheriteGear);
        readPlayers(tag.getList("fortress", Tag.TAG_INT_ARRAY), data.fortress);
        readPlayers(tag.getList("dragonSlayers", Tag.TAG_INT_ARRAY), data.dragonSlayers);
        readPlayers(tag.getList("nether", Tag.TAG_INT_ARRAY), data.nether);
        readPlayers(tag.getList("end", Tag.TAG_INT_ARRAY), data.end);
        readPlayers(tag.getList("monstrositySlayers", Tag.TAG_INT_ARRAY), data.monstrositySlayers);
        readPlayers(tag.getList("witherSlayers", Tag.TAG_INT_ARRAY), data.witherSlayers);
        readPlayers(tag.getList("railgunCrafters", Tag.TAG_INT_ARRAY), data.railgunCrafters);
        if (tag.hasUUID("firstRailgunCrafter")) {
            data.firstRailgunCrafter = tag.getUUID("firstRailgunCrafter");
        }
        var names = tag.getCompound("playerNames");
        for (String id : names.getAllKeys()) {
            data.playerNames.put(UUID.fromString(id), names.getString(id));
        }
        data.dragonDefeated = tag.getBoolean("dragonDefeated");
        if (tag.contains("portalOpened", Tag.TAG_BYTE)) {
            data.portalOpened = tag.getBoolean("portalOpened");
        } else if (!data.end.isEmpty() || data.dragonDefeated) {
            data.recordPortalOpened();
        }
        data.imported = tag.getBoolean("imported");
        data.importedExpandedMilestones = tag.getBoolean("importedExpandedMilestones");
        data.importedStarterMilestones = tag.getBoolean("importedStarterMilestones");
        data.importedBossMilestones = tag.getBoolean("importedBossMilestones");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("created", created.toEpochMilli());
        tag.put("diamondGear", writePlayers(diamondGear));
        tag.put("ironGear", writePlayers(ironGear));
        tag.put("enchantedAtTable", writePlayers(enchantedAtTable));
        tag.put("netheriteGear", writePlayers(netheriteGear));
        tag.put("fortress", writePlayers(fortress));
        tag.put("dragonSlayers", writePlayers(dragonSlayers));
        tag.put("nether", writePlayers(nether));
        tag.put("end", writePlayers(end));
        tag.put("monstrositySlayers", writePlayers(monstrositySlayers));
        tag.put("witherSlayers", writePlayers(witherSlayers));
        tag.put("railgunCrafters", writePlayers(railgunCrafters));
        if (firstRailgunCrafter != null) {
            tag.putUUID("firstRailgunCrafter", firstRailgunCrafter);
        }
        var names = new CompoundTag();
        playerNames.forEach((id, name) -> names.putString(id.toString(), name));
        tag.put("playerNames", names);
        tag.putBoolean("dragonDefeated", dragonDefeated);
        tag.putBoolean("portalOpened", portalOpened);
        tag.putBoolean("imported", imported);
        tag.putBoolean("importedExpandedMilestones", importedExpandedMilestones);
        tag.putBoolean("importedStarterMilestones", importedStarterMilestones);
        tag.putBoolean("importedBossMilestones", importedBossMilestones);
        return tag;
    }

    void visit(UUID player, ResourceKey<Level> dimension) {
        if ((dimension.equals(Level.NETHER) && nether.add(player))
                || (dimension.equals(Level.END) && end.add(player))) {
            setDirty();
        }
    }

    void recordDragonDefeated() {
        if (!dragonDefeated) {
            dragonDefeated = true;
            setDirty();
        }
    }

    void recordDiamondGear(UUID player) {
        if (diamondGear.add(player)) {
            setDirty();
        }
    }

    void recordAdvancement(UUID player, ResourceLocation advancement) {
        switch (advancement.toString()) {
            case NETHERITE_ARMOR -> recordNetheriteGear(player);
            case NETHER_FORTRESS -> recordFortress(player);
            case KILL_DRAGON -> recordDragonSlayer(player);
            case OBTAIN_IRON_ARMOR -> recordMilestone(ironGear, player);
            case ENCHANT_ITEM -> recordMilestone(enchantedAtTable, player);
            case KILL_MONSTROSITY -> recordMilestone(monstrositySlayers, player);
        }
    }

    private void recordMilestone(Set<UUID> milestone, UUID player) {
        if (milestone.add(player)) {
            setDirty();
        }
    }

    void recordNetheriteGear(UUID player) {
        if (netheriteGear.add(player)) {
            setDirty();
        }
    }

    private void recordFortress(UUID player) {
        if (fortress.add(player)) {
            setDirty();
        }
    }

    enum Boss {
        NETHERITE_MONSTROSITY("the Netherite Monstrosity"),
        WITHER("the Wither"),
        ENDER_DRAGON("the Ender Dragon");

        final String title;

        Boss(String title) {
            this.title = title;
        }
    }

    /** Returns true when this player is credited with the boss for the first time. */
    boolean recordBossKill(Boss boss, UUID player) {
        return switch (boss) {
            case NETHERITE_MONSTROSITY -> addTo(monstrositySlayers, player);
            case WITHER -> addTo(witherSlayers, player);
            case ENDER_DRAGON -> {
                boolean added = addTo(dragonSlayers, player);
                visit(player, Level.END);
                recordDragonDefeated();
                yield added;
            }
        };
    }

    private boolean addTo(Set<UUID> players, UUID player) {
        boolean added = players.add(player);
        if (added) {
            setDirty();
        }
        return added;
    }

    /** Returns true when this is the first Orbital Railgun crafted in this world. */
    boolean recordRailgunCrafted(UUID player) {
        addTo(railgunCrafters, player);
        if (firstRailgunCrafter == null) {
            firstRailgunCrafter = player;
            setDirty();
            return true;
        }
        return false;
    }

    private void recordDragonSlayer(UUID player) {
        if (dragonSlayers.add(player)) {
            setDirty();
        }
        visit(player, Level.END);
        recordDragonDefeated();
    }

    void rememberStats(UUID player, StatsCounter stats) {
        offlineStats.put(player, CombatStats.read(stats));
    }

    void loadStats(MinecraftServer server, Path directory, Logger log) {
        if (!Files.isDirectory(directory)) {
            return;
        }
        try (var entries = Files.newDirectoryStream(directory, "*.json")) {
            for (Path file : entries) {
                UUID player = playerFromFilename(file);
                if (player != null) {
                    rememberPlayer(player);
                    var stats = new ServerStatsCounter(server, file.toFile());
                    rememberStats(player, stats);
                }
            }
        } catch (IOException e) {
            log.warn("World welcome could not read the saved player statistics directory.", e);
        }
    }

    private void rememberPlayer(UUID player) {
        if (playerNames.putIfAbsent(player, "") == null) {
            setDirty();
        }
    }

    void rememberName(UUID id, String name) {
        if (name != null && !name.equals(playerNames.put(id, name))) {
            setDirty();
        }
    }

    void recoverNames(GameProfileCache cache) {
        var tracked = new HashSet<>(playerNames.keySet());
        tracked.addAll(diamondGear);
        tracked.addAll(ironGear);
        tracked.addAll(enchantedAtTable);
        tracked.addAll(netheriteGear);
        tracked.addAll(fortress);
        tracked.addAll(dragonSlayers);
        tracked.addAll(nether);
        tracked.addAll(end);
        tracked.addAll(monstrositySlayers);
        tracked.addAll(witherSlayers);
        tracked.addAll(railgunCrafters);
        for (UUID id : tracked) {
            rememberPlayer(id);
            if (playerNames.get(id).isBlank()) {
                cache.get(id).ifPresent(profile -> rememberName(id, profile.getName()));
            }
        }
    }

    boolean hasOpenedPortal() {
        return portalOpened;
    }

    void recordPortalOpened() {
        portalOpened = true;
        setDirty();
    }

    void importAdvancements(Path directory, Logger log) {
        if (importedExpandedMilestones && importedStarterMilestones && importedBossMilestones) {
            return;
        }
        boolean complete = true;
        if (Files.exists(directory)) {
            try (var entries = Files.newDirectoryStream(directory, "*.json")) {
                for (Path file : entries) {
                    UUID player = playerFromFilename(file);
                    if (player == null) {
                        continue;
                    }
                    try (var reader = Files.newBufferedReader(file)) {
                        JsonObject history = JsonParser.parseReader(reader).getAsJsonObject();
                        rememberPlayer(player);
                        if (completed(history, NETHERITE_ARMOR)) {
                            recordNetheriteGear(player);
                        }
                        if (completed(history, NETHER_FORTRESS)) {
                            recordFortress(player);
                        }
                        if (completed(history, "minecraft:story/enter_the_nether") || completed(history, "minecraft:nether/root")) {
                            visit(player, Level.NETHER);
                        }
                        if (completed(history, "minecraft:story/enter_the_end") || completed(history, "minecraft:end/root")) {
                            visit(player, Level.END);
                        }
                        if (completed(history, KILL_DRAGON)) {
                            recordDragonSlayer(player);
                        }
                        if (completed(history, OBTAIN_IRON_ARMOR)) {
                            recordMilestone(ironGear, player);
                        }
                        if (completed(history, ENCHANT_ITEM)) {
                            recordMilestone(enchantedAtTable, player);
                        }
                        if (completed(history, KILL_MONSTROSITY)) {
                            recordMilestone(monstrositySlayers, player);
                        }
                    } catch (IOException | JsonParseException | IllegalStateException e) {
                        complete = false;
                        log.warn("World welcome could not read one saved player advancement file.", e);
                    }
                }
            } catch (IOException e) {
                complete = false;
                log.warn("World welcome could not read the saved advancement directory.", e);
            }
        }
        if (!end.isEmpty()) {
            recordPortalOpened();
        }
        imported = complete;
        importedExpandedMilestones = complete;
        importedStarterMilestones = complete;
        importedBossMilestones = complete;
        setDirty();
    }

    Component message(Instant now) {
        return Component.empty()
                .append(Component.literal("Welcome to michael's modpack! This world is " + age(now) + " old.\n").withStyle(ChatFormatting.GOLD))
                .append(Component.literal("Type /progress to see the milestones.").withStyle(ChatFormatting.YELLOW));
    }

    ProgressSnapshot snapshot(MinecraftServer server, Instant now) {
        var rows = playerNames.entrySet().stream()
                .map(entry -> {
                    UUID player = entry.getKey();
                    var online = server.getPlayerList().getPlayer(player);
                    var stats = online == null ? offlineStats.getOrDefault(player, CombatStats.EMPTY)
                            : CombatStats.read(online.getStats());
                    String name = entry.getValue().isBlank() ? "Unknown player" : entry.getValue();
                    var row = new ProgressSnapshot.Player(name, monstrositySlayers.contains(player),
                            witherSlayers.contains(player), dragonSlayers.contains(player), stats.mobsKilled(), stats.deaths());
                    long completed = rankedMilestones.stream().filter(milestone -> milestone.contains(player)).count();
                    return new RankedPlayer(player, completed, row);
                })
                .sorted(Comparator.comparingLong(RankedPlayer::completed).reversed()
                        .thenComparing(Comparator.comparingInt((RankedPlayer rank) -> rank.row().mobsKilled()).reversed())
                        .thenComparing(rank -> rank.row().name(), String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(RankedPlayer::id))
                .map(RankedPlayer::row).toList();
        long deaths = rows.stream().mapToLong(ProgressSnapshot.Player::deaths).sum();
        long mobs = rows.stream().mapToLong(ProgressSnapshot.Player::mobsKilled).sum();
        return new ProgressSnapshot(age(now), railgunStatus(), panelMilestones(mobs, deaths), rows);
    }

    private record RankedPlayer(UUID id, long completed, ProgressSnapshot.Player row) {}

    private record CombatStats(int mobsKilled, int deaths) {
        private static final CombatStats EMPTY = new CombatStats(0, 0);

        private static CombatStats read(StatsCounter stats) {
            return new CombatStats(stats.getValue(Stats.CUSTOM.get(Stats.MOB_KILLS)),
                    stats.getValue(Stats.CUSTOM.get(Stats.DEATHS)));
        }
    }

    private String age(Instant now) {
        long days = Math.max(0, Duration.between(created, now).toDays());
        return days == 0 ? "less than a day" : days == 1 ? "1 day" : days + " days";
    }

    Component railgunStatus() {
        if (firstRailgunCrafter == null) {
            return Component.literal("No one has crafted the Orbital Railgun yet").withStyle(ChatFormatting.GRAY);
        }
        String name = playerNames.getOrDefault(firstRailgunCrafter, "");
        return Component.literal((name.isBlank() ? "A player" : name) + " crafted the Orbital Railgun!")
                .withStyle(ChatFormatting.GREEN);
    }

    String displayName(UUID player) {
        String name = playerNames.getOrDefault(player, "");
        return name.isBlank() ? "A player" : name;
    }

    private Component panelMilestones(long mobs, long deaths) {
        return Component.empty()
                .append(Component.literal(bossMilestone(monstrositySlayers, Boss.NETHERITE_MONSTROSITY) + "\n").withStyle(ChatFormatting.GOLD))
                .append(Component.literal(bossMilestone(witherSlayers, Boss.WITHER) + "\n").withStyle(ChatFormatting.AQUA))
                .append(Component.literal(bossMilestone(dragonSlayers, Boss.ENDER_DRAGON) + "\n").withStyle(ChatFormatting.LIGHT_PURPLE))
                .append(Component.literal(mobs + (mobs == 1 ? " total mob killed." : " total mobs killed.") + "\n").withStyle(ChatFormatting.WHITE))
                .append(Component.literal(deaths + (deaths == 1 ? " total player death." : " total player deaths.")).withStyle(ChatFormatting.GRAY));
    }

    private String bossMilestone(Set<UUID> players, Boss boss) {
        if (players.isEmpty()) {
            return "No one has killed " + boss.title + " yet.";
        }
        String sentence = milestone(players, "killed " + boss.title);
        return sentence.replace(" has killed ", " killed ").replace(" have killed ", " killed ");
    }

    private String milestone(Set<UUID> players, String achievement) {
        if (players.isEmpty()) {
            return "No one has " + achievement + ".";
        }
        var names = new ArrayList<>(players.stream().map(playerNames::get).filter(Objects::nonNull)
                .filter(name -> !name.isBlank())
                .sorted(String.CASE_INSENSITIVE_ORDER).toList());
        int unknown = players.size() - names.size();
        if (unknown > 0) {
            names.add(unknown + (names.isEmpty() ? " " : " other ") + (unknown == 1 ? "player" : "players"));
        }
        int last = names.size() - 1;
        String subject = last == 0 ? names.get(0) : String.join(", ", names.subList(0, last)) + " and " + names.get(last);
        return subject + (players.size() == 1 ? " has " : " have ") + achievement + ".";
    }

    private static UUID playerFromFilename(Path file) {
        String name = file.getFileName().toString();
        return name.matches(PLAYER_JSON) ? UUID.fromString(name.substring(0, 36)) : null;
    }

    private static boolean completed(JsonObject history, String key) {
        var entry = history.get(key);
        if (entry == null || !entry.isJsonObject()) {
            return false;
        }
        var done = entry.getAsJsonObject().get("done");
        return done != null && done.isJsonPrimitive() && done.getAsBoolean();
    }

    private static void readPlayers(ListTag list, Set<UUID> players) {
        for (Tag tag : list) {
            players.add(NbtUtils.loadUUID(tag));
        }
    }

    private static ListTag writePlayers(Set<UUID> players) {
        ListTag list = new ListTag();
        for (UUID player : players) {
            list.add(NbtUtils.createUUID(player));
        }
        return list;
    }
}
