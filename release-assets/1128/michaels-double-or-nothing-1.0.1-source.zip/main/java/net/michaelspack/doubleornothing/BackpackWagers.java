package net.michaelspack.doubleornothing;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.p3pp3rf1y.sophisticatedbackpacks.api.CapabilityBackpackWrapper;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.BackpackItem;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.BackpackStorage;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.BackpackWrapper;
import net.p3pp3rf1y.sophisticatedbackpacks.backpack.wrapper.IBackpackWrapper;
import net.p3pp3rf1y.sophisticatedcore.linkedstorage.LinkedStorageEndpointStackState;
import net.p3pp3rf1y.sophisticatedcore.linkedstorage.LinkedStorageStackLifecycle;

import java.util.Optional;

/** Sophisticated Backpacks keeps the actual inventory outside the item. */
final class BackpackWagers {
    private BackpackWagers() {}

    static Optional<Boolean> blocked(ItemStack stack, ServerLevel level) {
        if (!(stack.getItem() instanceof BackpackItem)) {
            return Optional.empty();
        }
        var tag = stack.getTag();
        if (tag == null) {
            return Optional.of(false);
        }
        if (LinkedStorageStackLifecycle.classifyEndpoint(stack) == LinkedStorageEndpointStackState.ENDPOINT) {
            return Optional.of(true);
        }
        String key = BackpackWrapper.CONTENTS_UUID_TAG;
        return Optional.of(tag.hasUUID(key) && BackpackStorage.get(level).getBackpackContents(tag.getUUID(key))
                .map(WagerStorage::containsItems).orElse(false));
    }

    static ItemStack copy(ItemStack stack) {
        var tag = stack.getTag();
        if (!(stack.getItem() instanceof BackpackItem) || tag == null || !tag.hasUUID(BackpackWrapper.CONTENTS_UUID_TAG)) {
            return stack.copy();
        }
        return stack.getCapability(CapabilityBackpackWrapper.getCapabilityInstance())
                .map(IBackpackWrapper::cloneBackpack)
                .orElseGet(stack::copy);
    }
}
