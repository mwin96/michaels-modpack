package net.michaelspack.doubleornothing;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.List;

@Mod(DoubleOrNothing.ID)
public final class DoubleOrNothing {
    public static final String ID = "michaels_double_or_nothing";
    static final String TITLE = "item." + ID + ".double_or_nothing";
    static final int MAX_FLIPS = 5;
    private static final String FLIPS_USED = "FlipsUsed";

    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    private static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, ID);

    static final RegistryObject<Item> GADGET = ITEMS.register("double_or_nothing", Gadget::new);
    static final RegistryObject<MenuType<DoubleMenu>> MENU = MENUS.register("double_or_nothing",
            () -> new MenuType<>(DoubleMenu::new, FeatureFlags.DEFAULT_FLAGS));

    public DoubleOrNothing(FMLJavaModLoadingContext context) {
        ITEMS.register(context.getModEventBus());
        MENUS.register(context.getModEventBus());
        MinecraftForge.EVENT_BUS.addListener(this::onLogin);
    }

    private void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            giveStarter(player);
        }
    }

    static void giveStarter(ServerPlayer player) {
        if (!state(player).getBoolean("receivedStarter")) {
            player.getInventory().placeItemBackInInventory(new ItemStack(GADGET.get()), false);
            state(player).putBoolean("receivedStarter", true);
        }
    }

    static CompoundTag state(Player player) {
        // Forge carries PlayerPersisted across respawns as well as saving it to player data.
        CompoundTag data = player.getPersistentData();
        if (!data.contains(Player.PERSISTED_NBT_TAG, Tag.TAG_COMPOUND)) {
            data.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        }
        CompoundTag persisted = data.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains(ID, Tag.TAG_COMPOUND)) {
            persisted.put(ID, new CompoundTag());
        }
        return persisted.getCompound(ID);
    }

    static ResourceLocation id(String path) {
        return new ResourceLocation(ID, path);
    }

    static int flipsLeft(ItemStack stack) {
        if (!stack.is(GADGET.get())) {
            return 0;
        }
        CompoundTag tag = stack.getTag();
        return MAX_FLIPS - (tag == null ? 0 : Mth.clamp(tag.getInt(FLIPS_USED), 0, MAX_FLIPS));
    }

    static void spendFlip(ItemStack stack) {
        int left = flipsLeft(stack);
        if (left == 1) {
            stack.shrink(1);
        } else {
            stack.getOrCreateTag().putInt(FLIPS_USED, MAX_FLIPS - left + 1);
        }
    }

    private static final class Gadget extends Item {
        private Gadget() {
            super(new Item.Properties().stacksTo(1));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (player instanceof ServerPlayer serverPlayer) {
                serverPlayer.openMenu(new SimpleMenuProvider(DoubleMenu::new, Component.translatable(TITLE)));
            }
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }

        @Override
        public void appendHoverText(ItemStack stack, Level level, List<Component> lines, TooltipFlag flags) {
            lines.add(Component.translatable("screen." + ID + ".open"));
            lines.add(Component.translatable("screen." + ID + ".flips", flipsLeft(stack), MAX_FLIPS));
        }

        @Override
        public boolean isBarVisible(ItemStack stack) {
            return flipsLeft(stack) < MAX_FLIPS;
        }

        @Override
        public int getBarWidth(ItemStack stack) {
            return Math.round(13F * flipsLeft(stack) / MAX_FLIPS);
        }

        @Override
        public int getBarColor(ItemStack stack) {
            return Mth.hsvToRgb(flipsLeft(stack) / (3F * MAX_FLIPS), 1F, 1F);
        }
    }
}
