package net.michaelspack.doubleornothing;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Locale;
import java.util.Set;

final class WagerStorage {
    private static final Set<String> ITEM_LISTS = Set.of("items", "inventory", "contents", "upgrades");
    private static final ResourceLocation AMMO_BOX = new ResourceLocation("tacz", "ammo_box");
    private static final ResourceLocation SEED_POUCH = new ResourceLocation("quark", "seed_pouch");

    private WagerStorage() {}

    static boolean blocked(ItemStack stack, ServerPlayer player) {
        CompoundTag tag = stack.getTag();
        if (tag != null && (containsItems(tag) || containsCountedItems(stack, tag))) {
            return true;
        }
        if (ModList.get().isLoaded("sophisticatedbackpacks")) {
            var backpack = BackpackWagers.blocked(stack, player.serverLevel());
            if (backpack.isPresent()) {
                return backpack.get();
            }
        }
        return stack.getCapability(ForgeCapabilities.ITEM_HANDLER).map(WagerStorage::hasItems).orElse(false);
    }

    private static boolean containsCountedItems(ItemStack stack, CompoundTag tag) {
        ResourceLocation item = ForgeRegistries.ITEMS.getKey(stack.getItem());
        if (AMMO_BOX.equals(item)) {
            return tag.getInt("AmmoCount") > 0 || tag.getBoolean("Creative") || tag.getBoolean("AllTypeCreative");
        }
        return SEED_POUCH.equals(item) && tag.getInt("itemCount") > 0;
    }

    static ItemStack duplicate(ItemStack stack) {
        return ModList.get().isLoaded("sophisticatedbackpacks") ? BackpackWagers.copy(stack) : stack.copy();
    }

    static boolean containsItems(CompoundTag data) {
        if (data == null) {
            return false;
        }
        if (!data.getString("LootTable").isEmpty() || !data.getString("lootTableName").isEmpty()) {
            return true;
        }
        for (String key : data.getAllKeys()) {
            Tag value = data.get(key);
            if (value instanceof CompoundTag compound && containsItems(compound)) {
                return true;
            }
            if (value instanceof ListTag list && ITEM_LISTS.contains(key.toLowerCase(Locale.ROOT))) {
                for (Tag entry : list) {
                    if (entry instanceof CompoundTag item && item.contains("id", Tag.TAG_STRING)
                            && !item.getString("id").equals("minecraft:air") && item.getInt("Count") > 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean hasItems(IItemHandler handler) {
        for (int slot = 0; slot < handler.getSlots(); slot++) {
            if (!handler.getStackInSlot(slot).isEmpty()) {
                return true;
            }
        }
        return false;
    }
}
