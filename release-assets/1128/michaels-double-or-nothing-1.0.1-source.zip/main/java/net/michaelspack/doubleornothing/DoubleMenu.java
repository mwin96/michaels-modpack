package net.michaelspack.doubleornothing;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

final class DoubleMenu extends AbstractContainerMenu {
    static final int FLIP = 0;
    static final int WIN_PERCENT = 49;
    static final int WIN = 1;
    static final int LOSE = 2;
    static final int NO_ROOM = 3;
    static final int STORAGE_BLOCKED = 4;

    private final SimpleContainer wager = new SimpleContainer(1);
    private final DataSlot result = addDataSlot(DataSlot.standalone());
    private final DataSlot charges = addDataSlot(DataSlot.standalone());
    private final Player owner;

    DoubleMenu(int id, Inventory inventory) {
        this(id, inventory, inventory.player);
    }

    DoubleMenu(int id, Inventory inventory, Player player) {
        super(DoubleOrNothing.MENU.get(), id);
        owner = player;
        if (owner instanceof ServerPlayer) {
            CompoundTag state = DoubleOrNothing.state(owner);
            wager.setItem(0, ItemStack.of(state.getCompound("wager")));
            // Keep the stake with the player if saving or disconnecting with the menu open.
            wager.addListener(container -> saveWager(state));
            charges.set(DoubleOrNothing.flipsLeft(heldGadget()));
        }
        addSlot(new Slot(wager, 0, 39, 62) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                if (owner instanceof ServerPlayer server && WagerStorage.blocked(stack, server)) {
                    setResult(STORAGE_BLOCKED);
                    return false;
                }
                return !stack.is(DoubleOrNothing.GADGET.get());
            }
        });
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, 52 + col * 18, 144 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 52 + col * 18, 202));
        }
    }

    ItemStack stake() {
        return wager.getItem(0);
    }

    int result() {
        return result.get();
    }

    static int outcome(int result) {
        return result & 7;
    }

    int charges() {
        return charges.get();
    }

    private ItemStack heldGadget() {
        ItemStack main = owner.getMainHandItem();
        return DoubleOrNothing.flipsLeft(main) > 0 ? main : owner.getOffhandItem();
    }

    @Override
    public void broadcastChanges() {
        if (owner instanceof ServerPlayer) {
            charges.set(DoubleOrNothing.flipsLeft(heldGadget()));
        }
        super.broadcastChanges();
    }

    private void saveWager(CompoundTag state) {
        if (stake().isEmpty()) {
            state.remove("wager");
        } else {
            state.put("wager", stake().save(new CompoundTag()));
            if (outcome(result()) == STORAGE_BLOCKED) {
                setResult(0);
            }
        }
    }

    @Override
    public boolean clickMenuButton(Player player, int button) {
        if (button != FLIP || player != owner || !(player instanceof ServerPlayer server)
                || stake().isEmpty() || stake().is(DoubleOrNothing.GADGET.get())) {
            return false;
        }
        ItemStack gadget = heldGadget();
        if (DoubleOrNothing.flipsLeft(gadget) == 0) {
            return false;
        }
        if (WagerStorage.blocked(stake(), server)) {
            setResult(STORAGE_BLOCKED);
            return true;
        }
        ItemStack bet = stake().copy();
        Inventory inventory = player.getInventory();
        if (!canFit(inventory, bet, 2)) {
            setResult(NO_ROOM);
            return true;
        }

        boolean won = player.getRandom().nextInt(100) < WIN_PERCENT;
        ItemStack duplicate = won ? WagerStorage.duplicate(bet) : ItemStack.EMPTY;
        DoubleOrNothing.spendFlip(gadget);
        charges.set(DoubleOrNothing.flipsLeft(heldGadget()));
        wager.setItem(0, ItemStack.EMPTY);
        if (won) {
            inventory.placeItemBackInInventory(duplicate, false);
            inventory.placeItemBackInInventory(bet, false);
        }
        setResult(won ? WIN : LOSE);
        return true;
    }

    private static boolean canFit(Inventory inventory, ItemStack bet, int copies) {
        int needed = bet.getCount() * copies;
        int stackLimit = Math.min(inventory.getMaxStackSize(), bet.getMaxStackSize());
        for (ItemStack slot : inventory.items) {
            if (slot.isEmpty()) {
                needed -= stackLimit;
            } else if (slot.isStackable() && ItemStack.isSameItemSameTags(slot, bet)) {
                needed -= Math.max(0, stackLimit - slot.getCount());
            }
            if (needed <= 0) {
                return true;
            }
        }
        return false;
    }

    private void setResult(int value) {
        // Keep the update within the signed short carried by the vanilla menu protocol.
        int sequence = ((result.get() >> 3) + 1) & 0xfff;
        result.set((sequence << 3) | value);
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        if (player instanceof ServerPlayer && player.isAlive() && !stake().isEmpty()
                && canFit(player.getInventory(), stake(), 1)) {
            player.getInventory().placeItemBackInInventory(stake().copy(), false);
            wager.setItem(0, ItemStack.EMPTY);
        }
    }

    @Override
    public boolean stillValid(Player player) {
        return player == owner;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int slotIndex) {
        Slot slot = slots.get(slotIndex);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack source = slot.getItem();
        ItemStack original = source.copy();
        if (slotIndex == 0 ? !moveItemStackTo(source, 1, slots.size(), true) : !moveItemStackTo(source, 0, 1, false)) {
            return ItemStack.EMPTY;
        }
        if (source.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        slot.onTake(player, source);
        return original;
    }
}
