package net.michaelspack.doubleornothing;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import org.anti_ad.mc.ipn.api.IPNIgnore;

@IPNIgnore
@Mod.EventBusSubscriber(modid = DoubleOrNothing.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class DoubleScreen extends AbstractContainerScreen<DoubleMenu> {
    private static final ResourceLocation WHEEL = DoubleOrNothing.id("textures/gui/wheel.png");
    private static final int GOLD = 0xffe9c679;
    private static final int TEXT = 0xfff1e9d7;
    private static final int SUBTLE = 0xffa8b5c7;
    private static final int RED = 0xffec9b9d;
    private static final int INK = 0xff141c2b;
    private static final int FRAME = 0xff4c5166;
    private static final int SPIN_MILLIS = 900;

    private Button flip;
    private ItemStack lastBet = ItemStack.EMPTY;
    private int lastResult;
    private long spinStarted = -SPIN_MILLIS;

    public DoubleScreen(DoubleMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 264;
        imageHeight = 226;
    }

    @SubscribeEvent
    public static void registerScreen(FMLClientSetupEvent event) {
        event.enqueueWork(() -> MenuScreens.register(DoubleOrNothing.MENU.get(), DoubleScreen::new));
    }

    @Override
    protected void init() {
        super.init();
        Component close = label("close");
        addRenderableWidget(new CloseButton(Button.builder(close, button -> onClose())
                .bounds(leftPos + imageWidth - 22, topPos + 6, 16, 16)
                .tooltip(Tooltip.create(close))));
        flip = addRenderableWidget(new FlipButton(Button.builder(label("flip"), button -> {
            lastBet = menu.stake().copy();
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, DoubleMenu.FLIP);
        }).bounds(leftPos + 82, topPos + 111, 100, 19)));
        updateButton();
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        int result = menu.result();
        if (result != lastResult) {
            lastResult = result;
            if (outcome() == DoubleMenu.WIN || outcome() == DoubleMenu.LOSE) {
                spinStarted = Util.getMillis();
            }
        }
        updateButton();
    }

    private void updateButton() {
        flip.active = !menu.stake().isEmpty() && menu.charges() > 0 && !spinning();
    }

    private boolean spinning() {
        return Util.getMillis() - spinStarted < SPIN_MILLIS;
    }

    private int outcome() {
        return DoubleMenu.outcome(lastResult);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        graphics.fill(x, y, x + imageWidth, y + imageHeight, FRAME);
        graphics.fill(x + 1, y + 1, x + imageWidth - 1, y + imageHeight - 1, INK);
        graphics.hLine(x + 6, x + imageWidth - 7, y + 3, GOLD);
        graphics.hLine(x + 10, x + imageWidth - 11, y + 24, FRAME);
        graphics.fill(x + 13, y + 35, x + 82, y + 103, 0xff202a3e);
        graphics.fill(x + 182, y + 35, x + 251, y + 103, 0xff202a3e);
        RenderSystem.enableBlend();
        graphics.blit(WHEEL, x + 90, y + 26, 0, 0, 84, 84, 84, 84);
        RenderSystem.disableBlend();

        slot(graphics, x + 38, y + 61);
        slot(graphics, x + 207, y + 61);
        for (int i = 1; i < menu.slots.size(); i++) {
            var slot = menu.slots.get(i);
            slot(graphics, x + slot.x - 1, y + slot.y - 1);
        }

        if (outcome() == DoubleMenu.WIN || outcome() == DoubleMenu.LOSE) {
            float progress = Mth.clamp((Util.getMillis() - spinStarted) / (float) SPIN_MILLIS, 0, 1);
            double end = outcome() == DoubleMenu.WIN ? Math.PI * 0.49 : Math.PI * 1.49;
            double angle = (Math.PI * 6 + end) * (1 - Math.pow(1 - progress, 3));
            int pointerX = x + 132 + (int) Math.round(37 * Math.sin(angle));
            int pointerY = y + 68 - (int) Math.round(37 * Math.cos(angle));
            graphics.fill(pointerX - 3, pointerY - 3, pointerX + 4, pointerY + 4, INK);
            graphics.fill(pointerX - 2, pointerY - 2, pointerX + 3, pointerY + 3, TEXT);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawCenteredString(font, title, 132, 10, GOLD);
        graphics.drawCenteredString(font, label("wager"), 47, 44, TEXT);
        graphics.drawCenteredString(font, label("win"), 216, 44, TEXT);
        graphics.drawCenteredString(font, label("flips", menu.charges(), DoubleOrNothing.MAX_FLIPS), 47, 86, SUBTLE);
        graphics.drawCenteredString(font, label("win_chance", DoubleMenu.WIN_PERCENT), 132, 58, GOLD);
        graphics.drawCenteredString(font, label("lose_chance", 100 - DoubleMenu.WIN_PERCENT), 132, 71, RED);

        ItemStack preview = menu.stake().isEmpty() && spinning() ? lastBet : menu.stake();
        if (!preview.isEmpty()) {
            graphics.renderItem(preview, 208, 62);
            graphics.drawCenteredString(font, label("amount", preview.getCount() * 2), 216, 86, GOLD);
        }
        Component status = label("drag");
        int color = SUBTLE;
        if (spinning()) {
            status = label("spinning");
        } else if (outcome() == DoubleMenu.STORAGE_BLOCKED) {
            status = label("storage_blocked");
            color = RED;
        } else if (outcome() == DoubleMenu.NO_ROOM && !menu.stake().isEmpty()) {
            status = label("no_room");
            color = RED;
        } else if (menu.stake().isEmpty() && outcome() == DoubleMenu.WIN) {
            status = label("won");
            color = GOLD;
        } else if (menu.stake().isEmpty() && outcome() == DoubleMenu.LOSE) {
            status = label("lost");
            color = RED;
        } else if (menu.charges() == 0) {
            status = label("hold");
            color = RED;
        } else if (!menu.stake().isEmpty()) {
            status = label("ready");
        }
        graphics.drawCenteredString(font, status, 132, 133, color);
    }

    private static void slot(GuiGraphics graphics, int x, int y) {
        graphics.fill(x, y, x + 18, y + 18, FRAME);
        graphics.fill(x + 1, y + 1, x + 17, y + 17, 0xff0e1522);
    }

    private static Component label(String key, Object... args) {
        return Component.translatable("screen." + DoubleOrNothing.ID + "." + key, args);
    }

    private final class CloseButton extends Button {
        private CloseButton(Button.Builder builder) {
            super(builder);
        }

        @Override
        protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            int x = getX();
            int y = getY();
            boolean highlighted = isHoveredOrFocused();
            graphics.fill(x, y, x + width, y + height, highlighted ? GOLD : FRAME);
            graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, 0xff202a3e);
            graphics.drawCenteredString(font, "×", x + width / 2, y + 4, highlighted ? GOLD : TEXT);
        }
    }

    private final class FlipButton extends Button {
        private FlipButton(Button.Builder builder) {
            super(builder);
        }

        @Override
        protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
            int x = getX();
            int y = getY();
            graphics.fill(x, y, x + width, y + height, active ? GOLD : FRAME);
            int fill = !active ? 0xff2b3447 : isHoveredOrFocused() ? 0xfff8dda0 : 0xffdcb667;
            graphics.fill(x + 1, y + 1, x + width - 1, y + height - 2, fill);
            graphics.drawString(font, getMessage(), x + (width - font.width(getMessage())) / 2,
                    y + (height - 8) / 2, active ? INK : SUBTLE, false);
        }
    }
}
