#if !defined THE_END && !defined NETHER
    float fogIntensityCoeff = max(eyeBrightSmoothFloat.y * 0.004166666666666667, visibleSky);
    frogAdjust = pow(
        clamp(gl_FogFragCoord / dhRenderDistance, 0.0, 1.0) * fogIntensityCoeff,
        mix(fogDensityCoeff * 0.15, 0.5, rainStrength)
    );
    // Michael's Modpack: subtle distance haze using the existing fog gradient.
    // No near-view, dark-cave, underwater, Nether, End or sky-layer change.
    if(isEyeInWater == 0 && gl_FogFragCoord > 64.0) {
        float michaelsHorizonHaze = smoothstep(64.0, 192.0, gl_FogFragCoord) * 0.35 * clamp(fogIntensityCoeff, 0.0, 1.0);
        frogAdjust = mix(frogAdjust, 1.0, michaelsHorizonHaze);
    }
#else
    frogAdjust = sqrt(clamp(gl_FogFragCoord / dhRenderDistance, 0.0, 1.0));
#endif