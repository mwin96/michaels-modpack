package net.michaelspack.welcome;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.players.GameProfileCache;
import net.minecraft.stats.ServerStatsCounter;
import net.minecraft.stats.Stats;
import net.minecraft.stats.StatsCounter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import org.slf4j.Logger;

final class WorldProgress extends SavedData {
    private static final String NETHERITE_ARMOR = "minecraft:nether/netherite_armor";
    private static final String NETHER_FORTRESS = "minecraft:nether/find_fortress";
    private static final String KILL_DRAGON = "minecraft:end/kill_dragon";
    private static final String OBTAIN_IRON_ARMOR = "minecraft:story/obtain_armor";
    private static final String ENCHANT_ITEM = "minecraft:story/enchant_item";
    private static final String PLAYER_JSON = "[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\\.json";
    private final Instant created;
    private final Set<UUID> diamondGear = new HashSet<>();
    private final Set<UUID> ironGear = new HashSet<>();
    private final Set<UUID> enchantedAtTable = new HashSet<>();
    private final Set<UUID> netheriteGear = new HashSet<>();
    private final Set<UUID> fortress = new HashSet<>();
    private final Set<UUID> dragonSlayers = new HashSet<>();
    private final Set<UUID> nether = new HashSet<>();
    private final Set<UUID> end = new HashSet<>();
    private final Map<UUID, String> playerNames = new HashMap<>();
    private final Map<UUID, CombatStats> offlineStats = new HashMap<>();
    private boolean dragonDefeated;
    private boolean portalOpened;
    private boolean imported;
    private boolean importedExpandedMilestones;
    private boolean importedStarterMilestones;

    WorldProgress(Instant created) {
        this.created = created;
    }

    static WorldProgress load(CompoundTag tag) {
        WorldProgress data = new WorldProgress(Instant.ofEpochMilli(tag.getLong("created")));
        readPlayers(tag.getList("diamondGear", Tag.TAG_INT_ARRAY), data.diamondGear);
        readPlayers(tag.getList("ironGear", Tag.TAG_INT_ARRAY), data.ironGear);
        readPlayers(tag.getList("enchantedAtTable", Tag.TAG_INT_ARRAY), data.enchantedAtTable);
        readPlayers(tag.getList("netheriteGear", Tag.TAG_INT_ARRAY), data.netheriteGear);
        readPlayers(tag.getList("fortress", Tag.TAG_INT_ARRAY), data.fortress);
        readPlayers(tag.getList("dragonSlayers", Tag.TAG_INT_ARRAY), data.dragonSlayers);
        readPlayers(tag.getList("nether", Tag.TAG_INT_ARRAY), data.nether);
        readPlayers(tag.getList("end", Tag.TAG_INT_ARRAY), data.end);
        var names = tag.getCompound("playerNames");
        for (String id : names.getAllKeys()) {
            data.playerNames.put(UUID.fromString(id), names.getString(id));
        }
        data.dragonDefeated = tag.getBoolean("dragonDefeated");
        if (tag.contains("portalOpened", Tag.TAG_BYTE)) {
            data.portalOpened = tag.getBoolean("portalOpened");
        } else if (!data.end.isEmpty() || data.dragonDefeated) {
            data.recordPortalOpened();
        }
        data.imported = tag.getBoolean("imported");
        data.importedExpandedMilestones = tag.getBoolean("importedExpandedMilestones");
        data.importedStarterMilestones = tag.getBoolean("importedStarterMilestones");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putLong("created", created.toEpochMilli());
        tag.put("diamondGear", writePlayers(diamondGear));
        tag.put("ironGear", writePlayers(ironGear));
        tag.put("enchantedAtTable", writePlayers(enchantedAtTable));
        tag.put("netheriteGear", writePlayers(netheriteGear));
        tag.put("fortress", writePlayers(fortress));
        tag.put("dragonSlayers", writePlayers(dragonSlayers));
        tag.put("nether", writePlayers(nether));
        tag.put("end", writePlayers(end));
        var names = new CompoundTag();
        playerNames.forEach((id, name) -> names.putString(id.toString(), name));
        tag.put("playerNames", names);
        tag.putBoolean("dragonDefeated", dragonDefeated);
        tag.putBoolean("portalOpened", portalOpened);
        tag.putBoolean("imported", imported);
        tag.putBoolean("importedExpandedMilestones", importedExpandedMilestones);
        tag.putBoolean("importedStarterMilestones", importedStarterMilestones);
        return tag;
    }

    void visit(UUID player, ResourceKey<Level> dimension) {
        if ((dimension.equals(Level.NETHER) && nether.add(player))
                || (dimension.equals(Level.END) && end.add(player))) {
            setDirty();
        }
    }

    void recordDragonDefeated() {
        if (!dragonDefeated) {
            dragonDefeated = true;
            setDirty();
        }
    }

    void recordDiamondGear(UUID player) {
        if (diamondGear.add(player)) {
            setDirty();
        }
    }

    void recordAdvancement(UUID player, ResourceLocation advancement) {
        switch (advancement.toString()) {
            case NETHERITE_ARMOR -> recordNetheriteGear(player);
            case NETHER_FORTRESS -> recordFortress(player);
            case KILL_DRAGON -> recordDragonSlayer(player);
            case OBTAIN_IRON_ARMOR -> recordMilestone(ironGear, player);
            case ENCHANT_ITEM -> recordMilestone(enchantedAtTable, player);
        }
    }

    private void recordMilestone(Set<UUID> milestone, UUID player) {
        if (milestone.add(player)) {
            setDirty();
        }
    }

    void recordNetheriteGear(UUID player) {
        if (netheriteGear.add(player)) {
            setDirty();
        }
    }

    private void recordFortress(UUID player) {
        if (fortress.add(player)) {
            setDirty();
        }
    }

    private void recordDragonSlayer(UUID player) {
        if (dragonSlayers.add(player)) {
            setDirty();
        }
        visit(player, Level.END);
        recordDragonDefeated();
    }

    void rememberStats(UUID player, StatsCounter stats) {
        offlineStats.put(player, CombatStats.read(stats));
    }

    void loadStats(MinecraftServer server, Path directory, Logger log) {
        if (!Files.isDirectory(directory)) {
            return;
        }
        try (var entries = Files.newDirectoryStream(directory, "*.json")) {
            for (Path file : entries) {
                UUID player = playerFromFilename(file);
                if (player != null) {
                    rememberPlayer(player);
                    var stats = new ServerStatsCounter(server, file.toFile());
                    rememberStats(player, stats);
                }
            }
        } catch (IOException e) {
            log.warn("World welcome could not read the saved player statistics directory.", e);
        }
    }

    private void rememberPlayer(UUID player) {
        if (playerNames.putIfAbsent(player, "") == null) {
            setDirty();
        }
    }

    void rememberName(UUID id, String name) {
        if (name != null && !name.equals(playerNames.put(id, name))) {
            setDirty();
        }
    }

    void recoverNames(GameProfileCache cache) {
        var tracked = new HashSet<>(playerNames.keySet());
        tracked.addAll(diamondGear);
        tracked.addAll(ironGear);
        tracked.addAll(enchantedAtTable);
        tracked.addAll(netheriteGear);
        tracked.addAll(fortress);
        tracked.addAll(dragonSlayers);
        tracked.addAll(nether);
        tracked.addAll(end);
        for (UUID id : tracked) {
            rememberPlayer(id);
            if (playerNames.get(id).isBlank()) {
                cache.get(id).ifPresent(profile -> rememberName(id, profile.getName()));
            }
        }
    }

    boolean hasOpenedPortal() {
        return portalOpened;
    }

    void recordPortalOpened() {
        portalOpened = true;
        setDirty();
    }

    void importAdvancements(Path directory, Logger log) {
        if (importedExpandedMilestones && importedStarterMilestones) {
            return;
        }
        boolean complete = true;
        if (Files.exists(directory)) {
            try (var entries = Files.newDirectoryStream(directory, "*.json")) {
                for (Path file : entries) {
                    UUID player = playerFromFilename(file);
                    if (player == null) {
                        continue;
                    }
                    try (var reader = Files.newBufferedReader(file)) {
                        JsonObject history = JsonParser.parseReader(reader).getAsJsonObject();
                        rememberPlayer(player);
                        if (completed(history, NETHERITE_ARMOR)) {
                            recordNetheriteGear(player);
                        }
                        if (completed(history, NETHER_FORTRESS)) {
                            recordFortress(player);
                        }
                        if (completed(history, "minecraft:story/enter_the_nether") || completed(history, "minecraft:nether/root")) {
                            visit(player, Level.NETHER);
                        }
                        if (completed(history, "minecraft:story/enter_the_end") || completed(history, "minecraft:end/root")) {
                            visit(player, Level.END);
                        }
                        if (completed(history, KILL_DRAGON)) {
                            recordDragonSlayer(player);
                        }
                        if (completed(history, OBTAIN_IRON_ARMOR)) {
                            recordMilestone(ironGear, player);
                        }
                        if (completed(history, ENCHANT_ITEM)) {
                            recordMilestone(enchantedAtTable, player);
                        }
                    } catch (IOException | JsonParseException | IllegalStateException e) {
                        complete = false;
                        log.warn("World welcome could not read one saved player advancement file.", e);
                    }
                }
            } catch (IOException e) {
                complete = false;
                log.warn("World welcome could not read the saved advancement directory.", e);
            }
        }
        if (!end.isEmpty()) {
            recordPortalOpened();
        }
        imported = complete;
        importedExpandedMilestones = complete;
        importedStarterMilestones = complete;
        setDirty();
    }

    Component message(Instant now) {
        return Component.empty()
                .append(Component.literal("Welcome to michael's modpack! This world is " + age(now) + " old.\n").withStyle(ChatFormatting.GOLD))
                .append(milestones());
    }

    ProgressSnapshot snapshot(MinecraftServer server, Instant now) {
        var rows = playerNames.entrySet().stream()
                .sorted(Map.Entry.<UUID, String>comparingByValue(String.CASE_INSENSITIVE_ORDER)
                        .thenComparing(Map.Entry::getKey))
                .map(entry -> {
                    UUID player = entry.getKey();
                    var online = server.getPlayerList().getPlayer(player);
                    var stats = online == null ? offlineStats.getOrDefault(player, CombatStats.EMPTY)
                            : CombatStats.read(online.getStats());
                    String name = entry.getValue().isBlank() ? "Unknown player" : entry.getValue();
                    return new ProgressSnapshot.Player(name, diamondGear.contains(player), nether.contains(player),
                            netheriteGear.contains(player), end.contains(player), stats.mobsKilled(), stats.deaths());
                }).toList();
        long deaths = rows.stream().mapToLong(ProgressSnapshot.Player::deaths).sum();
        return new ProgressSnapshot(age(now), dragonStatus(), panelMilestones(deaths), rows);
    }

    private record CombatStats(int mobsKilled, int deaths) {
        private static final CombatStats EMPTY = new CombatStats(0, 0);

        private static CombatStats read(StatsCounter stats) {
            return new CombatStats(stats.getValue(Stats.CUSTOM.get(Stats.MOB_KILLS)),
                    stats.getValue(Stats.CUSTOM.get(Stats.DEATHS)));
        }
    }

    private String age(Instant now) {
        long days = Math.max(0, Duration.between(created, now).toDays());
        return days == 0 ? "less than a day" : days == 1 ? "1 day" : days + " days";
    }

    private Component milestones() {
        String armor = milestone(diamondGear, "equipped full diamond armor or better");
        return Component.empty()
                .append(Component.literal(armor + "\n").withStyle(ChatFormatting.AQUA))
                .append(Component.literal(milestone(nether, "reached the Nether") + "\n").withStyle(ChatFormatting.YELLOW))
                .append(Component.literal(milestone(end, "reached the End") + "\n").withStyle(ChatFormatting.LIGHT_PURPLE))
                .append(dragonStatus());
    }

    private Component dragonStatus() {
        return Component.literal(dragonDefeated ? "The Ender Dragon has been defeated." : "The Ender Dragon is still alive.")
                .withStyle(dragonDefeated ? ChatFormatting.GREEN : ChatFormatting.GRAY);
    }

    private Component panelMilestones(long deaths) {
        return Component.empty()
                .append(Component.literal(milestone(ironGear, "obtained a piece of iron armor") + "\n").withStyle(ChatFormatting.GRAY))
                .append(Component.literal(milestone(enchantedAtTable, "enchanted an item at a table") + "\n").withStyle(ChatFormatting.WHITE))
                .append(Component.literal(milestone(diamondGear, "equipped full diamond armor or better") + "\n").withStyle(ChatFormatting.AQUA))
                .append(Component.literal(milestone(netheriteGear, "obtained full netherite armor") + "\n").withStyle(ChatFormatting.GRAY))
                .append(Component.literal(milestone(nether, "reached the Nether") + "\n").withStyle(ChatFormatting.YELLOW))
                .append(Component.literal(milestone(fortress, "found a Nether fortress") + "\n").withStyle(ChatFormatting.GOLD))
                .append(Component.literal(milestone(end, "reached the End") + "\n").withStyle(ChatFormatting.LIGHT_PURPLE))
                .append(Component.literal(deaths + (deaths == 1 ? " total player death." : " total player deaths.")).withStyle(ChatFormatting.GRAY));
    }

    private String milestone(Set<UUID> players, String achievement) {
        if (players.isEmpty()) {
            return "No one has " + achievement + ".";
        }
        var names = new ArrayList<>(players.stream().map(playerNames::get).filter(Objects::nonNull)
                .filter(name -> !name.isBlank())
                .sorted(String.CASE_INSENSITIVE_ORDER).toList());
        int unknown = players.size() - names.size();
        if (unknown > 0) {
            names.add(unknown + (names.isEmpty() ? " " : " other ") + (unknown == 1 ? "player" : "players"));
        }
        int last = names.size() - 1;
        String subject = last == 0 ? names.get(0) : String.join(", ", names.subList(0, last)) + " and " + names.get(last);
        return subject + (players.size() == 1 ? " has " : " have ") + achievement + ".";
    }

    private static UUID playerFromFilename(Path file) {
        String name = file.getFileName().toString();
        return name.matches(PLAYER_JSON) ? UUID.fromString(name.substring(0, 36)) : null;
    }

    private static boolean completed(JsonObject history, String key) {
        var entry = history.get(key);
        if (entry == null || !entry.isJsonObject()) {
            return false;
        }
        var done = entry.getAsJsonObject().get("done");
        return done != null && done.isJsonPrimitive() && done.getAsBoolean();
    }

    private static void readPlayers(ListTag list, Set<UUID> players) {
        for (Tag tag : list) {
            players.add(NbtUtils.loadUUID(tag));
        }
    }

    private static ListTag writePlayers(Set<UUID> players) {
        ListTag list = new ListTag();
        for (UUID player : players) {
            list.add(NbtUtils.createUUID(player));
        }
        return list;
    }
}
