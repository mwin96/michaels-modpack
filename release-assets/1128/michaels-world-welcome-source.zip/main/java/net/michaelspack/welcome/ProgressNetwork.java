package net.michaelspack.welcome;

import io.netty.handler.codec.DecoderException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import net.michaelspack.welcome.client.ProgressClient;

final class ProgressNetwork {
    private static final String VERSION = "5";
    private static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(WorldWelcome.ID, "progress"), () -> VERSION,
            NetworkRegistry.acceptMissingOr(VERSION), NetworkRegistry.acceptMissingOr(VERSION));

    private ProgressNetwork() {}

    static void register() {
        CHANNEL.registerMessage(0, ProgressSnapshot.class, ProgressNetwork::encode, ProgressNetwork::decode,
                ProgressNetwork::receive, Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    static boolean supports(ServerPlayer player) {
        return CHANNEL.isRemotePresent(player.connection.connection);
    }

    static void send(ServerPlayer player, ProgressSnapshot snapshot) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), snapshot);
    }

    private static void encode(ProgressSnapshot snapshot, FriendlyByteBuf buffer) {
        buffer.writeUtf(snapshot.age(), 32);
        buffer.writeComponent(snapshot.dragonStatus());
        buffer.writeComponent(snapshot.milestones());
        buffer.writeCollection(snapshot.players(), (buf, row) -> {
            buf.writeUtf(row.name(), 16);
            buf.writeBoolean(row.diamondArmor());
            buf.writeBoolean(row.nether());
            buf.writeBoolean(row.netheriteArmor());
            buf.writeBoolean(row.end());
            buf.writeVarInt(row.mobsKilled());
            buf.writeVarInt(row.deaths());
        });
    }

    private static ProgressSnapshot decode(FriendlyByteBuf buffer) {
        var age = buffer.readUtf(32);
        var dragon = buffer.readComponent();
        var milestones = buffer.readComponent();
        int count = buffer.readVarInt();
        if (count < 0 || count > buffer.readableBytes() / 7) {
            throw new DecoderException("Invalid world progress roster size");
        }
        var players = new ArrayList<ProgressSnapshot.Player>(count);
        for (int i = 0; i < count; i++) {
            players.add(new ProgressSnapshot.Player(buffer.readUtf(16), buffer.readBoolean(),
                    buffer.readBoolean(), buffer.readBoolean(), buffer.readBoolean(),
                    buffer.readVarInt(), buffer.readVarInt()));
        }
        return new ProgressSnapshot(age, dragon, milestones, List.copyOf(players));
    }

    private static void receive(ProgressSnapshot snapshot, Supplier<NetworkEvent.Context> supplier) {
        var context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ProgressClient.receive(snapshot)));
        context.setPacketHandled(true);
    }
}
