package net.michaelspack.welcome;

import java.time.Instant;
import java.time.format.DateTimeParseException;
import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EndPortalFrameBlock;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.event.entity.player.AdvancementEvent;
import net.minecraftforge.event.entity.living.LivingEquipmentChangeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;

@Mod("michaels_world_welcome")
public final class WorldWelcome {
    public static final String ID = "michaels_world_welcome";
    private static final Logger LOG = LogUtils.getLogger();
    private static final String DATA_KEY = "michaels_world_welcome";
    private final ForgeConfigSpec.ConfigValue<String> createdUtc;

    public WorldWelcome() {
        ProgressNetwork.register();
        ForgeConfigSpec.Builder config = new ForgeConfigSpec.Builder();
        createdUtc = config.comment("UTC creation time for an existing world. Leave empty for a new world.")
                .define("createdUtc", "");
        if (FMLEnvironment.dist.isDedicatedServer()) {
            ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, config.build());
            MinecraftForge.EVENT_BUS.addListener(this::onServerStarted);
            MinecraftForge.EVENT_BUS.addListener(this::onLogin);
            MinecraftForge.EVENT_BUS.addListener(this::onLogout);
            MinecraftForge.EVENT_BUS.addListener(this::onAdvancement);
            MinecraftForge.EVENT_BUS.addListener(this::onDimensionChange);
            MinecraftForge.EVENT_BUS.addListener(this::onEquipmentChange);
            MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST, this::onPortalFrameUse);
        }
    }

    private WorldProgress progress(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(WorldProgress::load, () -> {
            Instant created = Instant.now();
            if (!createdUtc.get().isBlank()) {
                try {
                    created = Instant.parse(createdUtc.get());
                } catch (DateTimeParseException e) {
                    LOG.warn("World welcome creation time is invalid. Using the time of this startup.");
                }
            }
            return new WorldProgress(created);
        }, DATA_KEY);
    }

    private void onServerStarted(ServerStartedEvent event) {
        MinecraftServer server = event.getServer();
        WorldProgress progress = progress(server);
        progress.importAdvancements(server.getWorldPath(LevelResource.PLAYER_ADVANCEMENTS_DIR), LOG);
        progress.loadStats(server, server.getWorldPath(LevelResource.PLAYER_STATS_DIR), LOG);
        progress.recoverNames(server.getProfileCache());
        updateDragonStatus(server, progress);
        LOG.info("World welcome ready. {}", progress.message(Instant.now()).getString().replace('\n', ' '));
    }

    private void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            MinecraftServer server = player.serverLevel().getServer();
            WorldProgress progress = progress(server);
            progress.rememberName(player.getUUID(), player.getGameProfile().getName());
            progress.visit(player.getUUID(), player.level().dimension());
            recordArmor(player, progress);
            updateDragonStatus(server, progress);
            Instant now = Instant.now();
            player.sendSystemMessage(progress.message(now));
            if (ProgressNetwork.supports(player)) {
                ProgressNetwork.send(player, progress.snapshot(server, now));
            }
        }
    }

    private void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            progress(player.serverLevel().getServer()).rememberStats(player.getUUID(), player.getStats());
        }
    }

    private void onAdvancement(AdvancementEvent.AdvancementEarnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            progress(player.serverLevel().getServer()).recordAdvancement(player.getUUID(),
                    event.getAdvancement().getId());
        }
    }

    private void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            progress(player.serverLevel().getServer()).visit(player.getUUID(), event.getTo());
        }
    }

    private void onEquipmentChange(LivingEquipmentChangeEvent event) {
        if (event.getSlot().getType() == EquipmentSlot.Type.ARMOR
                && event.getEntity() instanceof ServerPlayer player && !(player instanceof FakePlayer)) {
            recordArmor(player, progress(player.serverLevel().getServer()));
        }
    }

    private static void recordArmor(ServerPlayer player, WorldProgress progress) {
        boolean netherite = true;
        for (ArmorItem.Type slot : ArmorItem.Type.values()) {
            var item = player.getItemBySlot(slot.getSlot()).getItem();
            if (!(item instanceof ArmorItem armor) || armor.getType() != slot
                    || armor.getDefense() < ArmorMaterials.DIAMOND.getDefenseForType(slot)
                    || armor.getToughness() < ArmorMaterials.DIAMOND.getToughness()) {
                return;
            }
            netherite &= armor.getMaterial() == ArmorMaterials.NETHERITE;
        }
        progress.recordDiamondGear(player.getUUID());
        if (netherite) {
            progress.recordNetheriteGear(player.getUUID());
        }
    }

    private void onPortalFrameUse(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getLevel() instanceof ServerLevel level) || !event.getItemStack().is(Items.ENDER_EYE)) {
            return;
        }
        var pos = event.getPos().immutable();
        var frame = level.getBlockState(pos);
        if (!frame.is(Blocks.END_PORTAL_FRAME) || frame.getValue(EndPortalFrameBlock.HAS_EYE)) {
            return;
        }
        MinecraftServer server = level.getServer();
        WorldProgress progress = progress(server);
        if (progress.hasOpenedPortal()) {
            return;
        }
        // This event precedes item use. Inspect the completed portal after vanilla places it.
        server.tell(new TickTask(server.getTickCount(), () -> {
            if (progress.hasOpenedPortal()) {
                return;
            }
            var pattern = EndPortalFrameBlock.getOrCreatePortalShape().find(level, pos);
            if (pattern != null && level.getBlockState(pattern.getFrontTopLeft().offset(-2, 0, -2)).is(Blocks.END_PORTAL)) {
                progress.recordPortalOpened();
                server.getPlayerList().broadcastSystemMessage(Component.literal("The End portal is open!").withStyle(ChatFormatting.LIGHT_PURPLE), false);
            }
        }));
    }

    private static void updateDragonStatus(MinecraftServer server, WorldProgress progress) {
        var end = server.getLevel(Level.END);
        if (end != null && end.getDragonFight() != null && end.getDragonFight().hasPreviouslyKilledDragon()) {
            progress.recordDragonDefeated();
        }
    }
}
