package net.michaelspack.welcome;

import java.util.List;
import net.minecraft.network.chat.Component;

public record ProgressSnapshot(String age, Component dragonStatus, Component milestones, List<Player> players) {
    public record Player(String name, boolean diamondArmor, boolean nether, boolean netheriteArmor,
                         boolean end, int mobsKilled, int deaths) {}
}
