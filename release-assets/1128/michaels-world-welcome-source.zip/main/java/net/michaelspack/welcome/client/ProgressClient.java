package net.michaelspack.welcome.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.michaelspack.welcome.ProgressSnapshot;
import net.michaelspack.welcome.WorldWelcome;

@Mod.EventBusSubscriber(modid = WorldWelcome.ID, value = Dist.CLIENT)
public final class ProgressClient {
    private static ProgressSnapshot pending;

    private ProgressClient() {}

    public static void receive(ProgressSnapshot snapshot) {
        pending = snapshot;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        var game = Minecraft.getInstance();
        if (event.phase == TickEvent.Phase.END && pending != null && game.level != null && game.player != null
                && game.screen == null && game.getOverlay() == null) {
            var snapshot = pending;
            pending = null;
            game.setScreen(new ProgressScreen(snapshot));
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        pending = null;
    }
}
