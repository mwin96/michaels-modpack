package net.michaelspack.chestloot;

import net.minecraft.world.level.storage.loot.providers.number.BinomialDistributionGenerator;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ChestLoot.ID)
public final class ArtifactChestRolls {
    @SubscribeEvent
    public static void adjust(LootTableLoadEvent event) {
        var id = event.getName();
        if (!id.getNamespace().equals("artifacts")) {
            return;
        }
        var path = id.getPath();
        String poolName;
        if (path.startsWith("inject/chests/")) {
            poolName = "main";
        } else if (path.equals("chests/campsite_chest")) {
            poolName = "artifact";
        } else {
            return;
        }
        var pool = event.getTable().getPool(poolName);
        if (pool != null && pool.getRolls().equals(ConstantValue.exactly(1))) {
            pool.setRolls(BinomialDistributionGenerator.binomial(1, 0.5f));
        }
    }
}
