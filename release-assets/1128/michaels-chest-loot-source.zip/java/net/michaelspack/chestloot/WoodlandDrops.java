package net.michaelspack.chestloot;

import java.util.Set;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = ChestLoot.ID)
public final class WoodlandDrops {
    private static final Set<String> BIRDS = Set.of(
            "alexsmobs:crow", "alexsmobs:blue_jay", "alexsmobs:bald_eagle", "alexsmobs:potoo",
            "alexsmobs:toucan", "alexsmobs:roadrunner", "alexsmobs:emu", "alexsmobs:seagull",
            "alexsmobs:shoebill", "graveyard:crow", "graveyard:magpie", "graveyard:raven",
            "crittersandcompanions:shima_enaga");
    private static final Set<String> HIDE_ANIMALS = Set.of(
            "alexsmobs:moose", "alexsmobs:grizzly_bear", "alexsmobs:bison", "alexsmobs:raccoon",
            "alexsmobs:skunk", "alexsmobs:maned_wolf", "minecraft:fox");
    private static final Set<String> WOOL_ANIMALS = Set.of("minecraft:llama", "minecraft:goat");

    private WoodlandDrops() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void addSupplies(LivingDropsEvent event) {
        var animal = event.getEntity();
        if (animal.level().isClientSide() || animal instanceof AgeableMob ageable && ageable.isBaby()) {
            return;
        }
        var type = ForgeRegistries.ENTITY_TYPES.getKey(animal.getType());
        if (type == null) {
            return;
        }
        String id = type.toString();
        Item item = BIRDS.contains(id) ? Items.FEATHER : HIDE_ANIMALS.contains(id) ? Items.LEATHER
                : WOOL_ANIMALS.contains(id) ? Items.WHITE_WOOL : null;
        if (item == null || event.getDrops().stream().anyMatch(drop -> drop.getItem().is(item))) {
            return;
        }
        var drop = new ItemEntity(animal.level(), animal.getX(), animal.getY(), animal.getZ(), new ItemStack(item));
        drop.setDefaultPickUpDelay();
        event.getDrops().add(drop);
    }
}
