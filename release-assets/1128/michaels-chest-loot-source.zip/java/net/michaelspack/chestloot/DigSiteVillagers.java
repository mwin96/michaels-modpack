package net.michaelspack.chestloot;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ChestLoot.ID)
public final class DigSiteVillagers {
    private static final ResourceKey<Structure> DIG_SITE = structure("dig_site");
    private static final ResourceKey<Structure> DESERT_DIG_SITE = structure("dig_site_desert");

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void beforeTrade(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof Villager villager) || !(event.getLevel() instanceof ServerLevel level)
                || villager.isBaby() || villager.getVillagerXp() != 0 || villager.getVillagerData().getLevel() != 1
                || villager.getSpawnType() != MobSpawnType.SPAWN_EGG) {
            return;
        }
        var structures = level.structureManager();
        var pos = villager.blockPosition();
        if (structures.getStructureWithPieceAt(pos, DIG_SITE).isValid()
                || structures.getStructureWithPieceAt(pos, DESERT_DIG_SITE).isValid()) {
            repair(villager, level);
        }
    }

    private static void repair(Villager villager, ServerLevel level) {
        var data = villager.getVillagerData();
        var profession = data.getProfession();
        if (profession == VillagerProfession.NITWIT) {
            return;
        }
        var brain = villager.getBrain();
        var site = brain.getMemory(MemoryModuleType.JOB_SITE);
        boolean hasWorkstation = site.filter(pos -> pos.dimension().equals(level.dimension())
                && pos.pos().closerThan(villager.blockPosition(), 48)
                && level.getPoiManager().getType(pos.pos()).filter(profession.heldJobSite()).isPresent()).isPresent();
        var offers = villager.getOffers();
        offers.removeIf(offer -> offer.getBaseCostA().isEmpty() || offer.getResult().isEmpty());
        if (profession != VillagerProfession.NONE && hasWorkstation && !offers.isEmpty()) {
            return;
        }
        if (!hasWorkstation) {
            brain.eraseMemory(MemoryModuleType.JOB_SITE);
        }
        if (profession == VillagerProfession.NONE) {
            // The template's archaeology profession is absent. Changing profession clears the offer list.
            villager.setVillagerData(data.setProfession(VillagerProfession.MASON));
            if (!offers.isEmpty()) {
                villager.setOffers(offers);
            }
        } else if (offers.isEmpty()) {
            villager.setOffers(null);
        }
        // A villager with experience keeps its profession when the template workstation is absent.
        villager.setVillagerXp(1);
        villager.refreshBrain(level);
    }

    private static ResourceKey<Structure> structure(String name) {
        return ResourceKey.create(Registries.STRUCTURE, new ResourceLocation("idas", "dig_site/" + name));
    }
}
