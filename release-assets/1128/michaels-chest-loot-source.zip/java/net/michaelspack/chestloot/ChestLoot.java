package net.michaelspack.chestloot;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

@Mod(ChestLoot.ID)
@Mod.EventBusSubscriber(modid = ChestLoot.ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ChestLoot {
    public static final String ID = "michaels_chest_loot";

    @SubscribeEvent
    public static void register(RegisterEvent event) {
        event.register(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS,
                registry -> registry.register(new ResourceLocation(ID, "progression_items"), Filter.CODEC));
    }

    static final class Filter extends LootModifier {
        private static final float COPPER_REROLL_CHANCE = 0.60f;
        private static final Codec<Filter> CODEC = RecordCodecBuilder.create(
                instance -> codecStart(instance).apply(instance, Filter::new));

        private Filter(LootItemCondition[] conditions) {
            super(conditions);
        }

        @Override
        public Codec<? extends IGlobalLootModifier> codec() {
            return CODEC;
        }

        @Override
        protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
            var id = context.getQueriedLootTableId();
            var table = context.getLevel().getServer().getLootData().getLootTable(id);
            var path = id.getPath();
            if (table.getParamSet() == LootContextParamSets.CHEST
                    || path.startsWith("chests/") || path.startsWith("chest/")
                    || path.contains("/chests/") || path.contains("/chest/")) {
                loot.removeIf(stack -> stack.is(Items.ENDER_EYE)
                        || stack.is(Items.BLAZE_ROD) || stack.is(Items.BLAZE_POWDER));
                rerollGem(loot, context, Items.EMERALD, Items.EMERALD_BLOCK);
                rerollGem(loot, context, Items.DIAMOND, Items.DIAMOND_BLOCK);
            }
            return loot;
        }

        private static void rerollGem(ObjectArrayList<ItemStack> loot, LootContext context, Item gem, Item block) {
            // Roll once for all stacks of this gem, including its storage block.
            if (loot.stream().anyMatch(stack -> stack.is(gem) || stack.is(block))
                    && context.getRandom().nextFloat() < COPPER_REROLL_CHANCE) {
                loot.replaceAll(stack -> {
                    if (stack.is(gem)) {
                        return new ItemStack(Items.COPPER_INGOT, stack.getCount());
                    }
                    if (stack.is(block)) {
                        return new ItemStack(Items.COPPER_BLOCK, stack.getCount());
                    }
                    return stack;
                });
            }
        }
    }
}
