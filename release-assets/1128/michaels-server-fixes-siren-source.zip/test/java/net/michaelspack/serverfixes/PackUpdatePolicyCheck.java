package net.michaelspack.serverfixes;

/** Private plain-Java policy regression. It never starts Minecraft or opens a connection. */
public final class PackUpdatePolicyCheck {
    private static int checked;

    private static void check(boolean expected, boolean enabled, boolean present,
            String version, String minimum) {
        boolean actual = PackUpdatePolicy.allows(enabled, present, version, minimum);
        if (actual != expected) throw new AssertionError("Policy mismatch: enabled=" + enabled
                + ", present=" + present + ", version=" + version + ", minimum=" + minimum);
        checked++;
    }

    public static void main(String[] ignored) {
        check(true, true, true, "1.0.2", "1.0.2");
        check(true, true, true, "1.0.3", "1.0.2");
        check(true, true, true, "1.0.10", "1.0.2");
        check(true, true, true, "1.1.0", "1.0.2");
        check(true, true, true, "2.0.0", "1.0.2");
        check(true, true, true, "1.0.2+build.1", "1.0.2");
        check(false, true, true, "1.0.1", "1.0.2");
        check(false, true, true, "1.0.0", "1.0.2");
        check(false, true, true, "1.0.2-SNAPSHOT", "1.0.2");
        check(false, true, true, "1.0.2-rc1", "1.0.2");
        check(false, true, true, "1.0.2-beta", "1.0.2");
        check(false, true, true, "1.0.9", "1.0.10");
        check(true, true, true, "1.0.10", "1.0.10");
        check(true, true, true, "1.0.1", "1.0.1");
        for (String version : new String[]{null, "", "ABSENT", "garbage", " 1.0.2", "1.0.2\n", "9".repeat(65)}) {
            check(false, true, true, version, "1.0.2");
            check(true, false, true, version, "1.0.2");
            check(true, false, false, version, "1.0.2");
        }
        check(false, true, false, "1.0.2", "1.0.2");
        check(false, true, true, "1.0.2", "bad minimum");
        System.out.println("PackUpdatePolicy: " + checked + " cases passed");
    }
}
