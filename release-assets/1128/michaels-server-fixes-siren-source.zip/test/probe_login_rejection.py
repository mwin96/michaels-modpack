"""Private loopback-only native login rejection probe. Never starts a game/server."""
import argparse
import json
import socket
import struct
from pathlib import Path

def varint(value):
    result = bytearray()
    while True:
        byte = value & 0x7f
        value >>= 7
        result.append(byte | (0x80 if value else 0))
        if not value:
            return bytes(result)

def string(text):
    data = text.encode('utf-8')
    return varint(len(data)) + data

def recv_exact(stream, count):
    result = bytearray()
    while len(result) < count:
        block = (stream.recv(count-len(result)) if hasattr(stream,'recv')
                 else stream.read(count-len(result)))
        if not block:
            raise EOFError('Connection closed before disconnect packet was flushed')
        result.extend(block)
    return bytes(result)

def read_varint(stream):
    value = 0
    for shift in range(0,35,7):
        byte = recv_exact(stream,1)[0]
        value |= (byte & 0x7f) << shift
        if not byte & 0x80:
            return value
    raise ValueError('Oversized VarInt')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port',type=int,required=True)
    parser.add_argument('--mode',choices=['vanilla','wrong-fml'],required=True)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    # Forge3 is the correct1.20.1 protocol; Forge2 deliberately exercises its existing rejection.
    host = 'localhost' + ('\0FML2\0' if args.mode == 'wrong-fml' else '')
    handshake = varint(0) + varint(763) + string(host) + struct.pack('>H',args.port) + varint(2)
    with socket.create_connection(('127.0.0.1',args.port),timeout=10) as stream:
        stream.settimeout(10)
        stream.sendall(varint(len(handshake))+handshake)
        length = read_varint(stream)
        if length > 1048576:
            raise ValueError('Unexpected packet length')
        import io
        payload = io.BytesIO(recv_exact(stream,length))
        packet_id = read_varint(payload)
        if packet_id != 0:
            raise AssertionError(f'Expected login disconnect, got {packet_id}')
        component = json.loads(recv_exact(payload,read_varint(payload)).decode())
    text = json.dumps(component,ensure_ascii=False)
    report = {'passed': component.get('translate') == 'michaels.update.required'
              and 'Michael\'s Modpack needs an update.' in text
              and 'https://github.com/mwin96/michaels-modpack/releases/latest' in text,
              'mode':args.mode,'host':'127.0.0.1','port':args.port,
              'loginDisconnectComponent':component}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    if not report['passed']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
