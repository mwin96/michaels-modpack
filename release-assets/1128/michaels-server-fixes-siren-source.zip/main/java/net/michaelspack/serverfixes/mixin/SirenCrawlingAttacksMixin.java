package net.michaelspack.serverfixes.mixin;
import net.michaelspack.serverfixes.SirenBalance;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Pseudo
@Mixin(targets="net.meme.sirenhead.procedures.SirenHeadCrawlHadToMakeSeprateEntityForThisVerOnEntityTickUpdateProcedure",remap=false)
public abstract class SirenCrawlingAttacksMixin {
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/commands/Commands;m_230957_(Lnet/minecraft/commands/CommandSourceStack;Ljava/lang/String;)I"),remap=false,require=1)
    private static int noInstantPlayerKill(Commands commands,CommandSourceStack source,String command,LevelAccessor world,double x,double y,double z,Entity siren) {
        return SirenBalance.safeCommand(commands,source,command,siren);
    }
}
