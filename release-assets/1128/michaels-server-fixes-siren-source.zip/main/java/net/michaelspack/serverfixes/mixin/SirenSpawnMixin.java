package net.michaelspack.serverfixes.mixin;
import net.michaelspack.serverfixes.SirenNativeState;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.eventbus.api.Event;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Pseudo
@Mixin(targets="net.meme.sirenhead.procedures.SirenHeadSpawnProcedure",remap=false)
public abstract class SirenSpawnMixin {
    private static final String NATIVE="execute(Lnet/minecraftforge/eventbus/api/Event;Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V";
    /** There is exactly one 0.1 constant in this pinned private player-tick spawn procedure. */
    @ModifyConstant(method=NATIVE,constant=@Constant(doubleValue=0.1D),remap=false,require=1,expect=1,allow=1)
    private static double halfNativeAttempt(double chance){return chance*0.5D;}
    @Inject(method=NATIVE,at=@At("HEAD"),remap=false,require=1)
    private static void attemptStarted(Event event,LevelAccessor world,double x,double y,double z,Entity player,CallbackInfo ci){SirenNativeState.beginAttempt();}
    @Redirect(method=NATIVE,at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/EntityType;m_262496_(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/MobSpawnType;)Lnet/minecraft/world/entity/Entity;"),remap=false,require=8,expect=8,allow=8)
    private static Entity checkedSpawn(EntityType<?> type,ServerLevel world,BlockPos pos,MobSpawnType reason){return SirenNativeState.spawn(type,world,pos,reason);}
    @Inject(method=NATIVE,at=@At("RETURN"),remap=false,require=1)
    private static void recoverFailedAttempt(Event event,LevelAccessor world,double x,double y,double z,Entity player,CallbackInfo ci){SirenNativeState.endAttempt(world);}
}
