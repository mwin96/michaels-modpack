package net.michaelspack.serverfixes.mixin;
import net.michaelspack.serverfixes.SirenBalance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Pseudo
@Mixin(targets="net.meme.sirenhead.entity.SonicboomEntity",remap=false)
public abstract class SirenSonicOwnerMixin {
    @Redirect(method="m_8119_",at=@At(value="INVOKE",target="Lnet/meme/sirenhead/procedures/SonicboomWhileProjectileFlyingTickProcedure;execute(Lnet/minecraft/world/level/LevelAccessor;DDD)V"),remap=false,require=1,allow=1)
    private void scopedNativePulse(LevelAccessor world,double x,double y,double z) {
        Entity previous=SirenBalance.pushSonic((Entity)(Object)this);
        try { SirenSonicInvoker.invokePulse(world,x,y,z); }
        finally { SirenBalance.popSonic(previous); }
    }
}
