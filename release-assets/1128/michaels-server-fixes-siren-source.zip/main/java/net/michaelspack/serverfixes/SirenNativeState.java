package net.michaelspack.serverfixes;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.LevelAccessor;

/** Only calls publisher methods/fields with stable native names, on departure or failed spawn. */
public final class SirenNativeState {
    private static final ThreadLocal<int[]> ATTEMPTS=new ThreadLocal<>();
    private SirenNativeState() {}
    private static final class Access {
        static final Method GET, SYNC, DEPARTURE;
        static final Field SPAWNED;
        static {
            try {
                Class<?> state=Class.forName("net.meme.sirenhead.network.SirenHeadModVariables$MapVariables");
                GET=state.getMethod("get",LevelAccessor.class);
                SYNC=state.getMethod("syncData",LevelAccessor.class);
                SPAWNED=state.getField("sirenheadspawned");
                DEPARTURE=Class.forName("net.meme.sirenhead.procedures.SirendieProcedure")
                    .getMethod("execute",LevelAccessor.class,double.class,double.class,double.class);
            } catch(ReflectiveOperationException e) { throw new IllegalStateException("Pinned Siren native state changed",e); }
        }
    }
    public static void nativeDeparture(LevelAccessor world,double x,double y,double z) {
        try { Access.DEPARTURE.invoke(null,world,x,y,z); }
        catch(ReflectiveOperationException e) { throw new IllegalStateException("Siren departure failed",e); }
    }
    public static void beginAttempt() { ATTEMPTS.set(new int[2]); }
    public static Entity spawn(EntityType<?> type,ServerLevel level,BlockPos pos,MobSpawnType reason) {
        Entity result=type.spawn(level,pos,reason);
        int[] attempts=ATTEMPTS.get();
        if(attempts!=null) {
            attempts[0]++;
            if(result!=null && !result.isRemoved() && level.getEntity(result.getUUID())==result)attempts[1]++;
        }
        return result;
    }
    public static void endAttempt(LevelAccessor world) {
        int[] attempts=ATTEMPTS.get();ATTEMPTS.remove();
        if(!(world instanceof ServerLevel) || attempts==null || attempts[0]==0 || attempts[1]>0)return;
        try {
            Object state=Access.GET.invoke(null,world);
            Access.SPAWNED.setBoolean(state,false);
            Access.SYNC.invoke(state,world);
        } catch(ReflectiveOperationException e) { throw new IllegalStateException("Siren failed-spawn recovery failed",e); }
    }
    public static boolean reconcileOldBan(MinecraftServer server) {
        for(ServerLevel level:server.getAllLevels())for(Entity entity:level.getAllEntities())
            if(SirenBalance.isSiren(entity) && !entity.isRemoved())return false;
        try {
            Object state=Access.GET.invoke(null,server.overworld());
            if(!Access.SPAWNED.getBoolean(state))return false;
            Access.SPAWNED.setBoolean(state,false);
            Access.SYNC.invoke(state,server.overworld());
            return true;
        } catch(ReflectiveOperationException e) { throw new IllegalStateException("Siren stale-ban migration failed",e); }
    }
}
