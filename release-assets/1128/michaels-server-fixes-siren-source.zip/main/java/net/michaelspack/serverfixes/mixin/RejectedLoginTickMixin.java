package net.michaelspack.serverfixes.mixin;

import net.minecraft.network.Connection;
import net.minecraft.server.network.ServerLoginPacketListenerImpl;
import net.michaelspack.serverfixes.PackUpdateGate;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** A rejected connection must not advance negotiation/authentication while its reason is delivered. */
@Mixin(ServerLoginPacketListenerImpl.class)
public abstract class RejectedLoginTickMixin {
    @Shadow @Final public Connection connection;

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void michaels$keepRejectedLoginStopped(CallbackInfo ci) {
        if (PackUpdateGate.isRejected(connection)) ci.cancel();
    }
}
