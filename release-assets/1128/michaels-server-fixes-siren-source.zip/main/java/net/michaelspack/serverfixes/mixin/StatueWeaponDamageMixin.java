package net.michaelspack.serverfixes.mixin;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Normal weapon hurt path for these exact statue classes, retaining their AI/environment rules. */
@Pseudo
@Mixin(targets={"net.mcreator.scpultimate.entity.SCP173Entity","net.scpo.entity.SCP173Entity"},remap=false)
public abstract class StatueWeaponDamageMixin extends Monster {
    protected StatueWeaponDamageMixin(EntityType<? extends Monster> type,Level level){super(type,level);}
    @Inject(method="m_6469_",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private void ordinaryWeapons(DamageSource source,float amount,CallbackInfoReturnable<Boolean> ci) {
        var direct=source.getDirectEntity();
        if(direct instanceof Player || (direct!=null && "tacz:bullet".equals(String.valueOf(ForgeRegistries.ENTITY_TYPES.getKey(direct.getType())))))
            ci.setReturnValue(super.hurt(source,amount));
    }
}
