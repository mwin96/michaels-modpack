package net.michaelspack.serverfixes.mixin;

import net.michaelspack.serverfixes.ScpBalance;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Allow normal damage only for the requested SCP Additions173 entity. */
@Pseudo
@Mixin(targets="net.mcreator.scpadditions.event.Scp173DurabilityEvents",remap=false)
public final class Scp173DamageMixin {
    @Inject(method="onEntityJoinLevel",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private static void preserveHealthOnReload(EntityJoinLevelEvent event,CallbackInfo ci) {
        if (!event.getLevel().isClientSide && event.getEntity() instanceof LivingEntity living && ScpBalance.isTarget(living)) {
            ScpBalance.configureJoin(living);
            ci.cancel();
        }
    }
    @Inject(method="onLivingHurt",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private static void normalDamage(LivingHurtEvent event,CallbackInfo ci) {
        if (ScpBalance.isTarget(event.getEntity())) ci.cancel();
    }
}
