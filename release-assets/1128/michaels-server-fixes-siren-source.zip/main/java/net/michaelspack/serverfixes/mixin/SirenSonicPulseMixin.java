package net.michaelspack.serverfixes.mixin;
import net.michaelspack.serverfixes.SirenBalance;
import net.minecraft.core.BlockPos;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Pseudo
@Mixin(targets="net.meme.sirenhead.procedures.SonicboomWhileProjectileFlyingTickProcedure",remap=false)
public abstract class SirenSonicPulseMixin {
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/LevelAccessor;m_46961_(Lnet/minecraft/core/BlockPos;Z)Z"),remap=false,require=1,allow=1)
    private static boolean retainGlass(LevelAccessor world,BlockPos pos,boolean drops){return false;}
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/LivingEntity;m_6469_(Lnet/minecraft/world/damagesource/DamageSource;F)Z"),remap=false,require=1,allow=1)
    private static boolean ordinarySonic(LivingEntity victim,DamageSource source,float amount) {
        return SirenBalance.safeDamage(victim,SirenBalance.currentSonic(),source,amount);
    }
}
