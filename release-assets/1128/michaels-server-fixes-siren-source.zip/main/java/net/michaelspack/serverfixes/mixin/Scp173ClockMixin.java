package net.michaelspack.serverfixes.mixin;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Observed173 skips super.tick; retain ordinary damage/death clocks without changing its frozen pose. */
@Pseudo
@Mixin(targets="net.mcreator.scpadditions.entity.Scp173Entity",remap=false)
public abstract class Scp173ClockMixin extends Zombie {
    @Unique private int michael$beforeInvulnerable,michael$beforeHurt,michael$beforeDeath;
    @Unique private long michael$lastClockTime=Long.MIN_VALUE;
    protected Scp173ClockMixin(EntityType<? extends Zombie> type,Level level){super(type,level);}
    @Inject(method="m_8119_",at=@At("HEAD"),remap=false,require=1)
    private void snapshotClocks(CallbackInfo ci){
        michael$beforeInvulnerable=invulnerableTime;michael$beforeHurt=hurtTime;michael$beforeDeath=deathTime;
    }
    @Inject(method="m_8119_",at=@At("RETURN"),remap=false,require=1)
    private void advanceOnlyStalledClocks(CallbackInfo ci){
        if(level().isClientSide || michael$lastClockTime==level().getGameTime())return;
        michael$lastClockTime=level().getGameTime();
        if(isAlive()){
            if(michael$beforeInvulnerable>0 && invulnerableTime==michael$beforeInvulnerable)invulnerableTime--;
            if(michael$beforeHurt>0 && hurtTime==michael$beforeHurt)hurtTime--;
        }else if(isDeadOrDying() && deathTime==michael$beforeDeath)super.tickDeath();
    }
}
