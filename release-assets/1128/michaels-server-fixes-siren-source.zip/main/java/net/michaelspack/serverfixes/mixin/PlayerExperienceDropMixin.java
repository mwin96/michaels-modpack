package net.michaelspack.serverfixes.mixin;

import net.michaelspack.serverfixes.ExperienceRecovery;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Real death loot completion: cancelled deaths/totems never reach this hook. */
@Mixin(LivingEntity.class)
public abstract class PlayerExperienceDropMixin {
    @Inject(method="dropAllDeathLoot",at=@At("TAIL"),require=1)
    private void michaels$recoverablePlayerExperience(DamageSource source, CallbackInfo ci) {
        if ((Object)this instanceof ServerPlayer player) ExperienceRecovery.drop(player);
    }
}
