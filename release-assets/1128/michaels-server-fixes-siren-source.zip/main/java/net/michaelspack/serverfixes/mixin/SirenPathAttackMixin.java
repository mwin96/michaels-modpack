package net.michaelspack.serverfixes.mixin;
import net.michaelspack.serverfixes.SirenBalance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.eventbus.api.Event;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Pseudo
@Mixin(targets="net.meme.sirenhead.procedures.CorrectpathProcedure",remap=false)
public abstract class SirenPathAttackMixin {
    @Redirect(method="execute(Lnet/minecraftforge/eventbus/api/Event;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;)V",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/Entity;m_6469_(Lnet/minecraft/world/damagesource/DamageSource;F)Z"),remap=false,require=1,allow=1)
    private static boolean ordinaryCrawlAttack(Entity victim,DamageSource source,float amount,Event event,LevelAccessor world,Entity target,Entity siren) {
        return SirenBalance.safeDamage(victim,siren,source,amount);
    }
}
