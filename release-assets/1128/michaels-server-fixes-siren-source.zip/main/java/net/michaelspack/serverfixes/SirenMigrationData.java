package net.michaelspack.serverfixes;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** One persisted reconciliation after first player/chunk loading; never clears spawn state every tick. */
@Mod.EventBusSubscriber(modid="michaels_server_fixes",bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class SirenMigrationData extends SavedData {
    private static final Map<MinecraftServer,Integer> READY=new WeakHashMap<>();
    private boolean done,recovered;
    public SirenMigrationData() {}
    public static SirenMigrationData load(CompoundTag tag) {
        SirenMigrationData data=new SirenMigrationData();data.done=tag.getBoolean("done");data.recovered=tag.getBoolean("recoveredStaleBanFlag");return data;
    }
    @Override public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("done",done);tag.putBoolean("recoveredStaleBanFlag",recovered);return tag;
    }
    @SubscribeEvent public static void afterPlayersLoad(TickEvent.ServerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END)return;
        MinecraftServer server=event.getServer();
        if(server.getPlayerCount()==0)return;
        SirenMigrationData data=server.overworld().getDataStorage().computeIfAbsent(SirenMigrationData::load,SirenMigrationData::new,"michaels_siren_104");
        if(data.done)return;
        int ready=READY.computeIfAbsent(server,s->s.getTickCount()+40);
        if(server.getTickCount()<ready)return;
        data.recovered=SirenNativeState.reconcileOldBan(server);
        data.done=true;data.setDirty();READY.remove(server);
    }
}
