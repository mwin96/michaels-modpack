package net.michaelspack.serverfixes.mixin;

import net.michaelspack.serverfixes.StatusCompatibility;
import net.minecraftforge.network.ServerStatusPing;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Outgoing status construction only; channel maps and the actual login handshake are untouched. */
@Mixin(value=ServerStatusPing.class,remap=false)
public final class OptionalStatusMixin {
    @Inject(method="<init>()V",at=@At("RETURN"),remap=false,require=1)
    private void optionalMetadata(CallbackInfo ci) {
        StatusCompatibility.apply(((ServerStatusPing)(Object)this).getRemoteModData());
    }
}
