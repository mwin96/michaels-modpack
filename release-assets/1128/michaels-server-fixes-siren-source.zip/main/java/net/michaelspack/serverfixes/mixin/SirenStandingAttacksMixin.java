package net.michaelspack.serverfixes.mixin;
import net.michaelspack.serverfixes.SirenBalance;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
@Pseudo
@Mixin(targets="net.meme.sirenhead.procedures.SirentickupdateProcedure",remap=false)
public abstract class SirenStandingAttacksMixin {
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/Entity;m_6469_(Lnet/minecraft/world/damagesource/DamageSource;F)Z"),remap=false,require=7,expect=7,allow=7)
    private static boolean ordinaryAttack(Entity victim,DamageSource source,float amount,LevelAccessor world,double x,double y,double z,Entity siren) {
        return SirenBalance.safeDamage(victim,siren,source,amount);
    }
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/commands/Commands;m_230957_(Lnet/minecraft/commands/CommandSourceStack;Ljava/lang/String;)I"),remap=false,require=1)
    private static int noInstantPlayerKill(Commands commands,CommandSourceStack source,String command,LevelAccessor world,double x,double y,double z,Entity siren) {
        return SirenBalance.safeCommand(commands,source,command,siren);
    }
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/LivingEntity;m_21153_(F)V"),remap=false,require=1,allow=1)
    private static void transferHealthAndClock(LivingEntity replacement,float health,LevelAccessor world,double x,double y,double z,Entity siren) {
        SirenBalance.transferEncounter(siren,replacement,health);
    }
}
