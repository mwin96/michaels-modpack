package net.michaelspack.serverfixes.mixin;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.ServerFunctionManager;
import net.minecraft.commands.CommandFunction;
import net.minecraft.resources.ResourceLocation;
import java.util.Collection;
import net.michaelspack.serverfixes.EmptyPauseGuard;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freeze automatic tick functions; one-time load/init functions and explicit commands still run. */
@Mixin(ServerFunctionManager.class)
public abstract class PausedFunctionsMixin {
    @Shadow @Final MinecraftServer server;
    @Inject(method="executeTagFunctions",at=@At("HEAD"),cancellable=true,require=1)
    private void stopAutomaticFunctions(Collection<CommandFunction> functions,ResourceLocation tag,CallbackInfo ci){
        if(tag.getNamespace().equals("minecraft") && tag.getPath().equals("tick") && EmptyPauseGuard.isPaused(server)){
            if(EmptyPauseGuard.VALIDATION)EmptyPauseGuard.functionCallbacksSuppressed++;
            ci.cancel();
        }
    }
}
