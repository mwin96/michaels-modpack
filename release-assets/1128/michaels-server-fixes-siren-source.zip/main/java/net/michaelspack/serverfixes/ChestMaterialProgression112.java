package net.michaelspack.serverfixes;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.*;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.*;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.*;

/** Only newly generated selected chest stacks; runs before the existing equipment quality modifier. */
@Mod.EventBusSubscriber(modid="michaels_server_fixes",bus=Mod.EventBusSubscriber.Bus.MOD)
public final class ChestMaterialProgression112 extends LootModifier {
 public static final Codec<ChestMaterialProgression112> CODEC=RecordCodecBuilder.create(i->codecStart(i).and(i.group(
  ResourceLocation.CODEC.listOf().fieldOf("tables").forGetter(m->m.tableList),
  ResourceLocation.CODEC.listOf().fieldOf("hard_treasure_tables").forGetter(m->m.hardList),
  Codec.unboundedMap(ResourceLocation.CODEC,ResourceLocation.CODEC).fieldOf("item_replacements").forGetter(m->m.replacements),
  Codec.doubleRange(0,1).fieldOf("ordinary_keep").forGetter(m->m.ordinaryKeep),
  Codec.doubleRange(0,1).fieldOf("hard_keep").forGetter(m->m.hardKeep)
 )).apply(i,ChestMaterialProgression112::new));
 private final List<ResourceLocation> tableList,hardList;
 private final Set<ResourceLocation> tables,hard;
 private final Map<ResourceLocation,ResourceLocation> replacements;
 private final double ordinaryKeep,hardKeep;
 public ChestMaterialProgression112(LootItemCondition[] conditions,List<ResourceLocation> tableList,List<ResourceLocation> hardList,Map<ResourceLocation,ResourceLocation> replacements,double ordinaryKeep,double hardKeep){
  super(conditions);this.tableList=List.copyOf(tableList);this.hardList=List.copyOf(hardList);this.tables=Set.copyOf(tableList);this.hard=Set.copyOf(hardList);this.replacements=Map.copyOf(replacements);this.ordinaryKeep=ordinaryKeep;this.hardKeep=hardKeep;
 }
 @SubscribeEvent public static void register(RegisterEvent event){event.register(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS,helper->helper.register(new ResourceLocation("michaels_server_fixes","chest_material_progression"),CODEC));}
 @Override public Codec<? extends IGlobalLootModifier> codec(){return CODEC;}
 @Override protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot,LootContext context){
  ResourceLocation table=context.getQueriedLootTableId();if(!tables.contains(table))return loot;
  double keep=hard.contains(table)?hardKeep:ordinaryKeep;
  for(int i=0;i<loot.size();i++){
   ItemStack stack=loot.get(i);if(stack.isEmpty())continue;
   ResourceLocation replacement=replacements.get(ForgeRegistries.ITEMS.getKey(stack.getItem()));
   if(replacement==null||context.getRandom().nextDouble()<keep)continue;
   Item target=ForgeRegistries.ITEMS.getValue(replacement);if(target==null||target==Items.AIR)continue;
   // Save/load preserves count, enchantments, names, arbitrary item NBT and Forge capabilities.
   CompoundTag saved=stack.save(new CompoundTag());saved.putString("id",replacement.toString());ItemStack result=ItemStack.of(saved);
   if(result.isEmpty())continue;
   if(stack.isDamageableItem()&&result.isDamageableItem()){
    double fraction=Math.max(0,Math.min(1,stack.getDamageValue()/(double)stack.getMaxDamage()));
    result.setDamageValue(Math.min(result.getMaxDamage()-1,Math.max(0,(int)Math.round(fraction*result.getMaxDamage()))));
   }
   loot.set(i,result);
  }
  return loot;
 }
}
