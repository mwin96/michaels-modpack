package net.michaelspack.serverfixes;

import org.apache.maven.artifact.versioning.DefaultArtifactVersion;

/** Compatibility guidance for ordinary clients, never an authentication or anti-cheat mechanism. */
public final class PackUpdatePolicy {
    private PackUpdatePolicy() {}

    public static boolean isVersion(Object candidate) {
        return candidate instanceof String version
                && version.matches("[0-9][0-9A-Za-z.+_-]{0,63}");
    }

    public static boolean allows(boolean enabled, boolean hasClientFixes,
            String advertisedVersion, String minimumVersion) {
        if (!enabled) return true;
        if (!hasClientFixes || !isVersion(advertisedVersion) || !isVersion(minimumVersion))
            return false;
        return new DefaultArtifactVersion(advertisedVersion)
                .compareTo(new DefaultArtifactVersion(minimumVersion)) >= 0;
    }
}
