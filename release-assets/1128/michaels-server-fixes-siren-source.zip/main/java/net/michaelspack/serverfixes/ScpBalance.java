package net.michaelspack.serverfixes;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/** Changes only the three retained SCP173 statues; gaze, movement, and attacks remain upstream. */
public final class ScpBalance {
    private static final java.util.Set<ResourceLocation> TARGETS = java.util.Set.of(
        new ResourceLocation("scp_additions","scp_173"),new ResourceLocation("scp_ultimate","scp_173"),new ResourceLocation("scpo","scp_173"));
    public static boolean isTarget(LivingEntity entity) {
        return TARGETS.contains(ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()));
    }
    public static boolean enforce(LivingEntity entity) {
        if (entity.level().isClientSide || !isTarget(entity) || !entity.isAlive() || entity.isDeadOrDying()) return false;
        var max = entity.getAttribute(Attributes.MAX_HEALTH);
        if (max == null || max.getBaseValue() == 80.0) return false;
        float health = entity.getHealth();
        float oldMaximum = entity.getMaxHealth();
        max.setBaseValue(80.0);
        // Preserve the damage fraction when reducing max health; never increase current HP.
        float scaled = oldMaximum > 0 ? health / oldMaximum * entity.getMaxHealth() : health;
        entity.setHealth(Math.min(health, Math.min(entity.getMaxHealth(),scaled)));
        return true;
    }
    public static void configureJoin(LivingEntity entity) {
        if (entity.level().isClientSide || !isTarget(entity)) return;
        entity.getAttribute(Attributes.ARMOR).setBaseValue(0);
        entity.getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(0);
        entity.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1);
        enforce(entity);
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void joined(EntityJoinLevelEvent event) {
        if (!event.getLevel().isClientSide && event.getEntity() instanceof LivingEntity living) enforce(living);
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void tick(LivingEvent.LivingTickEvent event) {
        enforce(event.getEntity());
    }
}
