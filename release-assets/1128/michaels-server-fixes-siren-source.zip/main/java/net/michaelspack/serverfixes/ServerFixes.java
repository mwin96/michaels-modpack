package net.michaelspack.serverfixes;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerContainerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Normalize empty tags and repair the one historical invalid MP5 loot alias. */
@Mod("michaels_server_fixes")
public final class ServerFixes {
    public ServerFixes() {
        PackUpdateConfig.register();
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new ScpBalance());
        MinecraftForge.EVENT_BUS.register(new SpiderBalance());
        if (Boolean.getBoolean("michaels_server_fixes.validation")) {
            MinecraftForge.EVENT_BUS.register(new StackRegression());
            MinecraftForge.EVENT_BUS.register(new BundleRegression());
            MinecraftForge.EVENT_BUS.register(new CombatRegression());
        }
    }

    static boolean normalize(ItemStack stack) {
        boolean repaired = KnownGunRepair.repair(stack);
        if (!stack.isEmpty() && stack.getTag() != null && stack.getTag().isEmpty()) {
            stack.setTag(null);
            return true;
        }
        return repaired;
    }

    static boolean normalizePlayer(ServerPlayer player) {
        boolean changed = false;
        var inventory = player.getInventory();
        for (int slot = 0; slot < inventory.getContainerSize(); slot++)
            changed |= normalize(inventory.getItem(slot));
        changed |= normalize(player.containerMenu.getCarried());
        if (player.containerMenu != player.inventoryMenu)
            changed |= normalize(player.inventoryMenu.getCarried());
        if (changed) {
            inventory.setChanged();
            player.containerMenu.broadcastChanges();
            if (player.containerMenu != player.inventoryMenu)
                player.inventoryMenu.broadcastChanges();
        }
        return changed;
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void playerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.player instanceof ServerPlayer player)
            normalizePlayer(player);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void itemJoined(EntityJoinLevelEvent event) {
        if (!event.getLevel().isClientSide && event.getEntity() instanceof ItemEntity item)
            normalize(item.getItem());
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void containerOpened(PlayerContainerEvent.Open event) {
        if (!(event.getEntity() instanceof ServerPlayer)) return;
        boolean changed = false;
        for (var slot : event.getContainer().slots) {
            if (KnownGunRepair.repair(slot.getItem())) {
                slot.setChanged();
                changed = true;
            }
        }
        if (changed) event.getContainer().broadcastChanges();
    }
}
