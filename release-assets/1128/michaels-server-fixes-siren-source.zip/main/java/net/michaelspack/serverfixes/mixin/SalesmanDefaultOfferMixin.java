package net.michaelspack.serverfixes.mixin;
import net.michaelspack.serverfixes.SalesmanTradeDefaults;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Pseudo
@Mixin(targets="net.scpo.procedures.SCP1879RightClickedOnEntityProcedure",remap=false)
public abstract class SalesmanDefaultOfferMixin {
    @Inject(method="execute",at=@At("TAIL"),remap=false,require=1,expect=1,allow=1)
    private static void initialNativeOffer(LevelAccessor world,double x,double y,double z,Entity salesman,Entity source,CallbackInfo ci) {
        SalesmanTradeDefaults.ensureOffer(source);
    }
}
