package net.michaelspack.serverfixes;

import java.net.URI;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;

/** COMMON config is server-local; no extra client config-sync or network channel is introduced. */
public final class PackUpdateConfig {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.ConfigValue<String> MINIMUM_CLIENT_UI_VERSION;
    public static final ForgeConfigSpec.ConfigValue<String> UPDATE_DOWNLOAD_URL;
    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.push("clientUpdates");
        ENABLED = BUILDER.comment("Show a clear update instruction to outdated ordinary clients during login.")
                .define("enabled", true);
        MINIMUM_CLIENT_UI_VERSION = BUILDER.comment("Minimum michaels_client_fixes optional pack_version marker.",
                "This client-reported marker is compatibility metadata, not authentication.")
                .define("minimumClientUiVersion", "1.0.2", PackUpdatePolicy::isVersion);
        UPDATE_DOWNLOAD_URL = BUILDER.comment("Download page included in the disconnect instruction.")
                .define("updateDownloadUrl", "https://github.com/mwin96/michaels-modpack/releases/latest",
                        PackUpdateConfig::isDownloadUrl);
        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    private PackUpdateConfig() {}

    public static void register() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, SPEC,
                "michaels-server-fixes-common.toml");
    }

    static boolean isDownloadUrl(Object candidate) {
        if (!(candidate instanceof String text) || text.length() > 2048) return false;
        try {
            URI uri = URI.create(text);
            return ("https".equalsIgnoreCase(uri.getScheme())
                    || "http".equalsIgnoreCase(uri.getScheme())) && uri.getHost() != null;
        } catch (IllegalArgumentException invalid) {
            return false;
        }
    }
}
