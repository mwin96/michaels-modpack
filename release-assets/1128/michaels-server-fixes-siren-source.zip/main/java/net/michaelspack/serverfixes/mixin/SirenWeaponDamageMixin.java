package net.michaelspack.serverfixes.mixin;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Pseudo
@Mixin(targets={"net.meme.sirenhead.entity.SirenHeadEntity","net.meme.sirenhead.entity.SirenHeadCrawlHadToMakeSeprateEntityForThisVerEntity"},remap=false)
public abstract class SirenWeaponDamageMixin extends Monster {
    protected SirenWeaponDamageMixin(EntityType<? extends Monster> type,Level level){super(type,level);}
    @Inject(method="m_6469_",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private void ordinaryDamage(DamageSource source,float amount,CallbackInfoReturnable<Boolean> ci) {
        ci.setReturnValue(super.hurt(source,amount));
    }
}
