package net.michaelspack.serverfixes;

import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.commands.Commands;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.NetworkConstants;
import net.minecraftforge.network.ServerStatusPing;
import net.minecraftforge.registries.ForgeRegistries;

/** Explicit disposable-world checks, registered only with the validation JVM property. */
public final class BundleRegression {
    @SubscribeEvent public void command(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("serverbundletest").requires(s->s.hasPermission(2)).executes(c->{
            var source=c.getSource();var level=source.getServer().overworld();
            var player=source.getServer().getPlayerList().getPlayers().stream().findFirst().orElseThrow();
            var report=new LinkedHashMap<String,Object>();
            var type=ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation("scp_additions:scp_173"));
            var target=(LivingEntity)type.create(level);target.moveTo(16,250,16,0,0);target.setNoGravity(true);((Mob)target).setNoAi(true);
            level.addFreshEntity(target);target.xo=16;target.yo=250;target.zo=16;
            try {
                report.put("freshMaxHealth",target.getMaxHealth());report.put("freshHealth",target.getHealth());
                target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(1024);target.setHealth(512);
                ScpBalance.enforce(target);report.put("existingDamagedMaxHealth",target.getMaxHealth());report.put("existingDamagedScaledHealth",target.getHealth());
                target.setHealth(73);ScpBalance.enforce(target);report.put("sameMaximumDoesNotHeal",target.getHealth()==73);
                target.setHealth(40);
                Class.forName("net.mcreator.scpadditions.event.Scp173DurabilityEvents").getMethod("onEntityJoinLevel",net.minecraftforge.event.entity.EntityJoinLevelEvent.class).invoke(null,new net.minecraftforge.event.entity.EntityJoinLevelEvent(target,level));
                report.put("realUpstreamReloadPreserves40of80",target.getHealth()==40 && target.getMaxHealth()==80);
                var melee=new LinkedHashMap<String,Object>();
                ItemStack previous=player.getMainHandItem();
                for(var weapon:Map.of("fist",Items.AIR,"stone_sword",Items.STONE_SWORD,"iron_sword",Items.IRON_SWORD).entrySet()) {
                    player.getAttributes().removeAttributeModifiers(previous.getAttributeModifiers(net.minecraft.world.entity.EquipmentSlot.MAINHAND));
                    var equipped=weapon.getValue()==Items.AIR?ItemStack.EMPTY:new ItemStack(weapon.getValue());
                    player.setItemInHand(InteractionHand.MAIN_HAND,equipped);
                    player.getAttributes().addTransientAttributeModifiers(equipped.getAttributeModifiers(net.minecraft.world.entity.EquipmentSlot.MAINHAND));
                    previous=equipped;
                    target.invulnerableTime=0;player.resetAttackStrengthTicker();
                    // Real Player.attack path, full attack cooldown established through vanilla ticker.
                    var ticker=net.minecraftforge.fml.util.ObfuscationReflectionHelper.findField(LivingEntity.class,"f_20922_");ticker.setInt(player,100);
                    float before=target.getHealth();player.attack(target);melee.put(weapon.getKey()+"Damage",before-target.getHealth());
                }
                player.getAttributes().removeAttributeModifiers(previous.getAttributeModifiers(net.minecraft.world.entity.EquipmentSlot.MAINHAND));
                player.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);
                report.put("nativePlayerMelee",melee);
                float before=target.getHealth();target.invulnerableTime=0;target.hurt(level.damageSources().generic(),2);report.put("ordinaryTwoDamageAccepted",target.getHealth()<before);
                var other=net.minecraft.world.entity.EntityType.ZOMBIE.create(level);float otherHealth=other.getHealth();double otherMax=other.getMaxHealth();
                ScpBalance.enforce(other);report.put("otherEntityUntouched",other.getHealth()==otherHealth && other.getMaxHealth()==otherMax);other.discard();
                var ping=new ServerStatusPing();var mods=ping.getRemoteModData();
                report.put("outgoingOptionalVersions",Map.of("eternaljesus",mods.get("eternaljesus"),"simplytooltips",mods.get("simplytooltips"),"searchables",mods.get("searchables"),"xaerolib",mods.get("xaerolib")));
                report.put("threeServerOnlyMarkersIgnored",java.util.stream.Stream.of("incontrol","clumps","dungeons_arise").allMatch(id->NetworkConstants.IGNORESERVERONLY.equals(mods.get(id))));
                var trial=new java.util.HashMap<String,String>();trial.put("xaerolib","real-future-version");trial.put("unrelated","must-stay");StatusCompatibility.apply(trial);
                report.put("realPresentVersionAndOtherIdsRetained",trial.get("xaerolib").equals("real-future-version") && trial.get("unrelated").equals("must-stay") && !trial.containsKey("incontrol"));
                report.put("channelCount",ping.getRemoteChannels().size());report.put("fmlNetworkVersion",ping.getFMLNetworkVersion());
                target.setHealth(0);ScpBalance.enforce(target);report.put("deadNotRevived",target.getHealth()==0);
                boolean pass=target.getMaxHealth()==80 && Float.valueOf(80).equals(report.get("freshMaxHealth")) && Float.valueOf(80).equals(report.get("freshHealth")) && Float.valueOf(40).equals(report.get("existingDamagedScaledHealth")) && melee.values().stream().allMatch(v->((Number)v).floatValue()>0) && Boolean.TRUE.equals(report.get("sameMaximumDoesNotHeal")) && Boolean.TRUE.equals(report.get("realUpstreamReloadPreserves40of80")) && Boolean.TRUE.equals(report.get("ordinaryTwoDamageAccepted")) && Boolean.TRUE.equals(report.get("otherEntityUntouched")) && Boolean.TRUE.equals(report.get("threeServerOnlyMarkersIgnored")) && Boolean.TRUE.equals(report.get("realPresentVersionAndOtherIdsRetained")) && Boolean.TRUE.equals(report.get("deadNotRevived"));
                report.put("passed",pass);Files.writeString(Path.of("server-bundle-regression.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));
                source.sendSuccess(()->net.minecraft.network.chat.Component.literal("Server bundle regression: "+report),true);return pass?1:0;
            } catch(Exception ex){throw new RuntimeException(ex);} finally {target.discard();}
        }));
    }
}
