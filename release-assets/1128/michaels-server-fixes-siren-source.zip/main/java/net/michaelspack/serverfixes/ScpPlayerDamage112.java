package net.michaelspack.serverfixes;

import java.util.Set;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** SCP-173 neck snaps require diamond-grade armor in all four armor slots. */
@Mod.EventBusSubscriber(modid="michaels_server_fixes", bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class ScpPlayerDamage112 {
    private static final ThreadLocal<Boolean> REISSUING=ThreadLocal.withInitial(()->false);
    private static final Set<ResourceLocation> STATUES=Set.of(new ResourceLocation("scp_additions","scp_173"),new ResourceLocation("scp_ultimate","scp_173"),new ResourceLocation("scpo","scp_173"));
    private static final Set<ResourceLocation> SHY=Set.of(new ResourceLocation("scpo","scp_096"),new ResourceLocation("scpo","scp_096_aggro"),new ResourceLocation("scp_ultimate","scp_096"),new ResourceLocation("scp_ultimate","scp_0961"),new ResourceLocation("scp_ultimate","scp_0962"));
    private ScpPlayerDamage112(){}
    private static ResourceLocation livingType(Entity source) {
        return source instanceof LivingEntity ? ForgeRegistries.ENTITY_TYPES.getKey(source.getType()) : null;
    }

    private static float cap(ResourceLocation id) {
        if (id == null) return 0;
        return STATUES.contains(id) ? 8F : SHY.contains(id) ? 14F : 0;
    }

    private static boolean wearsDiamondGradeSet(ServerPlayer player) {
        for (ArmorItem.Type slot : ArmorItem.Type.values()) {
            var item = player.getItemBySlot(slot.getSlot()).getItem();
            if (!(item instanceof ArmorItem armor) || armor.getType() != slot
                    || armor.getDefense() < ArmorMaterials.DIAMOND.getDefenseForType(slot)
                    || armor.getToughness() < ArmorMaterials.DIAMOND.getToughness()) {
                return false;
            }
        }
        return true;
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void attack(LivingAttackEvent event){
        if(!(event.getEntity() instanceof ServerPlayer player)||player.level().isClientSide||event.getAmount()<=0)return;
        Entity source=event.getSource().getEntity();
        ResourceLocation id=livingType(source);
        float limit=cap(id);
        if(limit<=0||REISSUING.get())return;
        boolean lethal = STATUES.contains(id) && !player.getAbilities().invulnerable
                && !player.isSpectator() && !wearsDiamondGradeSet(player);
        if(lethal||!event.getSource().is(DamageTypes.MOB_ATTACK)||event.getAmount()>limit){
            event.setCanceled(true);
            // Guard bounds nested normalization, including other mod reissues.
            REISSUING.set(true);
            try {
                if (lethal) {
                    // Keep the statue as the cause of death. A neck snap has no blockable attack position.
                    var snap = new DamageSource(player.damageSources().genericKill().typeHolder(), null, source);
                    player.hurt(snap, 1_000_000F);
                } else {
                    player.hurt(player.damageSources().mobAttack((LivingEntity)source),Math.min(event.getAmount(),limit));
                }
            }
            finally{REISSUING.remove();}
        }
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void hurt(LivingHurtEvent event){
        if(!(event.getEntity() instanceof ServerPlayer)||event.getEntity().level().isClientSide)return;
        if (REISSUING.get() && event.getSource().is(DamageTypes.GENERIC_KILL)) return;
        float limit=cap(livingType(event.getSource().getEntity()));
        if(limit>0)event.setAmount(Math.min(event.getAmount(),limit));
    }
}
