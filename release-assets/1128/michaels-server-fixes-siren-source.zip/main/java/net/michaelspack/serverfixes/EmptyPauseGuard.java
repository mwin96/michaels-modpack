package net.michaelspack.serverfixes;

import java.lang.reflect.Method;
import net.minecraft.server.MinecraftServer;

/** Extends the existing level pause to simulation callbacks, without pausing network/server services. */
public final class EmptyPauseGuard {
    private static Method paused;
    private static boolean unavailable;
    public static final boolean VALIDATION=Boolean.getBoolean("michaels_server_fixes.validation");
    public static long levelCallbacksSuppressed,weatherCallbacksSuppressed,functionCallbacksSuppressed;
    public static boolean isPaused(MinecraftServer server) {
        if(server==null || server.getPlayerList()==null || server.getPlayerList().getPlayerCount()!=0 || unavailable)return false;
        try {
            if(paused==null)paused=Class.forName("com.dyxiaojiazi.unmannedonlinetickstasis.UnmannedOnlineTickStasis").getMethod("isPaused");
            return Boolean.TRUE.equals(paused.invoke(null));
        }catch(ReflectiveOperationException e){unavailable=true;return false;}
    }
}
