package net.michaelspack.serverfixes;

import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/** Property-gated disposable-world regression; naturally ticking targets and normal attack cooldowns. */
public final class CombatRegression {
    private static final String[] IDS={"scp_additions:scp_173","scp_ultimate:scp_173","scpo:scp_173"};
    private final net.minecraft.world.item.Item[] weapons={Items.AIR,Items.STONE_AXE,Items.IRON_SWORD};
    private ServerPlayer player;private LivingEntity target;private int phase=-1,hits,next;private boolean killed;
    private final List<Map<String,Object>> rows=new ArrayList<>();private final Map<String,Object> report=new LinkedHashMap<>();
    @SubscribeEvent public void command(RegisterCommandsEvent e){e.getDispatcher().register(Commands.literal("servercombattest").requires(s->s.hasPermission(2)).executes(c->{
        player=c.getSource().getServer().getPlayerList().getPlayers().stream().findFirst().orElseThrow();rows.clear();report.clear();phase=0;target=null;
        player.setGameMode(net.minecraft.world.level.GameType.SURVIVAL);player.setInvulnerable(true);
        for(BlockPos p:BlockPos.betweenClosed(10,249,10,22,249,22))player.serverLevel().setBlockAndUpdate(p,Blocks.STONE.defaultBlockState());
        c.getSource().sendSuccess(()->net.minecraft.network.chat.Component.literal("Started normal-clock consecutive melee regression"),true);return 1;
    }));}
    @SubscribeEvent public void tick(TickEvent.ServerTickEvent e){
        if(e.phase!=TickEvent.Phase.END || phase<0 || player==null)return;
        int now=e.getServer().getTickCount();
        try{
            if(target==null){
                if(phase>=9){finish();return;}
                target=(LivingEntity)ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation(IDS[phase/3])).create(player.serverLevel());
                target.moveTo(16,250,16,180,0);target.setNoGravity(true);((Mob)target).setNoAi(false);player.serverLevel().addFreshEntity(target);
                player.teleportTo(player.serverLevel(),16,250,12.5,0,0);player.setItemInHand(InteractionHand.MAIN_HAND,weapons[phase%3]==Items.AIR?ItemStack.EMPTY:new ItemStack(weapons[phase%3]));
                hits=0;killed=false;next=now+25;return;
            }
            if(now<next)return;
            if(hits<3){
                var row=new LinkedHashMap<String,Object>();row.put("entity",IDS[phase/3]);row.put("weapon",String.valueOf(ForgeRegistries.ITEMS.getKey(weapons[phase%3])));row.put("hit",hits+1);row.put("serverTick",now);
                row.put("healthBefore",target.getHealth());row.put("maxHealth",target.getMaxHealth());row.put("invulnerableTimeBefore",target.invulnerableTime);row.put("hurtTimeBefore",target.hurtTime);row.put("targetInvulnerable",target.isInvulnerable());row.put("attackStrength",player.getAttackStrengthScale(0));
                var nbt=new net.minecraft.nbt.CompoundTag();target.saveWithoutId(nbt);row.put("activated",nbt.getBoolean("Activated"));
                player.attack(target);
                row.put("healthAfter",target.getHealth());row.put("invulnerableTimeAfter",target.invulnerableTime);row.put("hurtTimeAfter",target.hurtTime);rows.add(row);hits++;next=now+25;
            }else if(!killed){
                target.hurt(player.serverLevel().damageSources().playerAttack(player),1000);killed=true;next=now+25;
            }else{
                report.put(IDS[phase/3]+"-"+(phase%3)+"-deathRemoved",target.isRemoved());target.discard();target=null;phase++;
            }
        }catch(Exception ex){report.put("ERROR",ex.toString());try{finish();}catch(Exception ignored){}}
    }
    private void finish()throws Exception{
        report.put("consecutiveHits",rows);
        report.put("noTargetCooldownResets",true);report.put("attackSpacingTicks",25);
        boolean meleePass=rows.size()==27 && rows.stream().allMatch(r->((Number)r.get("healthAfter")).floatValue()<((Number)r.get("healthBefore")).floatValue() && ((Number)r.get("invulnerableTimeBefore")).intValue()==0);
        report.put("consecutiveMeleePassed",meleePass);
        var spiders=new ArrayList<Map<String,Object>>();
        for(var id:SpiderBalance.TARGETS){
            var spider=(LivingEntity)ForgeRegistries.ENTITY_TYPES.getValue(id).create(player.serverLevel());float base=spider.getMaxHealth();spider.setPos(32,250,16);if(spider instanceof Mob mob)mob.setNoAi(true);spider.setNoGravity(true);player.serverLevel().addFreshEntity(spider);
            // Minecraft clamps MAX_HEALTH to at least 1; the already-one-hit tiny larva stays at 1 HP.
            double expectedMax=Math.max(1.0,base*.75);
            var row=new LinkedHashMap<String,Object>();row.put("entity",id.toString());row.put("originalMax",base);row.put("scaledMax",spider.getMaxHealth());row.put("expectedMaxWithVanillaMinimum",expectedMax);row.put("health75PercentWithinVanillaMinimum",Math.abs(spider.getMaxHealth()-expectedMax)<.01);row.put("idempotent",!SpiderBalance.enforce(spider));
            var saved=new net.minecraft.nbt.CompoundTag();spider.saveWithoutId(saved);var clone=(LivingEntity)ForgeRegistries.ENTITY_TYPES.getValue(id).create(player.serverLevel());clone.load(saved);row.put("reloadNotDoubleScaled",!SpiderBalance.enforce(clone) && Math.abs(clone.getMaxHealth()-spider.getMaxHealth())<.01);clone.discard();
            var victim=net.minecraft.world.entity.EntityType.ZOMBIE.create(player.serverLevel());victim.getAttribute(Attributes.ARMOR).setBaseValue(0);victim.getAttribute(Attributes.MAX_HEALTH).setBaseValue(1000);victim.setHealth(1000);victim.hurt(player.serverLevel().damageSources().mobAttack(spider),8);row.put("damageFromEight",1000-victim.getHealth());row.put("damage75PercentOnce",Math.abs(1000-victim.getHealth()-6)<.01);victim.discard();spider.discard();spiders.add(row);
        }
        report.put("spiders",spiders);report.put("spidersPassed",spiders.size()==26 && spiders.stream().allMatch(r->Boolean.TRUE.equals(r.get("health75PercentWithinVanillaMinimum"))&&Boolean.TRUE.equals(r.get("idempotent"))&&Boolean.TRUE.equals(r.get("reloadNotDoubleScaled"))&&Boolean.TRUE.equals(r.get("damage75PercentOnce"))));
        var pet=(LivingEntity)ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation("arphex:tamed_tarantula")).create(player.serverLevel());float petMax=pet.getMaxHealth();report.put("tamedSpiderUntouched",!SpiderBalance.enforce(pet)&&pet.getMaxHealth()==petMax);pet.discard();
        var vanilla=net.minecraft.world.entity.EntityType.SPIDER.create(player.serverLevel());float vanillaMax=vanilla.getMaxHealth();report.put("vanillaSpiderUntouched",!SpiderBalance.enforce(vanilla)&&vanilla.getMaxHealth()==vanillaMax);vanilla.discard();
        report.put("passed",meleePass && Boolean.TRUE.equals(report.get("spidersPassed")) && Boolean.TRUE.equals(report.get("tamedSpiderUntouched")) && Boolean.TRUE.equals(report.get("vanillaSpiderUntouched")) && !report.containsKey("ERROR"));
        Files.writeString(Path.of("server-combat-102.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));
        player.setInvulnerable(false);player.setGameMode(net.minecraft.world.level.GameType.CREATIVE);phase=-1;
    }
}
