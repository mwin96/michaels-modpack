package net.michaelspack.serverfixes;

/** Current levels and bar, rather than the lifetime counter which enchanting can leave stale. */
public final class CurrentExperience {
    private CurrentExperience() {}
    public static int points(int level, float progress, int nextLevelCost) {
        long l = Math.max(0, level);
        if (l > 25000) return Integer.MAX_VALUE;
        long base = l <= 16 ? l*l+6*l : l <= 31 ? (5*l*l-81*l+720)/2 : (9*l*l-325*l+4440)/2;
        double fraction = Float.isFinite(progress) ? Math.max(0,Math.min(1,progress)) : 0;
        long total = base + Math.round(fraction * Math.max(0,nextLevelCost));
        return (int)Math.min(Integer.MAX_VALUE,Math.max(0,total));
    }
}
