package net.michaelspack.serverfixes;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityMobGriefingEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.UUID;

/** Exact Siren forms only: ordinary weapons, ordinary armor, bounded encounters. */
@Mod.EventBusSubscriber(modid="michaels_server_fixes", bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class SirenBalance {
    public static final String STANDING="siren_head:siren_head";
    public static final String CRAWLING="siren_head:siren_head_crawl_had_to_make_seprate_entity_for_this_ver";
    public static final String SONIC="siren_head:projectile_sonicboom";
    public static final String START="michaels_siren_encounter_start";
    public static final String ACTIVE="michaels_siren_encounter_active";
    public static final int ENCOUNTER_TICKS=600;
    public static final float MAX_PLAYER_HIT=8F;
    private static final double RANGED_RETALIATION_RANGE=96;
    private static final UUID RANGED_FOLLOW=UUID.fromString("774a60b6-b7fb-4fd1-aec5-bee6674f92a9");
    private static final ThreadLocal<Entity> SONIC_CONTEXT=new ThreadLocal<>();

    private SirenBalance() {}
    public static String id(Entity entity) {
        ResourceLocation id=ForgeRegistries.ENTITY_TYPES.getKey(entity.getType());
        return id==null?"":id.toString();
    }
    public static boolean isSiren(Entity entity) {
        return entity!=null && (STANDING.equals(id(entity)) || CRAWLING.equals(id(entity)));
    }
    public static LivingEntity owner(Entity entity) {
        if(isSiren(entity) && entity instanceof LivingEntity living)return living;
        if(entity instanceof Projectile projectile && isSiren(projectile.getOwner()))return (LivingEntity)projectile.getOwner();
        return null;
    }
    public static LivingEntity owner(DamageSource source) {
        LivingEntity owner=owner(source.getEntity());
        return owner!=null?owner:owner(source.getDirectEntity());
    }
    public static Entity pushSonic(Entity projectile) {
        Entity previous=SONIC_CONTEXT.get(); SONIC_CONTEXT.set(projectile); return previous;
    }
    public static void popSonic(Entity previous) {
        if(previous==null)SONIC_CONTEXT.remove();else SONIC_CONTEXT.set(previous);
    }
    public static Entity currentSonic() { return SONIC_CONTEXT.get(); }
    private static boolean playerTarget(Entity target) {
        return target instanceof ServerPlayer player && player.isAlive() && !player.isSpectator() && !player.isCreative();
    }
    public static void beginEncounter(Entity siren) {
        if(!isSiren(siren) || siren.level().isClientSide || siren.isRemoved())return;
        CompoundTag data=siren.getPersistentData();
        if(!data.getBoolean(ACTIVE)) {
            data.putBoolean(ACTIVE,true);
            data.putLong(START,siren.level().getGameTime());
        }
    }
    public static void transferEncounter(Entity original, LivingEntity replacement, float health) {
        if(isSiren(original) && isSiren(replacement)) {
            CompoundTag old=original.getPersistentData(), next=replacement.getPersistentData();
            if(old.getBoolean(ACTIVE)) { next.putBoolean(ACTIVE,true);next.putLong(START,old.getLong(START)); }
            configure(replacement);
            if(original instanceof Mob previous && replacement instanceof Mob current
                    && hasRangedFollow(previous) && previous.getTarget() instanceof ServerPlayer shooter
                    && playerTarget(shooter)) {
                followShot(current,shooter);
            }
        }
        replacement.setHealth(Math.min(health,replacement.getMaxHealth()));
    }
    public static void configure(LivingEntity siren) {
        if(!isSiren(siren) || siren.level().isClientSide || !siren.isAlive())return;
        var maximum=siren.getAttribute(Attributes.MAX_HEALTH);
        if(maximum!=null && maximum.getBaseValue()!=180D) {
            float oldMax=siren.getMaxHealth(), hp=siren.getHealth();
            maximum.setBaseValue(180D);
            siren.setHealth(Math.min(hp,oldMax>0?hp/oldMax*siren.getMaxHealth():siren.getMaxHealth()));
        }
        var attack=siren.getAttribute(Attributes.ATTACK_DAMAGE);
        if(attack!=null && attack.getBaseValue()>8D)attack.setBaseValue(8D);
    }
    private static boolean hasRangedFollow(Mob siren) {
        var range=siren.getAttribute(Attributes.FOLLOW_RANGE);
        return range!=null && range.getModifier(RANGED_FOLLOW)!=null;
    }
    private static void followShot(Mob siren,ServerPlayer shooter) {
        var range=siren.getAttribute(Attributes.FOLLOW_RANGE);
        if(range!=null && range.getModifier(RANGED_FOLLOW)==null && range.getValue()<RANGED_RETALIATION_RANGE) {
            range.addTransientModifier(new AttributeModifier(RANGED_FOLLOW,"Siren ranged retaliation",
                    RANGED_RETALIATION_RANGE-range.getValue(),AttributeModifier.Operation.ADDITION));
        }
        siren.setTarget(shooter);
        beginEncounter(siren);
    }
    public static boolean safeDamage(Entity victim, Entity origin, DamageSource original, float amount) {
        LivingEntity siren=owner(origin);
        if(siren==null) {
            // The native sonic pulse normally has no source entity. Its scoped wrapper supplies one.
            // A manually summoned ownerless Siren projectile cannot damage an unattributable player.
            return !(victim instanceof ServerPlayer) && original!=null && victim.hurt(original,amount);
        }
        if(siren.isRemoved() || !siren.isAlive() || victim==siren)return false;
        if(victim instanceof ServerPlayer)beginEncounter(siren);
        return victim.hurt(siren.damageSources().mobAttack(siren),victim instanceof ServerPlayer?Math.min(amount,MAX_PLAYER_HIT):amount);
    }
    public static int safeCommand(Commands commands, CommandSourceStack source, String command, Entity siren) {
        if("kill @s".equals(command.trim()) && source.getEntity() instanceof ServerPlayer player) {
            return safeDamage(player,siren,null,MAX_PLAYER_HIT)?1:0;
        }
        return commands.performPrefixedCommand(source,command);
    }
    public static void finishEncounter(LivingEntity siren) {
        if(!isSiren(siren) || siren.isRemoved() || !(siren.level() instanceof ServerLevel level))return;
        // Discard owned sonic projectiles before removing the exact killer, preventing a second kill.
        for(Entity entity:level.getAllEntities()) {
            if(SONIC.equals(id(entity)) && owner(entity)==siren)entity.discard();
        }
        SirenNativeState.nativeDeparture(level,siren.getX(),siren.getY(),siren.getZ());
        siren.discard();
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void joined(EntityJoinLevelEvent event) {
        if(!event.getLevel().isClientSide && event.getEntity() instanceof LivingEntity living)configure(living);
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void tick(LivingEvent.LivingTickEvent event) {
        LivingEntity siren=event.getEntity();
        if(!isSiren(siren) || siren.level().isClientSide || siren.isRemoved())return;
        configure(siren);
        if(siren instanceof Mob mob) {
            var target=mob.getTarget();
            if(playerTarget(target))beginEncounter(siren);
            else if(hasRangedFollow(mob))mob.getAttribute(Attributes.FOLLOW_RANGE).removeModifier(RANGED_FOLLOW);
        }
        CompoundTag data=siren.getPersistentData();
        if(data.getBoolean(ACTIVE) && siren.level().getGameTime()-data.getLong(START)>=ENCOUNTER_TICKS)finishEncounter(siren);
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void target(LivingChangeTargetEvent event) {
        if(isSiren(event.getEntity()) && playerTarget(event.getNewTarget()))beginEncounter(event.getEntity());
    }
    @SubscribeEvent(priority=EventPriority.HIGHEST)
    public static void attack(LivingAttackEvent event) {
        if(event.getEntity().level().isClientSide)return;
        if(isSiren(event.getEntity()) && playerTarget(event.getSource().getEntity()))beginEncounter(event.getEntity());
        LivingEntity siren=owner(event.getSource());
        if(siren==null || !(event.getEntity() instanceof ServerPlayer))return;
        beginEncounter(siren);
        if(siren.isRemoved() || !siren.isAlive()) { event.setCanceled(true);return; }
        if(!event.getSource().is(DamageTypes.MOB_ATTACK)) {
            event.setCanceled(true);
            safeDamage(event.getEntity(),siren,null,Math.min(event.getAmount(),MAX_PLAYER_HIT));
        }
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void hurt(LivingHurtEvent event) {
        if(event.getEntity() instanceof ServerPlayer && owner(event.getSource())!=null)
            event.setAmount(Math.min(event.getAmount(),MAX_PLAYER_HIT));
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void damage(LivingDamageEvent event) {
        if(event.getEntity() instanceof ServerPlayer && owner(event.getSource())!=null)
            event.setAmount(Math.min(event.getAmount(),MAX_PLAYER_HIT));
        if(event.getAmount()>0 && event.getEntity() instanceof Mob siren && !siren.level().isClientSide
                && isSiren(siren) && event.getSource().getEntity() instanceof ServerPlayer shooter
                && playerTarget(shooter) && siren.distanceToSqr(shooter)<=RANGED_RETALIATION_RANGE*RANGED_RETALIATION_RANGE) {
            var direct=event.getSource().getDirectEntity();
            if(direct instanceof Projectile || direct!=null && "tacz:bullet".equals(id(direct))) {
                followShot(siren,shooter);
            }
        }
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void death(LivingDeathEvent event) {
        if(event.getEntity() instanceof ServerPlayer) {
            LivingEntity killer=owner(event.getSource());
            if(killer!=null)finishEncounter(killer);
        }
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void grief(EntityMobGriefingEvent event) {
        if(isSiren(event.getEntity()) || SONIC.equals(id(event.getEntity())))event.setResult(Event.Result.DENY);
    }
}
