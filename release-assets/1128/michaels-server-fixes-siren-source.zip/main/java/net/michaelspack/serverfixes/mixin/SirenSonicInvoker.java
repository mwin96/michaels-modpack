package net.michaelspack.serverfixes.mixin;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.gen.Invoker;
@Pseudo
@Mixin(targets="net.meme.sirenhead.procedures.SonicboomWhileProjectileFlyingTickProcedure",remap=false)
public interface SirenSonicInvoker {
    @Invoker(value="execute",remap=false)
    static void invokePulse(LevelAccessor world,double x,double y,double z){throw new AssertionError();}
}
