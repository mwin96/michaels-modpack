package net.michaelspack.serverfixes.mixin;

import net.minecraftforge.event.TickEvent;
import net.michaelspack.serverfixes.EmptyPauseGuard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Weather2 advances world storms from a server event rather than the paused level body. */
@Pseudo
@Mixin(targets="weather2.ServerTickHandler",remap=false)
public abstract class PausedWeatherMixin {
    @Inject(method="tickServer(Lnet/minecraftforge/event/TickEvent$ServerTickEvent;)V",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private static void stopStormTime(TickEvent.ServerTickEvent event,CallbackInfo ci){
        if(EmptyPauseGuard.isPaused(event.getServer())){
            if(EmptyPauseGuard.VALIDATION)EmptyPauseGuard.weatherCallbacksSuppressed++;
            ci.cancel();
        }
    }
}
