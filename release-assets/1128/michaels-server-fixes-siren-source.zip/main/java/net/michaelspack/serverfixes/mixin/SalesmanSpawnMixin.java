package net.michaelspack.serverfixes.mixin;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.eventbus.api.Event;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Disable the pinned salesman procedure before its timer, knock sound or spawn. */
@Pseudo
@Mixin(targets="net.scpo.procedures.SCP1879SpawnConditionProcedure",remap=false)
public abstract class SalesmanSpawnMixin {
    private static final String NATIVE="execute(Lnet/minecraftforge/eventbus/api/Event;Lnet/minecraft/world/level/LevelAccessor;DDDLnet/minecraft/world/entity/Entity;)V";
    @Inject(method=NATIVE,at=@At("HEAD"),cancellable=true,remap=false,require=1,expect=1,allow=1)
    private static void disableSalesman(Event event,LevelAccessor world,double x,double y,double z,Entity entity,CallbackInfo callback) {
        callback.cancel();
    }
}
