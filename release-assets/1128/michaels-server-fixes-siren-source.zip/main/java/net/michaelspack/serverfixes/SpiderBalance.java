package net.michaelspack.serverfixes;

import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/** One persistent health modifier and one outgoing-damage multiplier, for real hostile spiders only. */
public final class SpiderBalance {
    private static final UUID HEALTH_ID=UUID.fromString("4a368ee6-de31-4bdb-b9cd-043ded62d611");
    public static final Set<ResourceLocation> TARGETS=Stream.concat(Stream.of(
        "spider_moth_larvae","spider_larvae","spider_larvae_tiny","spider_brood","spider_flat","spider_lurker","spider_funnel","spider_goliath","spider_moth_summon","spider_moth_summon_larvae","spider_prowler","spider_jump","spider_moth","spider_snatcher","spider_reaper","spider_infestor","spider_ambusher","giant_enemy_spider","spider_recluse","spider_obstructer","spider_lunger","spider_matriarch","spider_matriarch_larvae","spider_sinker").map(id->"arphex:"+id),
        Stream.of("born_in_chaos_v1:mother_spider","born_in_chaos_v1:baby_spider")).map(ResourceLocation::new).collect(Collectors.toUnmodifiableSet());
    public static boolean isTarget(LivingEntity entity){return TARGETS.contains(ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()));}
    public static boolean enforce(LivingEntity entity){
        if(entity.level().isClientSide || !isTarget(entity) || !entity.isAlive() || entity.isDeadOrDying())return false;
        var max=entity.getAttribute(Attributes.MAX_HEALTH);
        if(max==null || max.getModifier(HEALTH_ID)!=null)return false;
        float oldHealth=entity.getHealth(),oldMax=entity.getMaxHealth();
        max.addPermanentModifier(new AttributeModifier(HEALTH_ID,"Michael spider health",-0.25,AttributeModifier.Operation.MULTIPLY_TOTAL));
        float scaled=oldMax>0?oldHealth/oldMax*entity.getMaxHealth():oldHealth;
        entity.setHealth(Math.min(oldHealth,Math.min(entity.getMaxHealth(),scaled)));
        return true;
    }
    @SubscribeEvent(priority=EventPriority.LOWEST) public void joined(EntityJoinLevelEvent e){if(!e.getLevel().isClientSide && e.getEntity() instanceof LivingEntity living)enforce(living);}
    @SubscribeEvent(priority=EventPriority.LOWEST) public void tick(LivingEvent.LivingTickEvent e){enforce(e.getEntity());}
    @SubscribeEvent(priority=EventPriority.LOWEST) public void outgoing(LivingHurtEvent e){
        if(!e.getEntity().level().isClientSide && e.getSource().getEntity() instanceof LivingEntity attacker && isTarget(attacker))e.setAmount(e.getAmount()*0.75F);
    }
}
