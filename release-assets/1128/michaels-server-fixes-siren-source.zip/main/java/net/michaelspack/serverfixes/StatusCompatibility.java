package net.michaelspack.serverfixes;

import java.util.Map;
import net.minecraftforge.network.NetworkConstants;

/** Correct only exact optional-mod list-ping discrepancies proven in native client pings. */
public final class StatusCompatibility {
    private static final Map<String,String> OPTIONAL_CLIENT = Map.of(
        "eternaljesus","1.0.0", "simplytooltips","0.1.5-1.20.1",
        "searchables","1.0.3", "xaerolib","1.7.3",
        "forgeskyboxes","0.0.2-1.20.2", "distanthorizons","2.3.6-b",
        "enhancedcelestials2shaders","1.0.0.5");
    public static void apply(Map<String,String> mods) {
        OPTIONAL_CLIENT.forEach(mods::putIfAbsent);
        for (String id : new String[]{"incontrol","clumps","dungeons_arise",
                "betterfortresses","betterdeserttemples","adorabuild_structures","t_and_t","cristellib"})
            if (mods.containsKey(id)) mods.put(id,NetworkConstants.IGNORESERVERONLY);
    }
}
