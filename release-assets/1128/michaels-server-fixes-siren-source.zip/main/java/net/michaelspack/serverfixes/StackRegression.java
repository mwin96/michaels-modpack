package net.michaelspack.serverfixes;

import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import net.minecraft.commands.Commands;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/** Explicit local-test fixture, registered only with the validation JVM property. */
public final class StackRegression {
    @SubscribeEvent public void attach(net.minecraftforge.event.AttachCapabilitiesEvent<ItemStack> event) {
        if (!event.getObject().is(Items.OAK_LOG)) return;
        event.addCapability(new ResourceLocation("michaels_server_fixes","regression_cap"),new net.minecraftforge.common.capabilities.ICapabilitySerializable<CompoundTag>() {
            private CompoundTag data=new CompoundTag();
            { data.putString("sentinel","preserve-forge-capabilities"); }
            public <T> net.minecraftforge.common.util.LazyOptional<T> getCapability(net.minecraftforge.common.capabilities.Capability<T> capability,net.minecraft.core.Direction side) { return net.minecraftforge.common.util.LazyOptional.empty(); }
            public CompoundTag serializeNBT() { return data.copy(); }
            public void deserializeNBT(CompoundTag tag) { data=tag.copy(); }
        });
    }
    @SubscribeEvent public void command(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("serverstacktest").requires(s -> s.hasPermission(2)).executes(c -> {
            var source=c.getSource();
            var player=source.getServer().getPlayerList().getPlayers().stream().findFirst().orElseThrow();
            var report=new LinkedHashMap<String,Object>();
            var inventory=player.getInventory();
            inventory.clearContent();
            var plain=new ItemStack(Items.OAK_LOG,1);
            var empty=new ItemStack(Items.OAK_LOG,2);empty.setTag(new CompoundTag());
            plain.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER);
            empty.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER);
            var capBefore=empty.save(new CompoundTag()).getCompound("ForgeCaps").copy();
            var named=new ItemStack(Items.OAK_LOG,3);named.getOrCreateTag().putString("meaningful","keep-exactly");
            named.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER);
            var namedBefore=named.save(new CompoundTag()).copy();
            var gunItem=ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacz:modern_kinetic_gun"));
            var gun=new ItemStack(gunItem);gun.getOrCreateTag().putString("GunId","tacz:ak47");gun.getOrCreateTag().putInt("GunCurrentAmmoCount",17);
            gun.getCapability(net.minecraftforge.common.capabilities.ForgeCapabilities.ITEM_HANDLER);
            var gunBefore=gun.save(new CompoundTag()).copy();
            inventory.setItem(0,plain);inventory.setItem(1,empty);inventory.setItem(2,named);inventory.setItem(3,gun);
            report.put("beforeMergeCompatible",ItemStack.isSameItemSameTags(plain,empty));
            report.put("emptyTagInitiallyPresent",empty.getTag()!=null && empty.getTag().isEmpty());
            var carried=new ItemStack(Items.OAK_LOG,4);carried.setTag(new CompoundTag());
            player.containerMenu.setCarried(carried);
            report.put("normalizationChanged",ServerFixes.normalizePlayer(player));
            report.put("emptyTagRemoved",empty.getTag()==null);
            report.put("forgeCapsPresentAndRetained",!capBefore.isEmpty() && capBefore.equals(empty.save(new CompoundTag()).getCompound("ForgeCaps")));
            report.put("carriedTagRemoved",carried.getTag()==null);
            report.put("afterMergeCompatible",ItemStack.isSameItemSameTags(plain,empty));
            player.containerMenu.setCarried(ItemStack.EMPTY);
            player.containerMenu=player.inventoryMenu;
            player.inventoryMenu.clicked(36,0,ClickType.PICKUP,player);
            player.inventoryMenu.clicked(37,0,ClickType.PICKUP,player);
            report.put("actualMenuMergedCount",inventory.getItem(1).getCount());
            report.put("actualMenuSourceEmpty",inventory.getItem(0).isEmpty());
            report.put("actualMenuCarriedEmpty",player.inventoryMenu.getCarried().isEmpty());
            report.put("nonemptyNbtRetainedExactly",namedBefore.equals(named.save(new CompoundTag())));
            report.put("gunNbtRetainedExactly",gunBefore.equals(gun.save(new CompoundTag())));
            report.put("idempotentNoChange",!ServerFixes.normalizePlayer(player));
            var dropped=new ItemStack(Items.OAK_LOG,5);dropped.setTag(new CompoundTag());
            var entity=new ItemEntity(player.serverLevel(),player.getX(),player.getY()+1,player.getZ(),dropped);
            player.serverLevel().addFreshEntity(entity);
            report.put("entityJoinEmptyTagRemoved",entity.getItem().getTag()==null);
            report.put("entityJoinCountPreserved",entity.getItem().getCount()==5);
            entity.discard();
            report.put("player",player.getGameProfile().getName());
            report.put("passed",Boolean.FALSE.equals(report.get("beforeMergeCompatible")) && Boolean.TRUE.equals(report.get("emptyTagInitiallyPresent")) && Boolean.TRUE.equals(report.get("emptyTagRemoved")) && Boolean.TRUE.equals(report.get("forgeCapsPresentAndRetained")) && Boolean.TRUE.equals(report.get("carriedTagRemoved")) && Boolean.TRUE.equals(report.get("afterMergeCompatible")) && Integer.valueOf(3).equals(report.get("actualMenuMergedCount")) && Boolean.TRUE.equals(report.get("actualMenuSourceEmpty")) && Boolean.TRUE.equals(report.get("actualMenuCarriedEmpty")) && Boolean.TRUE.equals(report.get("nonemptyNbtRetainedExactly")) && Boolean.TRUE.equals(report.get("gunNbtRetainedExactly")) && Boolean.TRUE.equals(report.get("idempotentNoChange")) && Boolean.TRUE.equals(report.get("entityJoinEmptyTagRemoved")) && Boolean.TRUE.equals(report.get("entityJoinCountPreserved")));
            try { Files.writeString(Path.of("server-stack-regression.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report)); } catch (Exception ex) { throw new RuntimeException(ex); }
            source.sendSuccess(() -> net.minecraft.network.chat.Component.literal("Server stack regression: "+report),true);
            return Boolean.TRUE.equals(report.get("passed")) ? 1 : 0;
        }));
    }
}
