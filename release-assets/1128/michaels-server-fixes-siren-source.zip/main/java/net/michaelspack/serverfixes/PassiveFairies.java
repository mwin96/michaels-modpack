package net.michaelspack.serverfixes;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Keep the fairy's flight and idle goals, removing only its combat behavior. */
@Mod.EventBusSubscriber(modid="michaels_server_fixes",bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class PassiveFairies {
    private static final ResourceLocation FAIRY=new ResourceLocation("touhou_little_maid","fairy");
    private static final String ATTACK_GOAL="com.github.tartaricacid.touhoulittlemaid.entity.ai.goal.FairyAttackGoal";
    private PassiveFairies() {}
    public static boolean isFairy(Entity entity) {
        return entity!=null && FAIRY.equals(ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()));
    }
    public static boolean pacify(Mob mob) {
        if(!isFairy(mob))return false;
        mob.targetSelector.removeAllGoals(goal->true);
        mob.goalSelector.removeAllGoals(goal->goal.getClass().getName().equals(ATTACK_GOAL));
        mob.setTarget(null);
        mob.setAggressive(false);
        return true;
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void joined(EntityJoinLevelEvent event) {
        if(!event.getLevel().isClientSide && event.getEntity() instanceof Mob mob)pacify(mob);
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void retargeted(LivingChangeTargetEvent event) {
        if(!event.getEntity().level().isClientSide && isFairy(event.getEntity()))event.setNewTarget(null);
    }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void attacking(LivingAttackEvent event) {
        if(!event.getEntity().level().isClientSide && isFairy(event.getSource().getEntity()))event.setCanceled(true);
    }
}
