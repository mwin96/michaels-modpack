package net.michaelspack.serverfixes.mixin;

import net.michaelspack.serverfixes.PackUpdateGate;
import net.minecraft.network.Connection;
import net.minecraftforge.network.ConnectionType;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replace only Forge's existing wrong-protocol/vanilla rejection, never its accept decision. */
@Mixin(value = ServerLifecycleHooks.class, remap = false)
public final class FriendlyLoginRejectMixin {
    @Inject(method = "rejectConnection", at = @At("HEAD"),
            cancellable = true, remap = false, require = 1)
    private static void friendlyProtocolRejection(Connection connection, ConnectionType type,
            String reason, CallbackInfo ci) {
        if (PackUpdateGate.replaceProtocolRejection(connection, reason)) ci.cancel();
    }
}
