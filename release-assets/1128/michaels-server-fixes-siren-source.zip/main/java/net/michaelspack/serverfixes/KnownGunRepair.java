package net.michaelspack.serverfixes;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Repairs the single historical MP5 alias from our loot bundle, without rerolling quality. */
public final class KnownGunRepair {
    public static final String OLD_ID = "tacz:mp5";
    public static final String CORRECT_ID = "tacz:hk_mp5a5";
    public static final String CORRECT_NAME = "tacz.gun.hk_mp5a5.name";
    private static final String ITEM = "tacz:modern_kinetic_gun";
    private static final String FALLBACK_NAME = "item.tacz.modern_kinetic_gun";
    private static final String QUALITY = "MichaelsLootQuality";
    private static final String[] NAMES = {"Common ", "Rare ", "Epic ", "Legendary "};
    private static final String[] COLORS = {"white", "blue", "light_purple", "gold"};

    private KnownGunRepair() {}

    public static boolean repair(ItemStack stack) {
        if (stack == null || stack.isEmpty() || !stack.hasTag()
                || !stack.getTag().contains("GunId", Tag.TAG_STRING)
                || !OLD_ID.equals(stack.getTag().getString("GunId"))) return false;
        ResourceLocation item = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return item != null && ITEM.equals(item.toString()) && repairTag(stack.getTag());
    }

    // Package-private so the standalone fixture can use real NBT without booting Minecraft registries.
    static boolean repairTag(CompoundTag tag) {
        if (tag == null || !tag.contains("GunId", Tag.TAG_STRING) || !OLD_ID.equals(tag.getString("GunId"))) return false;
        tag.putString("GunId", CORRECT_ID);
        if (!tag.contains(QUALITY, Tag.TAG_INT) || !tag.contains("display", Tag.TAG_COMPOUND)) return true;
        int tier = tag.getInt(QUALITY);
        if (tier < 0 || tier >= NAMES.length) return true;
        CompoundTag display = tag.getCompound("display");
        if (!display.contains("Name", Tag.TAG_STRING)) return true;
        try {
            JsonElement parsed = JsonParser.parseString(display.getString("Name"));
            if (!parsed.isJsonObject()) return true;
            JsonObject name = parsed.getAsJsonObject();
            // Recognize ONLY the exact generated quality prefix + generic fallback.
            // A renamed, styled or otherwise custom name is left untouched.
            if (name.size() != 3 || !stringEquals(name, "text", NAMES[tier])
                    || !stringEquals(name, "color", COLORS[tier]) || !name.has("extra")
                    || !name.get("extra").isJsonArray()) return true;
            JsonArray extra = name.getAsJsonArray("extra");
            if (extra.size() != 1 || !extra.get(0).isJsonObject()) return true;
            JsonObject original = extra.get(0).getAsJsonObject();
            if (original.size() != 1 || !stringEquals(original, "translate", FALLBACK_NAME)) return true;
            original.addProperty("translate", CORRECT_NAME);
            display.putString("Name", name.toString());
        } catch (RuntimeException ignored) {
            // A malformed/custom display name never prevents repairing the known model ID.
        }
        return true;
    }

    private static boolean stringEquals(JsonObject object, String key, String expected) {
        JsonElement value = object.get(key);
        return value != null && value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()
                && expected.equals(value.getAsString());
    }
}
