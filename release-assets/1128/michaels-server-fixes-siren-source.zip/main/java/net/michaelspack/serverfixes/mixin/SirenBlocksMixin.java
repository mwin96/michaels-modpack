package net.michaelspack.serverfixes.mixin;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
/** Every direct terrain mutation in the pinned standing/crawling tick procedures is suppressed. */
@Pseudo
@Mixin(targets={"net.meme.sirenhead.procedures.SirentickupdateProcedure","net.meme.sirenhead.procedures.SirenHeadCrawlHadToMakeSeprateEntityForThisVerOnEntityTickUpdateProcedure"},remap=false)
public abstract class SirenBlocksMixin {
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/LevelAccessor;m_46961_(Lnet/minecraft/core/BlockPos;Z)Z"),remap=false,require=1)
    private static boolean retainBlock(LevelAccessor world,BlockPos pos,boolean drops){return false;}
    @Redirect(method="execute",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/LevelAccessor;m_7731_(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"),remap=false,require=1)
    private static boolean retainState(LevelAccessor world,BlockPos pos,BlockState state,int flags){return false;}
}
