package net.michaelspack.serverfixes.mixin;

import java.util.function.BooleanSupplier;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.ForgeEventFactory;
import net.michaelspack.serverfixes.EmptyPauseGuard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Forge emits level events outside ServerLevel.tick, so vanilla's level pause does not stop them. */
@Mixin(value=ForgeEventFactory.class,remap=false)
public abstract class PausedLevelCallbacksMixin {
    @Inject(method={"onPreLevelTick","onPostLevelTick"},at=@At("HEAD"),cancellable=true,remap=false,require=2)
    private static void stopSimulationEvents(Level level,BooleanSupplier haveTime,CallbackInfo ci){
        if(!level.isClientSide && EmptyPauseGuard.isPaused(level.getServer())){
            if(EmptyPauseGuard.VALIDATION)EmptyPauseGuard.levelCallbacksSuppressed++;
            ci.cancel();
        }
    }
}
