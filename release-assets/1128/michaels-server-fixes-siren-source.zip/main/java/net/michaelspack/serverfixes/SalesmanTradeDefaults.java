package net.michaelspack.serverfixes;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.common.capabilities.Capability;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Selects one native offer only when the player's newly opened menu has none. */
public final class SalesmanTradeDefaults {
    private static final Logger LOG=LoggerFactory.getLogger("michaels_server_fixes");
    private static Access access;
    private static boolean warned;
    private SalesmanTradeDefaults() {}
    @SuppressWarnings("unchecked")
    private static Access access() throws ReflectiveOperationException {
        if (access!=null) return access;
        Class<?> vars=Class.forName("net.scpo.network.ScpoModVariables");
        Class<?> state=Class.forName("net.scpo.network.ScpoModVariables$PlayerVariables");
        Capability<Object> capability=(Capability<Object>)vars.getField("PLAYER_VARIABLES_CAPABILITY").get(null);
        Field[] offers={state.getField("randomizer_salesman"),state.getField("randomizer_salesman_2"),state.getField("randomizer_salesman_3")};
        Method[] choose=new Method[3];
        String[] categories={"Safe","Euclid","Keter"};
        for(int i=0;i<3;i++) choose[i]=Class.forName("net.scpo.procedures.SCP1879"+categories[i]+"ClickProcedure").getMethod("execute",Entity.class);
        access=new Access(capability,state.getField("SelectedSale"),offers,choose);
        return access;
    }
    public static void ensureOffer(Entity source) {
        if (!(source instanceof ServerPlayer player) || !player.containerMenu.getClass().getName().equals("net.scpo.world.inventory.SCP1879GUIMenu")) return;
        try {
            Access a=access();Object state=player.getCapability(a.capability).resolve().orElse(null);
            if (state==null) return;
            double selected=a.selected.getDouble(state);
            int category=selected==1D?1:selected==2D?2:0;
            double offer=a.offers[category].getDouble(state);
            int maxOffer=category==0?30:category==1?26:9;
            if (selected>=0D && selected<=2D && selected==Math.rint(selected) && Double.isFinite(offer) && offer>=1D && offer<=maxOffer && offer==Math.rint(offer)) return;
            a.choose[category].invoke(null,player);
        } catch (ReflectiveOperationException | ClassCastException failure) {
            if (!warned) { warned=true; LOG.warn("Could not initialize the Salesman offer; native category buttons remain available.",failure); }
        }
    }
    private record Access(Capability<Object> capability,Field selected,Field[] offers,Method[] choose) {}
}
