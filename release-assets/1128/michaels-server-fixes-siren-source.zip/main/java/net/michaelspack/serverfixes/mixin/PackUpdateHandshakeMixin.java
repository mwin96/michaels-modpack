package net.michaelspack.serverfixes.mixin;

import java.util.function.Supplier;
import net.michaelspack.serverfixes.PackUpdateGate;
import net.minecraftforge.network.HandshakeHandler;
import net.minecraftforge.network.HandshakeMessages;
import net.minecraftforge.network.NetworkEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Exact Forge47.4.28 route: no required channel, no modified registry or gameplay packets. */
@Mixin(value = HandshakeHandler.class, remap = false)
public final class PackUpdateHandshakeMixin {
    @Inject(method = "handleClientModListOnServer", at = @At("HEAD"),
            cancellable = true, remap = false, require = 1)
    private void friendlyOutdatedClient(HandshakeMessages.C2SModListReply message,
            Supplier<NetworkEvent.Context> context, CallbackInfo ci) {
        if (PackUpdateGate.rejectOutdated(context.get().getNetworkManager(),
                message.getModList(), message.getChannels())) {
            context.get().setPacketHandled(true);
            ci.cancel();
        }
    }
}
