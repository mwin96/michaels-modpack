package net.michaelspack.serverfixes;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import io.netty.channel.socket.DuplexChannel;
import io.netty.util.AttributeKey;
import io.netty.util.ReferenceCountUtil;
import net.minecraft.network.Connection;
import net.minecraft.network.ConnectionProtocol;
import net.minecraft.network.PacketSendListener;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.login.ClientboundLoginDisconnectPacket;
import net.minecraft.network.protocol.login.ClientboundCustomQueryPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.network.ServerLoginPacketListenerImpl;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

/** Read the optional client marker before Forge can replace the reason with its channel mismatch UI. */
public final class PackUpdateGate {
    public static final ResourceLocation VERSION_MARKER =
            new ResourceLocation("michaels_client_fixes", "pack_version");
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final AttributeKey<Boolean> REJECTED =
            AttributeKey.valueOf("michaels_server_fixes:update_rejected");

    private PackUpdateGate() {}

    /** Only set after the update policy has already rejected this remote connection. */
    public static boolean isRejected(Connection connection) {
        return connection.channel() != null && Boolean.TRUE.equals(connection.channel().attr(REJECTED).get());
    }

    public static boolean rejectOutdated(Connection connection, List<String> clientMods,
            Map<ResourceLocation, String> channels) {
        // Never affect an integrated server's in-process single-player connection.
        if (connection.isMemoryConnection()) return false;
        String version = channels.get(VERSION_MARKER);
        if (PackUpdatePolicy.allows(PackUpdateConfig.ENABLED.get(),
                clientMods.contains("michaels_client_fixes"), version,
                PackUpdateConfig.MINIMUM_CLIENT_UI_VERSION.get())) return false;
        LOGGER.info("Michael's Modpack update required: client marker {}, minimum {}",
                version == null ? "absent" : version, PackUpdateConfig.MINIMUM_CLIENT_UI_VERSION.get());
        disconnectLogin(connection, friendlyReason());
        return true;
    }

    public static boolean replaceProtocolRejection(Connection connection, String originalReason) {
        if (!PackUpdateConfig.ENABLED.get() || connection.isMemoryConnection()) return false;
        LOGGER.info("Michael's Modpack update guidance for Forge login rejection: {}", originalReason);
        // Forge invokes this route before it has installed the normal login packet listener.
        connection.setProtocol(ConnectionProtocol.LOGIN);
        disconnectLogin(connection, friendlyReason());
        return true;
    }

    public static Component friendlyReason() {
        String instruction = "Michael's Modpack needs an update.\n\n"
                + "Close Minecraft, then download and run the latest updater:\n"
                + PackUpdateConfig.UPDATE_DOWNLOAD_URL.get()
                + "\n\nReopen the modpack and reconnect after updating.";
        // Old1.20.1 clients display the fallback. New UI detects the key without a visible technical marker.
        return Component.translatableWithFallback("michaels.update.required", instruction);
    }

    private static void disconnectLogin(Connection connection, Component reason) {
        if (connection.getPacketListener() instanceof ServerLoginPacketListenerImpl) {
            var channel = connection.channel();
            if (channel.attr(REJECTED).setIfAbsent(Boolean.TRUE) != null) return;
            channel.eventLoop().execute(() -> {
                if (!channel.isOpen()) return;
                connection.setProtocol(ConnectionProtocol.LOGIN);
                // Run after Forge's queued protocol/auto-read update. Only this already-rejected
                // channel is drained; no further bytes reach a login/authentication decoder.
                channel.eventLoop().execute(() -> {
                    if (!channel.isOpen()) return;
                    var packet = new ClientboundLoginDisconnectPacket(reason);
                    var timeout = channel.eventLoop().schedule(() -> connection.disconnect(reason), 10, TimeUnit.SECONDS);
                    channel.closeFuture().addListener(closed -> timeout.cancel(false));
                    channel.pipeline().addBefore("splitter", "michaels_update_rejected_drain", new ChannelInboundHandlerAdapter() {
                        @Override public void channelRead(ChannelHandlerContext context, Object message) {
                            ReferenceCountUtil.release(message);
                        }
                    });
                    channel.pipeline().addBefore("packet_handler", "michaels_update_rejected_outbound", new ChannelOutboundHandlerAdapter() {
                        @Override public void write(ChannelHandlerContext context, Object message, ChannelPromise promise) throws Exception {
                            if (message == packet) {
                                super.write(context, message, promise);
                            } else {
                                // Forge's LoginWrapper creates a new buffer for each query. A
                                // dropped query never reaches its encoder, so release it here.
                                if (message instanceof ClientboundCustomQueryPacket query) ReferenceCountUtil.release(query.getData());
                                ReferenceCountUtil.release(message);
                                promise.trySuccess();
                            }
                        }
                    });
                    channel.config().setAutoRead(true);
                    channel.writeAndFlush(packet).addListener(future -> {
                        if (!future.isSuccess()) {
                            LOGGER.warn("Friendly login instruction write failed: {}",
                                    future.cause() == null ? "unknown" : future.cause().getClass().getSimpleName());
                            connection.disconnect(reason);
                        } else if (channel instanceof DuplexChannel duplex) {
                            // FIN follows the actual flushed instruction. Keep input drained until
                            // peer EOF; a full close with unread pipelined replies can send TCP RST.
                            duplex.shutdownOutput().addListener(shutdown -> {
                                if (!shutdown.isSuccess()) connection.disconnect(reason);
                            });
                        } else {
                            connection.disconnect(reason);
                        }
                    });
                });
            });
            return;
        }
        // Keep the native login protocol and flush the reason before closing the channel.
        connection.send(new ClientboundLoginDisconnectPacket(reason),
                PacketSendListener.thenRun(() -> connection.disconnect(reason)));
        connection.setReadOnly();
    }
}
