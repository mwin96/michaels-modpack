package net.michaelspack.serverfixes.mixin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
/** Halving the single native cooldown decrement doubles configured cooldown cadence. */
@Pseudo
@Mixin(targets="net.meme.sirenhead.procedures.SpawncooldowntimerProcedure",remap=false)
public abstract class SirenCooldownMixin {
    @ModifyConstant(method="execute(Lnet/minecraftforge/eventbus/api/Event;Lnet/minecraft/world/level/LevelAccessor;)V",constant=@Constant(doubleValue=1.0D),remap=false,require=1,expect=1,allow=1)
    private static double halfNativeCooldownSpeed(double step){return step*0.5D;}
}
