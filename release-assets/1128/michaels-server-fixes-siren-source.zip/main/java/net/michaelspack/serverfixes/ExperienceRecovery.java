package net.michaelspack.serverfixes;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.level.GameRules;

/** Keep items/armour under keepInventory, but drop current XP as one ordinary recoverable orb. */
public final class ExperienceRecovery {
    private ExperienceRecovery() {}
    public static int currentExperience(ServerPlayer player) {
        return CurrentExperience.points(player.experienceLevel,player.experienceProgress,player.getXpNeededForNextLevel());
    }
    public static void drop(ServerPlayer player) {
        if (player.isSpectator() || !player.serverLevel().getGameRules().getBoolean(GameRules.RULE_KEEPINVENTORY)) return;
        int amount = currentExperience(player);
        if (amount == 0) return;
        // A single native orb avoids allocating thousands of entities for high level players.
        var orb = new ExperienceOrb(player.serverLevel(),player.getX(),player.getY(),player.getZ(),amount);
        if (!player.serverLevel().addFreshEntity(orb)) return; // Retain XP if another mod refuses the drop.
        player.experienceLevel = 0;
        player.experienceProgress = 0;
        player.totalExperience = 0;
    }
}
