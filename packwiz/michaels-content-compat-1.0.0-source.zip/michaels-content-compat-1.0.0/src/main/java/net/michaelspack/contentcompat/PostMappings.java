package net.michaelspack.contentcompat;
import java.util.Map;
public final class PostMappings {
    private PostMappings() {}
    public static final Map<String, String> IDS = Map.ofEntries(
        Map.entry("quark:acacia_post", "minecraft:acacia_log"),
        Map.entry("quark:ancient_post", "quark:ancient_log"),
        Map.entry("quark:azalea_post", "quark:azalea_log"),
        Map.entry("quark:bamboo_post", "minecraft:bamboo_block"),
        Map.entry("quark:birch_post", "minecraft:birch_log"),
        Map.entry("quark:blossom_post", "quark:blossom_log"),
        Map.entry("quark:cherry_post", "minecraft:cherry_log"),
        Map.entry("quark:crimson_post", "minecraft:crimson_stem"),
        Map.entry("quark:dark_oak_post", "minecraft:dark_oak_log"),
        Map.entry("quark:jungle_post", "minecraft:jungle_log"),
        Map.entry("quark:mangrove_post", "minecraft:mangrove_log"),
        Map.entry("quark:oak_post", "minecraft:oak_log"),
        Map.entry("quark:spruce_post", "minecraft:spruce_log"),
        Map.entry("quark:stripped_acacia_post", "minecraft:stripped_acacia_log"),
        Map.entry("quark:stripped_ancient_post", "quark:stripped_ancient_log"),
        Map.entry("quark:stripped_azalea_post", "quark:stripped_azalea_log"),
        Map.entry("quark:stripped_bamboo_post", "minecraft:stripped_bamboo_block"),
        Map.entry("quark:stripped_birch_post", "minecraft:stripped_birch_log"),
        Map.entry("quark:stripped_blossom_post", "quark:stripped_blossom_log"),
        Map.entry("quark:stripped_cherry_post", "minecraft:stripped_cherry_log"),
        Map.entry("quark:stripped_crimson_post", "minecraft:stripped_crimson_stem"),
        Map.entry("quark:stripped_dark_oak_post", "minecraft:stripped_dark_oak_log"),
        Map.entry("quark:stripped_jungle_post", "minecraft:stripped_jungle_log"),
        Map.entry("quark:stripped_mangrove_post", "minecraft:stripped_mangrove_log"),
        Map.entry("quark:stripped_oak_post", "minecraft:stripped_oak_log"),
        Map.entry("quark:stripped_spruce_post", "minecraft:stripped_spruce_log"),
        Map.entry("quark:stripped_warped_post", "minecraft:stripped_warped_stem"),
        Map.entry("quark:warped_post", "minecraft:warped_stem"));
}
