package net.michaelspack.contentcompat;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.MissingMappingsEvent;
import org.slf4j.Logger;
import java.util.List;

@Mod("michaels_content_compat")
public final class ContentCompat {
    private static final Logger LOG = LogUtils.getLogger();
    public static final ForgeConfigSpec.BooleanValue ALLOW_RETIRED_RATS_MAPPINGS;
    private static final ForgeConfigSpec CONFIG;
    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        ALLOW_RETIRED_RATS_MAPPINGS = builder.comment(
            "OFF by default. Enable only for an offline-audited, migrated host world.",
            "This allows dropping historical rats registry entries; it does not migrate any saved content.",
            "Do not enable for arbitrary existing personal worlds.")
            .define("allowRetiredRatsMappings", false);
        CONFIG = builder.build();
    }

    public ContentCompat() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, CONFIG, "michaels-content-compat-common.toml");
        MinecraftForge.EVENT_BUS.addListener(ContentCompat::missingMappings);
    }

    private static void missingMappings(MissingMappingsEvent event) {
        int remapped = 0;
        for (MissingMappingsEvent.Mapping<Block> mapping : event.getMappings(ForgeRegistries.Keys.BLOCKS, "quark")) {
            String target = PostMappings.IDS.get(mapping.getKey().toString());
            if (target != null) {
                Block block = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(target));
                if (block == null || !ForgeRegistries.BLOCKS.containsKey(new ResourceLocation(target))) {
                    mapping.fail();
                    throw new IllegalStateException("Retired post destination is absent: " + target);
                }
                mapping.remap(block);
                remapped++;
            }
        }
        for (MissingMappingsEvent.Mapping<Item> mapping : event.getMappings(ForgeRegistries.Keys.ITEMS, "quark")) {
            String target = PostMappings.IDS.get(mapping.getKey().toString());
            if (target != null) {
                Item item = ForgeRegistries.ITEMS.getValue(new ResourceLocation(target));
                if (item == null || !ForgeRegistries.ITEMS.containsKey(new ResourceLocation(target))) {
                    mapping.fail();
                    throw new IllegalStateException("Retired post item destination is absent: " + target);
                }
                mapping.remap(item);
                remapped++;
            }
        }
        if (remapped > 0) LOG.info("Remapped {} retired Quark post entries in {}", remapped, event.getKey().location());
        if (ALLOW_RETIRED_RATS_MAPPINGS.get()) ignoreVerifiedRetiredRats(event);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void ignoreVerifiedRetiredRats(MissingMappingsEvent event) {
        List<MissingMappingsEvent.Mapping<?>> mappings = (List) event.getMappings((ResourceKey) event.getKey(), "rats");
        for (MissingMappingsEvent.Mapping<?> mapping : mappings) mapping.ignore();
        if (!mappings.isEmpty()) LOG.warn("Verified-migration opt-in: ignored {} historical Rats mappings in {}", mappings.size(), event.getKey().location());
    }
}
