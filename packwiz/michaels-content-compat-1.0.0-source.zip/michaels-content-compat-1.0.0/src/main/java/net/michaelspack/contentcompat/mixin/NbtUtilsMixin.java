package net.michaelspack.contentcompat.mixin;

import net.minecraft.core.HolderGetter;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.michaelspack.contentcompat.PostMappings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(NbtUtils.class)
public abstract class NbtUtilsMixin {
    @Inject(method = "readBlockState", at = @At("HEAD"), cancellable = true)
    private static void michaels$translateRetiredPost(HolderGetter<Block> blocks, CompoundTag input, CallbackInfoReturnable<BlockState> result) {
        String replacement = PostMappings.IDS.get(input.getString("Name"));
        if (replacement == null) return;
        CompoundTag translated = input.copy();
        translated.putString("Name", replacement);
        String axis = input.getCompound("Properties").getString("axis");
        if (!axis.equals("x") && !axis.equals("y") && !axis.equals("z")) axis = "y";
        CompoundTag properties = new CompoundTag();
        properties.putString("axis", axis);
        translated.put("Properties", properties);
        // Destinations are retained log/stem/block names, never keys in the map.
        // Exactly one recursive call reaches the unchanged native lookup.
        result.setReturnValue(NbtUtils.readBlockState(blocks, translated));
    }
}
