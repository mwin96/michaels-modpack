# Michael's content compatibility1.0.0

Original MIT common client/server helper for Minecraft1.20.1 / Forge47.4.28 / Java17. It registers no blocks, items, states, entities or network channels.

`post-mappings.json` is the exact28-name contract. A HEAD injection into native `NbtUtils.readBlockState` copies only a matching retired post tag, translates its name, keeps its x/y/z axis and discards post-only connection/water properties. It invokes the original lookup once with the destination, which is never another retired key. Unrelated inputs and the caller's original compound are untouched. This covers saved palettes and future IDAS structure templates without modifying publisher JARs or templates. Logs are thicker than posts by explicit user choice.

Forge missing-mapping handling remaps only those28 Quark block/item names to registered retained logs/stems/bamboo blocks; absent destinations fail. Custom ancient/azalea/blossom logs remain Quark content.

`config/michaels-content-compat-common.toml` has `allowRetiredRatsMappings=false` by default. Only the explicitly audited/migrated host fixture may set it true. That flag ignores orphaned historical Rats registry entries; it does **not** migrate a world, retire an entity, empty an inventory or change a block. Arbitrary existing personal worlds are not silently approved or purged. The private migration separately checks all saved Rats content, player/build progress, inventories, entities and dimensions.

Reproduce with the cached Java17/ForgeGradle environment: `gradlew --offline build --no-daemon`. The reobfuscated JAR and exact source/license bundle are hash-pinned in the final descriptor. Native validation is a separate private helper, not shipped in this mod.
