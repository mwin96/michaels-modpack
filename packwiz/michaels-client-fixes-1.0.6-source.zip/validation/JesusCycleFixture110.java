import net.michaelspack.clientfixes.BellBudget109;
public final class JesusCycleFixture110 {
 static int checks;
 static void ok(boolean yes,String label){checks++;if(!yes)throw new AssertionError(label);}
 static long s(long seconds){return seconds*1_000_000_000L;}
 public static void main(String[] args){
  BellBudget109 b=new BellBudget109();long t=123_000_000L;
  ok(!b.due(t,false),"ineligible cannot start");ok(!b.admit(t,false),"no creative/healthy admission");
  ok(b.admit(t,true),"first critical starts");ok(b.active(t,true),"image begins immediately");
  ok(b.claimBell(t,true),"first bell shared admission");ok(!b.claimBell(t+1,true),"overlap bell dropped");
  ok(!b.admit(t+s(1),true),"hurt retrigger dropped");ok(b.active(t+s(6)-1,true),"last active nanosecond");
  ok(b.elapsedMillis(t+s(3))==3000,"fade uses elapsed monotonic millis");
  ok(!b.active(t+s(6),true),"exact six-second cutoff");ok(!b.claimBell(t+s(6),true),"no bell at cutoff");
  ok(!b.due(t+s(65),true),"quiet through65");ok(!b.admit(t+s(66)-1,true),"last quiet nanosecond");
  ok(b.admit(t+s(66),true),"automatic repeat exact66");ok(b.claimBell(t+s(66),true),"new window new bell");
  ok(!b.active(t+s(67),false),"heal stops both");ok(!b.active(t+s(68),true),"rehurt cannot resume interrupted window");
  ok(!b.admit(t+s(70),true),"heal keeps cooldown");ok(!b.admit(t+s(132),false),"healthy never auto cycles");
  ok(b.admit(t+s(140),true),"critical after cooldown starts immediately");
  b.reset();ok(!b.active(t+s(141),true),"logout clears window");ok(b.admit(t+s(141),true),"new session fresh admission");
  b.reset();long wrap=Long.MAX_VALUE-s(4);ok(b.admit(wrap,true),"nanoTime near overflow");
  ok(b.active(wrap+s(5),true),"overflow remains active");ok(!b.active(wrap+s(6),true),"overflow cutoff");
  ok(!b.admit(wrap+s(66)-1,true),"overflow quiet");ok(b.admit(wrap+s(66),true),"overflow next cycle");
  b.reset();ok(b.admit(-s(20),true),"negative nanoTime legal");ok(b.active(-s(15),true),"negative-origin active");
  b.reset();for(int cycle=0;cycle<100;cycle++){long now=s(66L*cycle);ok(b.admit(now,true),"repeating critical cycle"+cycle);ok(b.claimBell(now,true),"one bell per cycle"+cycle);ok(!b.active(now+s(6),true),"stop every cycle"+cycle);ok(!b.admit(now+s(65),true),"quiet every cycle"+cycle);}
  System.out.println("{\"passed\":true,\"checks\":"+checks+"}");
 }
}
