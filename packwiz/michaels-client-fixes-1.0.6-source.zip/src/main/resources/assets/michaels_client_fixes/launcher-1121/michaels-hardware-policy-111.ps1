# Fresh policy and one-time graphics review. Dot-sourcing has no side effects.
$script:MichaelsFreshReceipt = 'michaels-fresh-hardware-111:3bb4f0222d890bef:portable-only:v1'
$script:MichaelsFreshMarker = 'config\michaels-fresh-hardware-111.json'
$script:MichaelsHardwareAck = 'config\michaels-hardware-defaults-109.done'
$script:MichaelsMemoryAck = 'config\michaels-memory-106\completed.enabled'

function Get-MichaelsHardwareProfile {
    param($Hardware)
    $ram = [double]$Hardware.totalMemoryBytes / 1GB
    $physical = [int]$Hardware.physicalCores; $logical = [int]$Hardware.logicalProcessors
    $name = [string]$Hardware.primaryAdapter; $vram = [double]$Hardware.dedicatedVideoMemoryBytes / 1GB
    $cpuName = [string]$Hardware.processorName
    $pixels = [long]$Hardware.displayWidth * [long]$Hardware.displayHeight
    $heap = 4096; if ($ram -ge 14) { $heap = 6144 } elseif ($ram -ge 10) { $heap = 5120 }
    $verified = $Hardware.primaryAdapterVerified -eq $true
    $virtual = $name -match '(?i)parsec|software|llvmpipe|basic render|virtual|remote|indirect|spacedesk|displaylink|vmware|citrix'
    $gaming = $name -match '(?i)GeForce\s+(?:GTX\s+(?:9[678]0|10[5678]0|16[356]0)|RTX\s+[2345]\d{3})|Radeon\s+RX\s+\d{3,4}|Arc.*(?:A(?:380|580|750|770)|B(?:570|580))'
    $strong = $name -match '(?i)GeForce\s+RTX\s+(?:20[78]0|30[6789]0|40[6789]0|50[6789]0)|Radeon\s+RX\s+(?:6700|6750|6800|6850|6900|6950|7700|7800|7900|9060|9070)'
    $recentCpu = $cpuName -match '(?i)\b(?:i[3579]-(?:1[2-5]\d{3})|Core(?:\(TM\))?\s+Ultra\s+[579]|Ryzen\s+[3579]\s+[789]\d{3})'
    $highPixelGpu = $name -match '(?i)\b(?:RTX\s+[45]0[789]0|RX\s+(?:7800|7900|9070))\b' -and $vram -ge 12
    $highPixelLoad = $pixels -ge 4400000
    $preferNormal = $highPixelLoad -and (-not $recentCpu -or -not $highPixelGpu)
    $tier='integrated-or-unknown'; $render=4; if($ram -ge 7){$render=6};if($ram -ge 14){$render=8}
    $simulation=4; $dh=32; $shader='OFF'
    if($verified -and -not $virtual -and $gaming -and $vram -ge 2 -and $ram -ge 7 -and $physical -ge 2 -and $logical -ge 4){
        $tier='modest-discrete';$render=8;$shader='Normal'
        if($ram -ge 14 -and $vram -ge 4 -and $physical -ge 4 -and $logical -ge 8){
            $tier='mid-discrete';$render=12;$simulation=6;$dh=64
            if($strong -and $vram -ge 8 -and $physical -ge 6 -and $logical -ge 12 -and -not $preferNormal){$shader='Enhanced'}
        }
        if($ram -ge 28 -and $strong -and $vram -ge 8 -and $physical -ge 6 -and $logical -ge 12 -and -not $preferNormal){
            $tier='strong-discrete';$render=16;$simulation=8;$dh=128;$shader='Enhanced'
        }
    }
    [pscustomobject]@{tier=$tier;heapMiB=$heap;renderDistance=$render;simulationDistance=$simulation;dhRadius=$dh;shader=$shader;displayPixels=$pixels;highPixelLoad=$highPixelLoad;policyRevision='1128'}
}

function Select-MichaelsPhysicalAdapter {
    param($Adapters)
    $candidates=@($Adapters | Where-Object {
        -not $_.Software -and $_.Name -notmatch '(?i)parsec|software|llvmpipe|basic render|virtual|remote|indirect|spacedesk|displaylink|vmware|citrix' -and
        [uint32]$_.VendorId -in @(0x10de,0x1002,0x8086) -and [double]$_.DedicatedBytes -ge 2GB -and
        $_.Name -match '(?i)GeForce\s+(?:GTX|RTX)|Radeon\s+RX|Arc.*(?:A\d{3}|B\d{3})'
    })
    if(-not $candidates.Count){return}
    # Physical enumeration avoids a virtual desktop adapter and WMI's 32-bit VRAM clamp.
    $candidates | Sort-Object -Property @{Expression={[double]$_.DedicatedBytes};Descending=$true} | Select-Object -First 1
}

function Get-MichaelsLocalHardware {
    $ram=0L;$physical=0;$logical=0;$adapters=@();$gpu=$null;$cpuName='';$display=@(0,0)
    try{$ram=[long](Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).TotalPhysicalMemory}catch{}
    try{foreach($cpu in @(Get-CimInstance Win32_Processor -ErrorAction Stop)){
        if(-not $cpuName){$cpuName=[string]$cpu.Name}
        $physical += [int]$cpu.NumberOfCores;$logical += [int]$cpu.NumberOfLogicalProcessors
    }}catch{$physical=0;$logical=0;$cpuName=''}
    try{
        if(-not ('MichaelsHardware1128.Dxgi' -as [type])){
            Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
namespace MichaelsHardware1128 {
 public sealed class Adapter { public string Name; public ulong DedicatedBytes; public uint VendorId; public bool Software; public uint Index; }
 public static class Dxgi {
  [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct Desc1 {
   [MarshalAs(UnmanagedType.ByValTStr,SizeConst=128)] public string Description;
   public uint Vendor,Device,Subsystem,Revision;
   public UIntPtr DedicatedVideo,DedicatedSystem,Shared;
   public uint LuidLow; public int LuidHigh; public uint Flags;
  }
  [DllImport("dxgi.dll",CallingConvention=CallingConvention.StdCall)] static extern int CreateDXGIFactory1(ref Guid iid,out IntPtr factory);
  [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct DisplayMode {
   [MarshalAs(UnmanagedType.ByValTStr,SizeConst=32)] public string DeviceName;
   public ushort SpecVersion,DriverVersion,Size,DriverExtra;
   public uint Fields;
   public int PositionX,PositionY;
   public uint Orientation,FixedOutput;
   public short Color,Duplex,YResolution,TTOption,Collate;
   [MarshalAs(UnmanagedType.ByValTStr,SizeConst=32)] public string FormName;
   public ushort LogPixels;
   public uint BitsPerPel,PelsWidth,PelsHeight,Flags,Frequency,ICMMethod,ICMIntent,MediaType,DitherType,Reserved1,Reserved2,PanningWidth,PanningHeight;
  }
  [DllImport("user32.dll",EntryPoint="EnumDisplaySettingsW",CharSet=CharSet.Unicode,ExactSpelling=true)]
  static extern bool EnumDisplaySettings(string deviceName,int mode,ref DisplayMode result);
  public static int[] PrimaryDisplay() {
   var mode = new DisplayMode();
   mode.Size=(ushort)Marshal.SizeOf(typeof(DisplayMode));
   return EnumDisplaySettings(null,-1,ref mode) ? new[]{(int)mode.PelsWidth,(int)mode.PelsHeight} : new[]{0,0};
  }
  [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int EnumAdapters1(IntPtr self,uint index,out IntPtr adapter);
  [UnmanagedFunctionPointer(CallingConvention.StdCall)] delegate int GetDesc1(IntPtr self,out Desc1 desc);
  static T Method<T>(IntPtr obj,int slot) where T:class {return (T)(object)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(Marshal.ReadIntPtr(obj),slot*IntPtr.Size),typeof(T));}
  public static Adapter[] ReadAll(){
   IntPtr factory=IntPtr.Zero;var result=new List<Adapter>();
   try{Guid iid=new Guid("770aae78-f26f-4dba-a829-253c83d1b387");Marshal.ThrowExceptionForHR(CreateDXGIFactory1(ref iid,out factory));
    for(uint i=0;i<32;i++){IntPtr adapter=IntPtr.Zero;try{int hr=Method<EnumAdapters1>(factory,12)(factory,i,out adapter);if(hr==unchecked((int)0x887A0002))break;Marshal.ThrowExceptionForHR(hr);Desc1 d;Marshal.ThrowExceptionForHR(Method<GetDesc1>(adapter,10)(adapter,out d));result.Add(new Adapter{Name=d.Description,DedicatedBytes=d.DedicatedVideo.ToUInt64(),VendorId=d.Vendor,Software=(d.Flags&2)!=0,Index=i});}finally{if(adapter!=IntPtr.Zero)Marshal.Release(adapter);}}
   }finally{if(factory!=IntPtr.Zero)Marshal.Release(factory);}return result.ToArray();
  }
 }
}
'@ -ErrorAction Stop
        }
        $display=[MichaelsHardware1128.Dxgi]::PrimaryDisplay()
        $adapters=@([MichaelsHardware1128.Dxgi]::ReadAll());$gpu=Select-MichaelsPhysicalAdapter $adapters
    }catch{}
    [pscustomobject]@{totalMemoryBytes=$ram;physicalCores=$physical;logicalProcessors=$logical;processorName=$cpuName;displayWidth=$display[0];displayHeight=$display[1];primaryAdapter=$(if($gpu){$gpu.Name}else{''});dedicatedVideoMemoryBytes=$(if($gpu){$gpu.DedicatedBytes}else{0L});primaryAdapterVerified=($null -ne $gpu);selectionMethod='DXGI physical gaming adapter enumeration';adapters=$adapters}
}

function Assert-MichaelsFreshPath {
    param([string]$Path)
    $cursor = [IO.Path]::GetFullPath($Path)
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            if ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'The fresh setup path cannot contain links.' }
        }
        $parent = Split-Path -Parent $cursor
        if ($parent -eq $cursor) { break }; $cursor = $parent
    }
}

function Get-MichaelsFreshContext {
    param([string]$InstanceDirectory)
    $instance = [IO.Path]::GetFullPath($InstanceDirectory).TrimEnd('\')
    if ((Split-Path -Leaf $instance) -cne 'michaels-modpack') { throw 'Unrecognized fresh profile.' }
    $instances = Split-Path -Parent $instance
    $data = Split-Path -Parent $instances; $root = Split-Path -Parent $data
    if ((Split-Path -Leaf $instances) -cne 'instances' -or (Split-Path -Leaf $data) -cne 'Data') { throw 'Unrecognized fresh profile layout.' }
    Assert-MichaelsFreshPath $instance
    $cfg = Join-Path $instance 'instance.cfg'; $game = Join-Path $instance 'minecraft'
    $receipt = Join-Path $instance 'michaels-fresh-hardware-111.eligible'
    foreach ($owned in @($cfg,$game,$receipt,(Join-Path $root 'Launcher\prismlauncher.exe'))) { Assert-MichaelsFreshPath $owned }
    if (-not [IO.File]::Exists($cfg) -or -not [IO.File]::Exists((Join-Path $root 'Launcher\prismlauncher.exe')) -or
        -not [IO.File]::Exists($receipt) -or [IO.File]::ReadAllText($receipt).Trim() -cne $script:MichaelsFreshReceipt) { return }
    if (-not [IO.Directory]::Exists($game)) { return }
    [pscustomobject]@{Instance=$instance;Root=$root;Game=$game;Cfg=$cfg;Marker=(Join-Path $game $script:MichaelsFreshMarker)}
}

function Write-MichaelsAtomicBytes {
    param([string]$Path,[byte[]]$Bytes)
    Assert-MichaelsFreshPath $Path
    [IO.Directory]::CreateDirectory((Split-Path -Parent $Path)) | Out-Null
    $temp = $Path + '.fresh-' + [Guid]::NewGuid().ToString('N')
    try {
        [IO.File]::WriteAllBytes($temp,$Bytes)
        if ([IO.File]::Exists($Path)) { [IO.File]::Replace($temp,$Path,[NullString]::Value) } else { [IO.File]::Move($temp,$Path) }
    } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
}

function Write-MichaelsAtomicText {
    param([string]$Path,[string]$Text)
    Write-MichaelsAtomicBytes $Path ([Text.UTF8Encoding]::new($false).GetBytes($Text))
}

function Save-MichaelsFreshState {
    param($Context,$State)
    Write-MichaelsAtomicText $Context.Marker (($State | ConvertTo-Json -Depth 12) + "`n")
}

function Read-MichaelsFreshState {
    param($Context)
    Assert-MichaelsFreshPath $Context.Marker
    if (-not [IO.File]::Exists($Context.Marker)) { return }
    $state = [IO.File]::ReadAllText($Context.Marker) | ConvertFrom-Json
    if ($state.schema -ne 1 -or $state.receipt -cne $script:MichaelsFreshReceipt -or
        @('prepared','applied') -cnotcontains $state.state -or
        @('integrated-or-unknown','modest-discrete','mid-discrete','strong-discrete') -cnotcontains $state.profile.tier -or
        @(4096,5120,6144) -notcontains [int]$state.profile.heapMiB -or
        @(4,6,8,12,16) -notcontains [int]$state.profile.renderDistance -or @(4,6,8) -notcontains [int]$state.profile.simulationDistance -or
        @(32,64,128) -notcontains [int]$state.profile.dhRadius -or @('OFF','Normal','Enhanced') -cnotcontains $state.profile.shader) {
        throw 'The fresh setup record is invalid; existing settings were left alone.'
    }
    if ($state.state -ceq 'prepared' -and $state.instance -ine $Context.Instance) {
        throw 'The unfinished fresh setup moved. Return it to its original folder to resume safely.'
    }
    return $state
}

function Get-MichaelsSingleIniValue {
    param([string]$Text,[string]$Key)
    $matches = [regex]::Matches($Text,'(?m)^' + [regex]::Escape($Key) + '=([^\r\n]*)\r?$')
    if ($matches.Count -ne 1) { throw "The fresh profile has an ambiguous $Key setting." }
    return $matches[0].Groups[1].Value
}

function Set-MichaelsFreshHeap {
    param($Context,$State)
    if (-not $State.memoryPending) { return }
    $cfg = [IO.File]::ReadAllText($Context.Cfg)
    $current = Get-MichaelsSingleIniValue $cfg 'MaxMemAlloc'
    # Only the shipped conservative value is eligible. Any explicit choice wins, even >6GB.
    if ($current -ceq '4096' -and $State.originalHeap -ceq '4096') {
        $next = [regex]::Replace($cfg,'(?m)^MaxMemAlloc=4096(?=\r?$)',('MaxMemAlloc=' + $State.profile.heapMiB))
        if ($next -cne $cfg) { Write-MichaelsAtomicText $Context.Cfg $next }
        $State.memoryResult = 'selected-before-prism'
    } else { $State.memoryResult = 'explicit-profile-choice-preserved' }
    $State.memoryPending = $false
    Save-MichaelsFreshState $Context $State
}

function Start-MichaelsFreshHardware {
    param([string]$InstanceDirectory,[switch]$BeforePrism)
    $context = Get-MichaelsFreshContext $InstanceDirectory
    if (-not $context) { return }
    $state = Read-MichaelsFreshState $context
    if ($state) {
        # A completed portable pack may move. Its old choices remain final; do not
        # reapply pending defaults or rewrite preferences at the new location.
        if ($state.state -ceq 'applied' -and $state.instance -ine $context.Instance) { return $state }
        if ($BeforePrism) { Set-MichaelsFreshHeap $context $state }
        return $state
    }
    # Content/state of any kind means existing installation. Never infer freshness from version.
    $allowed = @('packwiz-installer-bootstrap.jar','packwiz-installer.jar')
    $children = @(Get-ChildItem -LiteralPath $context.Game -Force)
    if ($children.Count -ne 2 -or @($children | Where-Object { $_.PSIsContainer -or $allowed -cnotcontains $_.Name }).Count) { return }
    $pins = @{'packwiz-installer-bootstrap.jar'='a8fbb24dc604278e97f4688e82d3d91a318b98efc08d5dbfcbcbcab6443d116c';'packwiz-installer.jar'='c9f646908d340d84773948a9a7d98bc1dae250d35e1016dc6e2b8459760b5598'}
    foreach ($name in $allowed) {
        if ((Get-FileHash -LiteralPath (Join-Path $context.Game $name) -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pins[$name]) { throw 'The fresh setup bootstrap files do not match.' }
    }
    $cfg = [IO.File]::ReadAllText($context.Cfg)
    if ($cfg -notmatch '(?m)^OverrideMemory=true\r?$' -or $cfg -notmatch 'michaels-prelaunch-111.ps1') { return }
    $original = Get-MichaelsSingleIniValue $cfg 'MaxMemAlloc'
    $profile = Get-MichaelsHardwareProfile (Get-MichaelsLocalHardware)
    $state = [pscustomobject]@{schema=1;receipt=$script:MichaelsFreshReceipt;instance=$context.Instance;state='prepared';profile=$profile;originalHeap=$original;memoryPending=$true;memoryResult='deferred-until-play';postInstallResult=$null}
    # Persist proof before bootstrap creates content, so an interrupted download may resume.
    Save-MichaelsFreshState $context $state
    if ($BeforePrism) { Set-MichaelsFreshHeap $context $state }
    return $state
}

function Set-MichaelsFreshLine {
    param([string]$Text,[string]$Key,[string]$Baseline,[string]$Value,[string]$Separator='=')
    $pattern = '(?m)^' + [regex]::Escape($Key + $Separator) + [regex]::Escape($Baseline) + '(?=\r?$)'
    $all = [regex]::Matches($Text,'(?m)^' + [regex]::Escape($Key + $Separator) + '[^\r\n]*(?=\r?$)')
    if ($all.Count -ne 1) { throw "The fresh $Key setting is ambiguous or missing." }
    return [regex]::Replace($Text,$pattern,($Key + $Separator + $Value))
}

function Complete-MichaelsFreshHardware {
    param([string]$InstanceDirectory)
    $context = Get-MichaelsFreshContext $InstanceDirectory
    if (-not $context) { return }
    $state = Read-MichaelsFreshState $context
    if (-not $state -or $state.state -ceq 'applied') { return }
    $p = $state.profile
    $paths = @((Join-Path $context.Game 'options.txt'),(Join-Path $context.Game 'config\DistantHorizons.toml'),(Join-Path $context.Game 'config\oculus.properties'))
    foreach ($path in $paths) { Assert-MichaelsFreshPath $path; if (-not [IO.File]::Exists($path)) { throw 'The fresh pack download is incomplete; Play will retry it.' } }
    $old = @(); foreach ($path in $paths) { $old += ,([IO.File]::ReadAllBytes($path)) }
    $texts = @(); foreach ($raw in $old) { $texts += [Text.UTF8Encoding]::new($false,$true).GetString($raw) }
    $options = Set-MichaelsFreshLine $texts[0] 'renderDistance' '6' ([string]$p.renderDistance) ':'
    $options = Set-MichaelsFreshLine $options 'simulationDistance' '6' ([string]$p.simulationDistance) ':'
    if ($p.tier -in @('mid-discrete','strong-discrete') -and $options -match '(?m)^graphicsMode:0\r?$') {
        $options = Set-MichaelsFreshLine $options 'graphicsMode' '0' '1' ':'
    }
    # Only the exact owned quality table/key is changed; all other TOML bytes survive.
    $dh = $texts[1]; $sectionPattern = '(?ms)(^\[client\.advanced\.graphics\.quality\]\r?\n)(.*?)(?=^\[|\z)'
    $sections = [regex]::Matches($dh,$sectionPattern)
    if ($sections.Count -ne 1) { throw 'The fresh LOD configuration is ambiguous.' }
    $body = $sections[0].Groups[2].Value
    $key = [regex]::Matches($body,'(?m)^lodChunkRenderDistanceRadius\s*=\s*([^\r\n#]*)(?:[^\r\n]*)\r?$')
    if ($key.Count -ne 1) { throw 'The fresh LOD distance is ambiguous.' }
    if ($key[0].Groups[1].Value.Trim() -ceq '32') {
        $nextBody = [regex]::Replace($body,'(?m)^(lodChunkRenderDistanceRadius\s*=\s*)32(?=\s*(?:#.*)?\r?$)',('${1}' + $p.dhRadius))
        $dh = $dh.Substring(0,$sections[0].Groups[2].Index) + $nextBody + $dh.Substring($sections[0].Groups[2].Index+$body.Length)
    }
    $oculus = $texts[2]
    $enabled = Get-MichaelsSingleIniValue $oculus 'enableShaders'
    $shader = Get-MichaelsSingleIniValue $oculus 'shaderPack'
    if ($enabled -ceq 'true' -and $shader -ceq 'MakeUp-UltraFast-9.6.zip') {
        if ($p.shader -ceq 'OFF') { $oculus = Set-MichaelsFreshLine $oculus 'enableShaders' 'true' 'false' }
        elseif ($p.shader -ceq 'Enhanced') { $oculus = Set-MichaelsFreshLine $oculus 'shaderPack' 'MakeUp-UltraFast-9.6.zip' 'MakeUp-UltraFast-9.6-Enhanced.zip' }
    }
    $next = @($options,$dh,$oculus)
    $ackPaths = @((Join-Path $context.Game $script:MichaelsHardwareAck),(Join-Path $context.Game $script:MichaelsMemoryAck))
    $ackText = "Fresh1.0.11 hardware policy completed; later manual choices remain yours.`n"
    foreach ($ack in $ackPaths) {
        Assert-MichaelsFreshPath $ack
        if ([IO.File]::Exists($ack) -and [IO.File]::ReadAllText($ack) -cne $ackText) { throw 'Unexpected existing migration acknowledgement in fresh setup.' }
    }
    $written = 0; $createdAcks = @()
    try {
        for ($i=0;$i -lt $paths.Count;$i++) { Write-MichaelsAtomicText $paths[$i] $next[$i]; $written++ }
        foreach ($ack in $ackPaths) {
            if (-not [IO.File]::Exists($ack)) { Write-MichaelsAtomicText $ack $ackText; $createdAcks += $ack }
        }
        $state.state = 'applied'; $state.postInstallResult = 'fresh-only-before-first-game-resources'
        Save-MichaelsFreshState $context $state
    } catch {
        for ($i=0;$i -lt $written;$i++) { Write-MichaelsAtomicBytes $paths[$i] $old[$i] }
        foreach ($ack in $createdAcks) { [IO.File]::Delete($ack) }
        throw
    }
}

# Keep the legacy entry point used by existing portable launchers.
# Heap, audio, controls and every later manual graphics choice are outside this pass.
function Set-MichaelsReviewKey1121 {
    param([string]$Text,[string]$Key,[string]$Value,[string]$Separator='=')
    $pattern='(?m)^([ \t]*'+[regex]::Escape($Key)+'[ \t]*'+[regex]::Escape($Separator)+'[ \t]*)([^\r\n]*)(\r?)$'
    $matches=[regex]::Matches($Text,$pattern)
    if($matches.Count -gt 1){throw "Ambiguous hardware setting: $Key"}
    if($matches.Count -eq 0){$eol="`n";if($Text.Contains("`r`n")){$eol="`r`n"};if($Text -and -not $Text.EndsWith("`n")){$Text+=$eol};return $Text+$Key+$Separator+$Value+$eol}
    $m=$matches[0];$replacement=$m.Groups[1].Value+$Value+$m.Groups[3].Value
    return $Text.Substring(0,$m.Index)+$replacement+$Text.Substring($m.Index+$m.Length)
}

function Invoke-MichaelsHardwareReview1121 {
    param([string]$InstanceDirectory,[string]$GameDirectory,[switch]$BeforeGameLaunch,$Hardware)
    # A client UI hook that is already rendering must stage/install this helper for
    # the next Play/prelaunch instead of changing live graphics configuration.
    if(-not $BeforeGameLaunch){return [pscustomobject]@{status='deferred-until-next-prelaunch';changed=$false}}
    if(-not $InstanceDirectory){if(-not $GameDirectory){throw 'The pack profile is required.'};$InstanceDirectory=Split-Path -Parent ([IO.Path]::GetFullPath($GameDirectory))}
    $instance=[IO.Path]::GetFullPath($InstanceDirectory).TrimEnd('\')
    if(-not $GameDirectory){$GameDirectory=Join-Path $instance 'minecraft'}
    $game=[IO.Path]::GetFullPath($GameDirectory).TrimEnd('\')
    if((Split-Path -Parent $game) -ine $instance -or (Split-Path -Leaf $game) -notin @('minecraft','.minecraft')){throw 'The pack profile folders do not match.'}
    Assert-MichaelsFreshPath $game
    if(-not [IO.File]::Exists((Join-Path $instance 'instance.cfg'))){return [pscustomobject]@{status='profile-not-ready';changed=$false}}
    $marker=Join-Path $game 'config\michaels-hardware-policy-1128.json'
    Assert-MichaelsFreshPath $marker
    # Presence itself protects later choices, even if somebody edited the record.
    if([IO.File]::Exists($marker)){return [pscustomobject]@{status='already-reviewed';changed=$false}}
    $paths=@((Join-Path $game 'options.txt'),(Join-Path $game 'config\DistantHorizons.toml'),(Join-Path $game 'config\oculus.properties'))
    foreach($path in $paths){Assert-MichaelsFreshPath $path;if(-not [IO.File]::Exists($path)){return [pscustomobject]@{status='download-not-ready';changed=$false}}}
    if($null -eq $Hardware){$Hardware=Get-MichaelsLocalHardware}
    $profile=Get-MichaelsHardwareProfile $Hardware
    $previousMarker=Join-Path $game 'config\michaels-hardware-policy-1121.json'
    Assert-MichaelsFreshPath $previousMarker
    if([IO.File]::Exists($previousMarker) -and -not ($profile.highPixelLoad -and $profile.shader -eq 'Normal')){
        return [pscustomobject]@{status='existing-profile-kept';changed=$false;profile=$profile}
    }
    $old=@();$texts=@();foreach($path in $paths){$bytes=[IO.File]::ReadAllBytes($path);$old+=,$bytes;$texts+=[Text.UTF8Encoding]::new($false,$true).GetString($bytes)}
    if([IO.File]::Exists($previousMarker) -and
       ($texts[2] -notmatch '(?m)^\s*enableShaders\s*=\s*true\s*$' -or
        $texts[2] -notmatch '(?m)^\s*shaderPack\s*=\s*MakeUp-UltraFast-9\.6-Enhanced\.zip\s*$')){
        return [pscustomobject]@{status='existing-shader-kept';changed=$false;profile=$profile}
    }
    $options=Set-MichaelsReviewKey1121 $texts[0] 'renderDistance' ([string]$profile.renderDistance) ':'
    $options=Set-MichaelsReviewKey1121 $options 'simulationDistance' ([string]$profile.simulationDistance) ':'
    $dh=$texts[1];$sections=[regex]::Matches($dh,'(?ms)(^\[client\.advanced\.graphics\.quality\]\r?\n)(.*?)(?=^\[|\z)')
    if($sections.Count -ne 1){throw 'The LOD quality table is ambiguous.'}
    $body=$sections[0].Groups[2];$keys=[regex]::Matches($body.Value,'(?m)^(lodChunkRenderDistanceRadius\s*=\s*)([^\r\n#]*)([^\r\n]*)(\r?)$')
    if($keys.Count -ne 1){throw 'The LOD distance is ambiguous.'}
    $k=$keys[0];$line=$k.Groups[1].Value+[string]$profile.dhRadius+$k.Groups[3].Value+$k.Groups[4].Value
    $nextBody=$body.Value.Substring(0,$k.Index)+$line+$body.Value.Substring($k.Index+$k.Length)
    $dh=$dh.Substring(0,$body.Index)+$nextBody+$dh.Substring($body.Index+$body.Length)
    $shader=[string]$profile.shader;$selected='MakeUp-UltraFast-9.6.zip'
    if($shader -eq 'Enhanced'){$selected='MakeUp-UltraFast-9.6-Enhanced.zip'}
    if($shader -ne 'OFF' -and -not [IO.File]::Exists((Join-Path $game ('shaderpacks\'+$selected)))){$shader='OFF'}
    $oculus=Set-MichaelsReviewKey1121 $texts[2] 'enableShaders' $(if($shader -eq 'OFF'){'false'}else{'true'})
    if($shader -ne 'OFF'){$oculus=Set-MichaelsReviewKey1121 $oculus 'shaderPack' $selected}
    $next=@($options,$dh,$oculus);$written=@()
    try{
        for($i=0;$i -lt $paths.Count;$i++){if($next[$i] -cne $texts[$i]){Write-MichaelsAtomicText $paths[$i] $next[$i];$written+=$i}}
        $receipt=[pscustomobject]@{schema=1;receipt='michaels-hardware-policy-1128:once:v1';state='applied';policyRevision='1128';profile=$profile;appliedShader=$shader;heapChanged=$false;authorization='one-time-graphics-reevaluation';laterManualChoicesPreserved=$true}
        Write-MichaelsAtomicText $marker (($receipt|ConvertTo-Json -Depth 6)+"`n")
    }catch{foreach($i in $written){Write-MichaelsAtomicBytes $paths[$i] $old[$i]};throw}
    [pscustomobject]@{status='applied';changed=($written.Count -gt 0);profile=$profile;shader=$shader;heapChanged=$false}
}

function Invoke-MichaelsManagedHardwareUpgrade {
    param([string]$InstanceDirectory,[string]$GameDirectory,[switch]$BeforeGameLaunch,$Hardware)
    Invoke-MichaelsHardwareReview1121 -InstanceDirectory $InstanceDirectory -GameDirectory $GameDirectory -BeforeGameLaunch:$BeforeGameLaunch -Hardware $Hardware
}
