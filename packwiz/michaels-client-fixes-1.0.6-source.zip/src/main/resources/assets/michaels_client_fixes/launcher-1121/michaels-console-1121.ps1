function Get-MichaelsGeneral1121([string]$Text) {
 $sections=[regex]::Matches($Text,'(?ms)^\[General\]\r?\n(?<body>.*?)(?=^\[|\z)')
 if($sections.Count -ne 1){throw 'Unexpected launcher settings layout'}
 return $sections[0].Groups['body']
}
function Get-MichaelsGeneralValue1121([string]$Text,[string]$Key) {
 $body=(Get-MichaelsGeneral1121 $Text).Value
 $matches=[regex]::Matches($body,'(?m)^'+[regex]::Escape($Key)+'=([^\r\n]*)\r?$')
 if($matches.Count -gt 1){throw 'Duplicate launcher preference'}
 if($matches.Count){return $matches[0].Groups[1].Value}
}
function Set-MichaelsGeneralValue1121([string]$Text,[string]$Key,[string]$Value) {
 $body=Get-MichaelsGeneral1121 $Text
 $pattern='(?m)^'+[regex]::Escape($Key)+'=[^\r\n]*(?=\r?$)'
 $matches=[regex]::Matches($body.Value,$pattern)
 if($matches.Count -gt 1){throw 'Duplicate launcher preference'}
 if($matches.Count){$next=[regex]::Replace($body.Value,$pattern,[Text.RegularExpressions.MatchEvaluator]{param($m)$Key+'='+$Value})}
 else{
  $eol=if($Text.Contains("`r`n")){"`r`n"}else{"`n"}
  $next=$body.Value.TrimEnd("`r","`n")+$eol+$Key+'='+$Value+$eol+$eol
 }
 return $Text.Substring(0,$body.Index)+$next+$Text.Substring($body.Index+$body.Length)
}
function Set-MichaelsConsole1121 {
 param($Target)
 $marker=Join-Path $Target.Root 'Launcher\michaels-console-1121.done'
 if(Test-Path -LiteralPath $marker){return}
 # Prism caches its settings. Change them only before its own process starts.
 $own=@(Get-CimInstance Win32_Process -Filter "Name='prismlauncher.exe'" -Property ExecutablePath -ErrorAction SilentlyContinue|Where-Object {$_.ExecutablePath -ieq $Target.Exe})
 if($own.Count){return}
 $file=Join-Path $Target.Data ('instances\'+$Target.InstanceId+'\instance.cfg')
 if(-not (Test-Path -LiteralPath $file -PathType Leaf)){return}
 $globalFile=Join-Path $Target.Data 'prismlauncher.cfg'
 foreach($path in @($file,$marker,$globalFile)){if((Test-Path -LiteralPath $path) -and ([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint)){throw 'Console settings path is linked'}}
 $before=[IO.File]::ReadAllText($file);$next=$before
 $globalBefore=$null;$globalAfter=$null
 if(Test-Path -LiteralPath $globalFile -PathType Leaf){$globalBefore=[IO.File]::ReadAllText($globalFile);$globalAfter=$globalBefore}
 $shown=Get-MichaelsGeneralValue1121 $before 'ShowConsole'
 if($null -eq $shown -and $null -ne $globalBefore){$shown=Get-MichaelsGeneralValue1121 $globalBefore 'ShowConsole'}
 if($null -eq $shown){$shown='false'}
 foreach($pair in @(@('OverrideConsole','true'),@('AutoCloseConsole','true'),@('ShowConsoleOnError','true'),@('ShowConsole',$shown))){$next=Set-MichaelsGeneralValue1121 $next $pair[0] $pair[1]}
 # Upgrade only an exact archived official prelaunch command. Custom commands stay intact.
 $command=Get-MichaelsGeneralValue1121 $before 'PreLaunchCommand'
 if($null -ne $command){
  $digest=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($command))).Replace('-','').ToLowerInvariant()
  $official=@('305a0ef0b2e203e30098326351ee5ffe744c41327a09367f018ab7174377de11','d7ed01d1f474f50981a03f3219a2dd964583cf1fe835ee66c46b8fce51a22506','dca6ecb43e0d3dca3a9f8c12006ab38b5655ede9ef053adfa49fa9af26833636')
  if($official -contains $digest){
   $newCommand='powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "$INST_DIR/../../../Launcher/michaels-prelaunch-111.ps1" -InstanceDirectory "$INST_DIR" -GameDirectory "$INST_MC_DIR" -Java "$INST_JAVA"'
   $next=Set-MichaelsGeneralValue1121 $next 'PreLaunchCommand' $newCommand
  }
 }
 if($null -ne $globalBefore){foreach($key in @('AutoCloseConsole','ShowConsoleOnError')){$globalAfter=Set-MichaelsGeneralValue1121 $globalAfter $key 'true'}}
 if($next -cne $before){[IO.File]::WriteAllText($file,$next,[Text.UTF8Encoding]::new($false))}
 if($globalAfter -cne $globalBefore){[IO.File]::WriteAllText($globalFile,$globalAfter,[Text.UTF8Encoding]::new($false))}
 [IO.File]::WriteAllText($marker,"Close console after successful exit; show errors. Other settings preserved.`n",[Text.UTF8Encoding]::new($false))
}
