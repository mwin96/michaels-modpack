$ErrorActionPreference = 'Stop'

function Hide-MichaelsSupportFiles {
    param($Target)
    # Only our known support paths; never move Data or change account/profile contents.
    foreach ($relative in @('Launcher','Data','CLICK HERE TO INSTALL AND PLAY.cmd','UPDATE MICHAELS MODPACK.cmd','update.ps1','update-settings.json','launcher-ui.ps1','play.ps1','payload')) {
        $path = Join-Path $Target.Root $relative
        if (-not (Test-Path -LiteralPath $path)) { continue }
        $attributes = [IO.File]::GetAttributes($path)
        if ($attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
        [IO.File]::SetAttributes($path, $attributes -bor [IO.FileAttributes]::Hidden)
    }
    $play = Join-Path $Target.Root 'PLAY MICHAELS MODPACK.cmd'
    if (Test-Path -LiteralPath $play -PathType Leaf) {
        $attributes = [IO.File]::GetAttributes($play)
        [IO.File]::SetAttributes($play, $attributes -band (-bnot [IO.FileAttributes]::Hidden))
    }
}

function Get-MichaelsPortableTarget {
    param([string]$GameDirectory, [string]$BundleRoot)
    if ($BundleRoot) {
        $root = [IO.Path]::GetFullPath($BundleRoot)
        $data = Join-Path $root 'Data'
        $instance = Join-Path $data 'instances\michaels-modpack'
    } else {
        $game = [IO.Path]::GetFullPath($GameDirectory)
        $instance = Split-Path -Parent $game
        $instances = Split-Path -Parent $instance
        if ((Split-Path -Leaf $instances) -ine 'instances') { return }
        $data = Split-Path -Parent $instances
        if ((Split-Path -Leaf $data) -ine 'Data') { return }
        $root = Split-Path -Parent $data
    }
    $exe = Join-Path $root 'Launcher\prismlauncher.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf) -or
        -not (Test-Path -LiteralPath (Join-Path $instance 'instance.cfg') -PathType Leaf)) { return }
    $id = Split-Path -Leaf $instance
    if ($id -notmatch '^[A-Za-z0-9_. -]+$') { throw 'The installed pack has an unsupported folder name.' }
    foreach ($path in @($root,$data,$instance,$exe)) {
        if ($path -match '["\r\n]' -or (Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
            throw 'The launcher folder cannot be used safely.'
        }
    }
    [pscustomobject]@{Root=$root;Data=$data;InstanceId=$id;Exe=$exe;DisplayName=(Split-Path -Leaf $root)}
}

function Get-MichaelsLaunchArguments($Target) {
    '--dir "{0}" --launch "{1}" --server 51.81.148.186:25590' -f $Target.Data,$Target.InstanceId
}

function Start-MichaelsGame($Target) {
    # The explicit original Data folder contains the player's existing account.
    . (Join-Path $PSScriptRoot 'michaels-starting-1121.ps1')
    Show-MichaelsStarting -Target $Target
}


function Get-MichaelsPlayCommand {
    param($Target)
    $own = Join-Path $Target.Root 'PLAY MICHAELS MODPACK.cmd'
    if ((Split-Path -Leaf $Target.Root) -ieq 'Setup') {
        $parent = Split-Path -Parent $Target.Root
        $outer = Join-Path $parent 'PLAY MICHAELS MODPACK.cmd'
        $expectedRoot = [IO.Path]::GetFullPath((Join-Path $parent 'Setup')).TrimEnd('\')
        $expectedData = [IO.Path]::GetFullPath((Join-Path $Target.Root 'Data')).TrimEnd('\')
        $expectedExe = [IO.Path]::GetFullPath((Join-Path $Target.Root 'Launcher\prismlauncher.exe'))
        $valid = ($Target.InstanceId -ceq 'michaels-modpack') -and ($expectedRoot -ieq [IO.Path]::GetFullPath($Target.Root).TrimEnd('\')) -and
            ($expectedData -ieq [IO.Path]::GetFullPath($Target.Data).TrimEnd('\')) -and
            ($expectedExe -ieq [IO.Path]::GetFullPath($Target.Exe)) -and
            (Test-Path -LiteralPath $outer -PathType Leaf)
        foreach ($path in @($parent,$Target.Root,(Join-Path $Target.Root 'Launcher'),$Target.Data)) {
            if (-not (Test-Path -LiteralPath $path -PathType Container) -or
                ((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { $valid=$false }
        }
        if ($valid -and -not ((Get-Item -LiteralPath $outer -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            return [pscustomobject]@{Path=$outer;WorkingDirectory=$parent}
        }
    }
    return [pscustomobject]@{Path=$own;WorkingDirectory=$Target.Root}
}

function New-MichaelsDesktopShortcut {
    param($Target,[string]$DesktopPath,[string]$ProgramsPath)
    & (Join-Path $Target.Root 'Launcher\michaels-shortcuts-1111.ps1') -GameDirectory (Join-Path $Target.Data ('instances\'+$Target.InstanceId+'\minecraft')) -DesktopPath $DesktopPath -ProgramsPath $ProgramsPath
}

function Install-MichaelsPlayEntry {
    param($Target,[string]$SourceDirectory,[string]$DesktopPath,[switch]$SkipDesktop)
    $utf8 = New-Object Text.UTF8Encoding($false)
    $files = @{
        'PLAY MICHAELS MODPACK.cmd'='PLAY MICHAELS MODPACK.cmd'
        'play.ps1'='Launcher\michaels-play.ps1'
        'launcher-ui.ps1'='Launcher\michaels-launcher-ui.ps1'
    }
    foreach ($source in $files.Keys) {
        $destination = Join-Path $Target.Root $files[$source]
        if ((Test-Path -LiteralPath $destination) -and ((Get-Item -LiteralPath $destination -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'A Play shortcut file is linked to another location.'
        }
        $bytes = [IO.File]::ReadAllBytes((Join-Path $SourceDirectory $source))
        if ((Test-Path -LiteralPath $destination -PathType Leaf) -and
            [Convert]::ToBase64String([IO.File]::ReadAllBytes($destination)) -ceq [Convert]::ToBase64String($bytes)) { continue }
        [IO.File]::WriteAllBytes($destination,$bytes)
    }
    Hide-MichaelsSupportFiles -Target $Target
    if ($SkipDesktop) { return }
    try { New-MichaelsDesktopShortcut -Target $Target -DesktopPath $DesktopPath }
    catch { Write-Host 'Use PLAY MICHAELS MODPACK.cmd in your pack folder.' -ForegroundColor Yellow }
}

function New-MichaelsReadyForm {
    param([object[]]$Targets)
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $form = New-Object Windows.Forms.Form
    $form.Text = "Michael's Modpack"
    $form.ClientSize = New-Object Drawing.Size(420,230)
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.Font = New-Object Drawing.Font('Segoe UI',10)
    $title = New-Object Windows.Forms.Label
    $title.Text = 'Ready to play!'
    $title.Font = New-Object Drawing.Font('Segoe UI',16,[Drawing.FontStyle]::Bold)
    $title.SetBounds(24,20,372,36)
    $form.Controls.Add($title)
    $hint = New-Object Windows.Forms.Label
    $hint.Text = 'Next time, use Play Michael''s Modpack on your desktop.'
    $hint.SetBounds(24,65,372,48)
    $form.Controls.Add($hint)
    $choice = New-Object Windows.Forms.ComboBox
    $choice.DropDownStyle = 'DropDownList'
    $choice.DisplayMember = 'DisplayName'
    $choice.SetBounds(24,112,372,28)
    foreach ($target in $Targets) { [void]$choice.Items.Add($target) }
    $choice.SelectedIndex = 0
    $choice.Visible = $Targets.Count -gt 1
    $form.Controls.Add($choice)
    $play = New-Object Windows.Forms.Button
    $play.Name = 'PlayButton'
    $play.Text = 'PLAY'
    $play.Font = New-Object Drawing.Font('Segoe UI',15,[Drawing.FontStyle]::Bold)
    $play.ForeColor = [Drawing.Color]::White
    $play.BackColor = [Drawing.Color]::FromArgb(42,128,65)
    $play.FlatStyle = 'Flat'
    $play.SetBounds(24,156,372,52)
    $play.Add_Click({
        try { try { New-MichaelsDesktopShortcut -Target $choice.SelectedItem } catch {}; Start-MichaelsGame $choice.SelectedItem; $form.Close() }
        catch { [void][Windows.Forms.MessageBox]::Show('Could not start the pack. Use PLAY MICHAELS MODPACK.cmd in your original pack folder.',"Michael's Modpack") }
    }.GetNewClosure())
    $form.Controls.Add($play)
    $form.AcceptButton = $play
    return ,$form
}

function Complete-MichaelsLauncherSetup {
    param([string[]]$GameDirectories,[string]$SourceDirectory,[switch]$ShowPlayButton,[string]$DesktopPath)
    $targets = New-Object 'System.Collections.Generic.List[object]'
    foreach ($directory in $GameDirectories) {
        $target = Get-MichaelsPortableTarget -GameDirectory $directory
        if ($null -eq $target) { continue }
        if (@($targets | Where-Object {$_.Root -ieq $target.Root}).Count) { continue }
        Install-MichaelsPlayEntry -Target $target -SourceDirectory $SourceDirectory -DesktopPath $DesktopPath -SkipDesktop:($targets.Count -gt 0)
        $targets.Add($target)
    }
    if ($targets.Count -eq 0) { return }
    Write-Host 'Ready! Use Play Michael''s Modpack on your desktop.' -ForegroundColor Green
    if ($ShowPlayButton) {
        Add-Type -AssemblyName System.Windows.Forms
        [Windows.Forms.Application]::EnableVisualStyles()
        $form = New-MichaelsReadyForm -Targets $targets.ToArray()
        try { [void]$form.ShowDialog() } finally { $form.Dispose() }
    }
}
