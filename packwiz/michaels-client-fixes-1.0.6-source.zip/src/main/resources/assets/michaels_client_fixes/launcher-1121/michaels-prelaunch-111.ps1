param([Parameter(Mandatory=$true)][string]$InstanceDirectory,[Parameter(Mandatory=$true)][string]$GameDirectory,[Parameter(Mandatory=$true)][string]$Java)
$ErrorActionPreference = 'Stop'
try {
    $progress=Join-Path $PSScriptRoot 'michaels-starting-1121.ps1'
    if(Test-Path -LiteralPath $progress){. $progress;Set-MichaelsStartupStage $PSScriptRoot 'Updating'}
    . (Join-Path $PSScriptRoot 'michaels-hardware-policy-111.ps1')
    $instance = [IO.Path]::GetFullPath($InstanceDirectory).TrimEnd('\')
    $game = [IO.Path]::GetFullPath($GameDirectory).TrimEnd('\')
    if ($game -ine [IO.Path]::GetFullPath((Join-Path $instance 'minecraft')).TrimEnd('\')) { throw 'The pack profile folders do not match.' }
    Assert-MichaelsFreshPath $game
    [void](Start-MichaelsFreshHardware -InstanceDirectory $instance)
    Push-Location -LiteralPath $game
    try {
        # Use the console executable from the same Java runtime for the headless updater.
        # Windows PowerShell does not reliably wait or set LASTEXITCODE for javaw.exe.
        $installerJava = $Java
        if ([IO.Path]::GetFileName($Java) -ieq 'javaw.exe') {
            $installerJava = Join-Path (Split-Path -Parent $Java) 'java.exe'
            if (-not (Test-Path -LiteralPath $installerJava -PathType Leaf)) { throw 'The selected Java runtime is missing java.exe. Please repair the Java runtime in Prism.' }
        }
        & $installerJava '-Djava.awt.headless=true' '-jar' (Join-Path $game 'packwiz-installer-bootstrap.jar') '--bootstrap-no-update' '-g' '-s' 'client' 'https://raw.githubusercontent.com/mwin96/michaels-modpack/main/packwiz/pack.toml'
        if ($LASTEXITCODE -ne 0) { throw 'The pack update did not finish. Press Play again to resume.' }
    } finally { Pop-Location }
    # Load the current verified pack payload after packwiz, before Minecraft reads options.
    $currentPolicy=Join-Path $game 'config\michaels-launcher-1121\michaels-hardware-policy-111.ps1'
    if(Test-Path -LiteralPath $currentPolicy -PathType Leaf){. $currentPolicy}
    Complete-MichaelsFreshHardware -InstanceDirectory $instance
    if(Get-Command Invoke-MichaelsHardwareReview1121 -ErrorAction SilentlyContinue){
        [void](Invoke-MichaelsHardwareReview1121 -InstanceDirectory $instance -BeforeGameLaunch)
    }
    if(Get-Command Set-MichaelsStartupStage -ErrorAction SilentlyContinue){Set-MichaelsStartupStage $PSScriptRoot 'Loading'}
} catch { if(Get-Command Set-MichaelsStartupStage -ErrorAction SilentlyContinue){Set-MichaelsStartupStage $PSScriptRoot 'Error'}; Write-Error $_.Exception.Message; exit 1 }
exit 0
