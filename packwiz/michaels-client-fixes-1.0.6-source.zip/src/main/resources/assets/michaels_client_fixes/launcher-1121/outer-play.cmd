@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0Setup\Launcher\michaels-play.ps1" goto missing
if not exist "%~dp0Setup\Data\instances\michaels-modpack\instance.cfg" goto missing
attrib -h "%~dp0Setup" >nul 2>&1
set "MICHAELS_PLAY_SCRIPT=%~dp0Setup\Launcher\michaels-play.ps1"
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$p = New-Object Diagnostics.ProcessStartInfo; $p.FileName = Join-Path $PSHOME 'powershell.exe'; $p.UseShellExecute = $false; $p.CreateNoWindow = $true; $p.Arguments = '-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File ' + [char]34 + $env:MICHAELS_PLAY_SCRIPT + [char]34; [Diagnostics.Process]::Start($p).Dispose()"
exit /b %errorlevel%
:missing
echo First, right-click the downloaded ZIP and choose Extract All.
echo Open the extracted folder, then click PLAY MICHAELS MODPACK.cmd.
echo Keep the Play file and Setup folder together.
pause
exit /b 1
