@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0Setup\Launcher\michaels-play.ps1" goto missing
if not exist "%~dp0Setup\Data\instances\michaels-modpack\instance.cfg" goto missing
attrib -h "%~dp0Setup" >nul 2>&1
powershell.exe -NoLogo -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0Setup\Launcher\michaels-play.ps1"
exit /b %errorlevel%
:missing
echo First, right-click the downloaded ZIP and choose Extract All.
echo Open the extracted folder, then click PLAY MICHAELS MODPACK.cmd.
echo Keep the Play file and Setup folder together.
pause
exit /b 1
