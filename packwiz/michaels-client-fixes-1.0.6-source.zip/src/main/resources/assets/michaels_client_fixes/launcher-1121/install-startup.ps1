param([Parameter(Mandatory=$true)][string]$GameDirectory,[string]$DesktopPath,[string]$ProgramsPath)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'michaels-launcher-ui.ps1')
$target=Get-MichaelsPortableTarget -GameDirectory $GameDirectory
if(-not $target){exit 0}
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'payload.json') -Raw|ConvertFrom-Json
$launcher=Join-Path $target.Root 'Launcher'
$plan=@()
foreach($entry in $manifest.files){
 $source=Join-Path $PSScriptRoot $entry.name
 if((Get-FileHash -LiteralPath $source).Hash.ToLowerInvariant() -cne $entry.sha256){throw 'Startup payload verification failed'}
 $destination=Join-Path $launcher $entry.name
 if(Test-Path -LiteralPath $destination){
  if((Get-Item -LiteralPath $destination -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Startup destination is linked'}
  $old=(Get-FileHash -LiteralPath $destination).Hash.ToLowerInvariant()
  if($old -ceq $entry.sha256){continue}
  if(@($entry.previous) -cnotcontains $old){throw 'Custom startup helper preserved; update deferred'}
 }
 $plan+=@{Source=$source;Destination=$destination}
}
$play=Get-MichaelsPlayCommand -Target $target
$outer=(Split-Path -Leaf $target.Root) -ieq 'Setup'
if($outer){$play=[pscustomobject]@{Path=(Join-Path (Split-Path -Parent $target.Root) 'PLAY MICHAELS MODPACK.cmd')}}
$playSource=Join-Path $PSScriptRoot $(if($outer){'outer-play.cmd'}else{'flat-play.cmd'})
$needsPlay=$true
if(Test-Path -LiteralPath $play.Path){
 if((Get-Item -LiteralPath $play.Path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Play entry is linked'}
 $old=(Get-FileHash -LiteralPath $play.Path).Hash.ToLowerInvariant()
 $new=(Get-FileHash -LiteralPath $playSource).Hash.ToLowerInvariant()
 if($old -ceq $new){$needsPlay=$false}
 if($old -cne $new -and @($manifest.playPrevious) -cnotcontains $old){throw 'Custom Play entry preserved; update deferred'}
}
if($needsPlay){$plan+=@{Source=$playSource;Destination=$play.Path}}
foreach($entry in $plan){
 $destination=$entry.Destination
 if(Test-Path -LiteralPath $destination){
  $backup=$destination+'.before-1121'
  if(-not (Test-Path -LiteralPath $backup)){[IO.File]::Copy($destination,$backup,$false);[IO.File]::SetAttributes($backup,[IO.File]::GetAttributes($backup) -bor [IO.FileAttributes]::Hidden)}
 }
 $temporary=$destination+'.'+[Guid]::NewGuid().ToString('N')
 [IO.File]::Copy($entry.Source,$temporary,$false)
 if(Test-Path -LiteralPath $destination){[IO.File]::Replace($temporary,$destination,[NullString]::Value)}else{[IO.File]::Move($temporary,$destination)}
}
Hide-MichaelsSupportFiles -Target $target
if($outer){[IO.File]::SetAttributes($target.Root,[IO.File]::GetAttributes($target.Root) -band (-bnot [IO.FileAttributes]::Hidden))}
# Only shortcut assets/links are touched in an already-running client. Graphics wait for prelaunch.
& (Join-Path $launcher 'michaels-shortcuts-1111.ps1') -GameDirectory $GameDirectory -DesktopPath $DesktopPath -ProgramsPath $ProgramsPath
foreach($entry in $manifest.files){
 if((Get-FileHash -LiteralPath (Join-Path $launcher $entry.name)).Hash.ToLowerInvariant() -cne $entry.sha256){throw 'Installed startup verification failed'}
}
$marker=Join-Path $GameDirectory 'config\michaels-launcher-1122.done'
[IO.File]::WriteAllText($marker,"Startup helpers and square icon installed; graphics apply once before the next game launch.`n",[Text.UTF8Encoding]::new($false))
