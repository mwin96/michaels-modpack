# Launcher progress only. Never reads account data or process command lines.
$ErrorActionPreference='Stop'

function Set-MichaelsStartupStage {
    param([string]$LauncherDirectory,[string]$Phase)
    if ($Phase -notin @('Preparing','Updating','Loading','Error')) { return }
    $path=Join-Path $LauncherDirectory 'michaels-startup-1121.state.json'
    try {
        if (-not [IO.File]::Exists($path) -or ([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint)) { return }
        $state=[IO.File]::ReadAllText($path)|ConvertFrom-Json
        if ($state.schema -ne 1 -or ([DateTime]::UtcNow-[DateTime]::Parse($state.startedUtc).ToUniversalTime()).TotalMinutes -gt 30) { return }
        $state.phase=$Phase
        $temp=$path+'.'+[Guid]::NewGuid().ToString('N')
        [IO.File]::WriteAllText($temp,($state|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
        [IO.File]::Replace($temp,$path,[NullString]::Value)
    } catch { } # Progress display must never break an update or launch.
}

function Get-MichaelsStartupSnapshot {
    param($Target)
    $prism=@();$java=@();$known=$true
    try {
        $rows=@(Get-CimInstance Win32_Process -Filter "Name='prismlauncher.exe' OR Name='javaw.exe' OR Name='java.exe'" -Property Name,ProcessId,ParentProcessId,ExecutablePath -ErrorAction Stop)
        $prism=@($rows|Where-Object {$_.Name -ieq 'prismlauncher.exe' -and $_.ExecutablePath -ieq $Target.Exe}|ForEach-Object {[int]$_.ProcessId})
        foreach($row in $rows) {
            if ($row.Name -notin @('java.exe','javaw.exe') -or $prism -notcontains [int]$row.ParentProcessId) { continue }
            try {
                $process=[Diagnostics.Process]::GetProcessById([int]$row.ProcessId)
                $visible=$process.MainWindowHandle -ne [IntPtr]::Zero
                $java+=,[pscustomobject]@{Id=[int]$row.ProcessId;Visible=$visible}
                $process.Dispose()
            } catch { }
        }
    } catch { $known=$false }
    [pscustomobject]@{Known=$known;PrismCount=$prism.Count;Java=$java;GameVisible=@($java|Where-Object Visible).Count -gt 0}
}

function New-MichaelsStartingForm {
    param($Target)
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $form=New-Object Windows.Forms.Form
    $form.Text="Michael's Modpack"
    $form.ClientSize=[Drawing.Size]::new(540,352)
    $form.StartPosition='CenterScreen';$form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false
    $form.BackColor=[Drawing.Color]::FromArgb(24,30,34)
    $form.ForeColor=[Drawing.Color]::FromArgb(237,241,236)
    $form.Font=[Drawing.Font]::new('Segoe UI',10)
    $icon=Join-Path $Target.Root 'Launcher\michaels-modpack.ico'
    if([IO.File]::Exists($icon)){try{$form.Icon=[Drawing.Icon]::new($icon)}catch{}}
    $title=[Windows.Forms.Label]::new();$title.Name='StartupTitle'
    $title.Text='Minecraft is starting';$title.Font=[Drawing.Font]::new('Segoe UI',21,[Drawing.FontStyle]::Bold)
    $title.SetBounds(24,22,492,46);$form.Controls.Add($title)
    $hint=[Windows.Forms.Label]::new();$hint.Text='Please wait. The first launch can take a few minutes.'
    $hint.SetBounds(26,78,488,42);$form.Controls.Add($hint)
    $bar=[Windows.Forms.ProgressBar]::new();$bar.Style='Marquee';$bar.MarqueeAnimationSpeed=30
    $bar.SetBounds(26,128,488,10);$form.Controls.Add($bar)
    $status=[Windows.Forms.Label]::new();$status.Name='StartupStatus';$status.Text='Getting the launcher ready...'
    $status.Font=[Drawing.Font]::new('Segoe UI',11,[Drawing.FontStyle]::Bold)
    $status.SetBounds(26,158,488,44);$form.Controls.Add($status)
    $steps=[Windows.Forms.Label]::new();$steps.Name='StartupInstructions'
    $steps.Text="First time? Sign in when the launcher asks. Then press Launch.`nMinecraft will open automatically. Click Play only once."
    $steps.ForeColor=[Drawing.Color]::FromArgb(190,203,190);$steps.SetBounds(26,205,488,52);$form.Controls.Add($steps)
    $shortcut=[Windows.Forms.Label]::new();$shortcut.Name='ShortcutNotice'
    $shortcut.Text="Next time: use Play Michael's Modpack on your desktop."
    $shortcut.ForeColor=[Drawing.Color]::FromArgb(153,212,157);$shortcut.SetBounds(26,270,488,25);$form.Controls.Add($shortcut)
    $open=[Windows.Forms.Button]::new();$open.Name='OpenLauncher';$open.Text='Open launcher';$open.SetBounds(26,307,160,30)
    $open.Add_Click({Start-Process -FilePath $Target.Exe -ArgumentList ('--dir "{0}"' -f $Target.Data) -WorkingDirectory $Target.Root -WindowStyle Normal}.GetNewClosure())
    $form.Controls.Add($open)
    $close=[Windows.Forms.Button]::new();$close.Name='CloseMessage';$close.Text='Close this message';$close.SetBounds(335,307,179,30)
    $close.Add_Click({$form.Close()}.GetNewClosure());$form.Controls.Add($close)
    return ,$form
}

function Show-MichaelsStarting {
    param($Target)
    $key=[BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($Target.Root.ToLowerInvariant()))).Replace('-','').Substring(0,24)
    $mutex=[Threading.Mutex]::new($false,('Local\MichaelsModpackStartup-'+$key));$owned=$false
    try {
        try{$owned=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$owned=$true}
        if(-not $owned){
            Add-Type -AssemblyName System.Windows.Forms
            [void][Windows.Forms.MessageBox]::Show('Minecraft is already starting. Please wait for its window to open.',"Michael's Modpack")
            return
        }
        $form=New-MichaelsStartingForm $Target
        $statePath=Join-Path $Target.Root 'Launcher\michaels-startup-1121.state.json'
        if((Test-Path -LiteralPath $statePath) -and ([IO.File]::GetAttributes($statePath) -band [IO.FileAttributes]::ReparsePoint)){throw 'The startup status file is linked to another location.'}
        $started=[DateTime]::UtcNow
        [IO.File]::WriteAllText($statePath,(@{schema=1;startedUtc=$started.ToString('o');phase='Preparing'}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
        $context=@{Started=$started;SeenJava=$false;LastJava=$started;VisibleCount=0;Failed=$false;Launch=$null}
        $timer=[Windows.Forms.Timer]::new();$timer.Interval=1000
        $form.Add_Shown({
            try {
                $before=Get-MichaelsStartupSnapshot $Target
                if(-not $before.GameVisible -and @($before.Java).Count -eq 0){
                    $context.Launch=Start-Process -FilePath $Target.Exe -ArgumentList (Get-MichaelsLaunchArguments $Target) -WorkingDirectory $Target.Root -WindowStyle Normal -PassThru
                }
                $timer.Start()
            } catch {
                $form.Controls['StartupTitle'].Text='Minecraft could not start'
                $form.Controls['StartupStatus'].Text='Open the launcher to see the error, then try Launch again.'
                $context.Failed=$true
            }
        }.GetNewClosure())
        $timer.Add_Tick({
            try {
                $snapshot=Get-MichaelsStartupSnapshot $Target
                if($snapshot.GameVisible){$context.VisibleCount++}else{$context.VisibleCount=0}
                if($context.VisibleCount -ge 2){$timer.Stop();$form.Close();return}
                $phase='Preparing'
                try{$record=[IO.File]::ReadAllText($statePath)|ConvertFrom-Json;if($record.schema -eq 1){$phase=$record.phase}}catch{}
                $elapsed=([DateTime]::UtcNow-$context.Started).TotalSeconds
                $text='Sign in if asked, then press Launch. Minecraft will open next.'
                if($phase -eq 'Updating'){$text='Checking and downloading modpack updates...'}
                if($phase -eq 'Loading'){$text='Loading Minecraft and mods...'}
                if(@($snapshot.Java).Count){$context.SeenJava=$true;$context.LastJava=[DateTime]::UtcNow;$text='Loading Minecraft and mods...'}
                if($phase -eq 'Error' -or ($snapshot.Known -and $context.SeenJava -and @($snapshot.Java).Count -eq 0 -and ([DateTime]::UtcNow-$context.LastJava).TotalSeconds -gt 3)){
                    $form.Controls['StartupTitle'].Text='Minecraft needs attention';$text='Open the launcher to see the error, then try Launch again.'
                }elseif($snapshot.Known -and $snapshot.PrismCount -eq 0 -and @($snapshot.Java).Count -eq 0 -and $elapsed -gt 10){
                    $form.Controls['StartupTitle'].Text='The launcher was closed';$text='Open the launcher to sign in or start Minecraft again.'
                }elseif($elapsed -gt 600){$form.Controls['StartupTitle'].Text='Still getting Minecraft ready';$text='This is taking longer than usual. Check the launcher below.'}
                else{$form.Controls['StartupTitle'].Text='Minecraft is starting'}
                $form.Controls['StartupStatus'].Text=$text
            } catch { $form.Controls['StartupStatus'].Text='Still starting. You can check the launcher below.' }
        }.GetNewClosure())
        try{[void]$form.ShowDialog()}finally{$timer.Stop();$timer.Dispose();if($context.Launch){$context.Launch.Dispose()};$form.Dispose()}
    } finally {if($owned){$mutex.ReleaseMutex()};$mutex.Dispose()}
}
