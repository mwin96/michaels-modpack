# The Play window displays status. Prism handles Microsoft sign-in and launches Minecraft.
$ErrorActionPreference = 'Stop'

function Set-MichaelsStartupStage {
    param([string]$LauncherDirectory,[string]$Phase,[int]$Completed=0,[int]$Total=0,[string]$LastDownload='', [string]$Result='')
    $path = Join-Path $LauncherDirectory 'michaels-startup-1121.state.json'
    try {
        if (-not [IO.File]::Exists($path) -or ([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint)) { return }
        $old = [IO.File]::ReadAllText($path) | ConvertFrom-Json
        if ($old.schema -ne 1 -or ([DateTime]::UtcNow - [DateTime]::Parse($old.startedUtc).ToUniversalTime()).TotalMinutes -gt 30) { return }
        $record = @{
            schema=1; startedUtc=$old.startedUtc; phase=$Phase; completed=$Completed
            total=$Total; lastDownload=$LastDownload; result=$Result
        }
        $temp = $path + '.' + [Guid]::NewGuid().ToString('N')
        try {
            [IO.File]::WriteAllText($temp,($record | ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
            [IO.File]::Replace($temp,$path,[NullString]::Value)
        } finally { if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) } }
    } catch { } # A missing status window must never interrupt an update.
}

function Get-MichaelsStartupSnapshot {
    param($Target)
    $ids = @()
    $known = $true
    $launcherVisible = $false
    $hasJava = $false
    $gameVisible = $false
    try {
        $rows = @(Get-CimInstance Win32_Process -Filter "Name='prismlauncher.exe' OR Name='javaw.exe' OR Name='java.exe'" -Property Name,ProcessId,ParentProcessId,ExecutablePath -ErrorAction Stop)
        $ids = @($rows | Where-Object { $_.Name -ieq 'prismlauncher.exe' -and $_.ExecutablePath -ieq $Target.Exe } | ForEach-Object { [int]$_.ProcessId })
        foreach ($row in $rows) {
            $launcher = $ids -contains [int]$row.ProcessId
            if (-not $launcher -and ($row.Name -notin @('java.exe','javaw.exe') -or $ids -notcontains [int]$row.ParentProcessId)) { continue }
            try {
                $process = [Diagnostics.Process]::GetProcessById([int]$row.ProcessId)
                try { $visible = $process.MainWindowHandle -ne [IntPtr]::Zero }
                finally { $process.Dispose() }
                if ($launcher) { $launcherVisible = $launcherVisible -or $visible }
                else { $hasJava = $true; $gameVisible = $gameVisible -or $visible }
            } catch { }
        }
    } catch { $known = $false }
    [pscustomobject]@{Known=$known; PrismCount=$ids.Count; LauncherVisible=$launcherVisible; HasJava=$hasJava; GameVisible=$gameVisible}
}

function New-MichaelsLaunchForm {
    param($Target)
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [Windows.Forms.Application]::EnableVisualStyles()
    $form = [Windows.Forms.Form]::new()
    $form.Text = "Michael's Modpack"
    $form.AutoScaleDimensions = [Drawing.SizeF]::new(96,96)
    $form.AutoScaleMode = 'Dpi'
    $form.ClientSize = [Drawing.Size]::new(552,312)
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.BackColor = [Drawing.Color]::FromArgb(22,29,33)
    $form.ForeColor = [Drawing.Color]::FromArgb(242,246,244)
    $form.Font = [Drawing.Font]::new('Segoe UI',10)
    $icon = Join-Path $Target.Root 'Launcher\michaels-modpack.ico'
    if ([IO.File]::Exists($icon)) { try { $form.Icon = [Drawing.Icon]::new($icon) } catch { } }

    $labels = @(
        @{Name='Brand'; Bounds=@(30,26,492,23); Size=9; Color=@(148,214,164); Bold=$true}
        @{Name='Title'; Bounds=@(26,54,502,54); Size=24; Color=@(242,246,244); Bold=$true}
        @{Name='Description'; Bounds=@(30,112,492,53); Size=11; Color=@(201,212,208); Bold=$false}
        @{Name='Detail'; Bounds=@(30,194,492,25); Size=10; Color=@(179,196,187); Bold=$false}
        @{Name='Footer'; Bounds=@(30,280,492,23); Size=10; Color=@(164,189,174); Bold=$false}
    )
    foreach ($item in $labels) {
        $label = [Windows.Forms.Label]::new()
        $label.Name = $item.Name
        $label.UseMnemonic = $false
        $label.ForeColor = [Drawing.Color]::FromArgb($item.Color[0],$item.Color[1],$item.Color[2])
        $style = if ($item.Bold) { [Drawing.FontStyle]::Bold } else { [Drawing.FontStyle]::Regular }
        $label.Font = [Drawing.Font]::new('Segoe UI',$item.Size,$style)
        $x,$y,$width,$height = $item.Bounds
        $label.SetBounds($x,$y,$width,$height)
        $form.Controls.Add($label)
    }
    $form.Controls['Brand'].Text = "MICHAEL'S MODPACK"
    $form.Controls['Detail'].AutoEllipsis = $true
    $form.Controls['Footer'].Text = "We added Play Michael's Modpack to your desktop."

    $bar = [Windows.Forms.ProgressBar]::new()
    $bar.Name = 'Progress'
    $bar.SetBounds(30,173,492,12)
    $bar.Style = 'Marquee'
    $bar.MarqueeAnimationSpeed = 30
    $form.Controls.Add($bar)
    $action = [Windows.Forms.Button]::new()
    $action.Name = 'Action'
    $action.FlatStyle = 'Flat'
    $action.FlatAppearance.BorderSize = 0
    $action.BackColor = [Drawing.Color]::FromArgb(150,222,171)
    $action.ForeColor = [Drawing.Color]::FromArgb(17,44,28)
    $action.Font = [Drawing.Font]::new('Segoe UI',10,[Drawing.FontStyle]::Bold)
    $action.SetBounds(30,229,218,39)
    $form.Controls.Add($action)
    $form.AcceptButton = $action
    $details = [Windows.Forms.Button]::new()
    $details.Name = 'OpenLauncher'
    $details.Text = 'Open launcher'
    $details.SetBounds(260,229,150,39)
    $details.Add_Click({
        Start-Process -FilePath $Target.Exe -ArgumentList ('--dir "{0}"' -f $Target.Data) -WorkingDirectory $Target.Root -WindowStyle Normal
    }.GetNewClosure())
    $form.Controls.Add($details)
    return ,$form
}

function Set-MichaelsLaunchView {
    param($Form,[string]$Phase,$Record,[string]$Message)
    $controls = $Form.Controls
    $controls['Action'].Visible = $Phase -in @('SignIn','Error')
    $controls['OpenLauncher'].Visible = $Phase -eq 'Error'
    $bar = $controls['Progress']
    $bar.Visible = $Phase -notin @('SignIn','Error')
    $detail = ''
    $total = 0
    $completed = 0
    switch ($Phase) {
        'SignIn' {
            $title = 'Sign in to Minecraft'
            $description = 'Use the Microsoft account that owns Minecraft: Java Edition.'
            $controls['Action'].Text = 'Sign in with Microsoft'
            $detail = $Message
        }
        'OpeningSignIn' {
            $title = 'Opening Microsoft sign-in'
            $description = 'Follow the sign-in prompts, then close Accounts. We will continue here automatically.'
        }
        'Downloading' {
            $title = 'Downloading modpack files'
            $total = [int]$Record.total
            $completed = [int]$Record.completed
            $description = if ($total -gt 0) { "$completed of $total files checked" } else { 'Getting the list of files...' }
            if ($Record.lastDownload) { $detail = 'Last downloaded: ' + $Record.lastDownload }
        }
        'Loading' {
            $title = 'Launching Minecraft'
            $description = switch ($Record.result) {
                'NoUpdates' { "No updates found. You're up to date." }
                'Downloaded' { 'Your modpack files are ready.' }
                default { 'Starting the game...' }
            }
            $detail = 'This window closes when Minecraft opens.'
        }
        'Error' {
            $title = 'Minecraft needs attention'
            $description = $Message
            $controls['Action'].Text = 'Try again'
        }
        default {
            $title = 'Checking for updates'
            $description = 'Getting the latest version ready.'
        }
    }
    $controls['Title'].Text = $title
    $controls['Description'].Text = $description
    $controls['Detail'].Text = $detail
    if ($total -gt 0) {
        $bar.Style = 'Continuous'
        $bar.Maximum = $total
        $bar.Value = [Math]::Min($total,[Math]::Max(0,$completed))
    } elseif ($bar.Style -ne 'Marquee') { $bar.Style = 'Marquee' }
}

function Show-MichaelsStarting {
    param($Target,[Parameter(Mandatory=$true)][string]$LaunchArguments)
    $key = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($Target.Root.ToLowerInvariant()))).Replace('-','').Substring(0,24)
    $mutex = [Threading.Mutex]::new($false,('Local\MichaelsModpackStartup-' + $key))
    $owned = $false
    try {
        try { $owned = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $owned = $true }
        if (-not $owned) { return }
        $before = Get-MichaelsStartupSnapshot $Target
        if ($before.GameVisible) { return }
        $statePath = Join-Path $Target.Root 'Launcher\michaels-startup-1121.state.json'
        if ((Test-Path -LiteralPath $statePath) -and ([IO.File]::GetAttributes($statePath) -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'The startup status file is linked to another location.'
        }
        $accountFile = Join-Path $Target.Data 'accounts.json'
        $form = New-MichaelsLaunchForm $Target
        $app = [Windows.Forms.ApplicationContext]::new()
        $timer = [Windows.Forms.Timer]::new()
        $timer.Interval = 600
        $foreground = [Windows.Forms.Timer]::new()
        $foreground.Interval = 500
        $foreground.Add_Tick({
            $foreground.Stop()
            $form.TopMost = $false
        }.GetNewClosure())
        $ready = $null
        if ($env:MICHAELS_PLAY_READY -match '^Local\\MichaelsPlayReady-[0-9a-f]{32}$') {
            try { $ready = [Threading.EventWaitHandle]::OpenExisting($env:MICHAELS_PLAY_READY) } catch { }
        }
        # Capture the callbacks because WinForms runs them outside Play's local scope.
        $snapshot = (Get-Item Function:Get-MichaelsStartupSnapshot).ScriptBlock
        $view = (Get-Item Function:Set-MichaelsLaunchView).ScriptBlock
        $startProcess = Get-Command Start-Process -ErrorAction Stop
        $context = @{
            Process=$null; Started=$null; FirstSignIn=-not [IO.File]::Exists($accountFile)
            VisibleSamples=0; LastJava=$null; LastView=''; NativePrompt=$false
        }
        $form.Controls['Footer'].Visible = $context.FirstSignIn -and $Target.DesktopShortcutReady
        $begin = {
            $context.Started = [DateTime]::UtcNow
            $context.VisibleSamples = 0
            $context.LastJava = $null
            $context.NativePrompt = $false
            $context.LastView = ''
            if ($context.Process) { $context.Process.Dispose(); $context.Process = $null }
            try {
                $state = @{schema=1; startedUtc=$context.Started.ToString('o'); phase='Preparing'} | ConvertTo-Json -Compress
                [IO.File]::WriteAllText($statePath,$state,[Text.UTF8Encoding]::new($false))
                $phase = if ($context.FirstSignIn) { 'OpeningSignIn' } else { 'Checking' }
                & $view $form $phase
                $current = & $snapshot $Target
                if (-not $current.HasJava) {
                    $context.Process = & $startProcess -FilePath $Target.Exe -ArgumentList $LaunchArguments -WorkingDirectory $Target.Root -WindowStyle Normal -PassThru
                }
                $timer.Start()
            } catch {
                $timer.Stop()
                & $view $form 'Error' $null 'The launcher did not open. Try again or open the launcher for details.'
            }
        }.GetNewClosure()
        $form.Controls['Action'].Add_Click($begin)
        $form.Add_FormClosed({ $app.ExitThread() }.GetNewClosure())
        $timer.Add_Tick({
            try {
                $current = & $snapshot $Target
                if ($current.GameVisible) { $context.VisibleSamples++ } else { $context.VisibleSamples = 0 }
                if ($context.VisibleSamples -ge 2) { $app.ExitThread(); return }
                $record = $null
                try { $record = [IO.File]::ReadAllText($statePath) | ConvertFrom-Json } catch { }
                $phase = if ($record.schema -eq 1) { $record.phase } else { 'Preparing' }
                if ($phase -eq 'Error') {
                    & $view $form 'Error' $null 'The update did not finish. Try again to resume the download.'
                    if (-not $form.Visible) { $form.Show() }
                    $timer.Stop()
                    return
                }
                if ($phase -eq 'Loading' -and $current.HasJava) { $context.LastJava = [DateTime]::UtcNow }
                if ($context.LastJava -and $current.Known -and -not $current.HasJava -and
                    ([DateTime]::UtcNow - $context.LastJava).TotalSeconds -gt 3) {
                    $app.ExitThread()
                    return
                }
                $elapsed = ([DateTime]::UtcNow - $context.Started).TotalSeconds
                $closed = $elapsed -gt 8 -and $current.Known -and $current.PrismCount -eq 0 -and
                    (-not $context.Process -or $context.Process.HasExited)
                if ($closed -or $elapsed -gt 1800) {
                    $timer.Stop()
                    if ($context.FirstSignIn -and $phase -eq 'Preparing') {
                        & $view $form 'SignIn' $null 'Sign-in was closed. You can try again when you are ready.'
                    } else {
                        & $view $form 'Error' $null 'Minecraft did not finish opening. Try again or open the launcher for details.'
                    }
                    if (-not $form.Visible) { $form.Show() }
                    return
                }
                if ($phase -eq 'Preparing' -and $current.LauncherVisible -and -not $current.HasJava) {
                    $context.NativePrompt = $true
                    if ($form.Visible) { $form.Hide() }
                    return
                }
                if ($phase -eq 'Preparing' -and $context.FirstSignIn -and -not [IO.File]::Exists($accountFile) -and -not $current.HasJava) {
                    if (-not $context.NativePrompt) { & $view $form 'OpeningSignIn' }
                    return
                }
                $display = switch ($phase) {
                    'Downloading' { 'Downloading' }
                    'Loading' { 'Loading' }
                    default { if ($current.HasJava) { 'Loading' } else { 'Checking' } }
                }
                $viewKey = "$display|$($record.completed)|$($record.total)|$($record.lastDownload)|$($record.result)"
                if ($viewKey -cne $context.LastView) {
                    & $view $form $display $record
                    $context.LastView = $viewKey
                }
                if (-not $form.Visible) { $form.Show() }
            } catch { } # Prism still owns the actual launch and displays its own errors.
        }.GetNewClosure())

        try {
            $autoStart = -not $context.FirstSignIn -or $before.HasJava
            if ($autoStart) { & $view $form 'Checking' }
            else { & $view $form 'SignIn' }
            $form.Add_Shown({
                $form.WindowState = 'Normal'
                $form.TopMost = $true
                $form.BringToFront()
                $form.Activate()
                $form.Refresh()
                if ($ready) { [void]$ready.Set() }
                $foreground.Start()
                if ($autoStart) { & $begin }
            }.GetNewClosure())
            $form.Show()
            [Windows.Forms.Application]::Run($app)
        } finally {
            $timer.Stop()
            $timer.Dispose()
            $foreground.Stop()
            $foreground.Dispose()
            if ($ready) { $ready.Dispose() }
            if ($context.Process) { $context.Process.Dispose() }
            $form.Dispose()
            $app.Dispose()
        }
    } finally {
        if ($owned) { $mutex.ReleaseMutex() }
        $mutex.Dispose()
    }
}
