param([Parameter(Mandatory=$true)][string]$GameDirectory,[string]$DesktopPath,[string]$ProgramsPath)
$ErrorActionPreference='Stop'
$game=[IO.DirectoryInfo]::new([IO.Path]::GetFullPath($GameDirectory))
if($game.Name -notin @('minecraft','.minecraft')){throw 'Not a portable game folder'}
$instance=$game.Parent;$instances=$instance.Parent;$data=$instances.Parent;$root=$data.Parent
if($instances.Name -ine 'instances' -or $data.Name -ine 'Data' -or $instance.Name -notmatch '^[A-Za-z0-9_. -]+$'){throw 'Not a portable Prism instance'}
$launcher=Join-Path $root.FullName 'Launcher';$exe=Join-Path $launcher 'prismlauncher.exe';$instanceConfig=Join-Path $instance.FullName 'instance.cfg'
foreach($path in @($game.FullName,$instance.FullName,$instances.FullName,$data.FullName,$root.FullName,$launcher,$exe,$instanceConfig)){
 if(-not [IO.File]::Exists($path) -and -not [IO.Directory]::Exists($path)){throw 'Portable launcher path missing'}
 if($path -match '["\r\n]' -or ([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint)){throw 'Linked or ambiguous launcher path'}
}
function Copy-MichaelsShortcutAsset([string]$Source,[string]$Destination){
 if(-not [IO.File]::Exists($Source)){throw 'Shortcut artwork or helper missing'}
 foreach($path in @($Source,$Destination)){
  if((Test-Path -LiteralPath $path) -and ([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint)){throw 'Linked shortcut asset'}
 }
 if([IO.Path]::GetFullPath($Source) -ieq [IO.Path]::GetFullPath($Destination)){return}
 if([IO.File]::Exists($Destination) -and (Get-FileHash -LiteralPath $Source).Hash -eq (Get-FileHash -LiteralPath $Destination).Hash){return}
 [IO.File]::Copy($Source,$Destination,$true)
}
$icon=Join-Path $launcher 'michaels-modpack-1121.ico'
Copy-MichaelsShortcutAsset (Join-Path $PSScriptRoot 'michaels-modpack.ico') $icon
$installedScript=Join-Path $launcher 'michaels-shortcuts-1111.ps1'
Copy-MichaelsShortcutAsset $PSCommandPath $installedScript
# The installed helper expects the same icon name as the in-game migration.
Copy-MichaelsShortcutAsset $icon (Join-Path $launcher 'michaels-modpack.ico')
$target=$exe;$directory=$root.FullName
$arguments='--dir "{0}" --launch "{1}" --server 51.81.148.186:25590' -f $data.FullName,$instance.Name
$knownPlay=Join-Path $root.FullName 'PLAY MICHAELS MODPACK.cmd';$outer=$null
if($root.Name -ieq 'Setup'){$outer=Join-Path $root.Parent.FullName 'PLAY MICHAELS MODPACK.cmd'}
foreach($candidate in @($outer,$knownPlay)){
 if(-not $candidate -or -not [IO.File]::Exists($candidate)){continue}
 if(([IO.File]::GetAttributes($candidate) -band [IO.FileAttributes]::ReparsePoint)){throw 'Linked Play entry'}
 $target=$candidate;$directory=Split-Path -Parent $candidate;$arguments='';break
}
if(-not $DesktopPath){$DesktopPath=[Environment]::GetFolderPath('Desktop')}
if(-not $ProgramsPath){$ProgramsPath=[Environment]::GetFolderPath('Programs')}
if(-not $ProgramsPath){throw 'Windows Start menu unavailable'}
$shell=New-Object -ComObject WScript.Shell
try{
 foreach($entry in @(@{Folder=$DesktopPath;Name="Play Michael's Modpack.lnk"},@{Folder=$ProgramsPath;Name="Michael's Modpack.lnk"})){
  if(-not $entry.Folder){continue}
  if((Test-Path -LiteralPath $entry.Folder) -and ([IO.File]::GetAttributes($entry.Folder) -band [IO.FileAttributes]::ReparsePoint)){throw 'Linked shortcut destination'}
  [void][IO.Directory]::CreateDirectory($entry.Folder)
  $path=Join-Path $entry.Folder $entry.Name
  if((Test-Path -LiteralPath $path) -and ([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint)){continue}
  $exists=[IO.File]::Exists($path);$link=$shell.CreateShortcut($path)
  try{
   if($exists){
    $samePlay=($link.TargetPath -ieq $knownPlay -or ($outer -and $link.TargetPath -ieq $outer)) -and -not $link.Arguments
    $samePrism=($link.TargetPath -ieq $exe) -and ($link.Arguments -ceq ('--dir "{0}" --launch "{1}" --server 51.81.148.186:25590' -f $data.FullName,$instance.Name))
    $legacyNative=($link.TargetPath -ieq (Join-Path $env:WINDIR 'explorer.exe')) -and
      ($link.Arguments -ceq 'shell:AppsFolder\Microsoft.4297127D64EC6_8wekyb3d8bbwe!Minecraft') -and
      ($link.Description -ceq "Open the existing Minecraft Launcher for Michael's Modpack.") -and
      ($link.IconLocation -match '(?i)Michaels Modpack\\Artwork\\michaels-modpack-(1111|1121)\.ico,0$')
    if(-not($samePlay -or $samePrism -or $legacyNative)){continue}
   }
   $iconLocation=$icon+',0'
   if($exists -and $link.IconLocation -and $link.IconLocation -ine $iconLocation){
    $oldLocation=$link.IconLocation -replace ',0$',''
    $official=$legacyNative
    if([IO.Path]::GetDirectoryName($oldLocation) -ieq $launcher -and [IO.Path]::GetFileName($oldLocation) -in @('michaels-modpack-1111.ico','michaels-modpack.ico')){
     if(Test-Path -LiteralPath $oldLocation -PathType Leaf){$official=(Get-FileHash -LiteralPath $oldLocation).Hash.ToLowerInvariant() -in @('51c4dfba51abf47ecc886b169ee7a41b634830436d4b8ab245a9b7d18aa3afa9','cefb7ac11d860d46aa2a4faa69e1adb2bb9d41081d353d21e292fe9b3cda8602')}
    }
    if(-not $official){$iconLocation=$link.IconLocation}
   }
   if($exists -and $link.TargetPath -ieq $target -and $link.Arguments -ceq $arguments -and $link.WorkingDirectory -ieq $directory -and $link.IconLocation -ieq $iconLocation){continue}
   $link.TargetPath=$target;$link.Arguments=$arguments;$link.WorkingDirectory=$directory;$link.IconLocation=$iconLocation
   if(-not $exists){$link.Description="Play Michael's Modpack using your saved account."}
   $link.Save()
  }finally{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($link)}
 }
}finally{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell)}
# Retire only the exact old official helpers so they cannot reset the icon on Play.
$helper=Join-Path $launcher 'michaels-launcher-ui.ps1'
if([IO.File]::Exists($helper) -and -not ([IO.File]::GetAttributes($helper) -band [IO.FileAttributes]::ReparsePoint)){
 $allowed=@('651bc96807ecb57cfb2e0148e24db33372b604a626c7521f53e7f70d8b7d26f4','83d4796dd24a0d052488427092f22dfed426a0b4c2b9e2dc1b8b820453e51cf5')
 if($allowed -contains (Get-FileHash -LiteralPath $helper -Algorithm SHA256).Hash.ToLowerInvariant()){
  $source=[IO.File]::ReadAllText($helper);$start=$source.IndexOf('function New-MichaelsDesktopShortcut {');$end=$source.IndexOf('function Install-MichaelsPlayEntry',$start)
  if($start -ge 0 -and $end -gt $start){
   $replacement=@'
function New-MichaelsDesktopShortcut {
    param($Target,[string]$DesktopPath,[string]$ProgramsPath)
    & (Join-Path $Target.Root 'Launcher\michaels-shortcuts-1111.ps1') -GameDirectory (Join-Path $Target.Data ('instances\'+$Target.InstanceId+'\minecraft')) -DesktopPath $DesktopPath -ProgramsPath $ProgramsPath
}

'@
   [IO.File]::WriteAllText($helper,($source.Substring(0,$start)+$replacement+$source.Substring($end)),[Text.UTF8Encoding]::new($false))
  }
 }
}
$marker=Join-Path $game.FullName 'config\michaels-shortcuts-1111.done'
[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($marker))
if(-not [IO.File]::Exists($marker)){[IO.File]::WriteAllText($marker,"Thumbnail shortcuts and Start menu entry registered.`n",[Text.UTF8Encoding]::new($false))}
