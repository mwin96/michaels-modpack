@echo off
setlocal DisableDelayedExpansion
if not exist "%~dp0Launcher\michaels-play.ps1" goto missing
if not exist "%~dp0Data\instances\michaels-modpack\instance.cfg" goto missing
echo Opening launcher...
powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0Launcher\michaels-play.ps1" -WaitForWindow
if errorlevel 1 goto failed
exit /b 0
:failed
echo The launcher did not open. Close this window and try Play again.
pause
exit /b 1
:missing
echo First, right-click the downloaded ZIP and choose Extract All.
echo Open the extracted folder, then click PLAY MICHAELS MODPACK.cmd.
echo Keep the Play file and Setup folder together.
pause
exit /b 1
