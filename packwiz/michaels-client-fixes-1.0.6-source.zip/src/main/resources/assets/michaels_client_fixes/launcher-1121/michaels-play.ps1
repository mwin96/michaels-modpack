param([switch]$WaitForWindow)
$ErrorActionPreference='Stop'
if ($WaitForWindow) {
    $eventName = 'Local\MichaelsPlayReady-' + [Guid]::NewGuid().ToString('N')
    $ready = [Threading.EventWaitHandle]::new($false,[Threading.EventResetMode]::ManualReset,$eventName)
    $child = $null
    try {
        try {
            Add-Type -Namespace MichaelsModpack -Name Foreground -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("user32.dll")]
public static extern bool AllowSetForegroundWindow(int processId);
'@
        } catch { }
        $start = [Diagnostics.ProcessStartInfo]::new()
        $start.FileName = Join-Path $PSHOME 'powershell.exe'
        $start.UseShellExecute = $false
        $start.CreateNoWindow = $true
        $start.Arguments = '-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"'
        $start.EnvironmentVariables['MICHAELS_PLAY_READY'] = $eventName
        $start.EnvironmentVariables['PSModulePath'] = Join-Path $PSHOME 'Modules'
        $child = [Diagnostics.Process]::Start($start)
        if ('MichaelsModpack.Foreground' -as [type]) {
            [void][MichaelsModpack.Foreground]::AllowSetForegroundWindow($child.Id)
        }
        $clock = [Diagnostics.Stopwatch]::StartNew()
        while ($clock.Elapsed.TotalSeconds -lt 90) {
            # WaitOne wakes as soon as the window signals that it has been painted.
            if ($ready.WaitOne(100)) { exit 0 }
            if ($child.HasExited) { exit $child.ExitCode }
        }
        Write-Host 'The launcher is taking longer than expected.'
        exit 1
    } finally {
        if ($child) { $child.Dispose() }
        $ready.Dispose()
    }
}
try {
    . (Join-Path $PSScriptRoot 'michaels-launcher-ui.ps1')
    $target=Get-MichaelsPortableTarget -BundleRoot (Split-Path -Parent $PSScriptRoot)
    if($null -eq $target){throw 'Extract the whole modpack ZIP first, then click PLAY MICHAELS MODPACK.cmd.'}
    Hide-MichaelsSupportFiles -Target $target
    $policy=Join-Path $PSScriptRoot 'michaels-hardware-policy-111.ps1'
    if(Test-Path -LiteralPath $policy -PathType Leaf){
        . $policy
        [void](Start-MichaelsFreshHardware -InstanceDirectory (Join-Path $target.Data ('instances\'+$target.InstanceId)) -BeforePrism)
    }
    # Freshness must be recorded before shortcuts create the first game/config file.
    $desktopShortcutReady = $false
    try {
        New-MichaelsDesktopShortcut -Target $target
        $desktop = [Environment]::GetFolderPath('Desktop')
        if ($desktop -and -not [IO.File]::Exists((Join-Path $target.Data 'accounts.json'))) {
            $shortcut = Join-Path $desktop "Play Michael's Modpack.lnk"
            $play = Get-MichaelsPlayCommand -Target $target
            if ($play -and [IO.File]::Exists($shortcut)) {
                $shell = New-Object -ComObject WScript.Shell
                try {
                    $link = $shell.CreateShortcut($shortcut)
                    try { $desktopShortcutReady = $link.TargetPath -ieq $play.Path -and -not $link.Arguments }
                    finally { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($link) }
                } finally { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell) }
            }
        }
    } catch { }
    $target | Add-Member -NotePropertyName DesktopShortcutReady -NotePropertyValue $desktopShortcutReady
    . (Join-Path $PSScriptRoot 'michaels-console-1121.ps1')
    Set-MichaelsConsole1121 -Target $target
    Start-MichaelsGame $target
}catch{
    Add-Type -AssemblyName System.Windows.Forms
    [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,"Michael's Modpack",'OK','Warning')
    exit 1
}
