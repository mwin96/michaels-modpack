$ErrorActionPreference='Stop'
try {
    . (Join-Path $PSScriptRoot 'michaels-launcher-ui.ps1')
    $target=Get-MichaelsPortableTarget -BundleRoot (Split-Path -Parent $PSScriptRoot)
    if($null -eq $target){throw 'Extract the whole modpack ZIP first, then click PLAY MICHAELS MODPACK.cmd.'}
    Hide-MichaelsSupportFiles -Target $target
    $policy=Join-Path $PSScriptRoot 'michaels-hardware-policy-111.ps1'
    if(Test-Path -LiteralPath $policy -PathType Leaf){
        . $policy
        [void](Start-MichaelsFreshHardware -InstanceDirectory (Join-Path $target.Data ('instances\'+$target.InstanceId)) -BeforePrism)
    }
    # Freshness must be recorded before shortcuts create the first game/config file.
    try{New-MichaelsDesktopShortcut -Target $target}catch{}
    . (Join-Path $PSScriptRoot 'michaels-console-1121.ps1')
    Set-MichaelsConsole1121 -Target $target
    Start-MichaelsGame $target
}catch{
    Add-Type -AssemblyName System.Windows.Forms
    [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,"Michael's Modpack",'OK','Warning')
    exit 1
}
