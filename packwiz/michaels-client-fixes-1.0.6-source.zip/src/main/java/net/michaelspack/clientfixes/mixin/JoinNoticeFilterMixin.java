package net.michaelspack.clientfixes.mixin;

import net.michaelspack.clientfixes.JoinNoticeFilter;
import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import net.minecraft.network.chat.contents.TranslatableContents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatComponent.class)
abstract class JoinNoticeFilterMixin {
    @Inject(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V",
            at = @At("HEAD"), cancellable = true)
    private void michaels$hideSetupNotice(Component message, MessageSignature signature, GuiMessageTag tag, CallbackInfo callback) {
        if (signature != null) {
            return;
        }
        if (message.getContents() instanceof TranslatableContents text && JoinNoticeFilter.isSetupTranslation(text.getKey())) {
            callback.cancel();
            return;
        }
        if (JoinNoticeFilter.isSetupText(message.getString())) {
            callback.cancel();
        }
    }
}
