package net.michaelspack.clientfixes;

import java.util.regex.Pattern;

public final class JoinNoticeFilter {
    private static final Pattern LEGACY_COLOR = Pattern.compile("§[0-9a-fk-or]", Pattern.CASE_INSENSITIVE);
    private static final Pattern MAID_TIMING = Pattern.compile("\\[TLM\\] Model loading time: \\d+(?:[.,]\\d+)? ms");

    private JoinNoticeFilter() {}

    public static boolean isSetupTranslation(String key) {
        return switch (key) {
            case "enhancedcelestials2core.translation.not_configured",
                 "message.unmannedonlinetickstasis.resumed_chat",
                 "message.touhou_little_maid.reload.tip" -> true;
            default -> false;
        };
    }

    public static boolean isSetupText(String message) {
        String text = LEGACY_COLOR.matcher(message).replaceAll("").strip();
        int end = text.indexOf('\n');
        String firstLine = end < 0 ? text : text.substring(0, end).stripTrailing();
        return switch (firstLine) {
            case "Distant Horizons: High vanilla render distance detected.",
                 "Distant Horizons: Alex's Cave detected.",
                 "Server resumed. Welcome back!" -> true;
            default -> firstLine.startsWith("Enhanced Celestials 2 translation settings not yet configured.")
                    || MAID_TIMING.matcher(firstLine).matches();
        };
    }
}
