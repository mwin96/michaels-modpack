package net.michaelspack.clientfixes;

import java.util.concurrent.CompletableFuture;
import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.AudioStream;
import net.minecraft.client.sounds.SoundBufferLibrary;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;

/** Preserve native sound parameters; only its looping flag belongs to the six-second controller. */
final class EternalBellSound110 implements SoundInstance {
    private final SoundInstance nativeSound;
    EternalBellSound110(SoundInstance nativeSound){this.nativeSound=nativeSound;}
    public ResourceLocation getLocation(){return nativeSound.getLocation();}
    public WeighedSoundEvents resolve(SoundManager manager){return nativeSound.resolve(manager);}
    public Sound getSound(){return nativeSound.getSound();}
    public SoundSource getSource(){return nativeSound.getSource();}
    public boolean isLooping(){return true;}
    public boolean isRelative(){return nativeSound.isRelative();}
    public int getDelay(){return 0;}
    public float getVolume(){return nativeSound.getVolume();}
    public float getPitch(){return nativeSound.getPitch();}
    public double getX(){return nativeSound.getX();}
    public double getY(){return nativeSound.getY();}
    public double getZ(){return nativeSound.getZ();}
    public Attenuation getAttenuation(){return nativeSound.getAttenuation();}
    public boolean canStartSilent(){return nativeSound.canStartSilent();}
    public boolean canPlaySound(){return nativeSound.canPlaySound();}
    public CompletableFuture<AudioStream> getStream(SoundBufferLibrary library,Sound sound,boolean looping){return nativeSound.getStream(library,sound,looping);}
}
