package net.michaelspack.clientfixes;

/** One monotonic six-second image/sound window, then sixty seconds of quiet. */
public final class BellBudget109 {
    public static final long ACTIVE_NANOS=6_000_000_000L, CYCLE_NANOS=66_000_000_000L;
    private boolean started,interrupted,bellClaimed;
    private long start;
    public synchronized boolean due(long now,boolean eligible){return eligible&&(!started||now-start>=CYCLE_NANOS);}
    public synchronized boolean admit(long now,boolean eligible){
        if(!due(now,eligible))return false;
        started=true;interrupted=false;bellClaimed=false;start=now;return true;
    }
    public synchronized void eligibility(boolean eligible){if(!eligible&&started)interrupted=true;}
    public synchronized boolean active(long now,boolean eligible){
        eligibility(eligible);long elapsed=now-start;
        return eligible&&started&&!interrupted&&elapsed>=0&&elapsed<ACTIVE_NANOS;
    }
    public synchronized boolean claimBell(long now,boolean eligible){if(!active(now,eligible)||bellClaimed)return false;bellClaimed=true;return true;}
    public synchronized long elapsedMillis(long now){return Math.max(0L,Math.min(6_000L,(now-start)/1_000_000L));}
    public synchronized void reset(){started=false;interrupted=false;bellClaimed=false;start=0;}
}
