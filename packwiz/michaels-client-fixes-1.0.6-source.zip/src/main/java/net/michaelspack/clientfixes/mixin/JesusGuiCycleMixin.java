package net.michaelspack.clientfixes.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.michaelspack.clientfixes.EternalBellLimit109;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Exact optional Eternal Jesus1.4 hook; native image choice and sound creation remain intact. */
@Pseudo
@Mixin(targets="com.eternity.jessemood.client.guihandler",remap=false)
public abstract class JesusGuiCycleMixin {
    @Shadow(remap=false) private static boolean shouldDisplay;
    @Shadow(remap=false) private static long startTime;
    @Unique private static boolean michaels$restoreColor;
    @Unique private static float michaels$r,michaels$g,michaels$b,michaels$a;
    @Inject(method="triggerDisplay()V",at=@At("HEAD"),cancellable=true,require=1,remap=false)
    private static void michaels$sharedAdmission(CallbackInfo callback){
        if(!EternalBellLimit109.admitTrigger()){callback.cancel();return;}
        // Ensure even a non-rendered previous window cannot suppress the next native display().
        shouldDisplay=false;startTime=-1L;
    }
    @Inject(method="render(Lnet/minecraft/client/gui/GuiGraphics;)V",at=@At("HEAD"),cancellable=true,require=1,remap=false)
    private static void michaels$activeOnly(GuiGraphics graphics,CallbackInfo callback){
        michaels$restoreColor=false;
        if(!EternalBellLimit109.effectActive()){shouldDisplay=false;startTime=-1L;callback.cancel();return;}
        float[] color=RenderSystem.getShaderColor();michaels$r=color[0];michaels$g=color[1];michaels$b=color[2];michaels$a=color[3];michaels$restoreColor=true;
    }
    @Redirect(method="render(Lnet/minecraft/client/gui/GuiGraphics;)V",at=@At(value="INVOKE",target="Ljava/lang/System;currentTimeMillis()J"),require=1,remap=false)
    private static long michaels$monotonicFade(){return startTime+EternalBellLimit109.elapsedMillis();}
    @ModifyConstant(method="render(Lnet/minecraft/client/gui/GuiGraphics;)V",constant=@Constant(longValue=500L),require=1,allow=1,remap=false)
    private static long michaels$sixSecondDisplay(long original){return 6_000L;}
    @ModifyConstant(method="render(Lnet/minecraft/client/gui/GuiGraphics;)V",constant=@Constant(floatValue=500F),require=1,allow=1,remap=false)
    private static float michaels$sixSecondFade(float original){return 6_000F;}
    @Inject(method="render(Lnet/minecraft/client/gui/GuiGraphics;)V",at=@At("RETURN"),require=1,remap=false)
    private static void michaels$restoreShaderColor(GuiGraphics graphics,CallbackInfo callback){
        if(michaels$restoreColor){RenderSystem.setShaderColor(michaels$r,michaels$g,michaels$b,michaels$a);michaels$restoreColor=false;}
    }
}
