package net.michaelspack.clientfixes;

import java.nio.file.*;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Locale;

/** Once-only COM shortcut creation for this already installed portable Prism instance. */
public final class AutomaticPlayShortcut109 {
    public static final String MARKER="config/michaels-shortcuts-1111.done";
    private static final String ASSET="/assets/michaels_client_fixes/desktop-play-1111.ps1";
    private static final String SCRIPT_SHA256="f3f19892a8c8a574b5dbffc48d74d0ea45613456801c3fabe5e6dd4ed79081d0";
    private static boolean attempted;
    private AutomaticPlayShortcut109(){}
    public static Path portableRoot(Path game){
        if(game==null)return null;Path current=game.toAbsolutePath().normalize();if(current.getFileName()==null)return null;String leaf=current.getFileName().toString();
        if(!leaf.equalsIgnoreCase("minecraft")&&!leaf.equalsIgnoreCase(".minecraft"))return null;
        Path instance=current.getParent(),instances=instance==null?null:instance.getParent(),data=instances==null?null:instances.getParent(),root=data==null?null:data.getParent();
        if(root==null||!instances.getFileName().toString().equalsIgnoreCase("instances")||!data.getFileName().toString().equalsIgnoreCase("Data")||!instance.getFileName().toString().matches("[A-Za-z0-9_. -]+"))return null;
        if(!Files.isRegularFile(instance.resolve("instance.cfg"))||!Files.isRegularFile(root.resolve("Launcher/prismlauncher.exe")))return null;
        return root;
    }
    public static void tick(Path game){ LauncherStartupMigration1121.tick(game); }
}
