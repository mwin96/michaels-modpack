package net.michaelspack.clientfixes;

import java.nio.file.*;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Locale;

/** Once-only COM shortcut creation for this already installed portable Prism instance. */
public final class AutomaticPlayShortcut109 {
    public static final String MARKER="config/michaels-shortcuts-1111.done";
    private static final String ASSET="/assets/michaels_client_fixes/desktop-play-1111.ps1";
    private static final String SCRIPT_SHA256="f3f19892a8c8a574b5dbffc48d74d0ea45613456801c3fabe5e6dd4ed79081d0";
    private static boolean attempted;
    private AutomaticPlayShortcut109(){}
    public static Path portableRoot(Path game){
        if(game==null)return null;Path current=game.toAbsolutePath().normalize();if(current.getFileName()==null)return null;String leaf=current.getFileName().toString();
        if(!leaf.equalsIgnoreCase("minecraft")&&!leaf.equalsIgnoreCase(".minecraft"))return null;
        Path instance=current.getParent(),instances=instance==null?null:instance.getParent(),data=instances==null?null:instances.getParent(),root=data==null?null:data.getParent();
        if(root==null||!instances.getFileName().toString().equalsIgnoreCase("instances")||!data.getFileName().toString().equalsIgnoreCase("Data")||!instance.getFileName().toString().matches("[A-Za-z0-9_. -]+"))return null;
        if(!Files.isRegularFile(instance.resolve("instance.cfg"))||!Files.isRegularFile(root.resolve("Launcher/prismlauncher.exe")))return null;
        return root;
    }
    public static void tick(Path game){
        if(attempted)return;attempted=true;
        if(!System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows")||Files.isRegularFile(game.resolve(MARKER)))return;
        Path root=portableRoot(game);if(root==null)return;
        try{
            byte[] script;try(var input=AutomaticPlayShortcut109.class.getResourceAsStream(ASSET)){if(input==null)return;script=input.readAllBytes();}
            if(!HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(script)).equals(SCRIPT_SHA256))throw new IllegalStateException("Shortcut helper integrity");
            Path directory=game.resolve("config/michaels-shortcuts-1111"),file=directory.resolve("create-shortcut.ps1");Files.createDirectories(directory);
            Path temporary=Files.createTempFile(directory,".shortcut-",".tmp");try{Files.write(temporary,script);try{Files.move(temporary,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException unsupported){Files.move(temporary,file,StandardCopyOption.REPLACE_EXISTING);}}finally{Files.deleteIfExists(temporary);}
            byte[] icon;try(var input=AutomaticPlayShortcut109.class.getResourceAsStream("/assets/michaels_client_fixes/michaels-modpack.ico")){if(input==null)return;icon=input.readAllBytes();}
            if(!HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(icon)).equals("51c4dfba51abf47ecc886b169ee7a41b634830436d4b8ab245a9b7d18aa3afa9"))throw new IllegalStateException("Shortcut icon integrity");
            Files.write(directory.resolve("michaels-modpack.ico"),icon);
            String system=System.getenv("SystemRoot");if(system==null)return;
            Path powershell=Path.of(system,"System32","WindowsPowerShell","v1.0","powershell.exe");if(!Files.isRegularFile(powershell))return;
            ProcessBuilder process=new ProcessBuilder(powershell.toString(),"-NoLogo","-NoProfile","-NonInteractive","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",file.toAbsolutePath().toString(),"-GameDirectory",game.toAbsolutePath().toString());
            process.environment().put("PSModulePath",Path.of(system,"System32","WindowsPowerShell","v1.0","Modules").toString());
            process.directory(root.toFile()).redirectOutput(ProcessBuilder.Redirect.DISCARD).redirectError(ProcessBuilder.Redirect.DISCARD).start();
        }catch(Exception failure){System.err.println("Michael's desktop Play shortcut was deferred: "+failure.getClass().getSimpleName());}
    }
}
