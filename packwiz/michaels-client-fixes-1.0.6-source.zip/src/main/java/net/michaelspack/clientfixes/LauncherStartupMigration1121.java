package net.michaelspack.clientfixes;
import java.nio.file.*;import java.util.*;import java.security.*;
public final class LauncherStartupMigration1121 {
 private static boolean attempted;
 private static final String[][] FILES={{"flat-play.cmd","f7aa8a6f93705104e1b8c27ea7c715604bc0953ce570ec5ec5bc89e3ef63b01e"},{"install-startup.ps1","fe1ba3c40871656faf264768f545366cfcf111e151ce64042f54f3be5b112115"},{"michaels-console-1121.ps1","4b94a896c46acf36b321119b57be3bb385afadc3477cba3906b1413316093922"},{"michaels-hardware-policy-111.ps1","0cf3670efdb7f6f1964ea481652bfff045c39b980fe2dcf2ba3cc5d5028842d1"},{"michaels-launcher-ui.ps1","17e646ce5823aa6f8803e8c5e2d0269ac1fa9273f66a6bc1a7ac0ce94f687525"},{"michaels-modpack.ico","cefb7ac11d860d46aa2a4faa69e1adb2bb9d41081d353d21e292fe9b3cda8602"},{"michaels-play.ps1","f842a8c34e469fd68a9a5c3aeb0d68f32e43b4608bc879973547647d1301c3b8"},{"michaels-prelaunch-111.ps1","c3468242e3734b4895a3bf5cd012103cfb4b5a334bbe55b62b5742fa17474a0a"},{"michaels-shortcuts-1111.ps1","de096984bda690a840dcdc13d31dab5b75de405751b607035499e977481cd348"},{"michaels-starting-1121.ps1","aad975d63a3c650cf17e2456bacd922e2bbb3d4017af33e4d9bc6bac24678971"},{"outer-play.cmd","0465a7085faaa57ff8fcab06a8a7e907d17a92cb737c59ffb6b612cc9bfa0420"},{"payload.json","a5ea59709c9ab5c0b7c638e42e0236bf17a6e9e3e7124db474a2f9a9decf1007"}};
 private LauncherStartupMigration1121(){}
 public static void tick(Path game){
  if(attempted)return;attempted=true;
  if(!System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows")||Files.isRegularFile(game.resolve("config/michaels-launcher-1128.done")))return;
  Path root=AutomaticPlayShortcut109.portableRoot(game);if(root==null)return;
  try{
   for(Path cursor=game.toAbsolutePath();cursor!=null;cursor=cursor.getParent())if(Files.isSymbolicLink(cursor)||(Files.readAttributes(cursor,java.nio.file.attribute.BasicFileAttributes.class,LinkOption.NOFOLLOW_LINKS).isOther()))return;
   Path directory=game.resolve("config/michaels-launcher-1121");Files.createDirectories(directory);
   for(String[] row:FILES){
    byte[] data;try(var input=LauncherStartupMigration1121.class.getResourceAsStream("/assets/michaels_client_fixes/launcher-1121/"+row[0])){if(input==null)throw new IllegalStateException("Missing startup asset");data=input.readAllBytes();}
    if(!HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data)).equals(row[1]))throw new IllegalStateException("Startup asset integrity");
    Path destination=directory.resolve(row[0]);if(Files.isSymbolicLink(destination))return;
    Path temporary=Files.createTempFile(directory,".startup-",".tmp");try{Files.write(temporary,data);Files.move(temporary,destination,StandardCopyOption.REPLACE_EXISTING);}finally{Files.deleteIfExists(temporary);}
   }
   String system=System.getenv("SystemRoot");if(system==null)return;
   Path powershell=Path.of(system,"System32","WindowsPowerShell","v1.0","powershell.exe");if(!Files.isRegularFile(powershell))return;
   ProcessBuilder process=new ProcessBuilder(powershell.toString(),"-NoLogo","-NoProfile","-NonInteractive","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",directory.resolve("install-startup.ps1").toString(),"-GameDirectory",game.toAbsolutePath().toString());
   process.environment().put("PSModulePath",Path.of(system,"System32","WindowsPowerShell","v1.0","Modules").toString());process.directory(root.toFile()).redirectOutput(directory.resolve("migration.log").toFile()).redirectErrorStream(true).start();
  }catch(Exception failure){System.err.println("Michael's startup update deferred: "+failure.getClass().getSimpleName());}
 }
}