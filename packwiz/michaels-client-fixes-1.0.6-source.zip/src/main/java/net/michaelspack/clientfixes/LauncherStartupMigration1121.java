package net.michaelspack.clientfixes;
import java.nio.file.*;import java.util.*;import java.security.*;
public final class LauncherStartupMigration1121 {
 private static boolean attempted;
 private static final String[][] FILES={{"flat-play.cmd","f4536ec13ff24c95b9c960c5f129e7270f663d0e57cef20f5f8a7afdced7f318"},{"install-startup.ps1","6f18ba4c48fdef806c4da19da7d1f34e198f305bdb44c87964718518c80aef21"},{"michaels-console-1121.ps1","2e36220a67303655cf7b3fe70c0cd8ae174bfd60f3be25db09148edfc1e2ed7b"},{"michaels-hardware-policy-111.ps1","44e43c8cf5a078af5a7850d0ce90ae200c80cf88b6a50032bc48e3fb435a9c73"},{"michaels-launcher-ui.ps1","4729042711386c32bd140fddd641e356ecc9fe3c00a59ff72584d583759a58bd"},{"michaels-modpack.ico","cefb7ac11d860d46aa2a4faa69e1adb2bb9d41081d353d21e292fe9b3cda8602"},{"michaels-play.ps1","f98ff162e278285fa815108eb0abfb2a51bb4d77d35b97c634387dfa99ebb75e"},{"michaels-prelaunch-111.ps1","4995b5f79297831fab22b075215abafb959f6dd81b1446f145010655ca803693"},{"michaels-shortcuts-1111.ps1","de096984bda690a840dcdc13d31dab5b75de405751b607035499e977481cd348"},{"michaels-starting-1121.ps1","5727ede3eb08972cfae2fbad31f49f3b3b2bbe0e9206d9cec479ae77dbd19cd8"},{"outer-play.cmd","79bf75576ff724fef2f0b7ce6646d762a5ad13d23f4c4499d168cf56cefaa632"},{"payload.json","6bbe788e2c69a68b7282136ad7d93b572b931160dd3b85a998545d5d41093ecb"}};
 private LauncherStartupMigration1121(){}
 public static void tick(Path game){
  if(attempted)return;attempted=true;
  if(!System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows")||Files.isRegularFile(game.resolve("config/michaels-launcher-1121.done")))return;
  Path root=AutomaticPlayShortcut109.portableRoot(game);if(root==null)return;
  try{
   for(Path cursor=game.toAbsolutePath();cursor!=null;cursor=cursor.getParent())if(Files.isSymbolicLink(cursor)||(Files.readAttributes(cursor,java.nio.file.attribute.BasicFileAttributes.class,LinkOption.NOFOLLOW_LINKS).isOther()))return;
   Path directory=game.resolve("config/michaels-launcher-1121");Files.createDirectories(directory);
   for(String[] row:FILES){
    byte[] data;try(var input=LauncherStartupMigration1121.class.getResourceAsStream("/assets/michaels_client_fixes/launcher-1121/"+row[0])){if(input==null)throw new IllegalStateException("Missing startup asset");data=input.readAllBytes();}
    if(!HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data)).equals(row[1]))throw new IllegalStateException("Startup asset integrity");
    Path destination=directory.resolve(row[0]);if(Files.isSymbolicLink(destination))return;
    Path temporary=Files.createTempFile(directory,".startup-",".tmp");try{Files.write(temporary,data);Files.move(temporary,destination,StandardCopyOption.REPLACE_EXISTING);}finally{Files.deleteIfExists(temporary);}
   }
   String system=System.getenv("SystemRoot");if(system==null)return;
   Path powershell=Path.of(system,"System32","WindowsPowerShell","v1.0","powershell.exe");if(!Files.isRegularFile(powershell))return;
   ProcessBuilder process=new ProcessBuilder(powershell.toString(),"-NoLogo","-NoProfile","-NonInteractive","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",directory.resolve("install-startup.ps1").toString(),"-GameDirectory",game.toAbsolutePath().toString());
   process.environment().put("PSModulePath",Path.of(system,"System32","WindowsPowerShell","v1.0","Modules").toString());process.directory(root.toFile()).redirectOutput(directory.resolve("migration.log").toFile()).redirectErrorStream(true).start();
  }catch(Exception failure){System.err.println("Michael's startup update deferred: "+failure.getClass().getSimpleName());}
 }
}