package net.michaelspack.clientfixes;
import java.nio.file.*;import java.util.*;import java.security.*;
public final class LauncherStartupMigration1121 {
 private static boolean attempted;
 private static final String[][] FILES={{"flat-play.cmd","a92765d4764ab2fc2b555b909da9b646d01f732f70dcba0b2b57738ff8d845d6"},{"install-startup.ps1","93811117615993e6588d29daf869fb5ffde8fe98818b8efd13cf6d5614586841"},{"michaels-console-1121.ps1","4b94a896c46acf36b321119b57be3bb385afadc3477cba3906b1413316093922"},{"michaels-hardware-policy-111.ps1","44e43c8cf5a078af5a7850d0ce90ae200c80cf88b6a50032bc48e3fb435a9c73"},{"michaels-launcher-ui.ps1","17e646ce5823aa6f8803e8c5e2d0269ac1fa9273f66a6bc1a7ac0ce94f687525"},{"michaels-modpack.ico","cefb7ac11d860d46aa2a4faa69e1adb2bb9d41081d353d21e292fe9b3cda8602"},{"michaels-play.ps1","f98ff162e278285fa815108eb0abfb2a51bb4d77d35b97c634387dfa99ebb75e"},{"michaels-prelaunch-111.ps1","d1f85ea63385630c07019908fe08424a44e4af1b14f79019f3ee4e51fffde4ba"},{"michaels-shortcuts-1111.ps1","de096984bda690a840dcdc13d31dab5b75de405751b607035499e977481cd348"},{"michaels-starting-1121.ps1","aed6a739c30d9f7fbbb524fb0653b1f4d9f69155806b856f9dff044543ee6d2d"},{"outer-play.cmd","4e07e84b040257f88e5b92e6f03996304a7e2144da4a97be79b5d7e00c15b88e"},{"payload.json","a3bb4bde52e119f92ef5e609020d25a8393f9d3ce6be37bcb6f02b1b6411dd78"}};
 private LauncherStartupMigration1121(){}
 public static void tick(Path game){
  if(attempted)return;attempted=true;
  if(!System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows")||Files.isRegularFile(game.resolve("config/michaels-launcher-1122.done")))return;
  Path root=AutomaticPlayShortcut109.portableRoot(game);if(root==null)return;
  try{
   for(Path cursor=game.toAbsolutePath();cursor!=null;cursor=cursor.getParent())if(Files.isSymbolicLink(cursor)||(Files.readAttributes(cursor,java.nio.file.attribute.BasicFileAttributes.class,LinkOption.NOFOLLOW_LINKS).isOther()))return;
   Path directory=game.resolve("config/michaels-launcher-1121");Files.createDirectories(directory);
   for(String[] row:FILES){
    byte[] data;try(var input=LauncherStartupMigration1121.class.getResourceAsStream("/assets/michaels_client_fixes/launcher-1121/"+row[0])){if(input==null)throw new IllegalStateException("Missing startup asset");data=input.readAllBytes();}
    if(!HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data)).equals(row[1]))throw new IllegalStateException("Startup asset integrity");
    Path destination=directory.resolve(row[0]);if(Files.isSymbolicLink(destination))return;
    Path temporary=Files.createTempFile(directory,".startup-",".tmp");try{Files.write(temporary,data);Files.move(temporary,destination,StandardCopyOption.REPLACE_EXISTING);}finally{Files.deleteIfExists(temporary);}
   }
   String system=System.getenv("SystemRoot");if(system==null)return;
   Path powershell=Path.of(system,"System32","WindowsPowerShell","v1.0","powershell.exe");if(!Files.isRegularFile(powershell))return;
   ProcessBuilder process=new ProcessBuilder(powershell.toString(),"-NoLogo","-NoProfile","-NonInteractive","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",directory.resolve("install-startup.ps1").toString(),"-GameDirectory",game.toAbsolutePath().toString());
   process.environment().put("PSModulePath",Path.of(system,"System32","WindowsPowerShell","v1.0","Modules").toString());process.directory(root.toFile()).redirectOutput(directory.resolve("migration.log").toFile()).redirectErrorStream(true).start();
  }catch(Exception failure){System.err.println("Michael's startup update deferred: "+failure.getClass().getSimpleName());}
 }
}