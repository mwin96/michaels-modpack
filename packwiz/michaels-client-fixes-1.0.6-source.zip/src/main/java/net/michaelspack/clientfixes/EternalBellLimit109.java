package net.michaelspack.clientfixes;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;

/** The optional Eternal Jesus image and its exact bell share one session-local clock. */
public final class EternalBellLimit109 {
    private static final BellBudget109 BUDGET=new BellBudget109();
    private static SoundInstance active;
    private static boolean installed,lookupDone;
    private static Method trigger;
    private static Field display,startTime;
    private EternalBellLimit109(){}
    public static synchronized void install(){
        if(installed)return;installed=true;
        MinecraftForge.EVENT_BUS.addListener(EternalBellLimit109::play);
        MinecraftForge.EVENT_BUS.addListener(EternalBellLimit109::tick);
        MinecraftForge.EVENT_BUS.addListener(EternalBellLimit109::logout);
    }
    private static boolean eligible(){
        Minecraft client=Minecraft.getInstance();
        return client.level!=null&&client.player!=null&&client.player.isAlive()
            &&client.player.getHealth()<=3.0F&&!client.player.isCreative()&&!client.player.isSpectator();
    }
    /** Called only at the original trigger's HEAD, including automatic critical-health cycles. */
    public static synchronized boolean admitTrigger(){return BUDGET.admit(System.nanoTime(),eligible());}
    public static synchronized boolean effectActive(){return BUDGET.active(System.nanoTime(),eligible());}
    public static synchronized long elapsedMillis(){return BUDGET.elapsedMillis(System.nanoTime());}
    private static synchronized void play(PlaySoundEvent event){
        SoundInstance sound=event.getSound();
        if(sound==null||!sound.getLocation().toString().equals("eternaljesus:jesus_bell"))return;
        if(!BUDGET.claimBell(System.nanoTime(),eligible())){event.setSound(null);return;}
        // Original non-streaming bell is 1.922s. Loop it only inside the shared six-second window.
        active=new EternalBellSound110(sound);event.setSound(active);
    }
    private static synchronized void lookup(){
        if(lookupDone)return;lookupDone=true;
        try{
            Class<?> type=Class.forName("com.eternity.jessemood.client.guihandler");
            trigger=type.getMethod("triggerDisplay");display=type.getDeclaredField("shouldDisplay");
            startTime=type.getDeclaredField("startTime");display.setAccessible(true);startTime.setAccessible(true);
        }catch(ReflectiveOperationException|LinkageError absent){trigger=null;display=null;startTime=null;}
    }
    private static void hide(){
        if(display==null)return;
        try{display.setBoolean(null,false);startTime.setLong(null,-1L);}
        catch(IllegalAccessException failure){throw new IllegalStateException("Eternal Jesus display fields changed",failure);}
    }
    private static synchronized void tick(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END)return;
        lookup();Minecraft client=Minecraft.getInstance();boolean eligible=eligible();long now=System.nanoTime();
        if(client.level==null||client.player==null){reset();return;}
        if(!BUDGET.active(now,eligible)){
            if(active!=null){client.getSoundManager().stop(active);active=null;}hide();
        }
        if(trigger!=null&&BUDGET.due(now,eligible))try{trigger.invoke(null);}
        catch(ReflectiveOperationException failure){throw new IllegalStateException("Eternal Jesus trigger changed",failure);}
    }
    private static synchronized void logout(ClientPlayerNetworkEvent.LoggingOut event){reset();}
    private static void reset(){
        if(active!=null){Minecraft.getInstance().getSoundManager().stop(active);active=null;}
        BUDGET.reset();hide();
    }
}
