package net.michaelspack.clientfixes.mixin;

import net.minecraft.client.GuiMessageTag;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ChatComponent.class)
abstract class ProgressChatLifetimeMixin {
    @ModifyVariable(method = "m_240465_(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;ILnet/minecraft/client/GuiMessageTag;Z)V",
            at = @At("HEAD"), argsOnly = true, ordinal = 0, remap = false)
    private int michaels$extendProgressDisplay(int addedTime, Component message, MessageSignature signature,
            int originalTime, GuiMessageTag tag, boolean refreshing) {
        if (refreshing || signature != null) {
            return addedTime;
        }
        String text = message.getString();
        if (text.startsWith("Welcome to michael's modpack! This world is ") || text.equals("The End portal is open!")) {
            // Vanilla keeps unfocused chat visible for 200 ticks from its added time.
            return addedTime + 200;
        }
        return addedTime;
    }
}
