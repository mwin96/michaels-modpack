package net.michaelspack.clientfixes;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.regex.*;

/** Applies the authorized 1121 review on the first updated client open when prelaunch could not. */
public final class HardwareReview1121 {
    static final String MARKER="config/michaels-hardware-policy-1128.json";
    private static final String PRIOR="config/michaels-hardware-policy-1121.json";
    static final String NORMAL="MakeUp-UltraFast-9.6.zip", ENHANCED="MakeUp-UltraFast-9.6-Enhanced.zip";
    private static final String POLICY="michaels-hardware-policy-111.ps1";
    private static final String POLICY_SHA="0cf3670efdb7f6f1964ea481652bfff045c39b980fe2dcf2ba3cc5d5028842d1";
    private static final String ASSET="/assets/michaels_client_fixes/launcher-1121/"+POLICY;
    private static final LinkOption[] NO_LINKS={LinkOption.NOFOLLOW_LINKS};
    private static final Pattern QUALITY=Pattern.compile("(?ms)^\\h*\\[client\\.advanced\\.graphics\\.quality\\]\\h*(?:#[^\\r\\n]*)?\\r?\\n(.*?)(?=^\\h*\\[|\\z)");
    private static final Pattern RADIUS=Pattern.compile("(?m)^(\\h*lodChunkRenderDistanceRadius\\h*=\\h*)[+-]?\\d+(\\h*(?:#[^\\r\\n]*)?)(\\r?)$");
    private static FutureTask<Profile> query;
    private static boolean finished;

    private HardwareReview1121() {}

    /** Call on ClientTickEvent.END, after AutomaticPlayShortcut109.tick(game). */
    public static void tick(Path game) {
        if(finished || game==null)return;
        if(!System.getProperty("os.name","").toLowerCase(Locale.ROOT).startsWith("windows") || Files.exists(game.resolve(MARKER),NO_LINKS)){
            finished=true;return;
        }
        if(query==null){
            query=new FutureTask<>(()->detect(game));
            Thread worker=new Thread(query,"Michaels hardware review 1121");worker.setDaemon(true);worker.start();
            return;
        }
        if(!query.isDone())return;
        try{
            Profile profile=query.get();
            Class<?> minecraft=Class.forName("net.minecraft.client.Minecraft");
            Object client=method(minecraft,"getInstance","m_91087_").invoke(null);
            if(client==null || method(minecraft,"getOverlay","m_91265_").invoke(client)!=null)return;
            Object options;
            try{options=minecraft.getField("options").get(client);}catch(NoSuchFieldException srg){options=minecraft.getField("f_91066_").get(client);}
            Class<?> iris=Class.forName("net.irisshaders.iris.Iris");
            if(options==null || iris.getMethod("getIrisConfig").invoke(null)==null)return;
            finished=true;
            apply(game,profile,new NativeGraphics(options,iris));
        }catch(Exception|LinkageError failed){
            finished=true;
            // Failed attempts do not consume the once receipt; the next launch can retry.
            System.err.println("Michael's graphics review deferred safely: "+failed.getClass().getSimpleName());
        }
    }

    record Profile(String tier,int heap,int render,int simulation,int dh,String shader,boolean highPixelLoad) {
        Profile {
            if(!Set.of("integrated-or-unknown","modest-discrete","mid-discrete","strong-discrete").contains(tier)
                || !Set.of(4096,5120,6144).contains(heap) || !Set.of(4,6,8,12,16).contains(render)
                || !Set.of(4,6,8).contains(simulation) || !Set.of(32,64,128).contains(dh)
                || !Set.of("OFF","Normal","Enhanced").contains(shader))throw new IllegalArgumentException("Invalid hardware profile");
        }
    }

    static Profile detect(Path game)throws Exception {
        byte[] policy=verifiedPolicy(game);
        String system=Objects.requireNonNull(System.getenv("SystemRoot"));
        Path powershell=Path.of(system,"System32","WindowsPowerShell","v1.0","powershell.exe");
        if(!Files.isRegularFile(powershell))throw new IOException("Windows hardware probe unavailable");
        // Pass the already verified bytes through stdin, so a staged file cannot be swapped after hashing.
        // The policy is side-effect-free when sourced; only the two detection functions are invoked.
        String code="$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Console]::InputEncoding=[Text.UTF8Encoding]::new($false); "
            +". ([ScriptBlock]::Create([Console]::In.ReadToEnd())); "
            +"$p=Get-MichaelsHardwareProfile (Get-MichaelsLocalHardware); "
            +"[Console]::WriteLine(('1128|{0}|{1}|{2}|{3}|{4}|{5}|{6}' -f $p.tier,$p.heapMiB,$p.renderDistance,$p.simulationDistance,$p.dhRadius,$p.shader,$p.highPixelLoad))";
        ProcessBuilder builder=new ProcessBuilder(powershell.toString(),"-NoLogo","-NoProfile","-NonInteractive","-WindowStyle","Hidden",
            "-ExecutionPolicy","Bypass","-EncodedCommand",Base64.getEncoder().encodeToString(code.getBytes(StandardCharsets.UTF_16LE)));
        builder.environment().put("PSModulePath",Path.of(system,"System32","WindowsPowerShell","v1.0","Modules").toString());
        builder.redirectError(ProcessBuilder.Redirect.DISCARD);
        Process process=builder.start();
        try{
            Thread writer=new Thread(()->{try(var input=process.getOutputStream()){input.write(policy);}catch(IOException ignored){}},"Michaels verified policy input");
            writer.setDaemon(true);writer.start();
            if(!process.waitFor(20,TimeUnit.SECONDS))throw new IOException("Hardware probe timed out");
            byte[] output;try(var stream=process.getInputStream()){output=stream.readNBytes(4097);}
            if(process.exitValue()!=0 || output.length>4096)throw new IOException("Hardware probe failed");
            String[] fields=new String(output,StandardCharsets.UTF_8).strip().split("\\|",-1);
            if(fields.length!=8 || !fields[0].equals("1128"))throw new IOException("Hardware probe response invalid");
            return new Profile(fields[1],Integer.parseInt(fields[2]),Integer.parseInt(fields[3]),Integer.parseInt(fields[4]),Integer.parseInt(fields[5]),fields[6],Boolean.parseBoolean(fields[7]));
        }finally{if(process.isAlive())process.destroyForcibly();}
    }

    private static byte[] verifiedPolicy(Path game)throws Exception {
        Path staged=game.resolve("config/michaels-launcher-1121").resolve(POLICY);
        if(Files.isRegularFile(staged,NO_LINKS) && Files.size(staged)<=32768){
            try{
                safePath(staged);
                byte[] bytes;try(var in=Files.newInputStream(staged)){bytes=in.readNBytes(32769);}
                if(policyMatches(bytes))return bytes;
            }catch(IOException invalidStaging){/* use the packaged asset */}
        }
        try(var in=HardwareReview1121.class.getResourceAsStream(ASSET)){
            if(in!=null){byte[] bytes=in.readNBytes(32769);if(policyMatches(bytes))return bytes;}
        }
        throw new IOException("Verified graphics policy missing");
    }

    private static boolean policyMatches(byte[] bytes)throws Exception {
        return bytes.length<=32768 && HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)).equals(POLICY_SHA);
    }

    interface Graphics {
        int render()throws Exception; int simulation()throws Exception; int dh()throws Exception;
        void render(int value)throws Exception; void simulation(int value)throws Exception; void dh(int value)throws Exception;
        boolean shaderMatches(boolean enabled,String pack)throws Exception;
        void reloadShaders()throws Exception;
        void broadcast()throws Exception;
    }

    static boolean apply(Path game,Profile profile,Graphics live)throws Exception {
        Path marker=game.resolve(MARKER);
        if(Files.exists(marker,NO_LINKS))return false;
        safePath(marker);
        Path prior=game.resolve(PRIOR);
        safePath(prior);
        boolean reviewed=Files.exists(prior,NO_LINKS);
        if(reviewed && (!profile.highPixelLoad() || !profile.shader().equals("Normal")))return false;
        Path[] files={game.resolve("options.txt"),game.resolve("config/DistantHorizons.toml"),game.resolve("config/oculus.properties")};
        byte[][] old=new byte[3][],next=new byte[3][];
        String[] text=new String[3];
        for(int i=0;i<files.length;i++){
            safePath(files[i]);if(!Files.isRegularFile(files[i],NO_LINKS))throw new IOException("Graphics settings missing");
            old[i]=Files.readAllBytes(files[i]);text[i]=StandardCharsets.UTF_8.newDecoder().decode(ByteBuffer.wrap(old[i])).toString();
        }
        if(reviewed && !(Pattern.compile("(?m)^\\h*enableShaders\\h*=\\h*true\\h*$").matcher(text[2]).find()
                && Pattern.compile("(?m)^\\h*shaderPack\\h*=\\h*"+Pattern.quote(ENHANCED)+"\\h*$").matcher(text[2]).find()))return false;
        String pack=profile.shader().equals("Enhanced")?ENHANCED:NORMAL;
        Path shaderFile=game.resolve("shaderpacks").resolve(pack);
        boolean enabled=!profile.shader().equals("OFF")&&Files.isRegularFile(shaderFile,NO_LINKS);
        if(enabled)safePath(shaderFile);
        String shader=enabled?profile.shader():"OFF";
        String options=key(key(text[0],"renderDistance",":",Integer.toString(profile.render())),"simulationDistance",":",Integer.toString(profile.simulation()));
        String lod=radius(text[1],profile.dh());
        String oculus=key(text[2],"enableShaders","=",Boolean.toString(enabled));
        if(enabled)oculus=key(oculus,"shaderPack","=",pack);
        next[0]=options.getBytes(StandardCharsets.UTF_8);next[1]=lod.getBytes(StandardCharsets.UTF_8);next[2]=oculus.getBytes(StandardCharsets.UTF_8);
        int oldRender=live.render(),oldSimulation=live.simulation(),oldDh=live.dh();
        boolean[] written=new boolean[3];boolean reloaded=false;
        try{
            live.render(profile.render());live.simulation(profile.simulation());live.dh(profile.dh());
            if(live.render()!=profile.render() || live.simulation()!=profile.simulation() || live.dh()!=profile.dh())throw new IOException("Live graphics rejected profile");
            for(int i=0;i<files.length;i++)if(!Arrays.equals(old[i],next[i])){atomic(files[i],next[i]);written[i]=true;}
            if(written[2] || !live.shaderMatches(enabled,pack)){reloaded=true;live.reloadShaders();}
            if(!live.shaderMatches(enabled,pack))throw new IOException("Live shader rejected profile");
            live.broadcast();
            if(Files.exists(marker,NO_LINKS))throw new IOException("Graphics review already committed elsewhere");
            atomic(marker,receipt(profile,shader).getBytes(StandardCharsets.UTF_8));
            return true;
        }catch(Exception|LinkageError failure){
            restore(failure,()->live.render(oldRender));restore(failure,()->live.simulation(oldSimulation));restore(failure,()->live.dh(oldDh));
            for(int i=0;i<files.length;i++)if(written[i]){final int slot=i;restore(failure,()->atomic(files[slot],old[slot]));}
            if(reloaded)restore(failure,live::reloadShaders);
            restore(failure,live::broadcast);
            throw failure;
        }
    }

    private static String receipt(Profile p,String shader){
        return "{\"schema\":1,\"receipt\":\"michaels-hardware-policy-1128:once:v1\",\"state\":\"applied\",\"policyRevision\":\"1128\","
            +"\"profile\":{\"tier\":\""+p.tier()+"\",\"heapMiB\":"+p.heap()+",\"renderDistance\":"+p.render()+",\"simulationDistance\":"+p.simulation()
            +",\"dhRadius\":"+p.dh()+",\"shader\":\""+p.shader()+"\",\"policyRevision\":\"1128\"},\"appliedShader\":\""+shader+"\","
            +"\"heapChanged\":false,\"authorization\":\"one-time-graphics-reevaluation\",\"laterManualChoicesPreserved\":true,\"appliedBy\":\"first-client-open\"}\n";
    }

    private static String key(String text,String key,String separator,String value)throws IOException {
        Matcher m=Pattern.compile("(?m)^(\\h*"+Pattern.quote(key)+"\\h*"+Pattern.quote(separator)+"\\h*)[^\\r\\n]*(\\r?)$").matcher(text);
        if(!m.find()){
            String eol=text.contains("\r\n")?"\r\n":"\n";
            return text+(text.isEmpty()||text.endsWith("\n")?"":eol)+key+separator+value+eol;
        }
        int start=m.start(),end=m.end();String replacement=m.group(1)+value+m.group(2);
        if(m.find())throw new IOException("Ambiguous graphics setting");
        return text.substring(0,start)+replacement+text.substring(end);
    }

    private static String radius(String text,int value)throws IOException {
        Matcher section=QUALITY.matcher(text);
        if(!section.find())throw new IOException("Missing LOD quality table");
        int start=section.start(1),end=section.end(1);String body=section.group(1);
        if(section.find())throw new IOException("Ambiguous LOD quality table");
        Matcher key=RADIUS.matcher(body);
        if(!key.find())throw new IOException("Missing LOD radius");
        int from=key.start(),to=key.end();String replacement=key.group(1)+value+key.group(2)+key.group(3);
        if(key.find())throw new IOException("Ambiguous LOD radius");
        return text.substring(0,start)+body.substring(0,from)+replacement+body.substring(to)+text.substring(end);
    }

    private static void safePath(Path path)throws IOException {
        for(Path p=path.toAbsolutePath().normalize();p!=null;p=p.getParent())if(Files.exists(p,NO_LINKS)){
            BasicFileAttributes attrs=Files.readAttributes(p,BasicFileAttributes.class,NO_LINKS);
            if(attrs.isSymbolicLink()||attrs.isOther())throw new IOException("Linked graphics path");
        }
    }

    private static void atomic(Path path,byte[] bytes)throws IOException {
        safePath(path);
        Path temp=Files.createTempFile(path.getParent(),".graphics-1121-",".tmp");
        try{Files.write(temp,bytes);Files.move(temp,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
        finally{Files.deleteIfExists(temp);}
    }

    @FunctionalInterface private interface Undo {void run()throws Exception;}
    private static void restore(Throwable failure,Undo undo){try{undo.run();}catch(Exception|LinkageError rollback){failure.addSuppressed(rollback);}}

    private static Method method(Class<?> type,String named,String srg,Class<?>... args)throws NoSuchMethodException {
        try{return type.getMethod(named,args);}catch(NoSuchMethodException ignored){return type.getMethod(srg,args);}
    }

    private static final class NativeGraphics implements Graphics {
        private final Object options,render,simulation,radius;
        private final Class<?> iris;
        private final Method optionGet,optionSet,dhGet,dhSet,broadcast;

        NativeGraphics(Object options,Class<?> iris)throws Exception {
            this.options=options;this.iris=iris;
            Class<?> type=options.getClass();
            render=method(type,"renderDistance","m_231984_").invoke(options);
            simulation=method(type,"simulationDistance","m_232001_").invoke(options);
            optionGet=method(render.getClass(),"get","m_231551_");optionSet=method(render.getClass(),"set","m_231514_",Object.class);
            broadcast=method(type,"broadcastOptions","m_92172_");
            Class<?> quality=Class.forName("com.seibel.distanthorizons.core.config.Config$Client$Advanced$Graphics$Quality");
            radius=quality.getField("lodChunkRenderDistanceRadius").get(null);
            dhGet=radius.getClass().getMethod("getTrueValue");dhSet=radius.getClass().getMethod("setWithoutSaving",Object.class);
        }

        public int render()throws Exception{return (Integer)optionGet.invoke(render);}
        public int simulation()throws Exception{return (Integer)optionGet.invoke(simulation);}
        public int dh()throws Exception{return (Integer)dhGet.invoke(radius);}
        public void render(int value)throws Exception{optionSet.invoke(render,Integer.valueOf(value));}
        public void simulation(int value)throws Exception{optionSet.invoke(simulation,Integer.valueOf(value));}
        public void dh(int value)throws Exception{dhSet.invoke(radius,Integer.valueOf(value));}
        public void broadcast()throws Exception{broadcast.invoke(options);}
        public void reloadShaders()throws Exception{iris.getMethod("reload").invoke(null);}

        public boolean shaderMatches(boolean enabled,String pack)throws Exception {
            Object config=iris.getMethod("getIrisConfig").invoke(null);
            if(config==null || (Boolean)config.getClass().getMethod("areShadersEnabled").invoke(config)!=enabled)return false;
            Optional<?> loaded=(Optional<?>)iris.getMethod("getCurrentPack").invoke(null);
            if(!enabled)return loaded.isEmpty();
            Optional<?> selected=(Optional<?>)config.getClass().getMethod("getShaderPackName").invoke(config);
            return loaded.isPresent() && selected.filter(pack::equals).isPresent() && pack.equals(iris.getMethod("getCurrentPackName").invoke(null));
        }
    }
}
