Michael's Belly Visuals 1.0.0

Original MIT-licensed Forge 1.20.1 addon, required on server and clients.
Six full meals cap cosmetic lower-torso growth. Each hunger point lost removes 0.3 meal; normal hunger meals do not grow it.
Uses the player's existing skin and body animation, three cached cuboids, no additional assets/dependencies.
No added items, HUD, keys, stat effects, hitbox changes, or world generation.

See technical-notes.json for precise food-hook ordering, networking, persistence, and validation scope.
Private validation controls require -Dmichaelspack.validation=true and the owned CombinedQA player; they register no gameplay commands.

Build with Java 17 and the bundled Gradle wrapper. The shared workspace Forge cache allows --offline build.
