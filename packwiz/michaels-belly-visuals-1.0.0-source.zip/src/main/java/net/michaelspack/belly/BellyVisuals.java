package net.michaelspack.belly;

import net.minecraftforge.fml.common.Mod;

/** Original cosmetic addon; no third-party mod code or assets. */
@Mod(BellyVisuals.MODID)
public final class BellyVisuals {
    public static final String MODID="michaels_belly_visuals";
    public BellyVisuals() { BellyNetwork.register(); }
}
