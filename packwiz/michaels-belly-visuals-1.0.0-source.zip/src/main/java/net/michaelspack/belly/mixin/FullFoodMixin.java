package net.michaelspack.belly.mixin;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Only the edible branch of Item.use changes; cake and other generic canEat callers stay native. */
@Mixin(Item.class)
public abstract class FullFoodMixin {
    @Redirect(method="use",at=@At(value="INVOKE",target="Lnet/minecraft/world/entity/player/Player;canEat(Z)Z"))
    private boolean allowFullFoodItem(Player player,boolean alwaysEat) {
        return player.canEat(alwaysEat)||(!player.isSpectator()&&player.getFoodData().getFoodLevel()>=20);
    }
}
