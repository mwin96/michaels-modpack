package net.michaelspack.belly.mixin;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.michaelspack.belly.BellyState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Capture at the exact native nutrition call, before food changes; Finish events run too late. */
@Mixin(Player.class)
public abstract class FullMealMixin {
    @Unique private boolean michaelsFullMeal;
    @Inject(method="eat",at=@At("HEAD"))
    private void beforeMeal(Level level,ItemStack stack,CallbackInfoReturnable<ItemStack> cir) {michaelsFullMeal=false;}
    @Redirect(method="eat",at=@At(value="INVOKE",
        target="Lnet/minecraft/world/food/FoodData;eat(Lnet/minecraft/world/item/Item;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)V",remap=false))
    private void cosmeticNutrition(FoodData food,Item item,ItemStack stack,LivingEntity entity) {
        michaelsFullMeal=food.getFoodLevel()>=20&&stack.isEdible();
        if(!michaelsFullMeal)food.eat(item,stack,entity);
    }
    @Inject(method="eat",at=@At("RETURN"))
    private void completedMeal(Level level,ItemStack stack,CallbackInfoReturnable<ItemStack> cir) {
        if(michaelsFullMeal&&(Object)this instanceof ServerPlayer player)BellyState.completedFullMeal(player);
        michaelsFullMeal=false;
    }
}
