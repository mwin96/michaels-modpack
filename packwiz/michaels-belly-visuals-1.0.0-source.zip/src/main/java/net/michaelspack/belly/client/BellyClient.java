package net.michaelspack.belly.client;

import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.michaelspack.belly.BellyVisuals;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=BellyVisuals.MODID,value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class BellyClient {
    @SubscribeEvent public static void definitions(EntityRenderersEvent.RegisterLayerDefinitions event) {event.registerLayerDefinition(BellyLayer.LAYER,BellyLayer::definition);}
    @SubscribeEvent public static void layers(EntityRenderersEvent.AddLayers event) {
        for(String skin:event.getSkins()) {
            PlayerRenderer renderer=event.getSkin(skin);
            if(renderer!=null)renderer.addLayer(new BellyLayer(renderer,event.getEntityModels().bakeLayer(BellyLayer.LAYER)));
        }
    }
    private BellyClient() {}
}
