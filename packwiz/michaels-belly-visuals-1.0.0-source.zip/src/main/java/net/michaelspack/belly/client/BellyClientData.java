package net.michaelspack.belly.client;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.util.Mth;
import net.michaelspack.belly.BellyState;
import net.michaelspack.belly.BellyVisuals;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=BellyVisuals.MODID,value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class BellyClientData {
    private static final Map<UUID,Value> VALUES=new HashMap<>();
    private static final class Value {float old,current,target;}
    public static void receive(UUID player,float size) {VALUES.computeIfAbsent(player,k->new Value()).target=BellyState.clamp(size);}
    public static float rendered(UUID player,float partial) {
        Value value=VALUES.get(player);return value==null?0:Mth.lerp(partial,value.old,value.current);
    }
    public static float target(UUID player) {Value value=VALUES.get(player);return value==null?0:value.target;}
    @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
        if(event.phase==TickEvent.Phase.END)for(Value value:VALUES.values()) {
            value.old=value.current;value.current+=(value.target-value.current)*0.25F;
            if(Math.abs(value.target-value.current)<0.0005F)value.current=value.target;
        }
    }
    @SubscribeEvent public static void logout(ClientPlayerNetworkEvent.LoggingOut event) {VALUES.clear();}
    private BellyClientData() {}
}
