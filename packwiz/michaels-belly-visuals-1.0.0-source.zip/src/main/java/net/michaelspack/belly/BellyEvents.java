package net.michaelspack.belly;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=BellyVisuals.MODID,bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class BellyEvents {
    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event) {
        if(event.phase==TickEvent.Phase.END&&event.player instanceof ServerPlayer player)BellyState.hungerChanged(player);
    }
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent event) {
        if(event.getEntity() instanceof ServerPlayer player)BellyState.login(player);
    }
    @SubscribeEvent public static void clone(PlayerEvent.Clone event) {
        BellyState.copy(event.getOriginal(),event.getEntity(),event.isWasDeath());
    }
    @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent event) {
        if(event.getEntity() instanceof ServerPlayer player)BellyState.login(player);
    }
    @SubscribeEvent public static void dimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if(event.getEntity() instanceof ServerPlayer player)BellyState.login(player);
    }
    @SubscribeEvent public static void tracking(PlayerEvent.StartTracking event) {
        if(event.getEntity() instanceof ServerPlayer watcher&&event.getTarget() instanceof ServerPlayer target)
            BellyNetwork.to(watcher,target,BellyState.growth(target));
    }
}
