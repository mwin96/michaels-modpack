package net.michaelspack.belly;

import java.util.Map;
import net.minecraft.server.level.ServerPlayer;

/** Only the owned QA process/player can use mutation controls; no gameplay command or key binding. */
public final class BellyValidationHooks {
    private static void check(ServerPlayer player) {
        if(!Boolean.getBoolean("michaelspack.validation")||!player.getGameProfile().getName().equals("CombinedQA"))
            throw new IllegalStateException("Private CombinedQA validation only");
    }
    public static Map<String,Object> inspect(ServerPlayer player) {
        check(player);return Map.of("growth",BellyState.growth(player),"food",player.getFoodData().getFoodLevel(),
            "saturation",player.getFoodData().getSaturationLevel(),"sent",BellyNetwork.validationSends,
            "width",player.getBbWidth(),"height",player.getBbHeight());
    }
    public static void setGrowth(ServerPlayer player,float value) {check(player);BellyState.set(player,value);}
    private BellyValidationHooks() {}
}
