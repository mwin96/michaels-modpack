package net.michaelspack.belly;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Stored in normal Forge player NBT; only hunger loss or a completed full meal changes growth. */
public final class BellyState {
    public static final String KEY="michaels_belly_visuals";
    public static final float MAX_MEALS=6F;
    public static final float SHRINK_PER_HUNGER_POINT=MAX_MEALS/20F;
    private BellyState() {}
    private static CompoundTag data(Player player) {
        CompoundTag forge=player.getPersistentData();
        if(!forge.contains(KEY,10)) {
            CompoundTag tag=new CompoundTag();tag.putInt("food",player.getFoodData().getFoodLevel());
            forge.put(KEY,tag);
        }
        return forge.getCompound(KEY);
    }
    public static float growth(Player player) { return clamp(data(player).getFloat("growth")); }
    public static float clamp(float value) { return Float.isFinite(value)?Math.max(0,Math.min(MAX_MEALS,value)):0; }
    public static void set(ServerPlayer player,float value) {
        CompoundTag tag=data(player);float before=clamp(tag.getFloat("growth")),next=clamp(value);
        if(Math.abs(before-next)<0.00001F)return;
        tag.putFloat("growth",next);BellyNetwork.changed(player,next);
    }
    public static void hungerChanged(ServerPlayer player) {
        CompoundTag tag=data(player);int current=player.getFoodData().getFoodLevel(),previous=tag.getInt("food");
        if(current==previous)return;
        tag.putInt("food",current);
        if(current<previous)set(player,growth(player)-(previous-current)*SHRINK_PER_HUNGER_POINT);
    }
    public static void completedFullMeal(ServerPlayer player) {
        hungerChanged(player);set(player,growth(player)+1);
    }
    public static void login(ServerPlayer player) {
        data(player).putInt("food",player.getFoodData().getFoodLevel());
        BellyNetwork.to(player,player,growth(player));
    }
    public static void copy(Player original,Player replacement,boolean death) {
        if(!death&&original.getPersistentData().contains(KEY,10))
            replacement.getPersistentData().put(KEY,original.getPersistentData().getCompound(KEY).copy());
        else replacement.getPersistentData().remove(KEY);
    }
}
