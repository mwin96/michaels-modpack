package net.michaelspack.belly;

import java.util.UUID;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class BellyNetwork {
    private static final String VERSION="1";
    private static final SimpleChannel CHANNEL=NetworkRegistry.newSimpleChannel(
        new ResourceLocation(BellyVisuals.MODID,"visuals"),()->VERSION,VERSION::equals,VERSION::equals);
    public static long validationSends;
    private BellyNetwork() {}
    public static void register() {
        CHANNEL.registerMessage(0,Visual.class,Visual::encode,Visual::decode,Visual::handle,Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }
    private static void sent() { if(Boolean.getBoolean("michaelspack.validation"))validationSends++; }
    public static void changed(ServerPlayer player,float growth) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(()->player),new Visual(player.getUUID(),growth));sent();
    }
    public static void to(ServerPlayer watcher,ServerPlayer subject,float growth) {
        CHANNEL.send(PacketDistributor.PLAYER.with(()->watcher),new Visual(subject.getUUID(),growth));sent();
    }
    private record Visual(UUID player,float growth) {
        private void encode(FriendlyByteBuf buf) { buf.writeUUID(player);buf.writeFloat(growth); }
        private static Visual decode(FriendlyByteBuf buf) { return new Visual(buf.readUUID(),BellyState.clamp(buf.readFloat())); }
        private void handle(Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context=supplier.get();
            context.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                ()->()->net.michaelspack.belly.client.BellyClientData.receive(player,growth)));
            context.setPacketHandled(true);
        }
    }
}
