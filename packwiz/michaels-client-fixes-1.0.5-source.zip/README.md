# Michael's Client Fixes 1.0.1

Forge1.20.1/47.4.28 client-only optional utility, GPL-3.0-or-later. Build with Java17 and `gradlew --offline build`.

The original SCP pickup-prompt/item-outline correction remains unchanged. Vanilla automatic pickup remains enabled.

Jade's existing target health element renders as one compact red current/max bar. It uses Jade's native target and health values, adding no entity scan or packet. A one-time startup migration enables minecraft:entity_health using Jade's own configuration API; later player choices are respected.

Zombie visuals in CMMRP_Release_1.0_NormalAnimals.zip and MyMonsterGirls.zip fall through to vanilla. Both direct resource lookup and resource enumeration omit only matching zombie/husk/drowned/zombie-villager/zombified-piglin visual paths in those two ZIPs. Original archives are never altered or copied. Other mobs, sounds, packs, textures and models remain unchanged. No Minecraft assets are redistributed.

## Version1.0.3

Client marker1.0.3 for the1.0.7 content update. Existing Auto-only GUI scaling,6GB one-time migration and opt-outs, sky defaults, health UI and DH bridge remain. A JDK/ImageIO-only early hook creates98 resized textures locally from SHA256-pinned installed original mods, then selects the generated personal-use resource pack once. No third-party image data is bundled in this source or mod. First launch tested about9seconds; cached run about0.09seconds on the test PC. The resize uses high-quality bicubic interpolation, preserves aspect ratio and transparency, and excludes animated strips/PBR maps in the pinned recipe. Later resource-pack opt-outs remain respected. Full comparative RAM/FPS benchmarking was explicitly waived by the user.

Rapid-flash choices are applied once before Forge config load: mbackrooms/JumpsScares Settings.flashEnabled=false and PHOTOSENSITIVITY WARNING !!!.photosensitivityWarningDisplayed=true. Only those Boolean values change; comments/CRLF/other keys and later deliberate changes are respected. A narrowly scoped optional Physics GUI resource-stream bridge reads selected generated parallax PNGs through Minecraft's ResourceManager; it leaves shader files and other custom resources native and falls back safely when unavailable.


UI1.0.4 cloud hotfix: only DH's enableCloudRendering is defaulted off once. The first safe client tick updates the native ConfigEntry without saving unrelated DH settings, then atomically changes the matching TOML key and writes config/michaels-dh-clouds-108.done. Later manual cloud choices are respected. Vanilla clouds, beacons, generic rendering, other DH options, existing textures/GUI/health/lightmap logic remain unchanged. DH is optional; absence consumes no marker. No shaders or terrain code is altered.


UI1.0.5 / pack1.0.9: session-only DH download consent is restricted to the pinned dedicated host and an actual ready DH remote session. Only the API override owned by this utility is cleared on logout, SP or another server; the saved generation setting is never enabled. Hardware defaults are considered once on the first safe client tick using physical RAM and the active dedicated GPU: at least14GiB RAM and4GiB VRAM select DH64 and Enhanced only from the prior32/Normal defaults. Unknown/integrated hardware and custom/off choices are retained; heap size and vanilla distance/FPS/caps are unchanged.

Master/hostile/neutral volume are scaled once by0.8/0.65/0.6; eleven named bird ambience values by0.65. General AmbientSounds, music and other audio stay unchanged. A default B key conflict moves only TaCZ zoom to a free backslash after the backpack key exists. Two Inventory Profiles Next continuous-crafting flags are disabled once while preserving other settings. Every migration has its own marker so later choices remain yours; runtime hardware markers must never be shipped in automatic update content.

Only eternaljesus:jesus_bell is limited to one audible instance up to10seconds, then60seconds quiet. Monotonic timing drops overlap/retriggers; other sounds are untouched.

The optional MainTarget stencil initialization is guarded on the actual TaCZ/DH/Iris class resources and allocates before world shader attachment retention. Its gun-table rendering hypothesis still requires native GL/preview proof; compilation and source review do not claim the visual bug fixed.


Additional unreleased1.0.5 request: AutoRefillSettings.refill_before_tool_break, visual_durability_notification and audio_durability_notification are disabled by the same once-only IPN migration. The native getters and primitive/object JSON encodings were verified against pinned IPN1.10.20/libIPN4.0.2. Custom hotkey-object fields are preserved while only their value becomes false; sorting, other refill behavior and all non-target settings remain unchanged.

Windows WMI reporting allowance: the dedicated VRAM threshold accepts4095MiB,1MiB below4GiB, because WMI caps larger modern adapters at that exact value. The pinned native RTX5070Ti case reported4095MiB while its real dedicated memory was approximately16GiB. RAM/active-adapter/discrete/custom-setting safeguards remain unchanged.

Optional Extreme Natural Disasters1.5 plume budget: an exact-descriptor @Pseudo client mixin cancels three of every four volcanicPlume=true emission requests at method HEAD, before allocating smoke puffs. Every ordinary smoke request is retained. Texture, puff lifetime, growth, size, motion, alpha, volcano terrain/damage/lava/bombs and server behavior remain native. Existing client rendering/stencil class bytes are unchanged. Native volcano FPS or appearance was not measured; the directly tested count policy is25kept/100volcanic requests and100kept/100ordinary requests.

Spider visual fallback: the existing exact-two-anime-ZIP vanilla fallback also covers spider and cave_spider visual paths. All eleven spider files in the official installed CMM NormalAnimals pack are excluded by the existing direct-resource and enumeration hooks. Namespace/prefix/name boundaries, other anime mobs, textures outside those ZIPs, Nyfs/AI/damage and all other gameplay remain unchanged.

Visible multiplayer entry: the native QuickPlay path saves a server as hidden. After the multiplayer screen initializes, this utility preserves an existing visible pack entry; otherwise it promotes the matching hidden entry using its original exact address/name/icon or creates one friendly visible entry. Only trimmed case-insensitive51.81.148.186:25590 matches. It saves and refreshes the native list only when changed. Native ServerList/NbtIo fixtures cover hidden promotion, custom metadata, unrelated visible/hidden entries, reopen/idempotence and absence. No servers.dat or private server lists are distributed.

Automatic desktop Play migration validates only the current portable Prism Data/instances layout, runs a SHA256-pinned COM-only helper hidden with fixed arguments, creates no game/UI, and preserves existing custom shortcuts. Legacy roots without PLAY.cmd use the original Prism executable/Data/instance/server arguments. Desktop SpecialFolder honors redirection; accounts/profiles/options are untouched. Marker config/michaels-desktop-play-109.done is runtime-only. Only promoted hidden entries with the native current-locale default label are renamed; custom labels remain.
