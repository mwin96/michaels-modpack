package net.michaelspack.clientfixes;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.api.distmarker.Dist;
@Mod("michaels_client_fixes")
public final class ClientFixes {
    public ClientFixes() { DistExecutor.safeRunWhenOn(Dist.CLIENT,()->ClientDefaults::install); }
}
