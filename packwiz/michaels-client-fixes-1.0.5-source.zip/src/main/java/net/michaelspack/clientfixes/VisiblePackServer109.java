package net.michaelspack.clientfixes;

import java.util.List;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.resources.language.I18n;

/** Promote only this pack's QuickPlay-hidden entry; retain all existing server objects. */
public final class VisiblePackServer109 {
    public static final String ADDRESS="51.81.148.186:25590";
    private VisiblePackServer109(){}
    public static boolean matches(String address){return address!=null&&ADDRESS.equalsIgnoreCase(address.trim());}
    public static boolean ensure(ServerList servers,List<ServerData> hidden){
        for(int i=0;i<servers.size();i++)if(matches(servers.get(i).ip))return false;
        ServerData promoted=null;
        for(ServerData server:hidden)if(matches(server.ip)){promoted=servers.unhide(server.ip);break;}
        if(promoted==null)servers.add(new ServerData("michael's modpack",ADDRESS,false),false);
        else if(promoted.name.equals(I18n.get("selectServer.defaultName")))promoted.name="michael's modpack";
        servers.save();return true;
    }
}
