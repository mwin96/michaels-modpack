package net.michaelspack.clientfixes.memory;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/** Changes only the three memory fields in Prism's General section. */
public final class MemoryConfig {
    public static final int MAX_MIB = 6144;
    private MemoryConfig() {}
    public static String apply(String original) {
        Matcher section = Pattern.compile("(?m)^\\[General\\][ \t]*\\r?$").matcher(original);
        if (!section.find()) throw new IllegalArgumentException("Prism General section absent");
        int start = section.end();
        if (section.find()) throw new IllegalArgumentException("Duplicate Prism General section");
        Matcher next = Pattern.compile("(?m)^\\[[^\\r\\n]+\\]").matcher(original);
        int end = original.length();
        while (next.find()) if (next.start() > start) { end = next.start(); break; }
        String body = original.substring(start, end);
        String newline = original.contains("\r\n") ? "\r\n" : "\n";
        body = set(body, "OverrideMemory", "true", newline);
        body = set(body, "MaxMemAlloc", "6144", newline);
        Matcher min = key("MinMemAlloc").matcher(body);
        if (!min.find()) body = set(body, "MinMemAlloc", "1024", newline);
        else {
            int value;
            try { value = Integer.parseInt(min.group(2).trim()); }
            catch (NumberFormatException invalid) { throw new IllegalArgumentException("Invalid Prism minimum memory", invalid); }
            if (min.find()) throw new IllegalArgumentException("Duplicate Prism minimum memory");
            if (value < 0) throw new IllegalArgumentException("Invalid Prism minimum memory");
            if (value > MAX_MIB) body = set(body, "MinMemAlloc", "6144", newline);
        }
        return original.substring(0,start) + body + original.substring(end);
    }
    private static Pattern key(String key) {
        return Pattern.compile("(?m)^([ \t]*" + key + "[ \t]*=[ \t]*)([^\r\n]*)(\r?)$");
    }
    private static String set(String text, String key, String value, String newline) {
        Matcher match = key(key).matcher(text);
        if (!match.find()) return text + (text.endsWith("\n") ? "" : newline) + key + "=" + value + newline;
        int start=match.start(), end=match.end();
        String replacement=match.group(1)+value+match.group(3);
        if (match.find()) throw new IllegalArgumentException("Duplicate Prism memory setting: " + key);
        return text.substring(0,start)+replacement+text.substring(end);
    }
}
