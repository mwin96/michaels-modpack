package net.michaelspack.clientfixes;

import com.google.gson.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** Pure policy and narrow file transforms; native callbacks are supplied by the safe client tick. */
public final class ClientPreferences109 {
    public static final String HARDWARE_MARKER="config/michaels-hardware-defaults-109.done";
    public static final String AUDIO_MARKER="config/michaels-audio-109.done";
    public static final String BIRD_MARKER="config/michaels-birds-109.done";
    public static final String NORMAL="MakeUp-UltraFast-9.6.zip", ENHANCED="MakeUp-UltraFast-9.6-Enhanced.zip";
    public static final String[][] BIRDS={
        {"beach","seagull"},{"beach","seagull-long"},{"forest_cold","crow"},{"forest","bird-ambience"},{"forest","owl"},
        {"forest_roofed","bird-ambience-spooky"},{"jungle","bird-ambience-jungle"},{"jungle","bird-ambience-jungle-night"},
        {"pale-garden","owl"},{"savanna","bird-warm"},{"taiga","bird-ambience-huge"}
    };
    private ClientPreferences109() {}
    public static double scale(double value,double factor) { return Math.max(0,Math.min(1,value*factor)); }
    private static String compact(String value) { return value.toLowerCase(Locale.ROOT).replace("(r)","").replace("(tm)","").replaceAll("[^a-z0-9]",""); }
    public static boolean ourServer(String address) { return address!=null&&address.trim().equals("51.81.148.186:25590"); }
    public static boolean approvedSession(boolean level,boolean singleplayer,String address,String worldClass,boolean ready) { return level&&!singleplayer&&ourServer(address)&&"com.seibel.distanthorizons.core.world.DhClientWorld".equals(worldClass)&&ready; }
    private static String model(String value) { return compact(value).replace("corporation","").replace("graphics","").replace("nvidia","").replace("geforce","").replace("radeon","").replace("intel","").replace("amd",""); }
    public static boolean discrete(String renderer) {
        String r=renderer.toLowerCase(Locale.ROOT);
        if(r.contains("llvmpipe")||r.contains("software")||r.contains("uhd")||r.contains("iris")||r.contains("integrated")||r.matches(".*vega ?(?:3|6|7|8|10|11)(?:[^0-9].*|$)"))return false;
        return r.contains("geforce")||r.contains("quadro")||r.contains("radeon rx")||r.contains("radeon pro")||r.contains("intel arc")||r.contains("intel(r) arc");
    }
    public static boolean capable(long physicalRam,String activeRenderer,String adapter,long vram) {
        // Windows WMI can clamp a >=4GiB dedicated adapter to4095MiB; allow that1MiB reporting gap.
        if(physicalRam<14L*(1L<<30)||vram<4095L*(1L<<20)||!discrete(activeRenderer)||!discrete(adapter))return false;
        String a=model(activeRenderer),b=model(adapter);return b.length()>=4&&(a.contains(b)||b.contains(a));
    }
    public static String patchOption(String text,String key,String value) {
        Matcher m=Pattern.compile("(?m)^("+Pattern.quote(key)+":)([^\\r\\n]*)(\\r?)$").matcher(text);
        if(!m.find())return text+(text.isEmpty()||text.endsWith("\n")?"":text.contains("\r\n")?"\r\n":"\n")+key+":"+value+(text.contains("\r\n")?"\r\n":"\n");
        int start=m.start(),end=m.end();String replacement=m.group(1)+value+m.group(3);if(m.find())throw new IllegalArgumentException("Duplicate option "+key);return text.substring(0,start)+replacement+text.substring(end);
    }
    public static String patchProperty(String text,String key,String value) {
        Matcher m=Pattern.compile("(?m)^([ \\t]*"+Pattern.quote(key)+"[ \\t]*=[ \\t]*)([^\\r\\n]*)(\\r?)$").matcher(text);
        if(!m.find())throw new IllegalArgumentException("Missing property "+key);
        int start=m.start(),end=m.end();String replacement=m.group(1)+value+m.group(3);if(m.find())throw new IllegalArgumentException("Duplicate property "+key);return text.substring(0,start)+replacement+text.substring(end);
    }
    public static String patchRadius32(String text) {
        Matcher m=Pattern.compile("(?m)^([ \\t]*lodChunkRenderDistanceRadius[ \\t]*=[ \\t]*)32([ \\t]*(?:#[^\\r\\n]*)?)(\\r?)$").matcher(text);
        if(!m.find())throw new IllegalArgumentException("DH radius no longer default32");
        int start=m.start(),end=m.end();String line=m.group(1)+"64"+m.group(2)+m.group(3);if(m.find())throw new IllegalArgumentException("Duplicate DH radius");return text.substring(0,start)+line+text.substring(end);
    }
    public static JsonObject quieterBirds(JsonObject original) {
        JsonObject result=original.deepCopy();JsonObject regions=result.has("regions")?result.getAsJsonObject("regions"):new JsonObject();result.add("regions",regions);
        for(String[] path:BIRDS){JsonObject region=regions.has(path[0])?regions.getAsJsonObject(path[0]):new JsonObject();regions.add(path[0],region);double old=region.has(path[1])?region.get(path[1]).getAsDouble():1;if(!Double.isFinite(old)||old<0)throw new IllegalArgumentException("Invalid bird volume");region.addProperty(path[1],old*.65);}
        return result;
    }
    /** Both native toggle encodings are valid; retain a custom hotkey object's other fields. */
    private static void toggleOff(JsonObject table,String key){JsonElement old=table.get(key);if(old!=null&&old.isJsonObject()){JsonObject object=old.getAsJsonObject();object.addProperty("value",false);}else table.addProperty(key,false);}
    public static JsonObject quieterIpn(JsonObject original){
        JsonObject result=original.deepCopy();
        JsonObject gui=result.has("GuiSettings")?result.getAsJsonObject("GuiSettings"):new JsonObject();result.add("GuiSettings",gui);
        toggleOff(gui,"show_continuous_crafting_checkbox");gui.addProperty("continuous_crafting_saved_value",false);
        JsonObject refill=result.has("AutoRefillSettings")?result.getAsJsonObject("AutoRefillSettings"):new JsonObject();result.add("AutoRefillSettings",refill);
        for(String key:List.of("refill_before_tool_break","visual_durability_notification","audio_durability_notification"))toggleOff(refill,key);
        return result;
    }
    public static void atomic(Path path,String text)throws Exception {
        Files.createDirectories(path.getParent());Path temporary=Files.createTempFile(path.getParent(),".michaels109-",".tmp");
        try{Files.writeString(temporary,text,StandardCharsets.UTF_8);try{Files.move(temporary,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException unsupported){Files.move(temporary,path,StandardCopyOption.REPLACE_EXISTING);}}finally{Files.deleteIfExists(temporary);}
    }
    public static void mark(Path game,String marker,String message)throws Exception { atomic(game.resolve(marker),message+"\n"); }
}
