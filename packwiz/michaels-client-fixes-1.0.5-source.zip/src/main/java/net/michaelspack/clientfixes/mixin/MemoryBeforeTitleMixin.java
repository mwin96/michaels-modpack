package net.michaelspack.clientfixes.mixin;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.michaelspack.clientfixes.LauncherMemoryMigration;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(TitleScreen.class)
public abstract class MemoryBeforeTitleMixin {
    @Inject(method="init",at=@At("HEAD"),cancellable=true)
    private void michaels$finishMemoryUpdate(CallbackInfo ci){
        if(LauncherMemoryMigration.mustFinishBeforeJoin(Minecraft.getInstance()))ci.cancel();
    }
}
