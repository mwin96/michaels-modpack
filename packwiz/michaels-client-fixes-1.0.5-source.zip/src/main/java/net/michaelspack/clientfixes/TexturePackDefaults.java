package net.michaelspack.clientfixes;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** One-time selection only; later personal opt-outs remain unchanged. */
public final class TexturePackDefaults {
    private TexturePackDefaults() {}
    public static List<String> apply(Path optionsFile, List<String> selected) {
        Path file = optionsFile.toAbsolutePath().normalize(), game = file.getParent();
        if (!LocalTexturePack.ensure(game)) return selected;
        Path marker = game.resolve("config/michaels-low-memory-defaults-107.enabled");
        if (Files.isRegularFile(marker)) return selected;
        try {
            List<String> updated = new ArrayList<>(selected);
            updated.removeIf(LocalTexturePack.ID::equals); updated.add(LocalTexturePack.ID);
            String original = Files.exists(file) ? Files.readString(file, StandardCharsets.UTF_8) : "";
            String patched = SkyPackDefaults.patchOptions(original, updated);
            if (!patched.equals(original)) atomic(file, patched);
            Files.createDirectories(marker.getParent());
            atomic(marker, "Selected locally generated textures once. Later selections remain yours.\n");
            return updated;
        } catch (Exception failure) {
            System.err.println("Michael's texture defaults kept existing preferences: " + failure.getClass().getSimpleName());
            return selected;
        }
    }
    private static void atomic(Path file, String text) throws Exception {
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), ".michaels-texture-defaults-", ".tmp");
        try {
            Files.writeString(temp, text, StandardCharsets.UTF_8);
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }
}
