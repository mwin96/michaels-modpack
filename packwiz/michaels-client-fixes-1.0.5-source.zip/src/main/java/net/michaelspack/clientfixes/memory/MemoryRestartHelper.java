package net.michaelspack.clientfixes.memory;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Standalone JDK-only helper: no account files, command-line inspection, credentials or game launch arguments. */
public final class MemoryRestartHelper {
    public static final String PRISM_SHA256 = "2f21c41241d551eae016a8f4174027e6d8d1ebe02b43af0e91512458c9b0f19d";
    public static String sha(Path path) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)));
    }
    private static void atomic(Path path, byte[] bytes) throws Exception {
        Path temp = Files.createTempFile(path.getParent(), ".michaels-memory-", ".tmp");
        try {
            Files.write(temp, bytes);
            Files.move(temp, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } finally { Files.deleteIfExists(temp); }
    }
    private static void result(Path directory, String value) throws Exception {
        atomic(directory.resolve("result.txt"), (value + "\n").getBytes(StandardCharsets.UTF_8));
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("One migration plan required");
        Path plan = Path.of(args[0]).toRealPath();
        Path directory = plan.getParent();
        try (FileChannel channel=FileChannel.open(directory.resolve("helper.lock"),StandardOpenOption.CREATE,StandardOpenOption.WRITE);
             FileLock lock=channel.tryLock()) {
            if (lock == null) return;
            try {
                Properties values=new Properties();
                try(InputStream in=Files.newInputStream(plan)){values.load(in);}
                Path instance=Path.of(values.getProperty("instance")).toRealPath();
                Path game=Path.of(values.getProperty("game")).toRealPath();
                Path data=Path.of(values.getProperty("data")).toRealPath();
                Path executable=Path.of(values.getProperty("launcher")).toRealPath();
                String id=values.getProperty("id");
                long gamePid=Long.parseLong(values.getProperty("gamePid"));
                long prismPid=Long.parseLong(values.getProperty("prismPid"));
                if (!"michaels-modpack".equals(id) || !instance.getFileName().toString().equals(id)
                    || !instance.getParent().getFileName().toString().equals("instances")
                    || !instance.getParent().getParent().equals(data) || !game.equals(instance.resolve("minecraft").toRealPath())
                    || !directory.equals(game.resolve("config/michaels-memory-106").toRealPath())
                    || !Files.isRegularFile(data.resolve("prismlauncher.cfg")) || !sha(executable).equals(PRISM_SHA256))
                    throw new IllegalStateException("Unrecognized portable Prism pack");
                ProcessHandle launcher=ProcessHandle.of(prismPid).orElseThrow();
                if (!launcher.isAlive() || !Path.of(launcher.info().command().orElseThrow()).toRealPath().equals(executable))
                    throw new IllegalStateException("Original Prism process is not available");
                ProcessHandle gameProcess=ProcessHandle.of(gamePid).orElseThrow();
                if (gameProcess.parent().map(ProcessHandle::pid).orElse(-1L)!=prismPid)
                    throw new IllegalStateException("Minecraft parent changed");
                Path cfg=instance.resolve("instance.cfg").toRealPath();
                String original=Files.readString(cfg,StandardCharsets.UTF_8);
                if (!original.contains("packwiz-installer-bootstrap.jar") || !original.contains("mwin96/michaels-modpack/main/packwiz/pack.toml"))
                    throw new IllegalStateException("Pack update hook absent");
                MemoryConfig.apply(original); // Preflight format and duplicate guards before asking the game to exit.
                atomic(directory.resolve("helper-ready"), new byte[]{1});
                gameProcess.onExit().get(90,TimeUnit.SECONDS);
                // Prism records played time after its child exits; let that final cached INI save complete first.
                long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(12);
                String previous=""; long unchangedSince=System.nanoTime();
                while(System.nanoTime()<deadline){
                    String current=sha(cfg);
                    if(!current.equals(previous)){previous=current;unchangedSince=System.nanoTime();}
                    if(System.nanoTime()-unchangedSince>=TimeUnit.SECONDS.toNanos(2))break;
                    Thread.sleep(100);
                }
                if(System.nanoTime()-unchangedSince<TimeUnit.SECONDS.toNanos(2))throw new IllegalStateException("Prism settings remain busy");
                byte[] before=Files.readAllBytes(cfg);
                byte[] after=MemoryConfig.apply(new String(before,StandardCharsets.UTF_8)).getBytes(StandardCharsets.UTF_8);
                Path backup=directory.resolve("instance-before-memory-106.cfg");
                if(Files.exists(backup))throw new IllegalStateException("Migration backup already exists");
                Files.write(backup,before,StandardOpenOption.CREATE_NEW);
                if(!Arrays.equals(Files.readAllBytes(cfg),before))throw new IllegalStateException("Prism settings changed during migration");
                atomic(cfg,after);
                if(!Arrays.equals(Files.readAllBytes(cfg),after))throw new IllegalStateException("Memory update did not persist");
                // Official CLI routes to the existing launcher/session; never construct or copy Minecraft authentication arguments.
                result(directory,"MEMORY_UPDATED_RESTART_REQUESTED");
                new ProcessBuilder(executable.toString(),"--dir",data.toString(),"--launch",id)
                    .redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            } catch(Exception failure){
                result(directory,"MANUAL_RESTART_REQUIRED: "+failure.getClass().getSimpleName());
                String pidValue = "";
                try (InputStream in=Files.newInputStream(plan)) {
                    Properties failed=new Properties();failed.load(in);pidValue=failed.getProperty("gamePid", "");
                } catch(Exception ignored) {}
                if (!pidValue.isEmpty() && ProcessHandle.of(Long.parseLong(pidValue)).map(ProcessHandle::isAlive).orElse(false)==false) {
                    javax.swing.JOptionPane.showMessageDialog(null,
                        "Open Michael's modpack in Prism Launcher again. If this repeats, use the latest updater.",
                        "Finish the pack update", javax.swing.JOptionPane.INFORMATION_MESSAGE);
                }
                throw failure;
            }
        }
    }
}
