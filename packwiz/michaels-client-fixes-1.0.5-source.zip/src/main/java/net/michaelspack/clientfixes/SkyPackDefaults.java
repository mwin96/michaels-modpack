package net.michaelspack.clientfixes;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** JDK/Gson only: no Minecraft resource classes, reload request, renderer, or Options.save call. */
public final class SkyPackDefaults {
    public static final List<String> IDS=List.of("file/Dramatic Skys Demo 1.5.3.36.6.zip","file/michaels-light-skies-overlay.zip");
    private static final Gson GSON=new Gson();
    private static boolean warned;
    public static volatile int applications;
    private SkyPackDefaults(){}
    public static List<String> apply(Path optionsFile,List<String> selected){
        Path file=optionsFile.toAbsolutePath().normalize();
        Path game=file.getParent(),marker=game.resolve("config/michaels-skies-defaults-106.enabled");
        if(Files.isRegularFile(marker))return selected;
        for(String id:IDS)if(!Files.isRegularFile(game.resolve("resourcepacks").resolve(id.substring(5))))return selected;
        try{
            List<String> updated=ordered(selected);
            String original=Files.exists(file)?Files.readString(file,StandardCharsets.UTF_8):"";
            String patched=patchOptions(original,updated);
            if(!patched.equals(original))atomic(file,patched);
            Files.createDirectories(marker.getParent());
            atomic(marker,"Enabled the two managed sky packs once for1.0.6. Later selections remain yours.\n");
            applications++;
            return updated;
        }catch(Exception failure){
            if(!warned){warned=true;System.err.println("Michael's sky defaults kept existing preferences: "+failure.getClass().getSimpleName());}
            return selected;
        }
    }
    public static List<String> ordered(List<String> selected){
        List<String> result=new ArrayList<>(selected);
        result.removeIf(IDS::contains);result.addAll(IDS);return result;
    }
    public static String patchOptions(String original,List<String> selected){
        Matcher line=Pattern.compile("(?m)^resourcePacks:([^\r\n]*)(\r?)$").matcher(original);
        String replacement="resourcePacks:"+GSON.toJson(selected);
        if(!line.find()){
            String newline=original.contains("\r\n")?"\r\n":"\n";
            return original+(original.isEmpty()||original.endsWith("\n")?"":newline)+replacement+newline;
        }
        // Parse the existing line before changing it; do not replace a malformed user selection silently.
        List<String> parsed=GSON.fromJson(line.group(1),new TypeToken<List<String>>(){}.getType());
        if(parsed==null)throw new IllegalArgumentException("Missing selected pack list");
        int start=line.start(),end=line.end();String carriage=line.group(2);
        if(line.find())throw new IllegalArgumentException("Duplicate resource-pack option");
        return original.substring(0,start)+replacement+carriage+original.substring(end);
    }
    private static void atomic(Path file,String value)throws Exception{
        Files.createDirectories(file.getParent());Path temp=Files.createTempFile(file.getParent(),".michaels-sky-", ".tmp");
        try{Files.writeString(temp,value,StandardCharsets.UTF_8);Files.move(temp,file,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
        finally{Files.deleteIfExists(temp);}
    }
}
