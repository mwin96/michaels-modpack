package net.michaelspack.clientfixes;

/** Owns only the API override it creates; never writes a saved config value. */
public final class DhSessionDownload109 {
    public interface Value {
        Object apiValue() throws Exception;
        boolean canOverride() throws Exception;
        boolean setTrue() throws Exception;
        boolean clear() throws Exception;
    }
    private boolean owned;
    public void update(boolean approvedReadySession, Value value) throws Exception {
        if (value == null) return;
        Object current = value.apiValue();
        if (owned && !Boolean.TRUE.equals(current)) owned = false;
        if (!approvedReadySession) {
            if (owned && Boolean.TRUE.equals(current) && value.clear()) owned = false;
            return;
        }
        if (!owned && current == null && value.canOverride() && value.setTrue()) owned = true;
    }
    public boolean ownsOverride() { return owned; }
}
