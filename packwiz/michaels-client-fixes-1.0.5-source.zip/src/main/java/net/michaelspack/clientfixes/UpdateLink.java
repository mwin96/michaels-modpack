package net.michaelspack.clientfixes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
public final class UpdateLink {
    public static final String URL = "https://github.com/mwin96/michaels-modpack/releases/latest";
    private UpdateLink() {}
    public static boolean isPackUpdate(Component reason) {
        if (reason.getContents() instanceof TranslatableContents translated) {
            if (translated.getKey().equals("michaels.update.required")) return true;
            for (Object argument : translated.getArgs()) {
                if (argument instanceof Component nested && isPackUpdate(nested)) return true;
            }
        }
        if (reason.getString().contains("[MICHAELS_UPDATE_REQUIRED]")) return true;
        for (Component sibling : reason.getSiblings()) if (isPackUpdate(sibling)) return true;
        return false;
    }
}
