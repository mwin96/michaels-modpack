package net.michaelspack.clientfixes.mixin;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Reuses Jade's current target and native health; adds no scan or packets. */
@Pseudo
@Mixin(targets="snownee.jade.impl.ui.HealthElement",remap=false)
public abstract class JadeHealthBarMixin {
    @Shadow @Final private float maxHealth;
    @Shadow @Final private float health;
    @Inject(method="getSize",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private void compactSize(CallbackInfoReturnable<Vec2> ci) { ci.setReturnValue(new Vec2(96,11)); }
    @Inject(method="render",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private void compactHealth(GuiGraphics graphics,float x,float y,float width,float height,CallbackInfo ci) {
        int left=(int)x,top=(int)y,w=Math.max(12,(int)width);
        graphics.fill(left,top,left+w,top+10,0xD0151515);
        float ratio=maxHealth>0 ? Mth.clamp(health/maxHealth,0F,1F):0F;
        int filled=Math.round((w-2)*ratio);
        if (filled>0) graphics.fill(left+1,top+1,left+1+filled,top+9,0xFFBC3038);
        String text=Mth.ceil(Math.max(0,health))+"/"+Mth.ceil(Math.max(0,maxHealth));
        var font=Minecraft.getInstance().font;
        graphics.drawString(font,text,left+(w-font.width(text))/2,top+1,0xFFFFFFFF,true);
        ci.cancel();
    }
}
