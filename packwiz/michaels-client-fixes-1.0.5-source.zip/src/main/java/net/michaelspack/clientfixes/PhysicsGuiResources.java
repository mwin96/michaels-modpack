package net.michaelspack.clientfixes;

import java.io.InputStream;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

/** Only the private Physics GUI loader needs this bridge; rendering and shader files stay native. */
public final class PhysicsGuiResources {
    public static volatile int redirects;
    private PhysicsGuiResources() {}
    public static InputStream open(ResourceLocation requested) {
        String path = requested.getPath();
        if (path.startsWith("physicsmod/")) path = path.substring("physicsmod/".length());
        else if (!requested.getNamespace().equals("physicsmod")) return null;
        if (!path.startsWith("textures/gui/parallax/") || !path.endsWith(".png")) return null;
        try {
            Minecraft client = Minecraft.getInstance();
            if (client == null || client.options == null || !client.options.resourcePacks.contains(LocalTexturePack.ID)) return null;
            var resource = client.getResourceManager().getResource(new ResourceLocation("physicsmod", path));
            if (resource.isEmpty()) return null;
            InputStream stream = resource.get().open();
            redirects++;
            return stream;
        } catch (Exception unavailable) { return null; }
    }
}
