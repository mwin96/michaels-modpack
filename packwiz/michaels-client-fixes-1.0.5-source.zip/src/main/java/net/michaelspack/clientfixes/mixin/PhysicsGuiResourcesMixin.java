package net.michaelspack.clientfixes.mixin;

import java.io.InputStream;
import net.minecraft.resources.ResourceLocation;
import net.michaelspack.clientfixes.PhysicsGuiResources;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets="net.diebuddies.opengl.ResourceManager", remap=false)
public abstract class PhysicsGuiResourcesMixin {
    @Inject(method="processResourceAsStream", at=@At("HEAD"), cancellable=true, remap=false)
    private void michaels$selectedLocalGuiTexture(ResourceLocation location, CallbackInfoReturnable<InputStream> result) {
        InputStream selected = PhysicsGuiResources.open(location);
        if (selected != null) result.setReturnValue(selected);
    }
}
