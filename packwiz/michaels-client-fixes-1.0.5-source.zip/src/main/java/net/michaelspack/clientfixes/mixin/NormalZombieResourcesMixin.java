package net.michaelspack.clientfixes.mixin;
import java.io.InputStream;
import net.michaelspack.clientfixes.NormalZombieResources;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.FilePackResources;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.IoSupplier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FilePackResources.class)
public abstract class NormalZombieResourcesMixin {
    @Inject(method="getResource",at=@At("HEAD"),cancellable=true,require=1)
    private void vanillaZombieFallback(PackType type,ResourceLocation id,CallbackInfoReturnable<IoSupplier<InputStream>> ci) {
        if (type==PackType.CLIENT_RESOURCES && NormalZombieResources.isAnimePack(((PackResources)(Object)this).packId()) &&
            NormalZombieResources.isZombieVisual(id.getNamespace(),id.getPath())) ci.setReturnValue(null);
    }
    @ModifyVariable(method="listResources",at=@At("HEAD"),argsOnly=true,require=1)
    private PackResources.ResourceOutput filterZombieListing(PackResources.ResourceOutput output) {
        if (!NormalZombieResources.isAnimePack(((PackResources)(Object)this).packId())) return output;
        return (id,supplier)-> { if (!NormalZombieResources.isZombieVisual(id.getNamespace(),id.getPath())) output.accept(id,supplier); };
    }
}
