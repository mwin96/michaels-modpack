package net.michaelspack.clientfixes.mixin;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.layouts.GridLayout;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.DisconnectedScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.michaelspack.clientfixes.UpdateLink;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(DisconnectedScreen.class)
public abstract class FriendlyDisconnectMixin extends Screen {
    @Shadow @Final private Component reason;
    @Shadow @Final private GridLayout layout;
    @Unique private boolean michaels$downloadAdded;
    protected FriendlyDisconnectMixin(Component title) { super(title); }
    @Inject(method="init", at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/layouts/GridLayout;arrangeElements()V"))
    private void michaels$offerUpdate(CallbackInfo ci) {
        if (!michaels$downloadAdded && UpdateLink.isPackUpdate(reason)) {
            layout.addChild(Button.builder(Component.literal("Download latest update"),
                ConfirmLinkScreen.confirmLink(UpdateLink.URL, this, true)).width(200).build(), 3, 0);
            michaels$downloadAdded = true;
        }
    }
}
