package net.michaelspack.clientfixes.mixin;

import java.util.List;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ServerList.class)
public interface ServerListHiddenAccessor {
    @Accessor("hiddenServerList") List<ServerData> michaels$hiddenServerList();
}
