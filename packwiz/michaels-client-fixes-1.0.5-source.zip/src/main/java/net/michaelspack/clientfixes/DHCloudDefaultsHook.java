package net.michaelspack.clientfixes;

import java.nio.file.*;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;

/** Optional DH config is touched only after startup reaches the client tick. */
public final class DHCloudDefaultsHook {
    private static boolean installed, complete;
    private static Path game;
    private DHCloudDefaultsHook() {}

    public static void install(Path gameDirectory) {
        if (installed) return;
        game = gameDirectory.toAbsolutePath().normalize();
        installed = true;
        if (Files.isRegularFile(game.resolve(DHCloudDefaults.MARKER))) { complete = true; return; }
        MinecraftForge.EVENT_BUS.addListener(DHCloudDefaultsHook::tick);
    }

    private static void tick(TickEvent.ClientTickEvent event) {
        if (complete || event.phase != TickEvent.Phase.END || Minecraft.getInstance().options == null) return;
        complete = true;
        try {
            Class<?> type = Class.forName("com.seibel.distanthorizons.core.config.Config$Client$Advanced$Graphics$GenericRendering");
            Object entry = type.getField("enableCloudRendering").get(null);
            var setter = entry.getClass().getMethod("setWithoutSaving", Object.class);
            var getter = entry.getClass().getMethod("get");
            DHCloudDefaults.apply(game, () -> {
                try {
                    setter.invoke(entry, Boolean.FALSE);
                    if (!Boolean.FALSE.equals(getter.invoke(entry))) throw new IllegalStateException("DH cloud option still overridden");
                } catch (ReflectiveOperationException failure) { throw new IllegalStateException(failure); }
            });
        } catch (ClassNotFoundException absent) {
            // DH is optional. Do not consume the marker if it is installed later.
        } catch (Exception failure) {
            System.err.println("Michael's DH cloud default could not be completed: " + failure.getClass().getSimpleName());
        }
    }
}
