package net.michaelspack.clientfixes;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
public final class MemoryUpdateScreen extends Screen {
    private final boolean manual;
    public MemoryUpdateScreen(boolean manual) { super(Component.literal(manual ? "Finish the pack update" : "Applying pack update")); this.manual=manual; }
    @Override protected void init() {
        if(manual){
            addRenderableWidget(Button.builder(Component.literal("Download latest update"), ConfirmLinkScreen.confirmLink(UpdateLink.URL,this,true)).bounds(width/2-100,height/2+20,200,20).build());
            addRenderableWidget(Button.builder(Component.literal("Close Minecraft"), ignored->minecraft.stop()).bounds(width/2-100,height/2+46,200,20).build());
        }
    }
    @Override public boolean shouldCloseOnEsc(){return false;}
    @Override public void render(GuiGraphics graphics,int mouseX,int mouseY,float partial){
        renderBackground(graphics);
        graphics.drawCenteredString(font,title,width/2,height/2-42,0xFFFFFF);
        graphics.drawCenteredString(font,manual ? "Close Minecraft and use the latest updater." : "Restarting once to finish setup...",width/2,height/2-16,0xDDDDDD);
        if(manual)graphics.drawCenteredString(font,"Then open the pack again.",width/2,height/2-2,0xDDDDDD);
        super.render(graphics,mouseX,mouseY,partial);
    }
}
