package net.michaelspack.clientfixes.mixin;
import java.io.File;
import java.util.List;
import net.minecraft.client.Options;
import net.michaelspack.clientfixes.SkyPackDefaults;
import net.michaelspack.clientfixes.TexturePackDefaults;
import net.michaelspack.clientfixes.FlashDefaults;
import net.michaelspack.clientfixes.DHCloudDefaultsHook;
import net.michaelspack.clientfixes.ClientFeatures109;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Initial Options.load finishes before Minecraft constructs/selects its startup resource packs. */
@Mixin(Options.class)
public abstract class SkyDefaultsBeforeLoadMixin {
    @Shadow @Final private File optionsFile;
    @Shadow public List<String> resourcePacks;
    @Inject(method="load()V",at=@At("TAIL"))
    private void michaels$activateSkiesOnce(CallbackInfo ci){FlashDefaults.apply(optionsFile.toPath().toAbsolutePath().getParent());resourcePacks=SkyPackDefaults.apply(optionsFile.toPath(),resourcePacks);resourcePacks=TexturePackDefaults.apply(optionsFile.toPath(),resourcePacks);DHCloudDefaultsHook.install(optionsFile.toPath().toAbsolutePath().getParent());ClientFeatures109.install(optionsFile.toPath().toAbsolutePath().getParent());}
}
