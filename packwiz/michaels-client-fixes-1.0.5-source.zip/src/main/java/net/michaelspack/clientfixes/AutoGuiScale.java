package net.michaelspack.clientfixes;
/** Fractional scale is consumed by native Window projection and integer-ceiling GUI dimensions. */
public final class AutoGuiScale {
    private AutoGuiScale() {}
    public static double adjust(double nativeScale, boolean automatic) {
        if (!automatic || !Double.isFinite(nativeScale) || nativeScale <= 0.0) return nativeScale;
        return Math.max(1.0, nativeScale * 0.85);
    }
}
