package net.michaelspack.clientfixes.mixin;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.michaelspack.clientfixes.LauncherMemoryMigration;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ConnectScreen.class)
public abstract class MemoryBeforeJoinMixin {
    @Inject(method="startConnecting",at=@At("HEAD"),cancellable=true)
    private static void michaels$finishMemoryUpdate(Screen parent,Minecraft client,ServerAddress address,ServerData data,boolean quickPlay,CallbackInfo ci){
        if(LauncherMemoryMigration.mustFinishBeforeJoin(client))ci.cancel();
    }
}
