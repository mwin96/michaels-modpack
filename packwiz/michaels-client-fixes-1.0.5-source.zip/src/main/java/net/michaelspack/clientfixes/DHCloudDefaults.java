package net.michaelspack.clientfixes;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.regex.*;

/** One named DH option, applied once; preserves all other text and later choices. */
public final class DHCloudDefaults {
    public static final String MARKER = "config/michaels-dh-clouds-108.done";
    public static final String CONFIG = "config/DistantHorizons.toml";
    private DHCloudDefaults() {}

    public static boolean apply(Path gameDirectory, Runnable nativeUpdate) throws Exception {
        Path game = gameDirectory.toAbsolutePath().normalize();
        Path marker = game.resolve(MARKER);
        if (Files.isRegularFile(marker)) return false;
        Path config = game.resolve(CONFIG);
        String before = Files.isRegularFile(config) ? Files.readString(config, StandardCharsets.UTF_8) : "";
        String after = merge(before); // Reject duplicate/ambiguous data before any mutation.
        nativeUpdate.run();
        if (!after.equals(before)) atomic(config, after);
        atomic(marker, "Disabled DH LOD clouds once; later cloud settings remain yours.\n");
        return true;
    }

    private static String name(String value) {
        return "(?:" + Pattern.quote(value) + "|\"" + Pattern.quote(value) + "\"|'" + Pattern.quote(value) + "')";
    }

    public static String merge(String input) {
        String bom = input.startsWith("\uFEFF") ? "\uFEFF" : "";
        String text = input.substring(bom.length());
        String newline = text.contains("\r\n") ? "\r\n" : "\n";
        String table = String.join("[ \\t]*\\.[ \\t]*", name("client"), name("advanced"), name("graphics"), name("genericRendering"));
        Pattern header = Pattern.compile("(?m)^[ \\t]*\\[[ \\t]*" + table + "[ \\t]*\\][ \\t]*(?:#[^\\r\\n]*)?(\\r?)$");
        Matcher found = header.matcher(text);
        String key = name("enableCloudRendering");
        if (!found.find()) {
            if (Pattern.compile("(?m)^[ \\t]*" + key + "[ \\t]*=").matcher(text).find())
                throw new IllegalArgumentException("Unrecognized DH cloud table layout");
            return bom + text + (text.isEmpty() || text.endsWith("\n") ? "" : newline)
                + "[client.advanced.graphics.genericRendering]" + newline + "enableCloudRendering = false" + newline;
        }
        int start = found.end();
        if (found.find()) throw new IllegalArgumentException("Duplicate DH cloud table");
        Matcher next = Pattern.compile("(?m)^[ \\t]*\\[").matcher(text);
        int end = next.find(start) ? next.start() : text.length();
        String block = text.substring(start, end);
        Matcher assignment = Pattern.compile("(?m)^([ \\t]*" + key + "[ \\t]*=[ \\t]*)(true|false)([ \\t]*(?:#[^\\r\\n]*)?)(\\r?)$").matcher(block);
        String updated;
        if (assignment.find()) {
            int from = assignment.start(), to = assignment.end();
            String line = assignment.group(1) + "false" + assignment.group(3) + assignment.group(4);
            if (assignment.find()) throw new IllegalArgumentException("Duplicate DH cloud option");
            updated = block.substring(0, from) + line + block.substring(to);
        } else {
            if (Pattern.compile("(?m)^[ \\t]*" + key + "[ \\t]*=").matcher(block).find())
                throw new IllegalArgumentException("Invalid DH cloud boolean");
            updated = block + (block.endsWith("\n") ? "" : newline) + "enableCloudRendering = false" + newline;
        }
        return bom + text.substring(0, start) + updated + text.substring(end);
    }

    private static void atomic(Path path, String text) throws Exception {
        Files.createDirectories(path.getParent());
        Path temporary = Files.createTempFile(path.getParent(), ".michaels-dh-clouds-", ".tmp");
        try {
            Files.writeString(temporary, text, StandardCharsets.UTF_8);
            try { Files.move(temporary, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temporary); }
    }
}
