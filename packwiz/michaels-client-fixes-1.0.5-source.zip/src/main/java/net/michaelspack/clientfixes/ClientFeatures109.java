package net.michaelspack.clientfixes;

import com.google.gson.*;
import java.nio.file.*;
import java.util.*;
import java.lang.reflect.*;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import org.lwjgl.opengl.GL11;
import oshi.SystemInfo;
import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

/** Startup defaults are once-only. Download consent is strictly an in-memory approved-session override. */
public final class ClientFeatures109 {
    private static boolean installed,hardwareDone,audioDone,birdsDone,keyDone,ipnDone,warned;
    private static Boolean hardwareCapable;
    private static int ticks;
    private static Path game;
    private static DhSessionDownload109.Value generation;
    private static final DhSessionDownload109 SESSION=new DhSessionDownload109();
    private ClientFeatures109() {}
    public static void install(Path path){if(installed)return;installed=true;game=path.toAbsolutePath().normalize();hardwareDone=Files.isRegularFile(game.resolve(ClientPreferences109.HARDWARE_MARKER));audioDone=Files.isRegularFile(game.resolve(ClientPreferences109.AUDIO_MARKER));birdsDone=Files.isRegularFile(game.resolve(ClientPreferences109.BIRD_MARKER));EternalBellLimit109.install();MinecraftForge.EVENT_BUS.addListener(ClientFeatures109::tick);MinecraftForge.EVENT_BUS.addListener(ClientFeatures109::logout);}
    private static void logout(ClientPlayerNetworkEvent.LoggingOut event){if(generation!=null)try{SESSION.update(false,generation);}catch(Exception failure){warn(failure);}}
    private static void tick(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END)return;Minecraft client=Minecraft.getInstance();if(client.options==null)return;AutomaticPlayShortcut109.tick(game);
        if(!audioDone){audioDone=true;try{audio(client);}catch(Exception failure){warn(failure);}}
        if(!hardwareDone)try{hardware();}catch(Exception failure){warn(failure);}
        if(!birdsDone&&ticks%20==0)try{birds();}catch(ClassNotFoundException absent){birdsDone=true;}catch(Exception failure){warn(failure);}
        if(!keyDone&&ticks%20==0)try{backpackKey(client);}catch(Exception failure){warn(failure);}
        if(!ipnDone&&ticks%20==0)try{craftingCheckbox();}catch(ClassNotFoundException absent){ipnDone=true;}catch(Exception failure){warn(failure);}
        boolean eligible=client.level!=null&&client.getSingleplayerServer()==null&&client.getConnection()!=null&&client.getConnection().getConnection().isConnected()&&client.getCurrentServer()!=null&&ClientPreferences109.ourServer(client.getCurrentServer().ip);
        if(++ticks%20==0||!eligible)try{session(client);}catch(ClassNotFoundException absent){}catch(Exception failure){warn(failure);}
    }
    private static void warn(Exception failure){if(!warned){warned=true;System.err.println("Michael's109 defaults/session setting retained safely: "+failure.getClass().getSimpleName());}}
    private static void audio(Minecraft client)throws Exception{
        Path file=game.resolve("options.txt");String before=Files.readString(file),after=before;
        SoundSource[] sources={SoundSource.MASTER,SoundSource.HOSTILE,SoundSource.NEUTRAL};double[] factors={.8,.65,.6};double[] values=new double[3];
        for(int i=0;i<3;i++){values[i]=ClientPreferences109.scale(client.options.getSoundSourceOptionInstance(sources[i]).get(),factors[i]);after=ClientPreferences109.patchOption(after,"soundCategory_"+sources[i].getName(),Double.toString(values[i]));}
        for(int i=0;i<3;i++)client.options.getSoundSourceOptionInstance(sources[i]).set(values[i]);
        ClientPreferences109.atomic(file,after);ClientPreferences109.mark(game,ClientPreferences109.AUDIO_MARKER,"Scaled master/hostile/neutral once; later settings remain yours.");audioDone=true;
    }
    private static void hardware()throws Exception{
        if(hardwareCapable==null){hardwareCapable=false;try{var system=new SystemInfo().getHardware();long ram=system.getMemory().getTotal();String renderer=GL11.glGetString(GL11.GL_RENDERER);
            if(renderer!=null)for(var gpu:system.getGraphicsCards())if(ClientPreferences109.capable(ram,renderer,gpu.getName(),gpu.getVRam())){hardwareCapable=true;break;}}catch(RuntimeException|LinkageError unknown){hardwareCapable=false;}}
        if(hardwareCapable){
            try{
                Class<?> quality=Class.forName("com.seibel.distanthorizons.core.config.Config$Client$Advanced$Graphics$Quality");Object radius=quality.getField("lodChunkRenderDistanceRadius").get(null);Object raw=radius.getClass().getMethod("getTrueValue").invoke(radius),resolved=radius.getClass().getMethod("get").invoke(radius);
                if(Integer.valueOf(32).equals(raw)&&Integer.valueOf(32).equals(resolved)){Path file=game.resolve("config/DistantHorizons.toml");String changed=ClientPreferences109.patchRadius32(Files.readString(file));radius.getClass().getMethod("setWithoutSaving",Object.class).invoke(radius,Integer.valueOf(64));ClientPreferences109.atomic(file,changed);}
            }catch(ClassNotFoundException absent){}
            Path properties=game.resolve("config/oculus.properties"),enhanced=game.resolve("shaderpacks/"+ClientPreferences109.ENHANCED);
            if(Files.isRegularFile(properties)&&Files.isRegularFile(enhanced)){
                Properties config=new Properties();try(var input=Files.newInputStream(properties)){config.load(input);}
                if("true".equals(config.getProperty("enableShaders"))&&ClientPreferences109.NORMAL.equals(config.getProperty("shaderPack"))){
                    Class<?> iris=Class.forName("net.irisshaders.iris.Iris");Object live=iris.getMethod("getIrisConfig").invoke(null);if(live==null)return;
                    Object pack=live.getClass().getMethod("getShaderPackName").invoke(live);boolean enabled=(Boolean)live.getClass().getMethod("areShadersEnabled").invoke(live);
                    if(enabled&&pack instanceof Optional<?> selected&&selected.filter(ClientPreferences109.NORMAL::equals).isPresent()){
                        String old=Files.readString(properties);ClientPreferences109.atomic(properties,ClientPreferences109.patchProperty(old,"shaderPack",ClientPreferences109.ENHANCED));
                        try{iris.getMethod("reload").invoke(null);}catch(Exception failed){ClientPreferences109.atomic(properties,old);try{iris.getMethod("reload").invoke(null);}catch(Exception ignored){}warn(failed);}
                    }
                }
            }
        }
        ClientPreferences109.mark(game,ClientPreferences109.HARDWARE_MARKER,"Evaluated conservative RAM/active-dedicated-GPU defaults once; custom/later choices remain yours.");hardwareDone=true;
    }
    private static void backpackKey(Minecraft client)throws Exception{
        String marker="config/michaels-backpack-key-109.done";if(Files.isRegularFile(game.resolve(marker))){keyDone=true;return;}
        KeyMapping backpack=null,zoom=null;for(KeyMapping key:client.options.keyMappings){if(key.getName().equals("key.sophisticatedbackpacks.open_backpack"))backpack=key;if(key.getName().equals("key.tacz.zoom.desc"))zoom=key;}
        if(backpack==null)return;
        boolean slashUsed=false;for(KeyMapping key:client.options.keyMappings)if(key!=zoom&&key.getKey().getType()==InputConstants.Type.KEYSYM&&key.getKey().getValue()==GLFW.GLFW_KEY_BACKSLASH)slashUsed=true;
        if(!slashUsed&&zoom!=null&&backpack.getKey().getType()==InputConstants.Type.KEYSYM&&zoom.getKey().getType()==InputConstants.Type.KEYSYM&&backpack.getKey().getValue()==GLFW.GLFW_KEY_B&&zoom.getKey().getValue()==GLFW.GLFW_KEY_B){
            Path options=game.resolve("options.txt");String changed=ClientPreferences109.patchOption(Files.readString(options),"key_key.tacz.zoom.desc","key.keyboard.backslash");
            zoom.setKey(InputConstants.Type.KEYSYM.getOrCreate(GLFW.GLFW_KEY_BACKSLASH));KeyMapping.resetMapping();ClientPreferences109.atomic(options,changed);
        }
        ClientPreferences109.mark(game,marker,"Reserved defaultB for backpack; only conflicting default TaCZzoom moved. Later/custom keys remain yours.");keyDone=true;
    }
    private static void birds()throws Exception{
        Class<?> sounds=Class.forName("team.creative.ambientsounds.AmbientSounds");Object handler=sounds.getField("TICK_HANDLER").get(null);Object engine=handler.getClass().getField("engine").get(handler);if(engine==null)return;
        Path file=game.resolve("config/ambientsounds-client.json");if(!Files.isRegularFile(file))return;JsonObject before=JsonParser.parseString(Files.readString(file)).getAsJsonObject(),after=ClientPreferences109.quieterBirds(before);
        for(String[] path:ClientPreferences109.BIRDS){Object region=engine.getClass().getMethod("getRegion",String.class).invoke(engine,path[0]);if(region==null)continue;Map<?,?> loaded=(Map<?,?>)region.getClass().getField("loadedSounds").get(region);Object sound=loaded.get(path[1]);if(sound!=null)sound.getClass().getField("volumeSetting").setDouble(sound,after.getAsJsonObject("regions").getAsJsonObject(path[0]).get(path[1]).getAsDouble());}
        ClientPreferences109.atomic(file,new GsonBuilder().setPrettyPrinting().create().toJson(after)+"\n");ClientPreferences109.mark(game,ClientPreferences109.BIRD_MARKER,"Scaled only eleven bird ambience entries once; general and later choices remain yours.");birdsDone=true;
    }
    private static void craftingCheckbox()throws Exception{
        String marker="config/michaels-ipn-crafting-109.done";if(Files.isRegularFile(game.resolve(marker))){ipnDone=true;return;}
        nativeIpnOff("GuiSettings",List.of("getSHOW_CONTINUOUS_CRAFTING_CHECKBOX","getCONTINUOUS_CRAFTING_SAVED_VALUE"));
        nativeIpnOff("AutoRefillSettings",List.of("getREFILL_BEFORE_TOOL_BREAK","getVISUAL_DURABILITY_NOTIFICATION","getAUDIO_DURABILITY_NOTIFICATION"));
        Path file=game.resolve("config/inventoryprofilesnext/inventoryprofiles.json");JsonObject original=Files.isRegularFile(file)?JsonParser.parseString(Files.readString(file)).getAsJsonObject():new JsonObject();JsonObject json=ClientPreferences109.quieterIpn(original);ClientPreferences109.atomic(file,new GsonBuilder().setPrettyPrinting().create().toJson(json)+"\n");ClientPreferences109.mark(game,marker,"Hid continuous crafting checkbox/saved state and near-break tool replacement/alerts once; other/later IPN choices remain yours.");ipnDone=true;
    }
    private static void nativeIpnOff(String className,List<String> methods)throws Exception{
        Class<?> type=Class.forName("org.anti_ad.mc.ipnext.config."+className);Object settings=type.getField("INSTANCE").get(null);
        for(String method:methods){
            Object option=type.getMethod(method).invoke(settings);Method setter=null;
            for(Method candidate:option.getClass().getMethods())if(candidate.getName().equals("setValue")&&candidate.getParameterCount()==1&&(candidate.getParameterTypes()[0]==boolean.class||candidate.getParameterTypes()[0]==Boolean.class||candidate.getParameterTypes()[0]==Object.class)){setter=candidate;if(candidate.getParameterTypes()[0]==boolean.class)break;}
            if(setter==null)throw new NoSuchMethodException("IPN boolean setter");setter.invoke(option,Boolean.FALSE);if(!Boolean.FALSE.equals(option.getClass().getMethod("getValue").invoke(option)))throw new IllegalStateException("IPN checkbox value did not change");
        }
    }
    private static void session(Minecraft client)throws Exception{
        if(generation==null){Class<?> delayed=Class.forName("com.seibel.distanthorizons.api.DhApi$Delayed");Object configs=delayed.getField("configs").get(null);if(configs==null)return;Object world=Class.forName("com.seibel.distanthorizons.api.interfaces.config.IDhApiConfig").getMethod("worldGenerator").invoke(configs);Object value=Class.forName("com.seibel.distanthorizons.api.interfaces.config.both.IDhApiWorldGenerationConfig").getMethod("enableDistantWorldGeneration").invoke(world);generation=new ReflectiveValue(value);}
        boolean target=client.level!=null&&client.getSingleplayerServer()==null&&client.getConnection()!=null&&client.getConnection().getConnection().isConnected()&&client.getCurrentServer()!=null&&ClientPreferences109.ourServer(client.getCurrentServer().ip);
        if(target)try{Object world=Class.forName("com.seibel.distanthorizons.core.api.internal.SharedApi").getMethod("getAbstractDhWorld").invoke(null);if(world==null||!world.getClass().getName().equals("com.seibel.distanthorizons.core.world.DhClientWorld"))target=false;else{Object state=world.getClass().getField("networkState").get(world);target=state!=null&&(Boolean)state.getClass().getMethod("isReady").invoke(state);}}catch(Exception unavailable){target=false;warn(unavailable);}
        SESSION.update(target,generation);
    }
    private static final class ReflectiveValue implements DhSessionDownload109.Value{
        private final Object value;private final Class<?> api;ReflectiveValue(Object value)throws Exception{this.value=value;this.api=Class.forName("com.seibel.distanthorizons.api.interfaces.config.IDhApiConfigValue");}
        public Object apiValue()throws Exception{return api.getMethod("getApiValue").invoke(value);}
        public boolean canOverride()throws Exception{return (Boolean)api.getMethod("getCanBeOverrodeByApi").invoke(value);}
        public boolean setTrue()throws Exception{return (Boolean)api.getMethod("setValue",Object.class).invoke(value,Boolean.TRUE);}
        public boolean clear()throws Exception{return (Boolean)api.getMethod("clearValue").invoke(value);}
    }
}
