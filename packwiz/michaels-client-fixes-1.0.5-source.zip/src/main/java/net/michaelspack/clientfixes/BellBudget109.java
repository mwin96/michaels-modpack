package net.michaelspack.clientfixes;

/** Monotonic ten-second playback budget followed by sixty seconds of quiet. */
public final class BellBudget109 {
    private static final long AUDIBLE=10_000_000_000L, CYCLE=70_000_000_000L;
    private boolean started;
    private long start;
    public boolean admit(long now){if(started&&now-start<CYCLE)return false;started=true;start=now;return true;}
    public boolean capped(long now){return started&&now-start>=AUDIBLE;}
}
