package net.michaelspack.clientfixes;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;

/** Only the Eternal Jesus bell is bounded; every other sound passes through unchanged. */
public final class EternalBellLimit109 {
    private static final BellBudget109 BUDGET=new BellBudget109();
    private static SoundInstance active;
    private static boolean installed;
    private EternalBellLimit109(){}
    public static void install(){if(installed)return;installed=true;MinecraftForge.EVENT_BUS.addListener(EternalBellLimit109::play);MinecraftForge.EVENT_BUS.addListener(EternalBellLimit109::tick);}
    private static synchronized void play(PlaySoundEvent event){
        SoundInstance sound=event.getSound();
        if(sound==null||!sound.getLocation().toString().equals("eternaljesus:jesus_bell"))return;
        if(!BUDGET.admit(System.nanoTime())){event.setSound(null);return;}
        active=sound;
    }
    private static void tick(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.END)return;SoundInstance stop;
        synchronized(EternalBellLimit109.class){if(active==null||!BUDGET.capped(System.nanoTime()))return;stop=active;active=null;}
        Minecraft.getInstance().getSoundManager().stop(stop);
    }
}
