package net.michaelspack.clientfixes;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.regex.*;

/** The mod's actual disable-flashes and acknowledgment choices, applied once before config loading. */
public final class FlashDefaults {
    private FlashDefaults() {}
    public static void apply(Path gameDirectory) {
        Path game = gameDirectory.toAbsolutePath().normalize();
        Path marker = game.resolve("config/michaels-no-rapid-flashes-107.done");
        if (Files.isRegularFile(marker)) return;
        Path config = game.resolve("config/mbackrooms/Mbackrooms-Config-Common.toml");
        try {
            String original = Files.isRegularFile(config) ? Files.readString(config, StandardCharsets.UTF_8) : "";
            String patched = merge(original, "JumpsScares Settings", "flashEnabled", false);
            patched = merge(patched, "PHOTOSENSITIVITY WARNING !!!", "photosensitivityWarningDisplayed", true);
            if (!patched.equals(original)) atomic(config, patched);
            atomic(marker, "Backrooms rapid flashes disabled and warning acknowledged once.\n");
        } catch (Exception failure) {
            System.err.println("Michael's Backrooms defaults kept existing settings: " + failure.getClass().getSimpleName());
        }
    }
    public static String merge(String text, String section, String key, boolean value) {
        String newline = text.contains("\r\n") ? "\r\n" : "\n";
        String sectionName = "(?:\"" + Pattern.quote(section) + "\"|'" + Pattern.quote(section) + "')";
        String keyName = "(?:\"" + Pattern.quote(key) + "\"|'" + Pattern.quote(key) + "'|" + Pattern.quote(key) + ")";
        Pattern header = Pattern.compile("(?m)^[ \\t]*\\[[ \\t]*" + sectionName + "[ \\t]*\\][ \\t]*(?:#[^\\r\\n]*)?(\\r?)$");
        Matcher found = header.matcher(text);
        if (!found.find()) return text + (text.isEmpty() || text.endsWith("\n") ? "" : newline) + "[\"" + section + "\"]" + newline + key + " = " + value + newline;
        int start = found.end();
        if (found.find()) throw new IllegalArgumentException("Duplicate configuration section");
        Matcher following = Pattern.compile("(?m)^[ \\t]*\\[").matcher(text);
        int end = following.find(start) ? following.start() : text.length();
        String block = text.substring(start, end);
        Matcher assignment = Pattern.compile("(?m)^([ \\t]*" + keyName + "[ \\t]*=[ \\t]*)(true|false)([ \\t]*(?:#[^\\r\\n]*)?)(\\r?)$").matcher(block);
        String updated;
        if (assignment.find()) {
            int from = assignment.start(), to = assignment.end();
            String line = assignment.group(1) + value + assignment.group(3) + assignment.group(4);
            if (assignment.find()) throw new IllegalArgumentException("Duplicate configuration value");
            updated = block.substring(0, from) + line + block.substring(to);
        } else {
            if (Pattern.compile("(?m)^[ \\t]*" + keyName + "[ \\t]*=").matcher(block).find())
                throw new IllegalArgumentException("Invalid configuration boolean");
            updated = block + (block.endsWith("\n") ? "" : newline) + key + " = " + value + newline;
        }
        return text.substring(0, start) + updated + text.substring(end);
    }
    private static void atomic(Path file, String text) throws Exception {
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), ".michaels-flashes-", ".tmp");
        try {
            Files.writeString(temp, text, StandardCharsets.UTF_8);
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }
}
