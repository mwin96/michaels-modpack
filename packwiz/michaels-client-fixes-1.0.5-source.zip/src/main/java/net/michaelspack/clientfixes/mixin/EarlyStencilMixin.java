package net.michaelspack.clientfixes.mixin;

import com.mojang.blaze3d.pipeline.MainTarget;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Allocate TaCZ's required stencil before world shader/DH pipelines retain the main depth attachment. */
@Mixin(MainTarget.class)
public abstract class EarlyStencilMixin {
    private static final boolean APPLICABLE = has("com/tacz/guns/util/RenderHelper.class")
        && has("com/seibel/distanthorizons/core/api/internal/SharedApi.class")
        && has("net/irisshaders/iris/Iris.class");
    private static boolean has(String path) {
        return RenderTarget.class.getClassLoader().getResource(path) != null;
    }
    @Inject(method="<init>(II)V",at=@At("TAIL"),require=1)
    private void michaels$prepareStencilBeforeShaders(int width,int height,CallbackInfo ci) {
        if (!APPLICABLE) return;
        RenderTarget target=(RenderTarget)(Object)this;
        if (RenderSystem.isOnRenderThread()) target.enableStencil();
        else RenderSystem.recordRenderCall(target::enableStencil);
    }
}
