package net.michaelspack.clientfixes.mixin;
import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.Minecraft;
import net.michaelspack.clientfixes.AutoGuiScale;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
@Mixin(Window.class)
public abstract class AutoGuiScaleMixin {
    @ModifyVariable(method="setGuiScale", at=@At("HEAD"), argsOnly=true, ordinal=0)
    private double michaels$smallerAutoScale(double scale) {
        Minecraft client = Minecraft.getInstance();
        return AutoGuiScale.adjust(scale, client != null && client.options != null && client.options.guiScale().get() == 0);
    }
}
