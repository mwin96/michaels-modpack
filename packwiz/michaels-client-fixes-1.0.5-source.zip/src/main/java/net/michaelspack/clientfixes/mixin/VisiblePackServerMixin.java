package net.michaelspack.clientfixes.mixin;

import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.multiplayer.ServerSelectionList;
import net.minecraft.client.multiplayer.ServerList;
import net.michaelspack.clientfixes.VisiblePackServer109;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(JoinMultiplayerScreen.class)
public abstract class VisiblePackServerMixin {
    @Shadow private ServerList servers;
    @Shadow protected ServerSelectionList serverSelectionList;
    @Inject(method="init",at=@At("TAIL"),require=1)
    private void michaels$keepPackServerVisible(CallbackInfo callback){
        if(servers!=null&&serverSelectionList!=null&&VisiblePackServer109.ensure(servers,((ServerListHiddenAccessor)(Object)servers).michaels$hiddenServerList()))serverSelectionList.updateOnlineServers(servers);
    }
}
