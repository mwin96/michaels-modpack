package net.michaelspack.clientfixes;

/** Keep every fourth volcanic emission; ordinary smoke never consumes this budget. */
public final class PlumeSmokeBudget109 {
    private int volcanicEmissions;
    public boolean keep(boolean volcanicPlume){return !volcanicPlume||(volcanicEmissions++&3)==0;}
}
