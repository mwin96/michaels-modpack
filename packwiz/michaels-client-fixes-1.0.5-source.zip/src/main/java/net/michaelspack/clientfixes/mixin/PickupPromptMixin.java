package net.michaelspack.clientfixes.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Disable the unconditional optional SCP manual-pickup UI; ordinary pickup is server-owned. */
@Pseudo
@Mixin(targets="com.bl4ues.scpinventory.client.PickupPromptClient", remap=false)
public final class PickupPromptMixin {
    @Inject(method="clientTick", at=@At("HEAD"), cancellable=true, remap=false, require=1)
    private static void noManualPickupTick(CallbackInfo ci) { ci.cancel(); }

    @Inject(method="render", at=@At("HEAD"), cancellable=true, remap=false, require=1)
    private static void noPickupPrompt(CallbackInfo ci) { ci.cancel(); }

    @Inject(method="renderWorldOutline", at=@At("HEAD"), cancellable=true, remap=false, require=1)
    private static void noPickupOutline(CallbackInfo ci) { ci.cancel(); }
}
