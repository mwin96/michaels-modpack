package net.michaelspack.clientfixes;

/** Fall through to vanilla only for zombie/spider visuals in the two anime ZIPs. */
public final class NormalZombieResources {
    private static final String[] TARGETS={"zombie","husk","drowned","zombified_piglin","horse_zombie","spider","cave_spider"};
    private NormalZombieResources() {}
    public static boolean isAnimePack(String id) {
        return named(id,"CMMRP_Release_1.0_NormalAnimals.zip") || named(id,"MyMonsterGirls.zip");
    }
    private static boolean named(String id,String filename) {
        return id.equals(filename) || id.endsWith("/"+filename) || id.endsWith("\\"+filename);
    }
    public static boolean isZombieVisual(String namespace,String path) {
        if (!namespace.equals("minecraft")) return false;
        if (!(path.startsWith("textures/entity/") || path.startsWith("optifine/cem/") ||
              path.startsWith("optifine/random/entity/") || path.startsWith("optifine/anim/"))) return false;
        for (String part:path.split("/")) {
            for (String name:TARGETS) {
                if (!part.startsWith(name)) continue;
                if (part.length()==name.length()) return true;
                char next=part.charAt(name.length());
                if (next=='.' || next=='_' || Character.isDigit(next)) return true;
            }
        }
        return false;
    }
}
