package net.michaelspack.clientfixes;

import com.google.gson.*;
import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;
import javax.imageio.ImageIO;

/** Generates personal-use assets locally; no third-party image bytes are distributed. */
public final class LocalTexturePack {
    public static final String FILE = "Michaels-LowMemory-Textures.zip";
    public static final String ID = "file/" + FILE;
    private static boolean attempted, ready;
    private LocalTexturePack() {}

    public static synchronized boolean ensure(Path gameDirectory) {
        if (attempted) return ready;
        attempted = true;
        Path game = gameDirectory.toAbsolutePath().normalize();
        Path output = game.resolve("resourcepacks").resolve(FILE);
        Path cache = game.resolve("config/michaels-texture-cache-107.txt");
        Path temporary = null;
        Map<String, ZipFile> archives = new HashMap<>();
        try {
            byte[] recipeBytes;
            try (InputStream input = LocalTexturePack.class.getResourceAsStream("/michaels-textures-107-recipe.json")) {
                if (input == null) return false;
                recipeBytes = input.readAllBytes();
            }
            JsonObject recipe = JsonParser.parseString(new String(recipeBytes, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject sources = recipe.getAsJsonObject("sourceJarHashes");
            List<String> names = new ArrayList<>(sources.keySet());
            Collections.sort(names);
            StringBuilder fingerprint = new StringBuilder("107-bicubic-v1\n").append(hash(recipeBytes)).append('\n');
            for (String name : names) {
                if (name.contains("/") || name.contains("\\") || name.contains("..")) return false;
                Path source = game.resolve("mods").resolve(name);
                if (!Files.isRegularFile(source)) return false;
                fingerprint.append(name).append('\t').append(Files.size(source)).append('\t')
                    .append(Files.getLastModifiedTime(source).toMillis()).append('\n');
            }
            String signature = fingerprint.toString();
            if (Files.isRegularFile(cache) && Files.isRegularFile(output)) {
                String stored = Files.readString(cache, StandardCharsets.UTF_8);
                if (stored.equals(signature + hash(output) + "\n")) return ready = true;
            }
            // Verify every original archive before replacing an existing generated pack.
            for (String name : names) {
                Path source = game.resolve("mods").resolve(name);
                if (!hash(source).equalsIgnoreCase(sources.get(name).getAsString())) return false;
                archives.put(name, new ZipFile(source.toFile()));
            }
            Files.createDirectories(output.getParent());
            Files.createDirectories(cache.getParent());
            temporary = Files.createTempFile(output.getParent(), ".michaels-textures-", ".zip");
            int count = 0;
            try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(temporary))) {
                putText(zip, "pack.mcmeta", "{\"pack\":{\"pack_format\":15,\"description\":\"Michael's low-memory textures\"}}\n");
                putText(zip, "LOCAL-USE-NOTICE.txt", "Generated locally from your installed mods for personal use. Original artwork and licenses remain with their authors. Do not redistribute this generated ZIP.\n");
                Set<String> written = new HashSet<>();
                for (JsonElement element : recipe.getAsJsonArray("entries")) {
                    JsonObject entry = element.getAsJsonObject();
                    String name = entry.get("path").getAsString();
                    if (!name.startsWith("assets/") || name.contains("..") || name.contains("\\") || !written.add(name))
                        throw new IOException("Invalid local texture recipe");
                    ZipFile source = archives.get(entry.get("sourceJar").getAsString());
                    ZipEntry original = source == null ? null : source.getEntry(name);
                    if (original == null) throw new IOException("Missing original texture");
                    byte[] originalBytes;
                    try (InputStream input = source.getInputStream(original)) { originalBytes = input.readAllBytes(); }
                    if (!hash(originalBytes).equalsIgnoreCase(entry.get("sourceSha256").getAsString()))
                        throw new IOException("Original texture changed");
                    BufferedImage image = ImageIO.read(new ByteArrayInputStream(originalBytes));
                    JsonArray before = entry.getAsJsonArray("before"), after = entry.getAsJsonArray("after");
                    if (image == null || image.getWidth() != before.get(0).getAsInt() || image.getHeight() != before.get(1).getAsInt())
                        throw new IOException("Unexpected original dimensions");
                    int width = after.get(0).getAsInt(), height = after.get(1).getAsInt();
                    if (width < 1 || height < 1 || width > 1024 || height > 1024) throw new IOException("Invalid target size");
                    BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
                    Graphics2D graphics = resized.createGraphics();
                    try {
                        graphics.setComposite(AlphaComposite.Src);
                        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                        graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
                        graphics.drawImage(image, 0, 0, width, height, null);
                    } finally { graphics.dispose(); }
                    zip.putNextEntry(new ZipEntry(name));
                    if (!ImageIO.write(resized, "png", zip)) throw new IOException("PNG encoder unavailable");
                    zip.closeEntry();
                    image.flush(); resized.flush();
                    count++;
                }
            }
            if (count != 98) throw new IOException("Incomplete local texture pack");
            move(temporary, output); temporary = null;
            Path stamp = Files.createTempFile(cache.getParent(), ".michaels-texture-cache-", ".tmp");
            try { Files.writeString(stamp, signature + hash(output) + "\n", StandardCharsets.UTF_8); move(stamp, cache); }
            finally { Files.deleteIfExists(stamp); }
            System.out.println("Michael's modpack generated its 98 local low-memory textures.");
            return ready = true;
        } catch (Exception failure) {
            System.err.println("Michael's local texture optimization kept existing resources: " + failure.getClass().getSimpleName());
            return false;
        } finally {
            for (ZipFile archive : archives.values()) try { archive.close(); } catch (IOException ignored) {}
            if (temporary != null) try { Files.deleteIfExists(temporary); } catch (IOException ignored) {}
        }
    }

    private static void putText(ZipOutputStream zip, String path, String text) throws IOException {
        zip.putNextEntry(new ZipEntry(path)); zip.write(text.getBytes(StandardCharsets.UTF_8)); zip.closeEntry();
    }
    private static void move(Path from, Path to) throws IOException {
        try { Files.move(from, to, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException unsupported) { Files.move(from, to, StandardCopyOption.REPLACE_EXISTING); }
    }
    private static String hash(Path file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = Files.newInputStream(file)) {
            byte[] buffer = new byte[65536]; int length;
            while ((length = input.read(buffer)) != -1) digest.update(buffer, 0, length);
        }
        return HexFormat.of().formatHex(digest.digest());
    }
    private static String hash(byte[] data) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
    }
}
