package net.michaelspack.clientfixes.mixin;

import net.minecraft.client.multiplayer.ClientLevel;
import net.michaelspack.clientfixes.PlumeSmokeBudget109;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Optional exact1.5 renderer hook: thin only volcanic plume requests before puff allocation. */
@Pseudo
@Mixin(targets="com.anobs.extremedisasters.client.SmokeRenderSystem",remap=false)
public abstract class VolcanoSmokeBudgetMixin {
    @Unique private static final PlumeSmokeBudget109 michaels$plumeBudget=new PlumeSmokeBudget109();
    @Inject(method="emit(Lnet/minecraft/client/multiplayer/ClientLevel;DDDIDDZZ)V",at=@At("HEAD"),cancellable=true,require=1,remap=false)
    private static void michaels$thinOnlyVolcanicPlume(ClientLevel level,double x,double y,double z,int count,double spread,double upwardSpeed,boolean dense,boolean volcanicPlume,CallbackInfo callback){
        if(!michaels$plumeBudget.keep(volcanicPlume))callback.cancel();
    }
}
