package net.michaelspack.dhcompat.mixin;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.michaelspack.dhcompat.CompletedLightmap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(DynamicTexture.class)
public abstract class CompletedLightmapMixin {
 @Inject(method="upload",at=@At("TAIL"))
 private void michaels$completedLightmap(CallbackInfo ci) { CompletedLightmap.afterUpload((DynamicTexture)(Object)this); }
}
