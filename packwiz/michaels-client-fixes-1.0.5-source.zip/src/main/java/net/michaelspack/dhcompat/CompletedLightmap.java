package net.michaelspack.dhcompat;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.logging.LogUtils;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModList;
import net.michaelspack.dhcompat.mixin.LightTextureAccessor;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

/** Shares the already completed texture. No pixel writes, uploads, texture binding, or ownership transfer. */
public final class CompletedLightmap {
 private static boolean attempted,disabled;
 private static MethodHandle wrapLevel,setLightmapId,alexDetectsDh;
 private static ForgeConfigSpec.BooleanValue alexColoring;
 private static final boolean VALIDATE=Boolean.getBoolean("michaelspack.benchmark") && Boolean.getBoolean("michaelspack.dhLightmap.validate");
 public static volatile long forwarded,failures,validated;
 public static volatile int lastTextureId,lastActiveTextureBefore,lastActiveTextureAfter,lastBindingBefore,lastBindingAfter;
 public static volatile long lastPixelHashBefore,lastPixelHashAfter;
 private CompletedLightmap() {}

 public static void afterUpload(DynamicTexture texture) {
  if(disabled)return;
  Minecraft game=Minecraft.getInstance();
  if(game.level==null||game.gameRenderer==null)return;
  NativeImage image=texture.getPixels();
  if(image==null||image!=((LightTextureAccessor)game.gameRenderer.lightTexture()).michaels$getLightPixels())return;
  try {
   if(!attempted)initialize();
   if(disabled||!alexColoring.get()||(boolean)alexDetectsDh.invokeExact())return;
   Object level=(Object)wrapLevel.invokeExact(game.level);
   if(level==null)return;
   int id=texture.getId();
   if(VALIDATE){lastActiveTextureBefore=GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);lastBindingBefore=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);lastPixelHashBefore=hash(image);}
   setLightmapId.invokeExact(id,level);
   forwarded++;lastTextureId=id;
   if(VALIDATE){lastActiveTextureAfter=GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);lastBindingAfter=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);lastPixelHashAfter=hash(image);validated++;}
  }catch(Throwable e){failures++;disabled=true;LogUtils.getLogger().error("Completed Alex lightmap could not be shared with DH; compatibility disabled",e);}
 }
 private static void initialize()throws ReflectiveOperationException {
  attempted=true;
  if(!ModList.get().isLoaded("distanthorizons")||!ModList.get().isLoaded("alexscaves")){disabled=true;return;}
  ClassLoader loader=Minecraft.class.getClassLoader();MethodHandles.Lookup lookup=MethodHandles.publicLookup();
  Class<?> levelType=Class.forName("com.seibel.distanthorizons.core.wrapperInterfaces.world.IClientLevelWrapper",false,loader);
  Class<?> levelWrapper=Class.forName("loaderCommon.forge.com.seibel.distanthorizons.common.wrappers.world.ClientLevelWrapper",false,loader);
  Class<?> renderer=Class.forName("loaderCommon.forge.com.seibel.distanthorizons.common.wrappers.minecraft.MinecraftRenderWrapper",false,loader);
  wrapLevel=lookup.unreflect(levelWrapper.getMethod("getWrapper",ClientLevel.class)).asType(MethodType.methodType(Object.class,ClientLevel.class));
  setLightmapId=lookup.unreflect(renderer.getMethod("setLightmapId",int.class,levelType)).bindTo(renderer.getField("INSTANCE").get(null)).asType(MethodType.methodType(void.class,int.class,Object.class));
  Class<?> ac=Class.forName("com.github.alexmodguy.alexscaves.AlexsCaves",false,loader);Object config=ac.getField("CLIENT_CONFIG").get(null);
  alexColoring=(ForgeConfigSpec.BooleanValue)config.getClass().getField("biomeAmbientLightColoring").get(config);
  Class<?> loaded=Class.forName("com.github.alexmodguy.alexscaves.server.misc.ACLoadedMods",false,loader);
  alexDetectsDh=lookup.unreflect(loaded.getMethod("isDistantHorizonsLoaded"));
 }
 private static long hash(NativeImage image){long h=0xcbf29ce484222325L;for(int y=0;y<image.getHeight();y++)for(int x=0;x<image.getWidth();x++)h=(h^Integer.toUnsignedLong(image.getPixelRGBA(x,y)))*0x100000001b3L;return h;}
}
