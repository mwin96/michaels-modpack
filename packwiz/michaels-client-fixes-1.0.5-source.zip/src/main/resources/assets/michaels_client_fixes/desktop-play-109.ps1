param([Parameter(Mandatory=$true)][string]$GameDirectory,[string]$DesktopPath)
$ErrorActionPreference='Stop'
$game=[IO.DirectoryInfo]::new([IO.Path]::GetFullPath($GameDirectory))
if($game.Name -notin @('minecraft','.minecraft')){throw 'Not a portable game folder'}
$instance=$game.Parent;$instances=$instance.Parent;$data=$instances.Parent;$root=$data.Parent
if($instances.Name -ine 'instances' -or $data.Name -ine 'Data' -or $instance.Name -notmatch '^[A-Za-z0-9_. -]+$'){throw 'Not a portable Prism instance'}
$launcher=Join-Path $root.FullName 'Launcher';$exe=Join-Path $launcher 'prismlauncher.exe';$instanceConfig=Join-Path $instance.FullName 'instance.cfg'
foreach($path in @($game.FullName,$instance.FullName,$instances.FullName,$data.FullName,$root.FullName,$launcher,$exe,$instanceConfig)){
 if(-not [IO.File]::Exists($path) -and -not [IO.Directory]::Exists($path)){throw 'Portable launcher path missing'}
 if($path -match '["\r\n]' -or ([IO.File]::GetAttributes($path) -band [IO.FileAttributes]::ReparsePoint)){throw 'Linked or ambiguous launcher path'}
}
if(-not $DesktopPath){$DesktopPath=[Environment]::GetFolderPath([Environment+SpecialFolder]::Desktop)}
if(-not $DesktopPath -or -not [IO.Directory]::Exists($DesktopPath)){throw 'Desktop unavailable'}
function Hide-MichaelsSupport([string]$BundleRoot){
 $playEntry=Join-Path $BundleRoot 'PLAY MICHAELS MODPACK.cmd'
 $legacyEntry=Join-Path $BundleRoot 'CLICK HERE TO INSTALL AND PLAY.cmd'
 if(-not [IO.File]::Exists($playEntry) -and [IO.File]::Exists($legacyEntry) -and -not ([IO.File]::GetAttributes($legacyEntry) -band [IO.FileAttributes]::ReparsePoint)){
  [IO.File]::Copy($legacyEntry,$playEntry,$false)
 }
 foreach($name in @('Launcher','Data','CLICK HERE TO INSTALL AND PLAY.cmd','UPDATE MICHAELS MODPACK.cmd','update.ps1','update-settings.json','launcher-ui.ps1','play.ps1')){
  $support=Join-Path $BundleRoot $name
  if([IO.File]::Exists($support) -or [IO.Directory]::Exists($support)){
   $attributes=[IO.File]::GetAttributes($support)
   if(-not ($attributes -band [IO.FileAttributes]::ReparsePoint)){[IO.File]::SetAttributes($support,($attributes -bor [IO.FileAttributes]::Hidden))}
  }
 }
 if([IO.File]::Exists($playEntry)){
  $attributes=[IO.File]::GetAttributes($playEntry)
  if(-not ($attributes -band [IO.FileAttributes]::ReparsePoint)){[IO.File]::SetAttributes($playEntry,($attributes -band (-bnot [IO.FileAttributes]::Hidden)))}
 }
}
Hide-MichaelsSupport $root.FullName
$shortcut=Join-Path $DesktopPath "Play Michael's Modpack.lnk"
$marker=Join-Path $game.FullName 'config\michaels-desktop-play-109.done'
[void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($marker))
if([IO.File]::Exists($shortcut)){
 [IO.File]::WriteAllText($marker,"Existing desktop shortcut preserved.`n",[Text.UTF8Encoding]::new($false));exit 0
}
$play=Join-Path $root.FullName 'PLAY MICHAELS MODPACK.cmd'
$target=$exe;$arguments='--dir "{0}" --launch "{1}" --server 51.81.148.186:25590' -f $data.FullName,$instance.Name
if([IO.File]::Exists($play)){
 if([IO.File]::GetAttributes($play) -band [IO.FileAttributes]::ReparsePoint){throw 'Linked Play entry'}
 $target=$play;$arguments=''
}
$shell=New-Object -ComObject WScript.Shell
try{
 $link=$shell.CreateShortcut($shortcut);$link.TargetPath=$target;$link.Arguments=$arguments;$link.WorkingDirectory=$root.FullName;$link.IconLocation=$exe+',0';$link.Description="Play Michael's Modpack using your saved account.";$link.Save()
 if(-not [IO.File]::Exists($shortcut)){throw 'Shortcut was not saved'}
}finally{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell)}
[IO.File]::WriteAllText($marker,"Created desktop Play shortcut once; saved account and Data retained.`n",[Text.UTF8Encoding]::new($false))
