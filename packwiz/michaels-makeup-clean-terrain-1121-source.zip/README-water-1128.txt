Replace the two named files in the pre-water shader ZIP with the supplied shader sources. Both profiles use this build.
