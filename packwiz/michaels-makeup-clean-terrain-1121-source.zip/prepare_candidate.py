"""Isolated1121 shader/source and original JSON grass models; never edits installed files."""
from pathlib import Path
import json,zipfile,hashlib,copy,difflib,datetime,math
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
BASE=R/'work/visual-fixes-112/candidate-smooth-grass/MakeUp-UltraFast-9.6.zip';EXPECTED='3bc0ff2b1cdccd5e181ff671062697cf49a8fa12e1ebfb38bf56cd1e69277821'
def sha(b):return hashlib.sha256(b).hexdigest()
def model(texture,height):
 f=lambda names:{d:{'uv':[0,0,16,16],'texture':'#cross','tintindex':0}for d in names}
 common={'rotation':{'origin':[8,8,8],'axis':'y','angle':45,'rescale':True},'shade':False}
 return {'ambientocclusion':False,'textures':{'cross':texture,'particle':'#cross'},'elements':[dict(copy.deepcopy(common),**{'from':[3,0,8],'to':[13,height,8],'faces':f(['north','south'])}),dict(copy.deepcopy(common),**{'from':[8,0,3],'to':[8,height,13],'faces':f(['west','east'])})]}
def main():
 assert sha(BASE.read_bytes())==EXPECTED
 z=zipfile.ZipFile(BASE);changed={}
 solid='shaders/common/solid_blocks_fragment.glsl';a=z.read(solid).decode();start=a.index('    // Avoid render in DH transition\n');end=a.index('\n    // Toma el color puro del bloque',start)
 old=a[start:end];assert 'michaelsDitherDhFragment && umbral > dither'in old
 changed[solid]=(a[:start]+'''    // Michael's1121: keep every loaded vanilla solid/cutout fragment intact.
    // DH's existing depth/nearclip path handles overlap; no screen-door rejection.
    // Native texture alpha/cutout behavior below remains unchanged.
'''+a[end:]).encode()
 water='shaders/common/water_blocks_fragment.glsl';a=z.read(water).decode();start=a.index('    // Avoid render in DH transition\n');end=a.index('\n    #include "/src/finalcolor.glsl"',start);assert 'draw_umbral > dither'in a[start:end]
 changed[water]=(a[:start]+'''    // Michael's1121: keep loaded vanilla water/glass coverage intact at DH overlap.
    // Preserve native transparency/reflection/refraction and DH water depth checks.
'''+a[end:]).encode()
 light='shaders/src/light_vertex.glsl';a=z.read(light).decode();assert a.count('tintColor.rgb, 0.93) * 0.94;')==1
 changed[light]=a.replace('tintColor.rgb, 0.93) * 0.94;','tintColor.rgb, 0.87) * 0.90;').encode()
 notice='''Michael's Modpack1121 visual polish,2026-11-07
Original MakeUp Ultra Fast9.6 by Javier Garduno / javiergcim.
https://github.com/javiergcim/MakeUpUltraFast
https://modrinth.com/shader/makeup-ultra-fast-shaders
LGPL-3.0-or-later; unchanged original LICENSE, COPYING.GPL-3.0.txt and README retained.

This section supersedes the historical112 note below about retaining other
materials' DH transition. Remove only the per-fragment DH screen-door discard
from loaded vanilla solid/cutout terrain and vanilla water/glass fragment sources.
Do not alter texture-alpha cutouts, DH nearclip/depth/material shaders, sky,
lighting, shadow, FXAA/TAA settings, grass geometry in shader, or outdoor haze.
Native visible geometry now ends at actual loaded chunk coverage, not a stippled
shader transition. The renderer/LOD boundary can remain visible; missing LOD data
is not regenerated or repaired by this shader. No new buffer, sampler or pass.
Green biome-tinted native grass-like IDs use0.90brightness/0.87chroma; allother
colors/alpha and existing restrained hue-preserving rule remain unchanged.

Corresponding source includes complete baseline source archive, original input,
full modified shaderZIP, reproducible script and exact patch. Native visual
acceptance remains separate. No measured FPS/RAM or universal gap cure claim.

--- Historical112 change notice retained for provenance ---
'''+z.read('MICHAELS-MODIFICATION-NOTICE.txt').decode()
 changed['MICHAELS-MODIFICATION-NOTICE.txt']=notice.encode()
 artifacts=[];out=O/'candidate';out.mkdir(exist_ok=True)
 for name in ['MakeUp-UltraFast-9.6.zip','MakeUp-UltraFast-9.6-Enhanced.zip']:
  p=out/name
  with zipfile.ZipFile(p,'w')as q:
   for info in z.infolist():q.writestr(copy.copy(info),changed.get(info.filename,z.read(info.filename)))
  with zipfile.ZipFile(p)as q:
   assert q.namelist()==z.namelist();assert sorted(n for n in q.namelist()if q.read(n)!=z.read(n))==sorted(changed)
  b=p.read_bytes();artifacts.append({'file':str(p),'fileName':name,'bytes':len(b),'sha256':sha(b),'sha512':hashlib.sha512(b).hexdigest(),'changedMembers':sorted(changed)})
 assert artifacts[0]['sha256']==artifacts[1]['sha256']
 patches=[]
 for n,b in changed.items():patches+=difflib.unified_diff(z.read(n).decode().splitlines(True),b.decode().splitlines(True),fromfile='published112/'+n,tofile='candidate1121/'+n)
 patch=''.join(patches);(O/'clean-terrain.patch').write_text(patch)
 resources=O/'grass-resources';rows=[]
 for name,h in [('grass',10),('tall_grass_bottom',16),('tall_grass_top',8)]:
  p=resources/'assets/minecraft/models/block'/f'{name}.json';p.parent.mkdir(parents=True,exist_ok=True);b=(json.dumps(model('minecraft:block/'+name,h),indent=2)+'\n').encode();p.write_bytes(b);rows.append({'source':str(p),'resourcePath':'assets/minecraft/models/block/'+name+'.json','bytes':len(b),'sha256':sha(b),'texture':'minecraft:block/'+name,'heightPixels':h,'planeWidthPixels':10})
 # Independent structural invariants:4 faces total, full nativeUV alpha, tint0,
 # exact allowedrotation and contiguous tallgrass lower16+upper8 from0.
 for row in rows:
  m=json.loads(Path(row['source']).read_text());assert len(m['elements'])==2
  assert sum(len(e['faces'])for e in m['elements'])==4
  for e in m['elements']:
   assert e['from'][1]==0 and e['to'][1]==row['heightPixels'] and e['rotation']['angle']==45
   assert all(f['uv']==[0,0,16,16]and f['tintindex']==0 for f in e['faces'].values())
 assert rows[1]['heightPixels']==16 and rows[2]['heightPixels']==8
 # All112buffers, sky, DHnearclip, reflections, shaderproperties and AA unchanged.
 untouched=['shaders/common/solid_dh_blocks_fragment.glsl','shaders/common/solid_dh_water_fragment.glsl','shaders/lib/config.glsl','shaders/shaders.properties','shaders/common/final_fragment.glsl','shaders/src/fog_vertex.glsl','shaders/src/fog_vertex_dh.glsl','shaders/lib/fxaa.glsl']
 assert not(set(untouched)&set(changed))
 # Tint invariants over4913 RGBcases; preserve hue/chroma ordering, alpha untouched.
 for rr in range(17):
  for gg in range(17):
   for bb in range(17):
    c=[rr/16,gg/16,bb/16];l=sum(v*w for v,w in zip(c,[.2126,.7152,.0722]))
    if gg>max(rr,bb):
     n=[(l*.13+v*.87)*.90 for v in c];assert all(0<=v<=1 for v in n);assert n[1]>max(n[0],n[2]);assert abs(sum(v*w for v,w in zip(n,[.2126,.7152,.0722]))-l*.90)<1e-12
 grassLicense='''MIT License

Copyright(c)2026 Michael's Modpack contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the Software), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
''';(resources/'LICENSE-MICHAELS-GRASS-MODELS.txt').write_text(grassLicense)
 fm={'passed':True,'scope':'Three original code-native block model resources to merge into Primary-owned clfixesJAR; no Java/JAR/config edits by this task.','files':rows,'license':'MIT; texture refs resolve native Minecraft assets, no PNGcopied/edited.','modelPolicy':{'shortGrassHeight':10,'shortGrassPlaneWidth':10,'tallGrassHeightTotal':24,'lowerHeight':16,'upperHeight':8,'noFloatingUpperHalf':True,'nativeAlphaUVTintTexturesPreserved':True,'blockCountsCollisionWorldgenUnchanged':True,'facesPerBlock':4,'activeInstalledPacksOverrideThesePaths':False}}
 (O/'grass-model-input-files.json').write_text(json.dumps(fm,indent=2)+'\n')
 source=O/'michaels-makeup-clean-terrain-1121-source.zip'
 with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED)as q:
  q.write(R/'work/visual-fixes-112/michaels-makeup-smooth-grass-112-source.zip','published112-complete-source.zip');q.write(BASE,'input/MakeUp-UltraFast-9.6.zip');q.write(out/'MakeUp-UltraFast-9.6.zip','modified/MakeUp-UltraFast-9.6.zip');q.write(__file__,'prepare_candidate.py');q.writestr('clean-terrain.patch',patch);q.writestr('LICENSE',z.read('LICENSE'));q.writestr('COPYING.GPL-3.0.txt',z.read('COPYING.GPL-3.0.txt'));q.writestr('MICHAELS-MODIFICATION-NOTICE.txt',notice)
  for row in rows:q.write(row['source'],'grass-models/'+row['resourcePath'])
  q.writestr('grass-models/LICENSE.txt',grassLicense)
  for helper in ['check_shader_paths.py','compile_hidden_context.py']:
   if (O/helper).exists():q.write(O/helper,helper)
 report={'staticPassed':True,'nativeCompilePassed':False,'nativeVisualPassed':False,'approvedForPublication':False,'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseShaderSha256':EXPECTED,'baseCompleteSourceSha256':'67cf0ad6a3f3b4e2f44d58c79e0b65107217f4a65b0158a49d83df013192f7bc','artifacts':artifacts,'source':str(source),'sourceSha256':sha(source.read_bytes()),'sourceSha512':hashlib.sha512(source.read_bytes()).hexdigest(),'grassModelFileMap':str(O/'grass-model-input-files.json'),'grassModelFileMapSha256':sha((O/'grass-model-input-files.json').read_bytes()),'unchangedCriticalMembers':untouched,'goldenGrassColorCases':4913,'newBuffersTexturesPasses':0,'noSidecarPreferencesHeapRuntimeWrites':True,'limits':['No actual renderer/visual acceptance yet.','No measured FPS/RAM benefit or universal DHgap cure.','Removing stochastic transition keeps geometry until native loaded boundary; coarseLOD handoff/pop or true missingLODdata may still be visible.','Grass models change visualcoverage, not actual grassblockdensity/count or collision. No bitmapediting.','Nativecutout texture holes remain intentionally.']}
 (O/'candidate-artifacts.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'staticPassed':True,'shaderSha256':artifacts[0]['sha256'],'sourceSha256':report['sourceSha256'],'grassFiles':len(rows)},indent=2))
if __name__=='__main__':main()
