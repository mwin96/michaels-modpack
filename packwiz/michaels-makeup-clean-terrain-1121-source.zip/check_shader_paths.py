"""Expand real shader includes and preprocess only; no game/config writes."""
from pathlib import Path
import zipfile,re,subprocess,json,hashlib
O=Path(__file__).resolve().parent;R=O.parents[1]
CPP=Path('C:/Strawberry/c/bin/gcc.exe')
def expand(z,name,options,stack=()):
 assert name not in stack,stack
 a=z.read(name).decode();lines=[]
 for line in a.splitlines():
  m=re.match(r'\s*#include\s+"([^"]+)"',line)
  if m:
   path='shaders/'+m.group(1).lstrip('/') if m.group(1).startswith('/')else str(Path(name).parent/m.group(1)).replace('\\','/')
   lines.append(expand(z,path,options,stack+(name,)));continue
  if name=='shaders/lib/config.glsl':
   m=re.match(r'(\s*#define\s+)([A-Za-z_][A-Za-z_0-9]*)(\s+[^/]*?)?(\s*//.*)?$',line)
   if m and m.group(2)in options:
    key=m.group(2);v=options[key]
    line='#define '+key+(''if v=='true'else ' '+v) if v!='false'else '// option '+key+' disabled'
  lines.append(line)
 return '\n'.join(lines)+'\n'
def preprocess(z,name,options,dh):
 src=expand(z,name,options);directives=[];clean=[]
 for l in src.splitlines():
  if l.lstrip().startswith(('#version','#extension')):directives.append(l)
  else:clean.append(l)
 definitions='#define MC_VERSION 12001\n#define MC_GL_VERSION 460\n#define MC_GLSL_VERSION 460\n'+('#define DISTANT_HORIZONS\n'if dh else'')
 p=subprocess.run([str(CPP),'-E','-P','-x','c','-'],input=(definitions+'\n'.join(clean)).encode(),capture_output=True)
 assert p.returncode==0,(name,p.stderr.decode())
 return '\n'.join(dict.fromkeys(directives))+'\n'+p.stdout.decode()
def main():
 base=zipfile.ZipFile(R/'work/visual-fixes-112/candidate-smooth-grass/MakeUp-UltraFast-9.6.zip');new=zipfile.ZipFile(O/'candidate/MakeUp-UltraFast-9.6.zip');out=O/'preprocessed';out.mkdir(exist_ok=True);cases=[]
 for preset in ['Normal','Enhanced']:
  file='MakeUp-UltraFast-9.6'+('-Enhanced'if preset=='Enhanced'else'')+'.zip.txt'
  p=R/'work/release-112/packwiz/shaderpacks'/file
  if not p.exists():p=R/'work/release-112/baseline-packwiz/shaderpacks'/file
  settings={}
  for line in p.read_text().splitlines():
   if '='in line and not line.startswith('#'):k,v=line.split('=',1);settings[k]=v
  for aa in [0,2]:
   for dh in [False,True]:
    for dim in ['','world0/','world-1/','world1/']:
     for wrapper in ['gbuffers_terrain.fsh','gbuffers_water.fsh','gbuffers_terrain.vsh']:
      n='shaders/'+dim+wrapper;o=dict(settings,AA_TYPE=str(aa));text=preprocess(new,n,o,dh)
      if not dh and wrapper.endswith('.fsh'):assert text==preprocess(base,n,o,dh),('nonDHfragmentchanged',n)
      if wrapper.endswith('.fsh'):
       assert 'umbral > dither'not in text and 'draw_umbral > dither'not in text
      assert text.count('{')==text.count('}') and text.count('(')==text.count(')')
      key=f'{preset}-AA{aa}-DH{int(dh)}-'+dim.replace('/','')+'-'+wrapper
      path=out/key;path.write_bytes(text.encode());cases.append({'key':key,'path':str(path.resolve()),'type':'vertex'if wrapper.endswith('.vsh')else'fragment','preset':preset,'aa':aa,'dh':dh,'dimension':dim or'fallback','sha256':hashlib.sha256(text.encode()).hexdigest()})
      if wrapper.endswith('.vsh'):
       baseline=preprocess(base,n,o,dh);bp=out/('baseline112-'+key);bp.write_bytes(baseline.encode());cases.append({'key':'baseline112-'+key,'path':str(bp.resolve()),'type':'vertex','preset':preset,'aa':aa,'dh':dh,'dimension':dim or'fallback','sha256':hashlib.sha256(baseline.encode()).hexdigest()})
 report={'passed':True,'scope':'GCC C-preprocessor resolves exact GLSL includes and active conditionals; not a GPUcompiler by itself.','cases':len(cases),'DHOffFragmentsExact112':True,'noDhScreenDoorDiscardInAnyAffectedActiveFragment':True,'noNewSamplerFramebufferPass':True,'programs':cases}
 (O/'shader-path-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='programs'}))
if __name__=='__main__':main()

