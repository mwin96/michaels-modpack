"""Compile GLSL with NVIDIA/OpenGL via one invisible1px owned WGLwindow; no game/UIinput."""
from pathlib import Path
import ctypes as C,ctypes.wintypes as W,json,time,hashlib
O=Path(__file__).resolve().parent
class PFD(C.Structure):
 _fields_=[('nSize',W.WORD),('nVersion',W.WORD),('dwFlags',W.DWORD),('iPixelType',C.c_ubyte),('cColorBits',C.c_ubyte),('cRedBits',C.c_ubyte),('cRedShift',C.c_ubyte),('cGreenBits',C.c_ubyte),('cGreenShift',C.c_ubyte),('cBlueBits',C.c_ubyte),('cBlueShift',C.c_ubyte),('cAlphaBits',C.c_ubyte),('cAlphaShift',C.c_ubyte),('cAccumBits',C.c_ubyte),('cAccumRedBits',C.c_ubyte),('cAccumGreenBits',C.c_ubyte),('cAccumBlueBits',C.c_ubyte),('cAccumAlphaBits',C.c_ubyte),('cDepthBits',C.c_ubyte),('cStencilBits',C.c_ubyte),('cAuxBuffers',C.c_ubyte),('iLayerType',C.c_ubyte),('bReserved',C.c_ubyte),('dwLayerMask',W.DWORD),('dwVisibleMask',W.DWORD),('dwDamageMask',W.DWORD)]
def main():
 started=time.monotonic();u=C.WinDLL('user32',use_last_error=True);g=C.WinDLL('gdi32',use_last_error=True);gl=C.WinDLL('opengl32',use_last_error=True)
 u.CreateWindowExW.argtypes=[W.DWORD,W.LPCWSTR,W.LPCWSTR,W.DWORD,C.c_int,C.c_int,C.c_int,C.c_int,W.HWND,W.HMENU,W.HINSTANCE,C.c_void_p];u.CreateWindowExW.restype=W.HWND
 u.GetDC.argtypes=[W.HWND];u.GetDC.restype=W.HDC;u.ReleaseDC.argtypes=[W.HWND,W.HDC];u.DestroyWindow.argtypes=[W.HWND];u.IsWindowVisible.argtypes=[W.HWND];u.GetForegroundWindow.restype=W.HWND
 g.ChoosePixelFormat.argtypes=[W.HDC,C.POINTER(PFD)];g.ChoosePixelFormat.restype=C.c_int;g.SetPixelFormat.argtypes=[W.HDC,C.c_int,C.POINTER(PFD)]
 gl.wglCreateContext.argtypes=[W.HDC];gl.wglCreateContext.restype=C.c_void_p;gl.wglMakeCurrent.argtypes=[W.HDC,C.c_void_p];gl.wglDeleteContext.argtypes=[C.c_void_p];gl.wglGetProcAddress.argtypes=[C.c_char_p];gl.wglGetProcAddress.restype=C.c_void_p;gl.glGetString.argtypes=[C.c_uint];gl.glGetString.restype=C.c_char_p
 before=u.GetForegroundWindow();hwnd=u.CreateWindowExW(0,'STATIC','Private shader compile1121',0x80000000,0,0,1,1,None,None,None,None);assert hwnd
 dc=None;ctx=None;rows=[];meta={}
 try:
  assert not u.IsWindowVisible(hwnd);dc=u.GetDC(hwnd);p=PFD();p.nSize=C.sizeof(PFD);p.nVersion=1;p.dwFlags=4|32|1;p.cColorBits=24;p.cDepthBits=24;p.cStencilBits=8
  fmt=g.ChoosePixelFormat(dc,C.byref(p));assert fmt and g.SetPixelFormat(dc,fmt,C.byref(p));ctx=gl.wglCreateContext(dc);assert ctx and gl.wglMakeCurrent(dc,ctx)
  meta={'vendor':gl.glGetString(0x1f00).decode(),'renderer':gl.glGetString(0x1f01).decode(),'version':gl.glGetString(0x1f02).decode(),'windowVisible':bool(u.IsWindowVisible(hwnd))}
  def fn(name,ret,args):
   addr=gl.wglGetProcAddress(name.encode());assert addr not in(None,0,1,2,3,C.c_void_p(-1).value),name;return C.WINFUNCTYPE(ret,*args)(addr)
  create=fn('glCreateShader',C.c_uint,[C.c_uint]);source=fn('glShaderSource',None,[C.c_uint,C.c_int,C.POINTER(C.c_char_p),C.POINTER(C.c_int)]);compile_=fn('glCompileShader',None,[C.c_uint]);query=fn('glGetShaderiv',None,[C.c_uint,C.c_uint,C.POINTER(C.c_int)]);log=fn('glGetShaderInfoLog',None,[C.c_uint,C.c_int,C.POINTER(C.c_int),C.c_char_p]);delete=fn('glDeleteShader',None,[C.c_uint])
  for row in json.loads((O/'shader-path-review.json').read_text())['programs']:
   b=Path(row['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];sh=create(0x8b31 if row['type']=='vertex' else 0x8b30)
   try:
    text=C.c_char_p(b);source(sh,1,C.byref(text),None);compile_(sh);ok=C.c_int();query(sh,0x8b81,C.byref(ok));n=C.c_int();query(sh,0x8b84,C.byref(n));buf=C.create_string_buffer(max(n.value,1));log(sh,len(buf),None,buf);rows.append({'key':row['key'],'passed':bool(ok.value),'log':buf.value.decode(errors='replace'),'sourceSha256':row['sha256']})
   finally:delete(sh)
  assert not u.IsWindowVisible(hwnd)
 finally:
  if ctx:gl.wglMakeCurrent(None,None);gl.wglDeleteContext(ctx)
  if dc:u.ReleaseDC(hwnd,dc)
  u.DestroyWindow(hwnd)
 result={'passed':all(r['passed']for r in rows)and len(rows)>0,'scope':'Actual standalone OpenGL GLSLstage compilation only; no Minecraft/Irislink/render/visual claim.','context':meta,'cases':len(rows),'failed':[r for r in rows if not r['passed']],'programs':rows,'hiddenOwnedWindowDestroyed':True,'contextDeleted':True,'foregroundUnchanged':before==u.GetForegroundWindow(),'showWindowInputFocusOrGameApisUsed':False,'newFramebuffersTexturesOrRendering':False,'elapsedSeconds':round(time.monotonic()-started,3)}
 (O/'native-shader-compile-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in['programs','failed']}));print(json.dumps(result['failed'][:3]))
if __name__=='__main__':main()

