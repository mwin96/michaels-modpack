package org.embeddedt.modernfix.forge.dynresources;
import java.util.*;
public final class LifecycleQueueTest {
    private static int passed;
    static void check(boolean b,String label){if(!b)throw new AssertionError(label);}
    static void test(String label,Runnable r){r.run();passed++;System.out.println("PASS "+label);}
    static boolean cleared(DeferredModelBakeQueue q){return Boolean.TRUE.equals(q.diagnostics().get("pendingStrongReferencesCleared"));}
    public static void main(String[] args){
      test("pair_wait_and_order_exactly_once",()->{
        var q=new DeferredModelBakeQueue();Object b=new Object(),r=new Object();List<String> out=new ArrayList<>();
        check(q.modify(b,r,()->out.add("modify"),true),"modify queued");q.drain(false,true);check(out.isEmpty(),"no completion yet");
        check(q.completed(b,()->out.add("completed"),x->x==r,true),"complete queued");q.drain(true,true);check(out.isEmpty(),"loading barrier");
        q.drain(false,true);q.drain(false,true);check(out.equals(List.of("modify","completed")),"pair order and single replay");check(cleared(q),"cleared");
        check(q.completed(b,()->out.add("duplicate"),x->true,false),"late duplicate rejected");check(out.size()==2,"no duplicate");
      });
      test("loading_flips_between_pair",()->{
        var q=new DeferredModelBakeQueue();Object b=new Object();List<String> out=new ArrayList<>();
        q.modify(b,new Object(),()->out.add("modify"),true);
        check(q.completed(b,()->out.add("completed"),x->true,false),"completion stays queued");check(out.isEmpty(),"no overtaking");
        q.drain(false,true);check(out.equals(List.of("modify","completed")),"ordered after flip");
      });
      test("latest_generation_drops_old_and_keeps_captured_registry",()->{
        var q=new DeferredModelBakeQueue();Object a=new Object(),b=new Object(),ra=new Object(),rb=new Object();List<String> out=new ArrayList<>();
        q.modify(a,ra,()->out.add("old"),true);q.modify(b,rb,()->out.add("new modify"),true);
        check(q.completed(a,()->out.add("old complete"),x->true,false),"stale completion rejected");
        q.completed(b,()->out.add("new complete"),x->x==rb,false);q.drain(false,true);
        check(out.equals(List.of("new modify","new complete")),"latest only");check(cleared(q),"cleared");
      });
      test("active_registry_guard",()->{
        var q=new DeferredModelBakeQueue();Object b=new Object();int[] count={0};
        q.modify(b,new Object(),()->count[0]++,true);q.completed(b,()->count[0]++,x->false,false);q.drain(false,true);
        check(count[0]==0,"superseded manager never called");check(cleared(q),"stale refs cleared");
      });
      test("invalid_loading_cancels_without_callbacks",()->{
        var q=new DeferredModelBakeQueue();Object b=new Object();int[] count={0};
        q.modify(b,new Object(),()->count[0]++,true);q.completed(b,()->count[0]++,x->true,true);q.drain(false,false);
        check(count[0]==0&&cleared(q),"invalid cancelled");
      });
      test("already_ready_direct_path_unchanged",()->{
        var q=new DeferredModelBakeQueue();Object b=new Object();List<String> out=new ArrayList<>();Runnable m=()->out.add("modify"),c=()->out.add("completed");
        if(!q.modify(b,new Object(),m,false))m.run();if(!q.completed(b,c,x->true,false))c.run();q.drain(false,true);
        check(out.equals(List.of("modify","completed")),"immediate original order");check(cleared(q),"no retained models");
      });
      test("new_ready_reload_supersedes_queued_initial",()->{
        var q=new DeferredModelBakeQueue();Object a=new Object(),b=new Object();List<String> out=new ArrayList<>();
        q.modify(a,new Object(),()->out.add("old"),true);
        if(!q.modify(b,new Object(),()->out.add("new"),false))out.add("new");
        q.completed(a,()->out.add("stale"),x->true,false);if(!q.completed(b,()->out.add("new complete"),x->true,false))out.add("new complete");
        q.drain(false,true);check(out.equals(List.of("new","new complete")),"normal reload wins");check(cleared(q),"cleared");
      });
      test("exception_clears_refs_without_retry",()->{
        var q=new DeferredModelBakeQueue();Object b=new Object();RuntimeException original=new RuntimeException("original");int[] count={0};
        q.modify(b,new Object(),()->{throw original;},true);q.completed(b,()->count[0]++,x->true,false);
        try{q.drain(false,true);throw new AssertionError("throw expected");}catch(RuntimeException got){check(got==original,"same exception");}
        q.drain(false,true);check(count[0]==0&&cleared(q),"no retry/leak/completion after failed modify");
      });
      test("callback_reentrant_new_generation_skips_old_completion",()->{
        var q=new DeferredModelBakeQueue();Object a=new Object(),b=new Object();List<String> out=new ArrayList<>();
        q.modify(a,new Object(),()->{out.add("old modify");q.modify(b,new Object(),()->out.add("new modify"),true);q.completed(b,()->out.add("new completed"),x->true,false);},true);
        q.completed(a,()->out.add("old completed"),x->true,false);q.drain(false,true);q.drain(false,true);
        check(out.equals(List.of("old modify","new modify","new completed")),"reentrant cycle not overwritten");check(cleared(q),"cleared");
      });
      test("weak_latest_does_not_keep_cycle_alive",()->{
        var q=new DeferredModelBakeQueue();Object b=new Object();
        q.modify(b,new Object(),()->{},true);q.cancel();check(cleared(q),"cancel clears all pending strong refs");
        check(q.diagnostics().keySet().stream().noneMatch(k->q.diagnostics().get(k) instanceof Runnable),"diagnostics contain no callbacks");
      });
      System.out.println("RESULT passed="+passed);
    }
}
