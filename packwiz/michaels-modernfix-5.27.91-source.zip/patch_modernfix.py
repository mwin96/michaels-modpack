"""Reproduce one exact ModernFix default change. Standard library only; never publishes or runs Java."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import zipfile

BASE_SHA256 = 'b42fe87fd5ffa46f7db56c6cee01b08dea362baf4cc56a70db40d928773b5000'
CLASS = 'org/embeddedt/modernfix/core/config/ModernFixEarlyConfig.class'
KEY = 'mixin.perf.dynamic_resources'
OUTPUT_NAME = 'michaels-modernfix-forge-5.27.91+mc1.20.1.jar'
COMMIT = '441fe62210157ae62e925eaa2ea95c43652836ad'
HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sha = lambda data: hashlib.sha256(data).hexdigest()


class Reader:
    def __init__(self, data): self.data, self.pos = data, 0
    def take(self, count):
        value = self.data[self.pos:self.pos+count]
        assert len(value) == count
        self.pos += count
        return value
    def u1(self): return self.take(1)[0]
    def u2(self): return struct.unpack('>H', self.take(2))[0]
    def u4(self): return struct.unpack('>I', self.take(4))[0]


def class_data(data):
    r = Reader(data)
    assert r.u4() == 0xcafebabe
    r.take(4)
    cp = [None] * r.u2()
    index = 1
    while index < len(cp):
        tag = r.u1()
        if tag == 1: value = r.take(r.u2()).decode('utf-8')
        elif tag in {3, 4}: value = r.take(4)
        elif tag in {5, 6}: value = r.take(8); cp[index] = (tag, value); index += 1
        elif tag in {7, 8, 16, 19, 20}: value = r.u2()
        elif tag in {9, 10, 11, 12, 17, 18}: value = (r.u2(), r.u2())
        elif tag == 15: value = (r.u1(), r.u2())
        else: raise AssertionError(('Unexpected constant pool tag', tag))
        cp[index] = (tag, value)
        index += 1

    def text(index): assert cp[index][0] == 1; return cp[index][1]
    def member(index):
        tag, (owner, name_type) = cp[index]
        assert tag in {9, 10, 11} and cp[owner][0] == 7 and cp[name_type][0] == 12
        name, desc = cp[name_type][1]
        return text(cp[owner][1]), text(name), text(desc)
    def attributes():
        result = []
        for _ in range(r.u2()):
            name, length = text(r.u2()), r.u4()
            result.append((name, r.pos, r.take(length)))
        return result
    r.take(6)
    r.take(2 * r.u2())
    for _ in range(r.u2()): r.take(6); attributes()
    methods = []
    for _ in range(r.u2()):
        access, name, desc = r.u2(), text(r.u2()), text(r.u2())
        methods.append((access, name, desc, attributes()))
    attributes()
    assert r.pos == len(data)
    matches = [m for m in methods if m[1:3] == ('<clinit>', '()V')]
    assert len(matches) == 1
    code_attrs = [(pos, raw) for name, pos, raw in matches[0][3] if name == 'Code']
    assert len(code_attrs) == 1
    code_pos, code_attr = code_attrs[0]
    code_length = struct.unpack_from('>I', code_attr, 4)[0]
    return cp, text, member, code_pos + 8, code_attr[8:8+code_length]


def instructions(code):
    """Enumerate real opcode boundaries, so matching cannot mistake an operand for ICONST_0."""
    one = set(range(0x15, 0x1a)) | set(range(0x36, 0x3b)) | {0x10, 0x12, 0xa9, 0xbc}
    two = set(range(0x99, 0xa9)) | set(range(0xb2, 0xb9)) | {0x11, 0x13, 0x14, 0x84, 0xbb, 0xbd, 0xc0, 0xc1, 0xc6, 0xc7}
    index, result = 0, []
    while index < len(code):
        start, op = index, code[index]
        index += 1
        if op in one: index += 1
        elif op in two: index += 2
        elif op in {0xb9, 0xba, 0xc8, 0xc9}: index += 4
        elif op == 0xc5: index += 3
        elif op == 0xc4: index += 5 if code[index] == 0x84 else 3
        elif op in {0xaa, 0xab}:
            index += (-index) % 4
            index += 4  # default jump
            if op == 0xaa:
                low, high = struct.unpack_from('>ii', code, index)
                assert high >= low
                index += 8 + 4 * (high-low+1)
            else:
                pairs = struct.unpack_from('>i', code, index)[0]
                assert pairs >= 0
                index += 4 + 8 * pairs
        assert index <= len(code)
        result.append((start, op, code[start+1:index]))
    return result


def patch_class(original):
    cp, text, member, code_pos, code = class_data(original)
    ops, sites = instructions(code), []
    for i in range(1, len(ops)-2):
        previous, current, boxing, put = ops[i-1:i+3]
        if current[1] != 0x03 or previous[1] not in {0x12, 0x13}: continue
        constant = int.from_bytes(previous[2], 'big')
        if cp[constant][0] != 8 or text(cp[constant][1]) != KEY: continue
        if boxing[1] != 0xb8 or put[1] != 0xb6: continue
        if member(int.from_bytes(boxing[2], 'big')) != ('java/lang/Boolean', 'valueOf', '(Z)Ljava/lang/Boolean;'): continue
        expected_owner = 'org/embeddedt/modernfix/core/config/ModernFixEarlyConfig$DefaultSettingMapBuilder'
        if member(int.from_bytes(put[2], 'big')) != (expected_owner, 'put', '(Ljava/lang/String;Ljava/lang/Boolean;)L'+expected_owner+';'): continue
        sites.append(code_pos + current[0])
    assert len(sites) == 1, ('Expected exactly one guarded default initializer', sites)
    offset = sites[0]
    changed = bytearray(original)
    assert changed[offset] == 0x03
    changed[offset] = 0x04
    changed = bytes(changed)
    differences = [i for i, (a, b) in enumerate(zip(original, changed)) if a != b]
    assert len(original) == len(changed) and differences == [offset]
    return changed, {'classEntry': CLASS, 'originalClassSha256': sha(original), 'patchedClassSha256': sha(changed),
        'classDifferenceCount': 1, 'classFileByteOffset': offset, 'beforeOpcode': 'ICONST_0 (0x03)',
        'afterOpcode': 'ICONST_1 (0x04)', 'guardedProperty': KEY, 'method': '<clinit>()V',
        'allOtherClassBytesIdentical': True, 'classLengthUnchanged': True}


def idle():
    state_path = WORK / 'performance-105/benchmark-state.json'
    if state_path.is_file():
        state = json.loads(state_path.read_text())
        assert state.get('timed') is False, ('No archive work during RAM measurement', state)


def build(original_path, output, license_path, notice_path):
    idle()
    raw = original_path.read_bytes()
    assert sha(raw) == BASE_SHA256, 'Wrong upstream ModernFix jar'
    with zipfile.ZipFile(original_path) as source:
        assert source.testzip() is None and len(source.namelist()) == len(set(source.namelist()))
        original_entries = {entry.filename: source.read(entry) for entry in source.infolist()}
        assert not any(name.upper().endswith(('.SF', '.RSA', '.DSA', '.EC')) for name in original_entries), 'Do not modify a signed jar'
        patched, proof = patch_class(original_entries[CLASS])
        additions = {'META-INF/MICHAELS-MODIFICATION.txt': notice_path.read_bytes(), 'META-INF/LICENSE-modernfix.txt': license_path.read_bytes()}
        assert not set(additions).intersection(original_entries)
        output.parent.mkdir(parents=True, exist_ok=True)
        assert output.resolve() != original_path.resolve() and output.name == OUTPUT_NAME
        idle()
        with zipfile.ZipFile(output, 'w') as target:
            for entry in source.infolist(): target.writestr(entry, patched if entry.filename == CLASS else original_entries[entry.filename])
            for name, data in sorted(additions.items()):
                info = zipfile.ZipInfo(name, (2026, 11, 5, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED
                target.writestr(info, data)
    with zipfile.ZipFile(output) as result:
        assert result.testzip() is None
        assert set(result.namelist()) == set(original_entries) | set(additions)
        for name, data in original_entries.items(): assert result.read(name) == (patched if name == CLASS else data), name
        for name, data in additions.items(): assert result.read(name) == data
    return dict(proof, originalJarSha256=BASE_SHA256, patchedJarSha256=sha(output.read_bytes()), output=str(output),
        originalEntryCount=len(original_entries), allOtherOriginalEntryContentsByteIdentical=True,
        onlyAdditionalEntries=sorted(additions), nativeModIdAndVersionUnchanged=True, serverJarModified=False,
        upstreamSourceCommit=COMMIT, acceptance='PRIVATE CANDIDATE ONLY; no native or measured acceptance implied')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--original', type=Path, default=WORK / 'performance-105-research/installed-jars/modernfix-forge-5.27.91+mc1.20.1.jar')
    parser.add_argument('--inspect-only', action='store_true')
    parser.add_argument('--output', type=Path, default=HERE / 'candidate' / OUTPUT_NAME)
    parser.add_argument('--license', type=Path, default=HERE / 'LICENSE-modernfix.txt')
    parser.add_argument('--notice', type=Path, default=HERE / 'MODIFICATION-NOTICE.txt')
    args = parser.parse_args()
    assert sha(args.original.read_bytes()) == BASE_SHA256
    if args.inspect_only:
        with zipfile.ZipFile(args.original) as jar: _, report = patch_class(jar.read(CLASS))
        report['originalJarSha256'] = BASE_SHA256
        report['jarWritten'] = False
    else: report = build(args.original, args.output, args.license, args.notice)
    (HERE / ('inspection.json' if args.inspect_only else 'patch-proof.json')).write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__': main()
