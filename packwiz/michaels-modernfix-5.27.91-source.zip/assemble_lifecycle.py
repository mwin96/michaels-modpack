"""Reproduce the narrow private lifecycle/default fork; never runs a game or publishes."""
from pathlib import Path
import argparse, hashlib, json, zipfile
from patch_modernfix import BASE_SHA256, CLASS, patch_class

REPLACE = {
 'org/embeddedt/modernfix/common/mixin/perf/dynamic_resources/ForgeHooksClientMixin.class',
 'org/embeddedt/modernfix/forge/init/ModernFixClientForge.class',
}
ADD = {
 'org/embeddedt/modernfix/forge/dynresources/DeferredModelBakeEvents.class',
 'org/embeddedt/modernfix/forge/dynresources/DeferredModelBakeQueue.class',
 'org/embeddedt/modernfix/forge/dynresources/DeferredModelBakeQueue$Pending.class',
}
sha=lambda data:hashlib.sha256(data).hexdigest()

def assemble(original, bridge, output, license_path, notice_path):
 assert sha(original.read_bytes())==BASE_SHA256
 assert original.resolve()!=output.resolve()
 with zipfile.ZipFile(original) as z:
  assert z.testzip() is None
  infos=z.infolist();base={i.filename:z.read(i) for i in infos}
  assert len(base)==len(infos)
 with zipfile.ZipFile(bridge) as z:
  classes={n:z.read(n) for n in z.namelist() if n.endswith('.class')}
 assert set(classes)==REPLACE|ADD, sorted(classes)
 assert REPLACE.issubset(base) and not ADD.intersection(base)
 assert not any(n.upper().endswith(('.SF','.RSA','.DSA','.EC')) for n in base)
 patched, one_byte_proof=patch_class(base[CLASS])
 changed={CLASS:patched, **{n:classes[n] for n in REPLACE}}
 added={n:classes[n] for n in ADD}
 added.update({'META-INF/MICHAELS-MODIFICATION.txt':notice_path.read_bytes(), 'META-INF/LICENSE-modernfix.txt':license_path.read_bytes()})
 assert not added.keys()&base.keys()
 output.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(output,'w') as out:
  for info in infos:out.writestr(info,changed.get(info.filename,base[info.filename]))
  for n,data in sorted(added.items()):
   info=zipfile.ZipInfo(n,(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;out.writestr(info,data)
 with zipfile.ZipFile(output) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
  assert set(z.namelist())==set(base)|set(added)
  for n,data in base.items():assert z.read(n)==changed.get(n,data),n
  for n,data in added.items():assert z.read(n)==data,n
 return {'passed':True,'originalJarSha256':BASE_SHA256,'jarSha256':sha(output.read_bytes()),'jarBytes':output.stat().st_size,
 'changedOriginalEntries':{n:{'beforeSha256':sha(base[n]),'afterSha256':sha(data)} for n,data in sorted(changed.items())},
 'addedEntries':{n:sha(data) for n,data in sorted(added.items())},'unchangedOriginalEntryCount':len(base)-len(changed),
 'everyOtherOriginalEntryContentByteIdentical':True,'oneByteDefaultProof':one_byte_proof,
 'serverOriginalUnmodified':True,'modIdVersionAndAllMixinConfigsUnchanged':True,'nativeAcceptance':False,'measuredAcceptance':False}

def main():
 p=argparse.ArgumentParser();p.add_argument('--original',type=Path,required=True);p.add_argument('--bridge',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--license',type=Path,required=True);p.add_argument('--notice',type=Path,required=True)
 a=p.parse_args();result=assemble(a.original,a.bridge,a.output,a.license,a.notice)
 a.output.with_suffix('.proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
