package org.embeddedt.modernfix.common.mixin.perf.dynamic_resources;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalCause;
import com.google.common.cache.RemovalNotification;
import com.google.common.collect.ForwardingMap;
import com.google.common.collect.ImmutableList;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import org.embeddedt.modernfix.ModernFix;
import org.embeddedt.modernfix.ModernFixClient;
import org.embeddedt.modernfix.api.entrypoint.ModernFixClientIntegration;
import org.embeddedt.modernfix.duck.IExtendedModelBaker;
import org.embeddedt.modernfix.dynamicresources.DynamicBakedModelProvider;
import org.embeddedt.modernfix.duck.IExtendedModelBakery;
import org.embeddedt.modernfix.annotation.ClientOnlyMixin;
import org.embeddedt.modernfix.dynamicresources.ModelBakeryHelpers;
import org.objectweb.asm.Opcodes;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

/* low priority so that our injectors are added after other mods' */
@Mixin(value = ModelBakery.class, priority = 1100)
@ClientOnlyMixin
public abstract class ModelBakeryMixin implements IExtendedModelBakery {

    private static final boolean debugDynamicModelLoading = Boolean.getBoolean("modernfix.debugDynamicModelLoading");

    @Shadow @Final @Mutable public Map<ResourceLocation, UnbakedModel> unbakedCache;

    @Shadow @Final public static ModelResourceLocation MISSING_MODEL_LOCATION;

    @Shadow protected abstract BlockModel loadBlockModel(ResourceLocation location) throws IOException;

    @Shadow @Final private Set<ResourceLocation> loadingStack;

    @Shadow protected abstract void loadModel(ResourceLocation blockstateLocation) throws Exception;

    @Shadow @Final @Mutable
    private Map<ResourceLocation, BakedModel> bakedTopLevelModels;

    @Shadow @Final @Mutable private Map<ModelBakery.BakedCacheKey, BakedModel> bakedCache;

    @Shadow @Final @Mutable private BlockColors blockColors;

    @Shadow @Final private static Logger LOGGER;

    @Shadow
    public abstract void loadTopLevel(ModelResourceLocation modelResourceLocation);

    @Shadow public abstract UnbakedModel getModel(ResourceLocation resourceLocation);

    private Cache<ModelBakery.BakedCacheKey, BakedModel> loadedBakedModels;

    private Cache<ResourceLocation, UnbakedModel> loadedModels;

    private HashMap<ResourceLocation, UnbakedModel> smallLoadingCache = new HashMap<>();

    private boolean ignoreModelLoad;

    // disable fabric recursion
    @SuppressWarnings("unused")
    private boolean fabric_enableGetOrLoadModelGuard;


    @Redirect(method = "<init>", at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, target = "Lnet/minecraft/client/resources/model/ModelBakery;blockColors:Lnet/minecraft/client/color/block/BlockColors;"))
    private void replaceTopLevelBakedModels(ModelBakery bakery, BlockColors val) {
        fabric_enableGetOrLoadModelGuard = false;
        this.blockColors = val;
        this.loadedBakedModels = CacheBuilder.newBuilder()
                .expireAfterAccess(ModelBakeryHelpers.MAX_MODEL_LIFETIME_SECS, TimeUnit.SECONDS)
                .maximumSize(ModelBakeryHelpers.MAX_BAKED_MODEL_COUNT)
                .concurrencyLevel(8)
                .removalListener(this::onModelRemoved)
                .softValues()
                .build();
        this.loadedModels = CacheBuilder.newBuilder()
                .expireAfterAccess(ModelBakeryHelpers.MAX_MODEL_LIFETIME_SECS, TimeUnit.SECONDS)
                .maximumSize(ModelBakeryHelpers.MAX_UNBAKED_MODEL_COUNT)
                .concurrencyLevel(8)
                .removalListener(this::onModelRemoved)
                .softValues()
                .build();
        this.bakedCache = loadedBakedModels.asMap();
        ConcurrentMap<ResourceLocation, UnbakedModel> unbakedCacheBackingMap = loadedModels.asMap();
        this.unbakedCache = new ForwardingMap<ResourceLocation, UnbakedModel>() {
            @Override
            protected Map<ResourceLocation, UnbakedModel> delegate() {
                return unbakedCacheBackingMap;
            }

            @Override
            public UnbakedModel put(ResourceLocation key, UnbakedModel value) {
                smallLoadingCache.put(key, value);
                return super.put(key, value);
            }
        };
        this.bakedTopLevelModels = new DynamicBakedModelProvider((ModelBakery)(Object)this, bakedCache);
    }

    @ModifyExpressionValue(method = "<init>", at = @At(value = "FIELD", opcode = Opcodes.GETSTATIC, ordinal = 0, target = "Lnet/minecraft/client/resources/model/ModelBakery;STATIC_DEFINITIONS:Ljava/util/Map;"))
    private Map<ResourceLocation, StateDefinition<Block, BlockState>> ignoreFutureModelLoads(Map<ResourceLocation, StateDefinition<Block, BlockState>> original) {
        this.ignoreModelLoad = true;
        return original;
    }

    private <K, V> void onModelRemoved(RemovalNotification<K, V> notification) {
        if(!debugDynamicModelLoading)
            return;
        // If the entry was replaced (happens because of the Minecraft model loading code structure), or
        // was explicitly removed, we don't really care.
        var reason = notification.getCause();
        if (reason == RemovalCause.REPLACED || reason == RemovalCause.EXPLICIT) {
            return;
        }
        Object k = notification.getKey();
        if(k == null)
            return;
        ResourceLocation rl;
        boolean baked = false;
        if(k instanceof ResourceLocation) {
            rl = (ResourceLocation)k;
        } else {
            rl = ((ModelBakery.BakedCacheKey)k).id();
            baked = true;
        }
        /* can fire when a model is replaced */
        if(!baked && this.loadedModels.getIfPresent(rl) != null)
            return;
        ModernFix.LOGGER.warn("Evicted {} model {}", baked ? "baked" : "unbaked", rl);
    }

    private UnbakedModel missingModel;

    private Set<ResourceLocation> blockStateFiles;
    private Set<ResourceLocation> modelFiles;

    @ModifyArg(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/util/Map;put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", ordinal = 0), index = 1)
    private Object captureMissingModel(Object model) {
        this.missingModel = (UnbakedModel)model;
        this.blockStateFiles = new HashSet<>();
        this.modelFiles = new HashSet<>();
        return this.missingModel;
    }

    /**
     * @author embeddedt
     * @reason don't actually load most models
     */
    @Redirect(method = "*", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/resources/model/ModelBakery;loadTopLevel(Lnet/minecraft/client/resources/model/ModelResourceLocation;)V"))
    private void addTopLevelFile(ModelBakery bakery, ModelResourceLocation location) {
        if(location == MISSING_MODEL_LOCATION || !this.ignoreModelLoad) {
            loadTopLevel(location);
        }
    }

    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/util/Map;forEach(Ljava/util/function/BiConsumer;)V", ordinal = 0))
    private void fetchStaticDefinitions(Map<ResourceLocation, StateDefinition<Block, BlockState>> map, BiConsumer<ResourceLocation, StateDefinition<Block, BlockState>> func) {
        /* no-op */
    }

    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/StateDefinition;getPossibleStates()Lcom/google/common/collect/ImmutableList;", ordinal = 0))
    private ImmutableList<BlockState> fetchBlocks(StateDefinition<Block, BlockState> def) {
        /* no-op */
        return ImmutableList.of();
    }

    /**
     * @author embeddedt
     * @reason Prevent the models provided by RegisterAdditional from being tracked, otherwise the unbaked models will
     * be loaded, baked, and added to permanent overrides unnecessarily.
     * We still need to fire the event, because there is a decent chance mods rely on it to set up state for their
     * model loaders, but we can ignore the return value.
     */
    @WrapOperation(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraftforge/client/ForgeHooksClient;onRegisterAdditionalModels(Ljava/util/Set;)V"))
    private void preventLoadOfAdditionalModels(Set<ResourceLocation> additionalModels, Operation<Void> original) {
        original.call(additionalModels);
        // Immediately clear the set
        additionalModels.clear();
    }

    /**
     * Make a copy of the top-level model list to avoid CME if more models get loaded here.
     */
    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/util/Map;values()Ljava/util/Collection;", ordinal = 0))
    private Collection<?> copyTopLevelModelList(Map<?, ?> map) {
        return new ArrayList<>(map.values());
    }

    private BiFunction<ResourceLocation, Material, TextureAtlasSprite> textureGetter;

    @Inject(method = "bakeModels", at = @At("HEAD"))
    private void captureGetter(BiFunction<ResourceLocation, Material, TextureAtlasSprite> getter, CallbackInfo ci) {
        this.ignoreModelLoad = false;
        textureGetter = getter;
        DynamicBakedModelProvider.currentInstance = (DynamicBakedModelProvider)this.bakedTopLevelModels;
    }

    @Redirect(method = "bakeModels", at = @At(value = "INVOKE", target = "Ljava/util/Map;keySet()Ljava/util/Set;"))
    private Set<ResourceLocation> skipBake(Map<ResourceLocation, UnbakedModel> instance) {
        Set<ResourceLocation> modelSet = new HashSet<>(instance.keySet());
        if(modelSet.size() > 0)
            ModernFix.LOGGER.info("Early baking {} models", modelSet.size());
        return modelSet;
    }

    /**
     * Use the already loaded missing model instead of the cache entry (which will probably get evicted).
     */
    @Redirect(method = "loadModel", at = @At(value = "INVOKE", target = "Ljava/util/Map;get(Ljava/lang/Object;)Ljava/lang/Object;", ordinal = 1))
    private Object getMissingModel(Map map, Object rl) {
        if(rl == MISSING_MODEL_LOCATION && map == unbakedCache)
            return missingModel;
        return unbakedCache.get(rl);
    }

    @ModifyVariable(method = "cacheAndQueueDependencies", at = @At("HEAD"), argsOnly = true)
    private UnbakedModel fireUnbakedEvent(UnbakedModel model, ResourceLocation location) {
        for(ModernFixClientIntegration integration : ModernFixClient.CLIENT_INTEGRATIONS) {
            try {
                model = integration.onUnbakedModelLoad(location, model, (ModelBakery)(Object)this);
            } catch(RuntimeException e) {
                ModernFix.LOGGER.error("Exception firing model load event for {}", location, e);
            }
        }
        return model;
    }

    @Inject(method = "cacheAndQueueDependencies", at = @At("RETURN"))
    private void addToSmallLoadingCache(ResourceLocation location, UnbakedModel model, CallbackInfo ci) {
        smallLoadingCache.put(location, model);
    }

    private int mfix$nestedLoads = 0;

    /**
     * @author embeddedt
     * @reason synchronize
     */
    @Inject(method = "getModel", at = @At("HEAD"), cancellable = true)
    public void getOrLoadModelDynamic(ResourceLocation modelLocation, CallbackInfoReturnable<UnbakedModel> cir) {
        if(modelLocation.equals(MISSING_MODEL_LOCATION)) {
            cir.setReturnValue(missingModel);
            return;
        }
        UnbakedModel existing = this.unbakedCache.get(modelLocation);
        if (existing != null) {
            cir.setReturnValue(existing);
        } else {
            synchronized(this) {
                // CIT Resewn adds dependencies to loadingStack outside of getModel(), so we must silently
                // ignore existing things in the stack for the outermost model
                if (mfix$nestedLoads > 0 && this.loadingStack.contains(modelLocation)) {
                    throw new IllegalStateException("Circular reference while loading " + modelLocation);
                } else {
                    this.loadingStack.add(modelLocation);
                    UnbakedModel iunbakedmodel = missingModel;

                    while(!this.loadingStack.isEmpty()) {
                        ResourceLocation resourcelocation = this.loadingStack.iterator().next();

                        mfix$nestedLoads++;
                        try {
                            existing = this.unbakedCache.get(resourcelocation);
                            if (existing == null) {
                                if(debugDynamicModelLoading)
                                    LOGGER.info("Loading {}", resourcelocation);
                                this.loadModel(resourcelocation);
                            } else
                                smallLoadingCache.put(resourcelocation, existing);
                        } catch (ModelBakery.BlockStateDefinitionException var9) {
                            LOGGER.warn(var9.getMessage());
                            this.unbakedCache.put(resourcelocation, iunbakedmodel);
                            smallLoadingCache.put(resourcelocation, iunbakedmodel);
                        } catch (Exception var10) {
                            LOGGER.warn("Unable to load model: '{}' referenced from: {}: {}", resourcelocation, modelLocation, var10);
                            this.unbakedCache.put(resourcelocation, iunbakedmodel);
                            smallLoadingCache.put(resourcelocation, iunbakedmodel);
                        } finally {
                            mfix$nestedLoads--;
                            this.loadingStack.remove(resourcelocation);
                        }
                    }

                    // We have to get the result from the temporary cache used for a model load
                    // As in pathological cases (e.g. Pedestals on 1.19) unbakedCache can lose
                    // the model immediately
                    UnbakedModel result = smallLoadingCache.getOrDefault(modelLocation, iunbakedmodel);
                    try {
                        // required as some mods (e.g. EBE) call bake directly on the returned model, without resolving parents themselves
                        result.resolveParents(this::getModel);
                    } catch(RuntimeException ignored) {}
                    // We are done with loading, so clear this cache to allow GC of any unneeded models
                    if(mfix$nestedLoads == 0)
                        smallLoadingCache.clear();
                    cir.setReturnValue(result);
                }
            }
        }
    }

    @Redirect(method = "loadModel", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/StateDefinition;getPossibleStates()Lcom/google/common/collect/ImmutableList;"))
    private ImmutableList<BlockState> loadOnlyRelevantBlockState(StateDefinition<Block, BlockState> stateDefinition, ResourceLocation location) {
        var allStates = stateDefinition.getPossibleStates();

        if(!(location instanceof ModelResourceLocation mrl)) {
            return allStates;
        }

        // Load a batch of models at once in certain initialization phases to speed up the loading process.
        // This is disabled when in-game as it will cause stutters when blocks are placed.
        boolean shouldLoadBatch = (Minecraft.getInstance().getOverlay() != null || Minecraft.getInstance().level == null);
        int batchSize = ModelBakeryHelpers.MAX_UNBAKED_MODEL_COUNT - 1000;

        // If loading a batch and all the states are smaller than the max batch size, just use them
        // This is hoisted above the computation of desiredStates for performance reasons
        if (shouldLoadBatch && allStates.size() <= batchSize) {
            return allStates;
        }

        var desiredStates = ModelBakeryHelpers.getBlockStatesForMRL(stateDefinition, mrl);

        // If not loading a batch, load only the desired states
        if (!shouldLoadBatch) {
            return desiredStates;
        }

        // At this point we want to load a batch if possible, but loading every state is too much. If desiredStates
        // is a single state (should almost always be the case), then we choose a sublist starting from it and extending
        // batchSize entries (or less if the list ends). If it's multiple states, a single sublist may not include
        // everything, so we bail.
        if (desiredStates.size() != 1) {
            return desiredStates;
        }

        var desiredState = desiredStates.get(0);
        int indexInAllStates = allStates.indexOf(desiredState);
        if (indexInAllStates == -1) {
            return desiredStates;
        }
        return allStates.subList(indexInAllStates, Math.min(indexInAllStates + batchSize, allStates.size()));
    }

    @Override
    public BakedModel bakeDefault(ResourceLocation modelLocation, ModelState state) {
        ModelBakery.BakedCacheKey key = new ModelBakery.BakedCacheKey(modelLocation, BlockModelRotation.X0_Y0.getRotation(), BlockModelRotation.X0_Y0.isUvLocked());
        BakedModel m = loadedBakedModels.getIfPresent(key);
        if(m != null)
            return m;
        ModelBakery self = (ModelBakery) (Object) this;
        ModelBaker theBaker = self.new ModelBakerImpl(textureGetter, modelLocation);
        ((IExtendedModelBaker)theBaker).throwOnMissingModel(true);
        synchronized(this) {
            // We intentionally use the 2-arg overload for better mixin compatibility, because we use the baker's default
            // texture getter anyway.
            //noinspection deprecation
            m = theBaker.bake(modelLocation, state);
        }
        if(m != null)
            loadedBakedModels.put(key, m);
        return m;
    }

    @Override
    public ImmutableList<BlockState> getBlockStatesForMRL(StateDefinition<Block, BlockState> stateDefinition, ModelResourceLocation location) {
        return loadOnlyRelevantBlockState(stateDefinition, location);
    }

    private BakedModel bakedMissingModel = null;

    public void setBakedMissingModel(BakedModel m) {
        bakedMissingModel = m;
    }

    public BakedModel getBakedMissingModel() {
        return bakedMissingModel;
    }

    public UnbakedModel mfix$getUnbakedMissingModel() {
        return missingModel;
    }

    @Override
    public void mfix$clearModels() {
        loadedModels.invalidateAll();
        loadedBakedModels.invalidateAll();
    }
}
