package org.embeddedt.modernfix.forge.dynresources;

import java.lang.ref.WeakReference;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Predicate;

/** Initial-loading callbacks only. Locks protect references; callbacks never run under a lock. */
final class DeferredModelBakeQueue {
    private Pending pending;
    private WeakReference<Object> latestBakery = new WeakReference<>(null);
    private long generation;
    private long deferredModify, deferredCompleted, replayedCycles, supersededCycles, staleEvents, cancelledCycles;
    private long lastReplayedGeneration, consumedGeneration;

    synchronized boolean modify(Object bakery, Object registry, Runnable delivery, boolean loading) {
        Objects.requireNonNull(bakery);
        Objects.requireNonNull(registry);
        Objects.requireNonNull(delivery);
        if (pending != null) supersededCycles++;
        pending = null;
        latestBakery = new WeakReference<>(bakery);
        long current = ++generation;
        if (!loading) return false;
        pending = new Pending(current, bakery, registry, delivery);
        deferredModify++;
        return true;
    }

    synchronized boolean completed(Object bakery, Runnable delivery, Predicate<Object> isCurrent, boolean loading) {
        Objects.requireNonNull(delivery);
        Objects.requireNonNull(isCurrent);
        if (latestBakery.get() != bakery) {
            staleEvents++;
            return true;
        }
        if (pending != null) {
            if (pending.bakery != bakery || pending.completed != null) {
                staleEvents++;
                return true;
            }
            pending.completed = delivery;
            pending.isCurrent = isCurrent;
            deferredCompleted++;
            return true;
        }
        if (generation == consumedGeneration) { staleEvents++; return true; }
        if (loading) { // A completion without its initial modify must never overtake another cycle.
            staleEvents++;
            return true;
        }
        return false;
    }

    void drain(boolean loading, boolean valid) {
        Pending cycle;
        synchronized (this) {
            if (!valid) { cancel(); return; }
            if (loading || pending == null || pending.completed == null) return;
            cycle = pending;
            consumedGeneration = cycle.generation;
            pending = null; // Clear strong event/model references before callbacks, including exceptional callbacks.
        }
        if (!isLatest(cycle) || !cycle.isCurrent.test(cycle.registry)) {
            synchronized (this) { staleEvents++; }
            return;
        }
        cycle.modify.run();
        if (!isLatest(cycle) || !cycle.isCurrent.test(cycle.registry)) {
            synchronized (this) { staleEvents++; }
            return;
        }
        cycle.completed.run();
        synchronized (this) {
            replayedCycles++;
            lastReplayedGeneration = cycle.generation;
        }
    }

    private synchronized boolean isLatest(Pending cycle) {
        return generation == cycle.generation && latestBakery.get() == cycle.bakery;
    }

    synchronized void cancel() {
        if (pending != null) cancelledCycles++;
        pending = null;
        latestBakery.clear();
        generation++;
    }

    synchronized Map<String, Object> diagnostics() {
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("deferredModify", deferredModify);
        values.put("deferredCompleted", deferredCompleted);
        values.put("replayedCycles", replayedCycles);
        values.put("supersededCycles", supersededCycles);
        values.put("staleEvents", staleEvents);
        values.put("cancelledCycles", cancelledCycles);
        values.put("generation", generation);
        values.put("lastReplayedGeneration", lastReplayedGeneration);
        values.put("pending", pending != null);
        values.put("pendingHasCompleted", pending != null && pending.completed != null);
        values.put("pendingBakeryIdentity", pending == null ? 0 : System.identityHashCode(pending.bakery));
        values.put("pendingRegistryIdentity", pending == null ? 0 : System.identityHashCode(pending.registry));
        values.put("pendingStrongReferencesCleared", pending == null);
        return values;
    }

    private static final class Pending {
        final long generation;
        final Object bakery, registry;
        final Runnable modify;
        Runnable completed;
        Predicate<Object> isCurrent;
        Pending(long generation, Object bakery, Object registry, Runnable modify) {
            this.generation = generation;
            this.bakery = bakery;
            this.registry = registry;
            this.modify = modify;
        }
    }
}
