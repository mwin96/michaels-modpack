package org.embeddedt.modernfix.forge.dynresources;

import com.google.common.base.Stopwatch;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.fml.ModContainer;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.ModLoader;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import org.embeddedt.modernfix.ModernFix;
import org.embeddedt.modernfix.dynamicresources.DynamicBakedModelProvider;
import org.embeddedt.modernfix.forge.dynresources.ModelBakeEventHelper;

import java.lang.reflect.Method;
import java.time.Duration;
import java.util.Comparator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/** Defers the initial dynamic model callbacks until all Forge setup and queued work has completed. */
public final class DeferredModelBakeEvents {
    private static final DeferredModelBakeQueue QUEUE = new DeferredModelBakeQueue();
    private static volatile boolean lastRegistryIdentityMatched;
    private static volatile int lastRegistryIdentity, lastBakeryIdentity;
    private static volatile String lastReplayThread = "";
    private static volatile int clearedBlockStateCaches;
    private static volatile boolean clearedForgeItemCache;

    public static void postModify(ModelEvent.ModifyBakingResult event) {
        if (!ModLoader.isLoadingStateValid()) { QUEUE.cancel(); return; }
        if (!QUEUE.modify(event.getModelBakery(), event.getModels(), () -> deliverModify(event),
                net.minecraftforge.client.loading.ClientModLoader.isLoading())) {
            deliverModify(event);
        }
    }

    public static void postCompleted(ModelEvent.BakingCompleted event) {
        if (!ModLoader.isLoadingStateValid()) { QUEUE.cancel(); return; }
        if (!QUEUE.completed(event.getModelBakery(), () -> { deliverCompleted(event); resetDeferredCaches(); }, registry -> isCurrent(event, registry),
                net.minecraftforge.client.loading.ClientModLoader.isLoading())) {
            deliverCompleted(event);
        }
    }

    public static void onClientTickStart() {
        QUEUE.drain(net.minecraftforge.client.loading.ClientModLoader.isLoading(), ModLoader.isLoadingStateValid());
    }

    private static boolean isCurrent(ModelEvent.BakingCompleted event, Object capturedRegistry) {
        ModelManager manager = event.getModelManager();
        Object rawRegistry = event.getModelBakery().getBakedTopLevelModels();
        Object activeRegistry = ObfuscationReflectionHelper.getPrivateValue(ModelManager.class, manager, "f_119397_");
        lastRegistryIdentity = System.identityHashCode(rawRegistry);
        lastBakeryIdentity = System.identityHashCode(event.getModelBakery());
        lastRegistryIdentityMatched = manager.getModelBakery() == event.getModelBakery() && activeRegistry == capturedRegistry && rawRegistry == capturedRegistry;
        lastReplayThread = Thread.currentThread().getName();
        return lastRegistryIdentityMatched;
    }

    private static void resetDeferredCaches() {
        // Match the native apply order: Modify -> Completed -> reset model-reference caches.
        // Keep every model map, override location and registry entry intact.
        int cleared = 0;
        for (net.minecraft.world.level.block.Block block : net.minecraft.core.registries.BuiltInRegistries.BLOCK) {
            for (net.minecraft.world.level.block.state.BlockState state : block.getStateDefinition().getPossibleStates()) {
                if (state instanceof org.embeddedt.modernfix.duck.IModelHoldingBlockState holder) {
                    holder.mfix$setModel(null);
                    cleared++;
                }
            }
        }
        clearedBlockStateCaches = cleared;
        net.minecraft.client.renderer.ItemModelShaper shaper = net.minecraft.client.Minecraft.getInstance().getItemRenderer().getItemModelShaper();
        if (shaper.getClass() == net.minecraftforge.client.model.ForgeItemModelShaper.class
                && org.embeddedt.modernfix.core.ModernFixMixinPlugin.instance.isOptionEnabled("perf.dynamic_resources.ItemModelMesherForgeMixin")) {
            try {
                // This field is created by the exact pinned MF override. Without it, never call an eager vanilla rebuild.
                if (shaper.getClass().getDeclaredField("mfix$modelCache").getType()
                        == org.embeddedt.modernfix.dynamicresources.DynamicModelCache.class) {
                    shaper.rebuildCache();
                    clearedForgeItemCache = true;
                }
            } catch (NoSuchFieldException ignored) {
                ModernFix.LOGGER.warn("Deferred model callback cache reset skipped: pinned ModernFix item-cache field absent");
            }
        }
    }

    /** Primitive/string observations only; never retains a model, bakery, event, manager, or registry. */
    public static Map<String, Object> diagnostics() {
        Map<String, Object> values = QUEUE.diagnostics();
        values.put("lastRegistryIdentityMatched", lastRegistryIdentityMatched);
        values.put("lastRegistryIdentity", lastRegistryIdentity);
        values.put("lastBakeryIdentity", lastBakeryIdentity);
        values.put("lastReplayThread", lastReplayThread);
        values.put("clearedBlockStateCaches", clearedBlockStateCaches);
        values.put("clearedForgeItemCache", clearedForgeItemCache);
        values.put("loaderLoading", net.minecraftforge.client.loading.ClientModLoader.isLoading());
        values.put("loaderValid", ModLoader.isLoadingStateValid());
        return values;
    }

    /**
     * Generate a more realistic keySet that contains every item and block model location, to help with mod compat.
     */
    private static void deliverModify(ModelEvent.ModifyBakingResult event) {
        if(!ModLoader.isLoadingStateValid())
            return;
        ModelEvent.ModifyBakingResult bakeEvent = ((ModelEvent.ModifyBakingResult)event);
        Stopwatch globalTimer = Stopwatch.createStarted();
        Stopwatch selfTimer = Stopwatch.createStarted();
        ModelBakeEventHelper helper = new ModelBakeEventHelper(bakeEvent.getModels());
        selfTimer.stop();
        Method acceptEv = ObfuscationReflectionHelper.findMethod(ModContainer.class, "acceptEvent", Event.class);
        Map<String, Stopwatch> times = new Object2ObjectOpenHashMap<>();
        times.put("modernfix", selfTimer);
        ModList.get().forEachModContainer((id, mc) -> {
            Map<ResourceLocation, BakedModel> newRegistry = helper.wrapRegistry(id);
            ModelEvent.ModifyBakingResult postedEvent = new ModelEvent.ModifyBakingResult(newRegistry, bakeEvent.getModelBakery());
            Stopwatch timer = times.computeIfAbsent(id, $ -> Stopwatch.createUnstarted());
            timer.start();
            try {
                acceptEv.invoke(mc, postedEvent);
            } catch(ReflectiveOperationException e) {
                e.printStackTrace();
            }
            timer.stop();
        });
        globalTimer.stop();
        if (globalTimer.elapsed(TimeUnit.SECONDS) >= 1) {
            ModernFix.LOGGER.warn("Posting dynamic ModelEvent.ModifyBakingResult to mods took {}, breakdown below:", globalTimer);
            times.entrySet().stream()
                    .sorted(Comparator.<Map.Entry<String, Stopwatch>, Duration>comparing(e -> e.getValue().elapsed()).reversed())
                    .filter(e -> e.getValue().elapsed(TimeUnit.MILLISECONDS) > 50)
                    .forEach(entry -> {
                        ModernFix.LOGGER.warn("    {}: {}", entry.getKey(), entry.getValue().toString());
                    });
        }
        if (bakeEvent.getModels() instanceof DynamicBakedModelProvider dynamicProvider) {
            dynamicProvider.dumpStats();
        }
    }

    /**
     * Post a separate BakingCompleted event per mod so they (a) see the wrapped registry and (b) are not able to
     * break other mods by trying to modify the event object (see https://github.com/embeddedt/ModernFix/issues/610
     * for an example).
     */
    private static void deliverCompleted(ModelEvent.BakingCompleted event) {
        if(!ModLoader.isLoadingStateValid())
            return;
        ModelEvent.BakingCompleted bakeEvent = ((ModelEvent.BakingCompleted)event);
        ModelManager modelManager = bakeEvent.getModelManager();
        ModelBakeEventHelper helper = new ModelBakeEventHelper(bakeEvent.getModels());
        Method acceptEv = ObfuscationReflectionHelper.findMethod(ModContainer.class, "acceptEvent", Event.class);
        ModList.get().forEachModContainer((id, mc) -> {
            Map<ResourceLocation, BakedModel> newRegistry = helper.wrapRegistry(id);
            ModelEvent.BakingCompleted postedEvent = new ModelEvent.BakingCompleted(modelManager, newRegistry, bakeEvent.getModelBakery());
            try {
                acceptEv.invoke(mc, postedEvent);
            } catch(ReflectiveOperationException e) {
                e.printStackTrace();
            }
        });
    }
}
