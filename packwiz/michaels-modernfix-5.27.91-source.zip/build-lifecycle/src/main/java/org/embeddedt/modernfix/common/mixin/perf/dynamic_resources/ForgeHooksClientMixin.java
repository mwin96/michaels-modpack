package org.embeddedt.modernfix.common.mixin.perf.dynamic_resources;

import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.fml.ModLoader;
import org.embeddedt.modernfix.forge.dynresources.DeferredModelBakeEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ForgeHooksClient.class)
public class ForgeHooksClientMixin {
    @Redirect(method = "onModifyBakingResult", at = @At(value = "INVOKE", target = "Lnet/minecraftforge/fml/ModLoader;postEvent(Lnet/minecraftforge/eventbus/api/Event;)V"), remap = false)
    private static void postNamespacedKeySetEvent(ModLoader loader, Event event) {
        DeferredModelBakeEvents.postModify((ModelEvent.ModifyBakingResult) event);
    }

    @Redirect(method = "onModelBake", at = @At(value = "INVOKE", target = "Lnet/minecraftforge/fml/ModLoader;postEvent(Lnet/minecraftforge/eventbus/api/Event;)V"), remap = false)
    private static void postNamespacedKeySetBakingCompletedEvent(ModLoader loader, Event event) {
        DeferredModelBakeEvents.postCompleted((ModelEvent.BakingCompleted) event);
    }
}
