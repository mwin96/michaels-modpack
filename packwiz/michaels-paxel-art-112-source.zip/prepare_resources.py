"""Resource-only licensed paxel art. Reads PNGs to build a model/preview; never edits PNG pixels."""
from pathlib import Path
from PIL import Image
import json,hashlib,shutil,zipfile,copy,datetime
R=Path(__file__).resolve().parent
UP=R/'upstream/src/tools/resources/assets/mekanismtools/textures/item'
PACK=R/'package/config/openloader/resources/michaels_paxel_art'
META={'pack':{'pack_format':15,'description':'Refined material-specific paxel icons'}}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(rel,obj):
 p=PACK/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')
def face(uv,tint):return {'uv':uv,'texture':'#paxel','tintindex':tint}
def main():
 names={'copper':'bronze/paxel.png','iron':'iron_paxel.png','diamond':'diamond_paxel.png','netherite':'netherite_paxel.png'}
 before={n:sha(UP/p) for n,p in names.items()}
 for n,rel in names.items():
  target=PACK/f'assets/michaels_paxel_art/textures/item/{n}_paxel.png';target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(UP/rel,target);assert sha(target)==before[n]
  write(f'assets/michaels_equipment/models/item/{n}_paxel.json',{'parent':'minecraft:item/handheld','textures':{'layer0':f'michaels_paxel_art:item/{n}_paxel'}})
 im=Image.open(UP/'iron_paxel.png').convert('RGBA');assert im.size==(16,16)
 pixels={(x,y):im.getpixel((x,y)) for x in range(16) for y in range(16) if im.getpixel((x,y))[3]}
 def tint(x,y):
  r,g,b,a=pixels[x,y];return 0 if r==g==b else 1
 # Native original sprite has gray metal right/top and brown wooden handle left/bottom.
 # Use a few front/back rectangles and only silhouette side faces, not per-pixel six-face cubes.
 spans=[]
 for y in range(16):
  metal=[x for x in range(16) if (x,y) in pixels and tint(x,y)==0];wood=[x for x in range(16) if (x,y) in pixels and tint(x,y)==1]
  boundary=min(metal) if metal else 16
  if not wood:boundary=0
  assert all(x<boundary for x in wood) and all(x>=boundary for x in metal)
  for lo,hi,t in [(0,boundary,1),(boundary,16,0)]:
   if lo==hi or not any((x,y) in pixels for x in range(lo,hi)):continue
   found=next((s for s in spans if s[0]==lo and s[1]==hi and s[3]==y and s[4]==t),None)
   if found:found[3]=y+1
   else:spans.append([lo,hi,y,y+1,t])
 elements=[]
 for lo,hi,top,bottom,t in spans:
  elements.append({'from':[lo,16-bottom,7.5],'to':[hi,16-top,8.5],'shade':False,'faces':{'south':face([lo,top,hi,bottom],t),'north':face([hi,top,lo,bottom],t)}})
 dirs=[('west',-1,0),('east',1,0),('up',0,-1),('down',0,1)]
 for (x,y),color in pixels.items():
  faces={d:face([x+.25,y+.25,x+.75,y+.75],tint(x,y)) for d,dx,dy in dirs if (x+dx,y+dy) not in pixels}
  if faces:elements.append({'from':[x,15-y,7.5],'to':[x+1,16-y,8.5],'shade':False,'faces':faces})
 pose=R/'native-handheld-display.json'
 if pose.exists():display=json.loads(pose.read_text())
 else:
  vanilla=zipfile.ZipFile(R.parent/'gradle-cache/caches/forge_gradle/minecraft_repo/versions/1.20.1/client-extra.jar')
  display=json.loads(vanilla.read('assets/minecraft/models/item/generated.json'))['display'];display.update(json.loads(vanilla.read('assets/minecraft/models/item/handheld.json'))['display'])
  pose.write_text(json.dumps(display,indent=2)+'\n')
 # No generated-marker parent: it would discard explicit elements. Identity GUI view retains a normal icon.
 display['gui']={'rotation':[0,0,0],'translation':[0,0,0],'scale':[1,1,1]}
 model={'gui_light':'front','ambientocclusion':False,'textures':{'particle':'michaels_paxel_art:item/iron_paxel','paxel':'michaels_paxel_art:item/iron_paxel'},'display':display,'elements':elements}
 write('assets/michaels_equipment/models/item/emerald_paxel.json',model);write('pack.mcmeta',META)
 lic=(R/'upstream/LICENSE').read_bytes();(PACK/'MEKANISM-MIT-LICENSE.txt').write_bytes(lic)
 notice="""Paxel art attribution and modification notice

Four unchanged16x16PNG assets from MekanismTools, MIT License.
Copyright(c)2017-2023 Aidan C. Brady; full upstream notice in MEKANISM-MIT-LICENSE.txt.
Repository:https://github.com/mekanism/Mekanism
Commit:96c736241e308a9cf1c73f7dcfa9aa221ea559d3
Paths:src/tools/resources/assets/mekanismtools/textures/item/{iron_paxel.png,diamond_paxel.png,netherite_paxel.png,bronze/paxel.png}

Copper references original bronze art, using the existing copper color handler.
Emerald references the unchanged iron image: an original JSON model assigns
existing green tint only to gray metal faces; brown wood is left untinted.
This is model geometry/material assignment, not bitmap editing. Other item
classes, registries, properties, recipes and the rest of the equipment art are unchanged.
No Mekanism mod or API is installed. Original JSON/model-generation code is MIT.
"""
 (PACK/'ATTRIBUTION.txt').write_text(notice)
 colors={'copper':(245,164,103),'iron':(255,255,255),'diamond':(255,255,255),'netherite':(255,255,255),'emerald':(81,222,136)}
 cards=[]
 for material in ['copper','iron','diamond','netherite','emerald']:
  source=UP/names[material] if material!='emerald' else UP/'iron_paxel.png';img=Image.open(source).convert('RGBA');rects=[]
  for y in range(16):
   for x in range(16):
    rr,gg,bb,aa=img.getpixel((x,y))
    if not aa:continue
    color=colors[material] if material!='emerald' or tint(x,y)==0 else (255,255,255)
    rr,gg,bb=[round(a*b/255) for a,b in zip((rr,gg,bb),color)]
    rects.append(f'<rect x="{x}" y="{y}" width="1" height="1" fill="rgb({rr},{gg},{bb})"/>')
  cards.append(f'<section><svg viewBox="0 0 16 16" width="160" height="160" shape-rendering="crispEdges">'+''.join(rects)+f'</svg><p>{material.title()}</p></section>')
 html='<!doctype html><meta charset="utf-8"><title>Paxel art preview</title><style>body{background:#252a32;color:#eee;font:18px system-ui;margin:32px}main{display:flex;gap:24px}section{text-align:center;background:#343b45;padding:16px;border-radius:8px}small{color:#bbb}</style><h1>Paxel art candidate</h1><main>'+''.join(cards)+'</main><p><small>Code-rendered pixel/tint preview; original PNGs unmodified. Actual Minecraft model bake remains to verify.</small></p>'
 (R/'preview.html').write_text(html)
 files=[]
 for p in sorted(PACK.rglob('*')):
  if p.is_file():files.append({'file':str(p.resolve()),'path':p.relative_to(R/'package').as_posix(),'sha256':sha(p),'bytes':p.stat().st_size,'scope':'client'})
 source=R/'michaels-paxel-art-112-source.zip'
 with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
  z.write(__file__,'prepare_resources.py');z.write(R/'upstream/LICENSE','LICENSE');z.write(R/'upstream/LICENSE','upstream/LICENSE');z.write(pose,pose.name);z.writestr('ATTRIBUTION.txt',notice)
  for p in (R/'upstream').rglob('*.png'):
   if 'advanced-emerald' not in p.parts:z.write(p,p.relative_to(R).as_posix())
  for p in PACK.rglob('*'):
   if p.is_file():z.write(p,'resource-pack/'+p.relative_to(PACK).as_posix())
 report={'staticPassed':True,'nativePassed':False,'approvedForPublication':False,'resourceOnly':True,'noJarChanges':True,'noClassesRegistryStatsRecipesChanges':True,'noBitmapEditingOrNewGeneratedPng':True,'upstreamCommit':'96c736241e308a9cf1c73f7dcfa9aa221ea559d3','license':'MIT','originalPngSha256':before,'allFourCopiedPngByteIdentical':True,'pngDimensions':[16,16],'emeraldHeadOnlyTint':True,'emeraldOpaquePixels':len(pixels),'emeraldModelElements':len(elements),'emeraldQuads':sum(len(e['faces']) for e in elements),'preview':str((R/'preview.html').resolve()),'source':str(source.resolve()),'sourceSha256':sha(source),'files':files,'nativeRequired':['Reloadresourcepack;all5actualmodelsnotmissing','Emeraldheadgreen/woodbrown;copperwarmbronze;other3distinct','Inventory/held/droppedmodeltransformssanity'],'limits':['Previewiscode-rendered,notanativeMinecraftcapture.','Emeraldexplicitmodelmaybedrawnas3Ditemstackratherthangeneratedflatstack;noitembehaviorchanges.']}
 (R/'candidate-artifacts.json').write_text(json.dumps(report,indent=2)+'\n');(R/'input-files.json').write_text(json.dumps({'passed':True,'stageOnly':True,'files':files},indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['staticPassed','nativePassed','emeraldOpaquePixels','emeraldModelElements','emeraldQuads','sourceSha256','preview']},indent=2))
if __name__=='__main__':main()
