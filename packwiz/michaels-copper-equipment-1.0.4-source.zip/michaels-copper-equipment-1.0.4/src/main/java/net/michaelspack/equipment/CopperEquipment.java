package net.michaelspack.equipment;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import java.util.*;
import java.util.function.Supplier;
import net.minecraft.sounds.*;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.*;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.*;

@Mod(CopperEquipment.ID)
public final class CopperEquipment {
 public static final String ID="michaels_equipment";
 public static final DeferredRegister<Item> ITEMS=DeferredRegister.create(ForgeRegistries.ITEMS,ID);
 public static final Map<String,RegistryObject<Item>> ALL=new LinkedHashMap<>();
 public static final Tier COPPER=new ForgeTier(1,190,5.0F,1.5F,14,BlockTags.NEEDS_STONE_TOOL,()->Ingredient.of(Items.COPPER_INGOT));
 public static final Tier EMERALD=new ForgeTier(3,1800,8.5F,3.5F,14,net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.BLOCK,new net.minecraft.resources.ResourceLocation(ID,"needs_emerald_tool")),()->Ingredient.of(Items.EMERALD));
 public static final ArmorMaterial ARMOR=new ArmorMaterial(){
  public int getDurabilityForType(ArmorItem.Type t){return switch(t){case HELMET->143;case CHESTPLATE->208;case LEGGINGS->195;case BOOTS->169;};}
  public int getDefenseForType(ArmorItem.Type t){return switch(t){case HELMET,BOOTS->2;case CHESTPLATE->5;case LEGGINGS->4;};}
  public int getEnchantmentValue(){return 12;}
  public SoundEvent getEquipSound(){return SoundEvents.ARMOR_EQUIP_IRON;}
  public Ingredient getRepairIngredient(){return Ingredient.of(Items.COPPER_INGOT);}
  public String getName(){return ID+":copper";}
  public float getToughness(){return 0;}
  public float getKnockbackResistance(){return 0;}
 };
 static Item.Properties props(){return new Item.Properties();}
 static void add(String name,Supplier<Item> make){ALL.put(name,ITEMS.register(name,make));}
 static void weapon(String name,int damage,float speed,double reach){add("copper_"+name,()->new ReachSword(damage,speed,reach));}
 static void emeraldWeapon(String name,int damage,float speed,double reach){add("emerald_"+name,()->new ReachSword(EMERALD,damage,speed,reach));}
 static {
  add("copper_helmet",()->new CopperArmorItem(ArmorItem.Type.HELMET));
  add("copper_chestplate",()->new CopperArmorItem(ArmorItem.Type.CHESTPLATE));
  add("copper_leggings",()->new CopperArmorItem(ArmorItem.Type.LEGGINGS));
  add("copper_boots",()->new CopperArmorItem(ArmorItem.Type.BOOTS));
  add("copper_sword",()->new SwordItem(COPPER,3,-2.4F,props()));
  add("copper_pickaxe",()->new PickaxeItem(COPPER,1,-2.8F,props()));
  add("copper_axe",()->new AxeItem(COPPER,6,-3.15F,props()));
  add("copper_shovel",()->new ShovelItem(COPPER,1.5F,-3F,props()));
  add("copper_hoe",()->new HoeItem(COPPER,-1,-1.5F,props()));
  weapon("cutlass",3,-2.0F,0);weapon("rapier",2,-1.8F,0);weapon("glaive",3,-2.6F,0);
  weapon("warglaive",3,-2.2F,0);weapon("spear",3,-2.7F,0);weapon("sai",0,-1.5F,0);
  weapon("katana",3,-2.0F,0);weapon("claymore",5,-2.8F,0);weapon("longsword",3,-2.4F,0);
  weapon("twinblade",3,-2.0F,0);weapon("greathammer",7,-3.2F,0);weapon("greataxe",6,-3.1F,0);
  weapon("chakram",2,-3.0F,0);weapon("scythe",4,-2.7F,0);weapon("halberd",6,-2.8F,0);
  add("copper_paxel",()->new Paxel(COPPER,false));add("iron_paxel",()->new Paxel(Tiers.IRON,false));
  add("diamond_paxel",()->new Paxel(Tiers.DIAMOND,false));add("netherite_paxel",()->new Paxel(Tiers.NETHERITE,true));
  add("emerald_sword",()->new SwordItem(EMERALD,3,-2.4F,props()));
  add("emerald_pickaxe",()->new PickaxeItem(EMERALD,1,-2.8F,props()));
  add("emerald_axe",()->new AxeItem(EMERALD,5,-3.1F,props()));
  add("emerald_shovel",()->new ShovelItem(EMERALD,1.5F,-3F,props()));
  add("emerald_hoe",()->new HoeItem(EMERALD,-2,-1F,props()));
  emeraldWeapon("cutlass",3,-2.0F,0);emeraldWeapon("rapier",2,-1.8F,0);emeraldWeapon("glaive",3,-2.6F,0);
  emeraldWeapon("warglaive",3,-2.2F,0);emeraldWeapon("spear",3,-2.7F,0);emeraldWeapon("sai",0,-1.5F,0);
  emeraldWeapon("katana",3,-2.0F,0);emeraldWeapon("claymore",5,-2.8F,0);emeraldWeapon("longsword",3,-2.4F,0);
  emeraldWeapon("twinblade",3,-2.0F,0);emeraldWeapon("greathammer",7,-3.2F,0);emeraldWeapon("greataxe",6,-3.1F,0);
  emeraldWeapon("chakram",2,-3.0F,0);emeraldWeapon("scythe",4,-2.7F,0);emeraldWeapon("halberd",6,-2.8F,0);
  add("emerald_paxel",()->new Paxel(EMERALD,false));
 }
 public CopperEquipment(){
  TierSortingRegistry.registerTier(EMERALD,new net.minecraft.resources.ResourceLocation(ID,"emerald"),List.of(Tiers.DIAMOND),List.of(Tiers.NETHERITE));
  var bus=FMLJavaModLoadingContext.get().getModEventBus();ITEMS.register(bus);bus.addListener(this::creative);QualityModule.init(bus);
 }
 private void creative(BuildCreativeModeTabContentsEvent e){
  if(e.getTabKey()==CreativeModeTabs.COMBAT)ALL.forEach((n,i)->{if(!n.endsWith("paxel")&&!Set.of("copper_pickaxe","copper_shovel","copper_hoe","emerald_pickaxe","emerald_shovel","emerald_hoe").contains(n))e.accept(i);});
  if(e.getTabKey()==CreativeModeTabs.TOOLS_AND_UTILITIES)ALL.forEach((n,i)->{if(n.endsWith("paxel")||Set.of("copper_pickaxe","copper_axe","copper_shovel","copper_hoe","emerald_pickaxe","emerald_axe","emerald_shovel","emerald_hoe").contains(n))e.accept(i);});
 }
 public static final class ReachSword extends SwordItem {
  private static final UUID REACH_ID=UUID.fromString("de6670cd-42ac-4164-b794-872e809c1233");
  private final Multimap<Attribute,AttributeModifier> modifiers;
  ReachSword(int damage,float speed,double reach){super(COPPER,damage,speed,props());var b=ImmutableMultimap.<Attribute,AttributeModifier>builder();b.putAll(super.getDefaultAttributeModifiers(EquipmentSlot.MAINHAND));if(reach>0)b.put(ForgeMod.ENTITY_REACH.get(),new AttributeModifier(REACH_ID,"Copper weapon reach",reach,AttributeModifier.Operation.ADDITION));modifiers=b.build();}
  ReachSword(Tier tier,int damage,float speed,double reach){super(tier,damage,speed,props());var b=ImmutableMultimap.<Attribute,AttributeModifier>builder();b.putAll(super.getDefaultAttributeModifiers(EquipmentSlot.MAINHAND));if(reach>0)b.put(ForgeMod.ENTITY_REACH.get(),new AttributeModifier(REACH_ID,"Emerald weapon reach",reach,AttributeModifier.Operation.ADDITION));modifiers=b.build();}
  @Override public Multimap<Attribute,AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot){return slot==EquipmentSlot.MAINHAND?modifiers:super.getDefaultAttributeModifiers(slot);}
 }
 public static final class Paxel extends PickaxeItem {
  private final AxeItem axe;
  private final ShovelItem shovel;
  Paxel(Tier t,boolean fireproof){super(t,2,-2.9F,fireproof?props().durability(t.getUses()*2).fireResistant():props().durability(t.getUses()*2));axe=(AxeItem)Items.IRON_AXE;shovel=(ShovelItem)Items.IRON_SHOVEL;}
  private boolean effective(BlockState s){return s.is(BlockTags.MINEABLE_WITH_PICKAXE)||s.is(BlockTags.MINEABLE_WITH_AXE)||s.is(BlockTags.MINEABLE_WITH_SHOVEL);}
  @Override public float getDestroySpeed(ItemStack s,BlockState state){return effective(state)?getTier().getSpeed():1F;}
  @Override public boolean isCorrectToolForDrops(BlockState s){return effective(s)&&TierSortingRegistry.isCorrectTierForDrops(getTier(),s);}
  @Override public boolean isCorrectToolForDrops(ItemStack stack,BlockState s){return isCorrectToolForDrops(s);}
  @Override public boolean canPerformAction(ItemStack s,ToolAction action){return ToolActions.DEFAULT_PICKAXE_ACTIONS.contains(action)||ToolActions.DEFAULT_AXE_ACTIONS.contains(action)||ToolActions.DEFAULT_SHOVEL_ACTIONS.contains(action);}
  @Override public InteractionResult useOn(UseOnContext c){InteractionResult r=axe.useOn(c);return r.consumesAction()?r:shovel.useOn(c);}
 }
}
