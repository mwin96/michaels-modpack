package net.michaelspack.menu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

/** Two static textures, only drawn on TitleScreen; nothing ticks or renders in a world. */
public final class MenuArtwork {
    public static final ResourceLocation BACKGROUND = new ResourceLocation("michaels_menu", "textures/gui/background.jpg");
    public static final ResourceLocation TITLE = new ResourceLocation("michaels_menu", "textures/gui/title.png");
    private static final int BACKGROUND_WIDTH = 2752;
    private static final int BACKGROUND_HEIGHT = 1536;
    private static final int TITLE_WIDTH = 2103;
    private static final int TITLE_HEIGHT = 748;

    private MenuArtwork() {}

    public static void draw(GuiGraphics g, int width, int height, float alpha) {
        // Cover the window without stretching the original illustration.
        float fit = Math.max((float)width / BACKGROUND_WIDTH, (float)height / BACKGROUND_HEIGHT);
        int imageWidth = (int)Math.ceil(BACKGROUND_WIDTH * fit);
        int imageHeight = (int)Math.ceil(BACKGROUND_HEIGHT * fit);
        g.setColor(1, 1, 1, 1);
        g.blit(BACKGROUND, (width-imageWidth)/2, (height-imageHeight)/2,
                imageWidth, imageHeight, 0F, 0F, BACKGROUND_WIDTH, BACKGROUND_HEIGHT,
                BACKGROUND_WIDTH, BACKGROUND_HEIGHT);
        // A restrained shade makes the ordinary buttons/footer readable at every size.
        g.fill(0, 0, width, height, 0x1C080810);

        int buttonTop = height/4+48;
        int titleTop = Math.max(7, Math.min(20, height/18));
        int titleWidth = Math.min(310, width-32);
        int titleHeight = Math.round((float)titleWidth * TITLE_HEIGHT / TITLE_WIDTH);
        int availableHeight = buttonTop-titleTop-17;
        if (titleHeight > availableHeight) {
            titleHeight = Math.max(1, availableHeight);
            titleWidth = Math.round((float)titleHeight * TITLE_WIDTH/TITLE_HEIGHT);
        }
        g.setColor(1, 1, 1, alpha);
        g.blit(TITLE, (width-titleWidth)/2, titleTop, titleWidth, titleHeight,
                0F, 0F, TITLE_WIDTH, TITLE_HEIGHT, TITLE_WIDTH, TITLE_HEIGHT);
        g.setColor(1, 1, 1, 1);
        g.drawCenteredString(Minecraft.getInstance().font, "Goal: Reach the End and defeat the Ender Dragon.",
                width/2, buttonTop-12, 0xFFE4C991);
    }
}
