# Michael's Client Fixes 1.0.1

Forge1.20.1/47.4.28 client-only optional utility, GPL-3.0-or-later. Build with Java17 and `gradlew --offline build`.

The original SCP pickup-prompt/item-outline correction remains unchanged. Vanilla automatic pickup remains enabled.

Jade's existing target health element renders as one compact red current/max bar. It uses Jade's native target and health values, adding no entity scan or packet. A one-time startup migration enables minecraft:entity_health using Jade's own configuration API; later player choices are respected.

Zombie visuals in CMMRP_Release_1.0_NormalAnimals.zip and MyMonsterGirls.zip fall through to vanilla. Both direct resource lookup and resource enumeration omit only matching zombie/husk/drowned/zombie-villager/zombified-piglin visual paths in those two ZIPs. Original archives are never altered or copied. Other mobs, sounds, packs, textures and models remain unchanged. No Minecraft assets are redistributed.

## Version1.0.3

Client marker1.0.3 for the1.0.7 content update. Existing Auto-only GUI scaling,6GB one-time migration and opt-outs, sky defaults, health UI and DH bridge remain. A JDK/ImageIO-only early hook creates98 resized textures locally from SHA256-pinned installed original mods, then selects the generated personal-use resource pack once. No third-party image data is bundled in this source or mod. First launch tested about9seconds; cached run about0.09seconds on the test PC. The resize uses high-quality bicubic interpolation, preserves aspect ratio and transparency, and excludes animated strips/PBR maps in the pinned recipe. Later resource-pack opt-outs remain respected. Full comparative RAM/FPS benchmarking was explicitly waived by the user.

Rapid-flash choices are applied once before Forge config load: mbackrooms/JumpsScares Settings.flashEnabled=false and PHOTOSENSITIVITY WARNING !!!.photosensitivityWarningDisplayed=true. Only those Boolean values change; comments/CRLF/other keys and later deliberate changes are respected. A narrowly scoped optional Physics GUI resource-stream bridge reads selected generated parallax PNGs through Minecraft's ResourceManager; it leaves shader files and other custom resources native and falls back safely when unavailable.


UI1.0.4 cloud hotfix: only DH's enableCloudRendering is defaulted off once. The first safe client tick updates the native ConfigEntry without saving unrelated DH settings, then atomically changes the matching TOML key and writes config/michaels-dh-clouds-108.done. Later manual cloud choices are respected. Vanilla clouds, beacons, generic rendering, other DH options, existing textures/GUI/health/lightmap logic remain unchanged. DH is optional; absence consumes no marker. No shaders or terrain code is altered.
