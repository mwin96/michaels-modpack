"""Derive a bounded shader-only successor; never writes installed files or sidecars."""
from pathlib import Path
import zipfile, copy, hashlib, json, datetime, difflib

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'candidate-haze35-outdoor/MakeUp-UltraFast-9.6.zip'
EXPECTED = '63fdcdc3d41cc6c5b819d27d0b02fb4eee654e9e88708c77f3506f03749f30ab'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    assert sha(BASE.read_bytes()) == EXPECTED
    zin = zipfile.ZipFile(BASE)
    changed = {}
    patches = []

    def edit(name, old, new):
        before = changed.get(name, zin.read(name)).decode()
        assert before.count(old) == 1, (name, old)
        changed[name] = before.replace(old, new).encode()

    edit('shaders/lib/config.glsl', '#define AA_TYPE 2 //',
         '// Michael\'s Modpack: spatial edge smoothing only when temporal AA is off.\n'
         '#define SMOOTH_EDGES // Reuse existing FXAA; no temporal history or extra framebuffer.\n\n'
         '#define AA_TYPE 2 //')
    edit('shaders/shaders.properties',
         'screen.POST_SCREEN = AA_TYPE SELECTIVE_TAA_V2 <empty> <empty>',
         'screen.POST_SCREEN = AA_TYPE SELECTIVE_TAA_V2 SMOOTH_EDGES <empty>')
    lang = 'shaders/lang/en_US.lang'
    changed[lang] = zin.read(lang) + b'\n# Michael\'s Modpack optional spatial filter\noption.SMOOTH_EDGES=Smooth Edges\noption.SMOOTH_EDGES.comment=Lightweight FXAA when Antialiasing is Off. Does not enable temporal history; existing TAA settings stay unchanged.\n'

    final = 'shaders/common/final_fragment.glsl'
    edit(final, '#if AA_TYPE == 3 || defined IMAGE_SHARPENING',
         '#if AA_TYPE == 3 || defined IMAGE_SHARPENING || (AA_TYPE == 0 && defined SMOOTH_EDGES)')
    edit(final, '#if AA_TYPE == 3\n    // #include',
         '#if AA_TYPE == 3 || (AA_TYPE == 0 && defined SMOOTH_EDGES)\n    // #include')
    edit(final, '        #if AA_TYPE == 3 && !defined DOF',
         '        // Spatial-only path uses the existing color input and final framebuffer.\n'
         '        #if AA_TYPE == 0 && defined SMOOTH_EDGES && !defined DOF\n'
         '            blockColor = fxaa311(blockColor, 5);\n'
         '        #endif\n\n'
         '        #if AA_TYPE == 3 && !defined DOF')

    tint = '''tintColor = gl_Color;

// Michael's Modpack: a restrained grass tint, preserving native biome variation.
// Shared grass-like IDs also include flowers; untinted/neutral flowers stay exact.
#if defined FOLIAGE_V && !defined NETHER && !defined THE_END
    bool michaelsGrassTint =
        (mc_Entity.x == ENTITY_LOWERGRASS || mc_Entity.x == ENTITY_UPPERGRASS || mc_Entity.x == ENTITY_SMALLGRASS)
        && tintColor.g > max(tintColor.r, tintColor.b);
    if(michaelsGrassTint) {
        float michaelsGrassLuma = dot(tintColor.rgb, vec3(0.2126, 0.7152, 0.0722));
        tintColor.rgb = mix(vec3(michaelsGrassLuma), tintColor.rgb, 0.93) * 0.94;
    }
#endif'''
    edit('shaders/src/light_vertex.glsl', 'tintColor = gl_Color;', tint)

    notice = zin.read('MICHAELS-MODIFICATION-NOTICE.txt').decode() + '''

Additional optional Smooth Edges and restrained grass change (same LGPL-3.0-or-later):
The existing final-pass fxaa311 is also available when AA_TYPE == 0, controlled by
the default-on SMOOTH_EDGES shader option. AA_TYPE 1 is upstream temporal denoise,
not FXAA: it and TAA/custom nonzero AA settings are deliberately unchanged.
Native DoF/chromatic-aberration exclusions remain. No history, sampler, framebuffer,
texture, shader program, geometry, alpha threshold or resource-pack asset was added.
Only green biome-tinted native grass-like vertex IDs receive a 6% darker and 7%
less saturated RGB tint. Neutral shared-ID flowers and all other blocks stay exact.
Sky, sun, moon, clouds, water programs and global color scheme remain unchanged.
The preceding foliage DH-transition and outdoor haze changes are retained exactly.
This is a visual candidate; no FPS/RAM benefit or exact shimmer elimination is claimed.
'''
    changed['MICHAELS-MODIFICATION-NOTICE.txt'] = notice.encode()

    for name, data in changed.items():
        patches.extend(difflib.unified_diff(zin.read(name).decode().splitlines(True),
                     data.decode().splitlines(True), fromfile='haze35-outdoor/'+name,
                     tofile='smooth-grass/'+name))
    patch = ''.join(patches)
    (ROOT/'smooth-grass.patch').write_text(patch)

    # RGB invariants: native-biome luma scales by exactly .94; alpha is never assigned.
    cases = 0
    for r in range(17):
        for g in range(17):
            for b in range(17):
                color = [r/16, g/16, b/16]
                luma = sum(x*w for x,w in zip(color, [.2126,.7152,.0722]))
                if g > max(r,b):
                    out = [(luma*.07+x*.93)*.94 for x in color]
                    assert all(0 <= x <= 1 for x in out)
                    assert abs(sum(x*w for x,w in zip(out,[.2126,.7152,.0722]))-luma*.94)<1e-12
                    assert out[1] > max(out[0],out[2])
                    # Pairwise chroma differences retain ordering and scale .93*.94.
                    for a,c in [(0,1),(0,2),(1,2)]:
                        assert abs((out[a]-out[c])-(color[a]-color[c])*.93*.94)<1e-12
                cases += 1
    assert 'tintColor.a' not in tint and 'gl_Position' not in tint
    assert zin.read('shaders/lib/fxaa.glsl')
    assert all(n not in changed for n in ['shaders/common/composite2_fragment.glsl',
        'shaders/common/solid_dh_water_fragment.glsl','shaders/lib/color_utils.glsl',
        'shaders/src/fog_vertex.glsl','shaders/src/fog_vertex_dh.glsl'])

    outdir = ROOT/'candidate-smooth-grass'
    outdir.mkdir(exist_ok=True)
    artifacts = []
    for name in ['MakeUp-UltraFast-9.6.zip','MakeUp-UltraFast-9.6-Enhanced.zip']:
        path = outdir/name
        with zipfile.ZipFile(path,'w') as zout:
            for info in zin.infolist():
                zout.writestr(copy.copy(info), changed.get(info.filename,zin.read(info.filename)))
        with zipfile.ZipFile(path) as check:
            delta = sorted(n for n in zin.namelist() if zin.read(n)!=check.read(n))
            assert delta == sorted(changed)
            assert check.namelist() == zin.namelist()
        data = path.read_bytes()
        artifacts.append({'file':str(path.resolve()),'fileName':name,'bytes':len(data),
            'sha256':sha(data),'sha512':hashlib.sha512(data).hexdigest(),
            'deltaFrom63fd':delta})
    assert artifacts[0]['sha256']==artifacts[1]['sha256']

    source = ROOT/'michaels-makeup-smooth-grass-112-source.zip'
    with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as zout:
        zout.write(ROOT/'michaels-makeup-foliage-haze35-outdoor-112-source.zip','haze35-outdoor-complete-source.zip')
        zout.write(BASE,'input/MakeUp-UltraFast-9.6.zip')
        zout.write(outdir/'MakeUp-UltraFast-9.6.zip','modified/MakeUp-UltraFast-9.6.zip')
        zout.write(__file__,'prepare_smooth_grass_candidate.py')
        zout.writestr('smooth-grass.patch',patch)
        zout.writestr('LICENSE',zin.read('LICENSE'))
        zout.writestr('COPYING.GPL-3.0.txt',zin.read('COPYING.GPL-3.0.txt'))
        zout.writestr('MICHAELS-MODIFICATION-NOTICE.txt',notice)
    report = {'staticPassed':True,'nativePassed':False,'approvedForPublication':False,
        'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'baseShaderSha256':EXPECTED,'artifacts':artifacts,'source':str(source.resolve()),
        'sourceSha256':sha(source.read_bytes()),'colorGoldenCasesPassed':cases,
        'smoothEdges':{'shaderOption':'SMOOTH_EDGES','displayName':'Smooth Edges',
            'defaultEnabled':True,'onlyWhenAAType':0,'existingFunction':'fxaa311(blockColor,5)',
            'upstreamAA1IsTemporalDenoise':True,'existingNonzeroAAPathsUnchanged':True,
            'noNewHistoryOrFramebuffer':True,'upstreamDOFAndChromaExclusionsPreserved':True,
            'costEstimate':'Existing final-pass FXAA adds four neighbor samples away from edges and up to seventeen at edges; no extra buffer. Not benchmarked.'},
        'grass':{'brightnessMultiplier':.94,'saturationMultiplier':.93,
            'nativeEntityIDs':[10031,10175,10176],'onlyGreenBiomeTint':True,
            'alphaGeometryHeightDensityUnchanged':True,'neutralFlowersUnchanged':True},
        'hazeFoliageSourceRetainedExactly':True,'playerSidecarsWritten':False,
        'shaderNamesPreserved':True,'normalEnhancedZipBytesIdentical':True,
        'remainingGate':'Root native Normal/Enhanced compile and grass/horizon visual check',
        'limits':['Not temporal supersampling: spatial FXAA softens edges but cannot eliminate every motion shimmer.',
            'No measured FPS/RAM claim.','No world, height, density or player-option migration.']}
    (ROOT/'candidate-smooth-grass-artifacts.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'staticPassed':True,'nativePassed':False,'shaderSha256':artifacts[0]['sha256'],
        'sourceSha256':report['sourceSha256'],'colorGoldenCasesPassed':cases},indent=2))

if __name__=='__main__':main()
