# Michael's Client Fixes 1.0.0

Optional Forge 1.20.1 client-only utility, GPL-3.0-or-later. No content, networking, server installation, or mandatory client/server handshake.

SCP Additions 3.0.7 invokes its manual pickup prompt despite disabled inventory/interactions/HUD modules. This cancels only PickupPromptClient.clientTick, render, and renderWorldOutline. It removes the hand prompt, its dropped-item outline, and its manual right-click request path. It does not modify vanilla pickup, the rest of the HUD, chat, item drops, SCP entities, or inventory behavior.

Build with Java 17 and `gradlew --offline build`. Keep the original core modpack immutable; add this jar only to the client profile. Runtime validation evidence is recorded separately.
