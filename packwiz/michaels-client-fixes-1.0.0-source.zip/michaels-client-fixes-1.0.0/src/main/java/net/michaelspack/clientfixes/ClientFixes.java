package net.michaelspack.clientfixes;

import net.minecraftforge.fml.common.Mod;

/** Optional client UI correction; no registry content or network channels. */
@Mod("michaels_client_fixes")
public final class ClientFixes {
    public ClientFixes() {}
}
