from pathlib import Path
from zipfile import ZipFile
import sys

source, destination = map(Path, sys.argv[1:3])
assert source.resolve() != destination.resolve()
with ZipFile(source) as original, ZipFile(destination, 'w') as output:
    for item in original.infolist():
        if item.filename == 'assets/minecraft/optifine/cem/bee.jem' or item.filename.startswith((
            'assets/minecraft/textures/entity/bee/', 'assets/minecraft/optifine/anim/blinks/bee/',
        )):
            continue
        output.writestr(item, original.read(item))
