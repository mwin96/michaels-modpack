"""GPL-3.0-only. Rebuild CMM variant without copying Minecraft assets."""
from pathlib import Path
import hashlib, json, re, zipfile

HERE = Path(__file__).resolve().parent
SOURCE = next((HERE.parent / 'downloads').glob('CMMRP_Release_1.0_*.zip'))
DEST = HERE / 'CMMRP_Release_1.0_NormalAnimals.zip'
ANIMALS = r'(?:bat|chicken|cow|pig|sheep)'
def remove(name):
    # Exact species boundaries preserve piglins and mooshrooms.
    return bool(re.fullmatch(r'assets/minecraft/optifine/cem/(?:bat|chicken|cow|pig|pig_saddle|sheep|sheep_wool)\.jem', name)
        or re.fullmatch(r'assets/minecraft/optifine/(?:anim/blinks|random/entity)/' + ANIMALS + r'/.*', name)
        or name in {'assets/minecraft/textures/entity/bat.png','assets/minecraft/textures/entity/chicken.png','assets/minecraft/textures/entity/cow/cow.png'}
        or re.fullmatch(r'assets/minecraft/textures/entity/(?:pig|sheep)/.*', name))

with zipfile.ZipFile(SOURCE) as src, zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED) as dst:
    removed=[]; kept=[]
    for item in src.infolist():
        if remove(item.filename):
            removed.append(item.filename)
        else:
            dst.writestr(item,src.read(item.filename)); kept.append(item.filename)
    for name in ['LICENSE-GPL-3.0.txt','MODIFICATION-NOTICE.txt']:
        info=zipfile.ZipInfo(name,(2026,11,5,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        dst.writestr(info,(HERE/name).read_bytes())
with zipfile.ZipFile(SOURCE) as src, zipfile.ZipFile(DEST) as dst:
    assert all(src.read(n)==dst.read(n) for n in kept)
    assert not any(remove(n) for n in dst.namelist())
report={'source':SOURCE.name,'sourceSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'variant':DEST.name,'variantSha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),
        'removed':removed,'unchangedEntries':len(kept),'allRetainedEntriesByteIdentical':True}
(HERE/'variant-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='removed'},indent=2))
