Build the previous derivative with build_variant.py, then run finish_bees.py on that output.
