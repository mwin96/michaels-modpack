# Michael's Copper Equipment 1.0.1

Original GPL-3.0-or-later Forge 1.20.1 shared mod. Install the same JAR on client and server. Forge 47.4.x is required. Clients also need the pack's existing SimplySwords 1.70.2 artwork provider; the server has no new required art dependency.

Adds 49 items: the original 28 copper armor/tools/shaped weapons and four-material paxels, plus 21 emerald items: sword, pickaxe, axe, shovel, hoe, fifteen matching weapon shapes and an emerald paxel. Emerald has harvest level 2, speed 7, 1,000 uses, +2.5 tier attack bonus, and emerald repair. Its paxel uses the family's double durability (2,000). Emerald can harvest diamond ore but cannot harvest obsidian. No emerald armor, new skill system or progression bypass is included. Original item IDs, recipes, copper stats and the quality module are preserved.

The ordinary vanilla minecraft:bundle now has a crafting-table recipe using six rabbit hides and two string. Its existing native 1.20.1 item requires no experimental world flag or world regeneration. Focused private native checks confirmed crafting and inserting/extracting eight cobblestone.

Copper and emerald item models reference installed Minecraft iron and SimplySwords iron artwork at runtime, tinted copper F5A467 or emerald 51DE88. The two greathammers use original five-cuboid geometry referencing vanilla iron-block and stripped-spruce textures. Copper armor keeps its original armor values and posed geometry, while rendering installed vanilla iron armor textures through a copper tint. No upstream PNG is copied or edited. The old original texture files remain for compatibility; paxels reference the original iron-paxel sprite with material tint.

The quality module remains unchanged: Common/Rare/Epic/Legendary 70/20/8/2; non-common damage/mining bonuses 10/20/30 percent and armor additions 0.5/1/1.5 per piece. Existing quality OpenLoader overrides remain required and unchanged. Ordinary crafting stays ungraded.

Build with JDK17 and the included Gradle8.8 wrapper: gradlew.bat jar. Project code is GPL3-or-later; copied unmodified Gradle wrapper tooling retains its own Apache2 LICENSE/NOTICE. The former 1.0.0 procedural art generator is omitted from this source release; normal Gradle builds consume the included model JSON and original compatibility assets.

Validation is focused: actual crafting result clicks for all21 emerald recipes plus bundle, emerald anvil repair, tier/harvest limits, vanilla bundle storage, old28 registry/copper-stat checks, and separately a short private client model/tint/armor rendering smoke. It is not a repeated loot/FPS/RAM benchmark.
