import net.michaelspack.clientfixes.SkyPackDefaults;
import java.nio.file.*;
import java.util.*;
public final class SkyDefaultsTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  Path game=Files.createTempDirectory("sky-defaults-106-");Path opts=game.resolve("options.txt");
  List<String> prior=List.of("vanilla","mod_resources","file/Custom λ.zip","file/OldPack.zip");
  String original="guiScale:3\r\nrenderDistance:12\r\nresourcePacks:[\"vanilla\",\"mod_resources\",\"file/Custom λ.zip\",\"file/OldPack.zip\"]\r\nincompatibleResourcePacks:[\"file/Melody.zip\"]\r\nmaxFps:47\r\n";
  Files.writeString(opts,original);check(SkyPackDefaults.apply(opts,prior)==prior);check(Files.readString(opts).equals(original));
  Path packs=game.resolve("resourcepacks");Files.createDirectories(packs);
  for(String id:SkyPackDefaults.IDS)Files.write(packs.resolve(id.substring(5)),new byte[]{1});
  List<String> selected=SkyPackDefaults.apply(opts,prior);
  check(selected.subList(0,prior.size()).equals(prior));check(selected.subList(prior.size(),selected.size()).equals(SkyPackDefaults.IDS));
  String after=Files.readString(opts);check(after.startsWith("guiScale:3\r\nrenderDistance:12\r\n"));
  check(after.endsWith("incompatibleResourcePacks:[\"file/Melody.zip\"]\r\nmaxFps:47\r\n"));
  check(Files.isRegularFile(game.resolve("config/michaels-skies-defaults-106.enabled")));
  // A deliberate later disable is retained: the migration marker blocks re-appending/reloading.
  Files.writeString(opts,original);check(SkyPackDefaults.apply(opts,prior)==prior);check(Files.readString(opts).equals(original));
  check(SkyPackDefaults.applications==1);
  List<String> reordered=SkyPackDefaults.ordered(List.of(SkyPackDefaults.IDS.get(1),"keep",SkyPackDefaults.IDS.get(0),"custom"));
  check(reordered.equals(List.of("keep","custom",SkyPackDefaults.IDS.get(0),SkyPackDefaults.IDS.get(1))));
  for(String invalid:List.of("resourcePacks:invalid\n","resourcePacks:[]\nresourcePacks:[]\n")){
   try{SkyPackDefaults.patchOptions(invalid,selected);throw new AssertionError("Invalid options accepted");}catch(IllegalArgumentException|com.google.gson.JsonParseException expected){}
  }
  System.out.println("PASS pre-file guard, initial selection/order, exact other-options/CRLF preservation, one-time user optout, invalid JSON/duplicates");
 }
}
