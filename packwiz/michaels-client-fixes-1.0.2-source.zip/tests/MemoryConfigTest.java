import net.michaelspack.clientfixes.memory.MemoryConfig;
public class MemoryConfigTest {
 static void check(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args){
  String source="[General]\r\nname=Unicode \u03bb\r\nMaxMemAlloc=4096\r\nMinMemAlloc=1024\r\nOverrideMemory=false\r\nnotes=keep=this\r\n[Other]\r\nMaxMemAlloc=8192\r\n";
  String expected="[General]\r\nname=Unicode \u03bb\r\nMaxMemAlloc=6144\r\nMinMemAlloc=1024\r\nOverrideMemory=true\r\nnotes=keep=this\r\n[Other]\r\nMaxMemAlloc=8192\r\n";
  check(MemoryConfig.apply(source).equals(expected));check(MemoryConfig.apply(expected).equals(expected));
  for(int max:new int[]{3584,4096,5120,6144,8192}){
   String input="[General]\nMaxMemAlloc="+max+"\nMinMemAlloc=512\nOverrideMemory=true\ncustom=unchanged\n";
   check(MemoryConfig.apply(input).equals("[General]\nMaxMemAlloc=6144\nMinMemAlloc=512\nOverrideMemory=true\ncustom=unchanged\n"));
  }
  check(MemoryConfig.apply("[General]\nMinMemAlloc=8192\nMaxMemAlloc=8192\n").contains("MinMemAlloc=6144"));
  check(MemoryConfig.apply("[General]\nname=pack\n").contains("MinMemAlloc=1024"));
  for(String bad:new String[]{"[Other]\nMaxMemAlloc=4\n","[General]\nMaxMemAlloc=1\nMaxMemAlloc=2\n","[General]\nMinMemAlloc=512\nMinMemAlloc=8192\n","[General]\nMinMemAlloc=bad\n","[General]\n[General]\n"}){
   try{MemoryConfig.apply(bad);throw new AssertionError("Invalid configuration accepted");}catch(IllegalArgumentException correct){}
  }
  System.out.println("PASS exact CRLF/Unicode preservation, idempotence, five authorized caps, min clamp/default, five invalid-input guards");
 }
}
