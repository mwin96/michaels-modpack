# Michael's Client Fixes 1.0.1

Forge1.20.1/47.4.28 client-only optional utility, GPL-3.0-or-later. Build with Java17 and `gradlew --offline build`.

The original SCP pickup-prompt/item-outline correction remains unchanged. Vanilla automatic pickup remains enabled.

Jade's existing target health element renders as one compact red current/max bar. It uses Jade's native target and health values, adding no entity scan or packet. A one-time startup migration enables minecraft:entity_health using Jade's own configuration API; later player choices are respected.

Zombie visuals in CMMRP_Release_1.0_NormalAnimals.zip and MyMonsterGirls.zip fall through to vanilla. Both direct resource lookup and resource enumeration omit only matching zombie/husk/drowned/zombie-villager/zombified-piglin visual paths in those two ZIPs. Original archives are never altered or copied. Other mobs, sounds, packs, textures and models remain unchanged. No Minecraft assets are redistributed.
