package net.michaelspack.clientfixes;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Enable this newly requested default once, then respect later player choices. */
public final class ClientDefaults {
    private static final Logger LOG=LoggerFactory.getLogger("michaels_client_fixes");
    private static final Path MARKER=FMLPaths.CONFIGDIR.get().resolve("michaels-client-fixes-health-101.enabled");
    private boolean complete=Files.exists(MARKER);
    private int attempts;
    public static void install() { MinecraftForge.EVENT_BUS.register(new ClientDefaults()); }
    @SubscribeEvent public void tick(TickEvent.ClientTickEvent event) {
        if (complete || event.phase!=TickEvent.Phase.END || !(Minecraft.getInstance().screen instanceof TitleScreen)) return;
        if (++attempts>100) { complete=true; LOG.warn("Jade health default could not be applied; existing settings retained."); return; }
        try {
            Class<?> type=Class.forName("snownee.jade.impl.config.PluginConfig");
            Object config=type.getField("INSTANCE").get(null);
            var key=new ResourceLocation("minecraft","entity_health");
            if (!(Boolean)type.getMethod("containsKey",ResourceLocation.class).invoke(config,key)) return;
            type.getMethod("set",ResourceLocation.class,Object.class).invoke(config,key,Boolean.TRUE);
            type.getMethod("save").invoke(config);
            Files.createDirectories(MARKER.getParent());
            Files.writeString(MARKER,"Enabled mob health once for update1.0.4. Later Jade choices remain yours.\n");
            complete=true;
        } catch (ClassNotFoundException absent) { complete=true; }
        catch (ReflectiveOperationException | java.io.IOException failed) { complete=true; LOG.warn("Could not save Jade health default; existing settings retained.",failed); }
    }
}
