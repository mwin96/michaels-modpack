# Michael's five-day Blood Moon data for gameplay 1.0.12

Original MIT-licensed data pack for the unmodified Enhanced Celestials 2 Core 1.0.3.4.
The existing weekly filenames are retained so automatic updates replace the managed
pack instead of installing two competing calendars.

Only the Overworld calendar and Blood Moon probability settings change: exclusive
minimum 4 days, maximum 5 days, 40-day scheduler year, minimum 4 nights and initial
native moon phase 4. With the pinned native scheduler, intended nights are zero-
indexed 4,9,14,...,39,44,... . Forty is the least common multiple of five and the
native eight moon phases. All other event data is retained byte for byte, including
native sleep prevention, the 1.5 monster multiplier and disabled other lunar events.
The separate server guard JAR, its wooden-door rules and local admission cap of 40
are unchanged.

Existing-world deployment: load the new data registry and run the native console
command `ec lunarForecast recompute` once. It rebuilds EC2's saved forecast cache;
do not delete lunar SavedData or change the world's dayTime/gameTime. The matching
runtime pack contains the exact contents of the datapack/ directory in this source.

Validation evidence is reported separately from this source archive. This data
change is not an FPS/RAM benchmark.
