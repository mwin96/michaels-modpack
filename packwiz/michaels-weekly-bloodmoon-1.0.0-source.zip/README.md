# Michael's Blood Moon Guard 1.0.0

Original MIT-licensed server-only Forge 1.20.1 / Java 17 addon. Requires Enhanced Celestials 2 Core 1.0.3.4. Lunar forecasting, event definitions, notifications, moon and shader rendering belong to the unmodified author mods. This addon installs no network channel and no client renderer.

The paired original weekly datapack schedules only Blood Moon on zero-indexed nights 6,13,20,... with a 56-day scheduler year, min-days-exclusive 6/max-days 7, and native moon-phase-6 initial alignment. Fifty-six is the least common multiple of 7 and the native 8 moon phases. It maintains exact weekly cadence across years rather than resetting to an event on day zero. Other lunar events, surface-only or closer spawning, sieges, and soundtrack are disabled; the monster cap multiplier is 1.5. Native EC2 sleep prevention is retained.

During that exact Overworld event, this addon admits at most 40 living monsters in a 64-block horizontal/vertical box around nearby players for NEW NATURAL spawns. It never removes existing mobs; travel and non-natural spawns can exceed the admission limit. A native wooden-door BreakDoorGoal is added only to vanilla ground-navigation Zombie/Husk/Zombie Villager types and activates only during Blood Moon. It honors mobGriefing, works on Normal, and does not break walls. Other goals remain intact. Separate zombie_tactics-common.toml changes only zombiesMineBlocks to false. Existing torch spawn guards are unchanged.

## Build

Use Java 17 and ./gradlew.bat jar (Forge 47.4.28). Download the three unmodified official compile-only jars named and hash-pinned in compile-dependencies.json into the sibling ../bloodmoon-research-110 directory; their exact official URLs are recorded there. They are not bundled in this addon or source. The Gradle wrapper LICENSE and NOTICE are retained. The JAR embeds the MIT license and pack.mcmeta.

## Focused native evidence

Full-pack private backend and hidden client passed native EC2 codec/scheduler, fresh existing-day 10/11/13/97/98 forecast and save/load checks; weekly gaps across three years; Blood Moon sleep wake-up with ordinary-night sleep control; actual native wooden-door destruction on Normal with adjacent oak plank unchanged; and 40-monster natural-admission denial with spawn-egg control. Both MakeUp Normal and Enhanced rendered the red moon with unchanged two-definition Dramatic Skys, distant opaque/water buffers and stable main depth ID / zero GL errors. This is compatibility evidence, not an FPS/RAM benchmark or certification on an 8 GB PC.
