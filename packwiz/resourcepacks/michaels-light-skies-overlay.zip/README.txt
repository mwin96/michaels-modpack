Michael's Light Skies configuration overlay — PRIVATE NATIVE CANDIDATE

This ZIP contains only original MIT configuration and this documentation.
It contains no PNG, image, shader, mod class, copied ARR JSON or audio asset.

Requires official unmodified ForgeSkyboxes0.0.2 and official unmodified
Dramatic Skys Demo1.5.3.36.6 from their original Modrinth download URLs.
Dramatic Skys textures belong to thebaum64 (Christian Baum), ARR.
Author page: https://modrinth.com/resourcepack/dramatic-skys
Provider: https://modrinth.com/mod/forgeskyboxes
Do not modify or redistribute the author's textures or original ZIP.

Select the overlay ABOVE the original Dramatic Skys ZIP. Its resource filter
hides lower fabricskyboxes/sky and celestial/sky JSON, then registers exactly
two new definitions in the michaels_skies namespace. The morning and night
definitions reference original skybox:sun.png and skybox:night.png in place.
There are no format conversions, texture copies, atlas edits or resizing.
Overworld/clear weather only. Fog is unchanged. Outside the two fade windows,
the provider should leave the native sky path active. Other dimension sky
content and existing shader options are not changed by the overlay.

Only the two referenced3072x2048sky atlases imply48MiB total RGBA base texture
storage. The original pack also globally supplies a4000x2000moon atlas
(30.52MiB base), sun and transparent cloud texture. Include these in actual
native measurements; PNG dimensions are not measured Windows process RAM.

Before acceptance, verify native SkyboxManager contains exactly2 definitions
and native TextureManager loads no other skybox namespace textures after
morning/noon/night/reload traversal. Verify full selected MakeUp shaders,
Oculus, Enhanced client behavior, Distant Horizons lighting, water/terrain,
resource reload, shader-off path, frame tails and net memory. No native
compatibility/performance approval is implied by this source-only candidate.
