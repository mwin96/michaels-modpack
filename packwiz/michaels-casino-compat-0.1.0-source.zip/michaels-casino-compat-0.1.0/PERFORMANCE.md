# Static performance review — Kirri's Casino 0.10.0

Reviewed the checksum-pinned Forge 1.20.1 JAR from the
[official file page](https://www.curseforge.com/minecraft/mc-mods/kirris-casino/files/9435630).
This review inspected bytecode, resources, configuration, and control flow. It did
not launch Minecraft or change the current RAM cap/settings.

## Cost estimate

| Area | Assessment |
| --- | --- |
| Download | Upstream 2,315,761 bytes (~2.21 MiB), plus ~16 KB original addon. |
| Additional client RAM | **About 50–100 MiB**, including loaded code/model overhead; engineering estimate. |
| Texture memory | 189 PNGs contain ~3.60 MiB of base-level RGBA pixels. Mipmaps and atlas padding add overhead. |
| FPS outside casinos | Expected little change: no loaded casino machines nearby and no new entities following players. Upstream still has small global input/HUD hooks. |
| FPS inside casinos | Some extra drawing and allocations from reels/cards/wheels. Four games and no dealers keep this bounded; an exact FPS number needs a native test. |
| Server | Four game block entities per building, plus six static signs. No initial casino mobs, AI, redstone clocks, or chunk loaders. Games do more work only while active. |
| World generation | Small single-piece templates at sparse placement candidates. Normal generation-time work; no recurring world search added. |

The RAM estimate is not inferred from the compressed download size alone. The JAR
contains 295 classes (~1.66 MiB raw bytecode), 294 model JSONs (~2.43 MiB text), and
38,133 directly specified model faces (~4.65 MiB of raw vertex data before baked
object overhead, variants, and caching). Those costs can grow into tens of MiB in
the running client. The proposed range allows for that overhead; actual retention
depends on the pack's model-loading optimizations and what is loaded.

This is a modest addition compared with a full technology or creature ecosystem.
It does not establish that the final pack uses less RAM than an earlier release.
It adds some memory to the current pack.

## Main findings and mitigations

**Removed full-window UI blur.** Upstream's `Glass` lazily allocates and retains
one RGBA8 window-sized texture, copies panel regions from the framebuffer, and
uses a custom blur shader. Its storage alone is ~7.91 MiB at 1080p, ~14.06 MiB at
1440p, and ~31.64 MiB at 4K. The client-only Mixin returns null from the shader
lookup, selecting upstream's existing flat fallback before allocation/copy work.
It adds no per-frame hook of its own. This also reduces exposure to the pack's
already-sensitive shader/render-state interactions; compatibility still needs
the normal in-game check.

**Bounded visible machinery.** Slot rendering draws multiple animated parts and
allocates temporary vectors. Filling a huge room with machines would be a worse
choice. Both original buildings contain just one slot machine and three other
games; the larger upstream Nether building is replaced. No renderer has been
disabled and no rendering distance setting has been forced on players.

**Disabled dealers and quests.** The config's `dealers: none` setting avoids its
cached visual dealer instances and rendering. `questNpcs: false` avoids quest
NPCs; our templates contain no entities. Temporary seating entities can still be
created while people play blackjack, which is expected functionality.

**Idle server work is simple.** Slot/roulette/blackjack game ticks primarily check
small state machines and counters. Slots check the shared progressive jackpot
every 40 game ticks. Active games send state updates; no new addon network channel
or scanner was added. Global casino save handling writes dirty data at a bounded
interval rather than scanning chunks. No extra sound files or audio decoding are
introduced; native games use vanilla sounds.

**Kept onboarding small.** Only the automatic book gift is suppressed. First-use
actionbar hints and server-to-client currency/dealer settings sync remain intact.
Entrance and game signs provide short instructions. No new key binding is needed
to enter a casino or open a table.

## Verification completed

- Forge 47.4.28 / Java 17 build and reobfuscation passed.
- Official file size, version, SHA-256, and stored hashes checked.
- Both exact upstream Mixin method signatures checked using `javap`.
- Compressed NBT independently parsed; bounds, unique positions, multipart
  blackjack/slot/dice blocks, real upstream block-state variants, sign backing,
  and walkable approaches to all four games checked.
- JSON resources parsed; references, sparse placement, and small Nether override
  checked. All resource bytes inside the built addon match the source files.
- Live pack/server/public repository left unchanged.

Not yet verified: actual Mixin application in a running client/server, gameplay
payouts/disconnect behavior, terrain placement quality, shader compatibility,
or measured RAM/FPS. The main-chat handover lists those small release checks.
