# Casino candidate for main-chat review

Status: **compiled and statically checked; not deployed or published**. This is a
standalone side-conversation repository. The live server, personal instance,
public modpack repository, and releases were not changed.

## What this adds

- Kirri's Casino **0.10.0**, pinned to its official Forge **1.20.1** file. It needs
  both client and server installation; no extra library mods are declared.
- Two original small buildings: an Overworld roadside casino and a Nether
  version. Each is 17 × 9 × 21 blocks with **one slot machine, one mini roulette,
  one three-seat blackjack table, and one Sic Bo dice game**.
- New Overworld generation in six ordinary land biomes. The native large Nether
  casino generation is replaced with our small template. Both use a sparse
  48-chunk placement grid; this is a rarity setting, not an exact distance promise.
- Emerald-only gambling, 1/2/4 slot stakes, reduced slot jackpot multiplier,
  four-item spot stakes, four spots, and a 128-emerald wager allowance per player
  per real calendar day (the upstream implementation uses the server's date).
- No dealer/quest NPCs, starter book gift, survival table crafting, or extra
  celebration particles. Native table animations and ordinary game sounds remain.
- A tiny original compatibility mod selects the upstream **flat-panel UI** so its
  full-screen frosted-glass texture is never allocated.

Estimated additional client RAM: **roughly 50–100 MiB**. FPS cost should be small
away from casinos; nearby machines add some drawing work. These are code-based
estimates, not measured results. See [PERFORMANCE.md](PERFORMANCE.md).

## Files to review and integrate

- `compat/`: original Forge source, two Mixins, and embedded worldgen/templates.
- `candidate/mods/michaels-casino-compat-0.1.0.jar`: built, reobfuscated addon.
- `candidate/config/kirriscasino.json`: apply on server and distribute to clients.
- `candidate/upstream-pin.json`: official upstream download and verified hashes.
- `candidate/validation.json`: results of `validate_candidate.py`.
- `generate_candidate.py`: original, reproducible structure generator.

Download Kirri's Casino from the pinned official source rather than committing or
rehosting its JAR/source/assets. It is All Rights Reserved. The candidate addon,
templates, and scripts are original MIT-licensed work; Gradle wrapper files retain
their own license. The ignored `vendor/` and `inspection/` folders are local review
material only.

## Main-chat review before release

1. Add both JARs to an isolated copy of the current pack/client and test server.
   Confirm startup, join, and both Mixins apply. The addon pins Kirri's to 0.10.0.
2. Use `/place structure michaels_casino:roadside` in a disposable world. Check
   floor height, entrance, sign placement, seating, four games, win/loss payments,
   leaving mid-game, and save/reload. Nether test command:
   `/place structure kirriscasino:abandoned_casino`.
3. Check natural generation with `/locate structure michaels_casino:roadside` and
   the Nether structure ID. Confirm our Nether definition wins resource priority.
   Check several placements for terrain fit and accessible entrances.
4. Check the flat interfaces with Oculus/MakeUp and the existing TaCZ render-state
   fixes. Compare ordinary play and a busy casino on the lower-memory profile.
5. Integrate through the main pack's normal pins/updater and version policy.
   Existing generated chunks will not gain casinos automatically. Place a few
   manually in genuinely unused terrain if desired; do not reset the world.

No main-repo cherry-pick or deployment has been attempted. Review this standalone
commit, then integrate the selected files into the main project's layout.

## Rebuild locally

Use JDK 17 and the existing Forge Gradle cache. From this repository:

```powershell
python inspect_candidate.py
python generate_candidate.py
# Set JAVA_HOME to JDK 17 and GRADLE_USER_HOME to the existing work/gradle-cache.
.\compat\gradlew.bat -p compat --offline --no-daemon build
python validate_candidate.py
```

`inspect_candidate.py` downloads and inspects the pinned JAR as data. It does not
execute the mod. The optional local decompiler was used only for this review and
is not required to build or distribute the addon.
