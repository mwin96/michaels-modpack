package net.michaelspack.casino;

import net.minecraftforge.fml.common.Mod;

/** No recurring event handlers, tasks, network messages, or world scans. */
@Mod(CasinoCompat.ID)
public final class CasinoCompat {
    public static final String ID = "michaels_casino_compat";
}
