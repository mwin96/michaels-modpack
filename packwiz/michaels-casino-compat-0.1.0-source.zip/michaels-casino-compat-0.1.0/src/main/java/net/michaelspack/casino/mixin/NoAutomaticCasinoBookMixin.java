package net.michaelspack.casino.mixin;

import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Suppress only the first-use book gift; retain hints, interaction, and login settings sync. */
@Pseudo
@Mixin(targets = "com.kirri.casino.util.CasinoGuide", remap = false)
public abstract class NoAutomaticCasinoBookMixin {
    @Inject(method = "onUse", at = @At("HEAD"), require = 1, remap = false)
    private static void michaelsCasino$noBook(ServerPlayer player, String game, CallbackInfo callback) {
        player.addTag("kirriscasino.guide");
    }
}
