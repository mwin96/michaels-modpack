package net.michaelspack.casino.mixin;

import net.minecraft.client.renderer.ShaderInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Use the upstream flat-panel fallback; never allocate its full-window blur texture. */
@Pseudo
@Mixin(targets = "com.kirri.casino.client.screen.Glass", remap = false)
public abstract class FlatCasinoPanelsMixin {
    @Inject(method = "shader", at = @At("HEAD"), cancellable = true, require = 1, remap = false)
    private static void michaelsCasino$flatPanels(CallbackInfoReturnable<ShaderInstance> callback) {
        callback.setReturnValue(null);
    }
}
