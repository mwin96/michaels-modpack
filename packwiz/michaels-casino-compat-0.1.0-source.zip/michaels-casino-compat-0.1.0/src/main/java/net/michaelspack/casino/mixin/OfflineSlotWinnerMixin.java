package net.michaelspack.casino.mixin;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keep a disconnected bettor's spin from paying a different nearby player. */
@Pseudo
@Mixin(targets="com.kirri.casino.block.entity.SlotMachineBlockEntity",remap=false)
public abstract class OfflineSlotWinnerMixin {
    @Shadow(remap=false) private UUID lastPlayer;
    @Shadow(remap=false) private ServerPlayer nearestPlayer(){throw new AssertionError();}

    @Redirect(method="finishSpin",at=@At(value="INVOKE",target="Lcom/kirri/casino/block/entity/SlotMachineBlockEntity;nearestPlayer()Lnet/minecraft/server/level/ServerPlayer;"),require=1,allow=1,remap=false)
    private ServerPlayer michaelsCasino$retainOriginalBettor(@Coerce Object machine){
        // Null selects the native payout drop at the machine. Unknown legacy spins retain their fallback.
        return lastPlayer==null?nearestPlayer():null;
    }

    @Inject(method="m_183515_",at=@At("TAIL"),require=1,remap=false)
    private void michaelsCasino$saveBettor(CompoundTag tag,CallbackInfo ci){
        if(lastPlayer!=null)tag.putUUID("MichaelsCasinoBettor112",lastPlayer);
    }

    @Inject(method="m_142466_",at=@At("TAIL"),require=1,remap=false)
    private void michaelsCasino$loadBettor(CompoundTag tag,CallbackInfo ci){
        lastPlayer=tag.hasUUID("MichaelsCasinoBettor112")?tag.getUUID("MichaelsCasinoBettor112"):null;
    }
}
