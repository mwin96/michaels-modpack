"""Generate original small-casino templates and worldgen resources (stdlib only).

No upstream structures/models/textures are copied. Coordinates and block IDs are
our own layout; the upstream mod supplies the functional table implementations.
"""
from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent
RES = ROOT / "compat/src/main/resources"
SIZE = (17, 9, 21)


def utf(s):
    b = s.encode("utf-8")
    return struct.pack(">H", len(b)) + b


def nbt(value):
    """Return a standard NBT (tag type, payload) pair for this generator's types."""
    if isinstance(value, bool):
        return 1, struct.pack(">b", value)
    if isinstance(value, int):
        return 3, struct.pack(">i", value)
    if isinstance(value, str):
        return 8, utf(value)
    if isinstance(value, list):
        items = [nbt(v) for v in value]
        kind = items[0][0] if items else 0
        assert all(k == kind for k, _ in items)
        return 9, bytes([kind]) + struct.pack(">i", len(items)) + b"".join(v for _, v in items)
    if isinstance(value, dict):
        data = b""
        for key, val in value.items():
            kind, payload = nbt(val)
            data += bytes([kind]) + utf(key) + payload
        return 10, data + b"\0"
    raise TypeError(type(value))


def write_json(relative, obj):
    dest = RES / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8")


def template(nether=False):
    cells = {}
    # Clear the room, not the whole bounding box: undefined outside cells preserve
    # terrain rather than cutting an air trench around the building's foundations.
    for x in range(1, 16):
        for y in range(2, 7):
            for z in range(3, 20):
                cells[x, y, z] = ("minecraft:air", {}, None)
    for x in range(5, 11):
        for y in range(2, 6):
            for z in range(3):
                cells[x, y, z] = ("minecraft:air", {}, None)

    def put(x, y, z, name, props=None, entity=None):
        assert 0 <= x < SIZE[0] and 0 <= y < SIZE[1] and 0 <= z < SIZE[2]
        cells[x, y, z] = (name if ":" in name else "minecraft:" + name, props or {}, entity)

    wall = "polished_blackstone_bricks" if nether else "dark_oak_planks"
    floor = "polished_blackstone" if nether else "polished_andesite"
    roof = "polished_blackstone_bricks" if nether else "deepslate_tiles"
    for x in range(1, 16):
        for z in range(3, 20):
            put(x, 0, z, "cobbled_deepslate")
            put(x, 1, z, floor)
            put(x, 6, z, roof)
            if x in (1, 15) or z in (3, 19):
                for y in range(2, 6):
                    put(x, y, z, wall)
    # Four solid corner posts; static colored trim rather than animated signs.
    for x in (1, 15):
        for z in (3, 19):
            for y in range(2, 7):
                put(x, y, z, "polished_blackstone_bricks")
    for x in range(2, 15):
        put(x, 5, 3, "yellow_terracotta")
    for x in range(4, 13):
        put(x, 7, 3, "black_concrete")
    for x in range(6, 11):
        put(x, 7, 3, "green_terracotta")
    for x in range(7, 10):
        put(x, 8, 3, "yellow_terracotta")
    # Windows on both sides and across the front, with conventional full glass.
    for x in (1, 15):
        for z in (6, 7, 10, 11, 14, 15):
            for y in (3, 4):
                put(x, y, z, "glass")
    for x in (3, 4, 11, 12):
        for y in (3, 4):
            put(x, y, 3, "glass")
    # Wide, clearly visible entrance and an exterior step/porch.
    for x in range(5, 11):
        for z in (1, 2):
            put(x, 0, z, "cobbled_deepslate")
            put(x, 1, z, floor)
        put(x, 1, 0, "stone_brick_stairs", {
            "facing": "south", "half": "bottom", "shape": "straight", "waterlogged": "false"
        })
    for x, hinge in ((7, "left"), (8, "right")):
        for y, half in ((2, "lower"), (3, "upper")):
            put(x, y, 3, "dark_oak_door", {
                "facing": "north", "half": half, "hinge": hinge,
                "open": "false", "powered": "false"
            })
    for x in range(7, 10):
        for z in range(4, 18):
            put(x, 2, z, "red_carpet")
    for x in (3, 13):
        for z in (5, 17):
            put(x, 5, z, "lantern", {"hanging": "true", "waterlogged": "false"})
    # Four functional games. Only core blocks create ticking block entities.
    for part, (dx, dz) in enumerate(((0, 0), (-1, 0), (1, 0), (-1, 1), (0, 1), (1, 1))):
        put(4 + dx, 2, 14 + dz, "kirriscasino:blackjack_table", {"facing": "north", "part": str(part)})
    put(4, 2, 8, "kirriscasino:roulette_mini", {"facing": "north", "part": "0"})
    for name, x, z in (("slot_machine_ruby", 12, 16), ("sicbo_table", 12, 8)):
        for y, upper in ((2, "false"), (3, "true")):
            put(x, y, z, "kirriscasino:" + name, {"facing": "north", "upper": upper})

    def sign(x, y, z, facing, lines):
        text = {"messages": [json.dumps({"text": line}, separators=(",", ":")) for line in lines],
                "color": "white", "has_glowing_text": False}
        put(x, y, z, "dark_oak_wall_sign", {"facing": facing, "waterlogged": "false"}, {
            "id": "minecraft:sign", "front_text": text,
            "back_text": {"messages": ['{"text":""}'] * 4, "color": "black", "has_glowing_text": False},
            "is_waxed": True
        })

    sign(5, 4, 2, "north", ["THE LAST", "LUCKY STOP", "Emerald bets", "Come back alive"])
    sign(10, 4, 2, "north", ["Right-click", "a game to play", "Then go beat", "the Dragon"])
    # Signs use opaque backing sections of the side walls, outside window runs.
    sign(2, 3, 8, "east", ["ROULETTE", "Right-click", "Emerald bets", "Good luck"])
    sign(2, 3, 16, "east", ["BLACKJACK", "Up to 3 players", "Right-click", "Emerald bets"])
    sign(14, 3, 8, "west", ["SIC BO", "Dice game", "Right-click", "Emerald bets"])
    sign(14, 3, 16, "west", ["SLOTS", "1 / 2 / 4 bets", "Right-click", "Emeralds only"])
    # A little abandoned atmosphere, entirely static vanilla decoration.
    for x in (7, 8, 9):
        put(x, 2, 18, "dark_oak_stairs", {
            "facing": "south", "half": "bottom", "shape": "straight", "waterlogged": "false"
        })
    put(10, 2, 17, "potted_dead_bush")

    palette, lookup, blocks = [], {}, []
    for pos, (name, props, entity) in sorted(cells.items()):
        key = (name, tuple(sorted(props.items())))
        if key not in lookup:
            lookup[key] = len(palette)
            entry = {"Name": name}
            if props:
                entry["Properties"] = props
            palette.append(entry)
        block = {"pos": list(pos), "state": lookup[key]}
        if entity:
            block["nbt"] = entity
        blocks.append(block)
    return {"DataVersion": 3465, "author": "Michael's Modpack",
            "size": list(SIZE), "palette": palette, "blocks": blocks, "entities": []}


def main():
    report = {}
    for theme in ("roadside", "nether"):
        data = template(nether=theme == "nether")
        kind, payload = nbt(data)
        raw = bytes([kind]) + utf("") + payload
        packed = gzip.compress(raw, mtime=0)
        target = RES / f"data/michaels_casino/structures/{theme}.nbt"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(packed)
        report[theme] = {"bytes": len(packed), "sha256": hashlib.sha256(packed).hexdigest(),
                         "size": list(SIZE), "games": 4, "entities": 0}
        write_json(f"data/michaels_casino/worldgen/template_pool/{theme}.json", {
            "name": "michaels_casino:" + theme, "fallback": "minecraft:empty",
            "elements": [{"weight": 1, "element": {
                "element_type": "minecraft:single_pool_element",
                "location": "michaels_casino:" + theme,
                "processors": "minecraft:empty", "projection": "rigid"
            }}]
        })
    write_json("data/michaels_casino/tags/worldgen/biome/has_roadside_casino.json", {
        "replace": False,
        "values": ["minecraft:" + s for s in (
            "plains", "sunflower_plains", "forest", "birch_forest", "savanna", "taiga"
        )]
    })
    write_json("data/michaels_casino/worldgen/structure/roadside.json", {
        "type": "minecraft:jigsaw", "biomes": "#michaels_casino:has_roadside_casino",
        "step": "surface_structures", "spawn_overrides": {}, "terrain_adaptation": "beard_thin",
        "start_pool": "michaels_casino:roadside", "size": 1,
        "start_height": {"absolute": 0}, "project_start_to_heightmap": "WORLD_SURFACE_WG",
        "max_distance_from_center": 32, "use_expansion_hack": False
    })
    write_json("data/michaels_casino/worldgen/structure_set/roadside.json", {
        "structures": [{"structure": "michaels_casino:roadside", "weight": 1}],
        "placement": {"type": "minecraft:random_spread", "spacing": 48,
                      "separation": 16, "salt": 614091377}
    })
    # Override the upstream Nether casino's generation entry, not its copyrighted template.
    # This avoids silently leaving its much larger, machine-filled casinos in the pack.
    write_json("data/kirriscasino/worldgen/structure/abandoned_casino.json", {
        "type": "minecraft:jigsaw", "biomes": "#kirriscasino:has_structure/abandoned_casino",
        "step": "underground_decoration", "spawn_overrides": {}, "terrain_adaptation": "beard_box",
        "start_pool": "michaels_casino:nether", "size": 1,
        "start_height": {"type": "minecraft:uniform", "min_inclusive": {"absolute": 34},
                         "max_inclusive": {"absolute": 72}},
        "max_distance_from_center": 32, "use_expansion_hack": False
    })
    write_json("data/kirriscasino/worldgen/structure_set/abandoned_casino.json", {
        "structures": [{"structure": "kirriscasino:abandoned_casino", "weight": 1}],
        "placement": {"type": "minecraft:random_spread", "spacing": 48,
                      "separation": 16, "salt": 614091379}
    })
    target = ROOT / "candidate/structures.json"
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
