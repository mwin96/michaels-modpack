package net.michaelspack.menu;

import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** Removes historical death markers through Xaero's native API, never waypoint files. */
@Mod.EventBusSubscriber(modid = "michaels_menu", value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class DeathpointCleanup {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static Api api;
    private static boolean unavailable;
    private static int ticks;

    private DeathpointCleanup() {}

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || unavailable) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null) {
            ticks = 0;
            return;
        }
        if (++ticks < 100) return;
        ticks = 0;
        try {
            if (api == null) api = new Api();
            clean(api);
        } catch (ReflectiveOperationException | LinkageError | RuntimeException error) {
            // Xaero remains optional. A changed API must not break the game or touch other data.
            unavailable = true;
            LOGGER.warn("Michael's historical deathpoint cleanup could not use Xaero's optional API.", error);
        }
    }

    private static void clean(Api api) throws ReflectiveOperationException {
        Object session = api.currentSession.invoke(null);
        if (session == null) return;
        Object processor = api.getProcessor.invoke(session);
        if (processor == null) return;
        Object minimapSession = api.getMinimapSession.invoke(processor);
        if (minimapSession == null) return;
        Object manager = api.getWorldManager.invoke(minimapSession);
        // Auto root is the connected server, even if a different map is selected in the UI.
        Object root = api.getAutoRoot.invoke(manager);
        if (root == null) return;
        Object io = api.getWorldManagerIO.invoke(minimapSession);
        for (Object world : (Iterable<?>) api.getAllWorlds.invoke(root)) {
            List<Removal> removals = new ArrayList<>();
            for (Object set : (Iterable<?>) api.getSets.invoke(world)) {
                List<Object> historical = new ArrayList<>();
                for (Object waypoint : (Iterable<?>) api.getWaypoints.invoke(set)) {
                    Object purpose = api.getPurpose.invoke(waypoint);
                    if (purpose == api.oldDeathPurpose) historical.add(waypoint);
                }
                if (!historical.isEmpty()) removals.add(new Removal(set, historical));
            }
            if (removals.isEmpty()) continue;
            int removed = 0;
            for (Removal removal : removals) {
                api.removeAll.invoke(removal.set(), removal.waypoints());
                removed += removal.waypoints().size();
            }
            // Same public save API used by Xaero's own deathpoint creation/deletion paths.
            api.saveWorld.invoke(io, world);
            LOGGER.info("Michael's waypoint cleanup removed {} historical death markers; latest and manual markers were retained.", removed);
        }
    }

    private record Removal(Object set, List<Object> waypoints) {}

    /** Exact public API signatures inspected in the installed Xaero Minimap 26.6.0 jar. */
    private static final class Api {
        final Method currentSession;
        final Method getProcessor;
        final Method getMinimapSession;
        final Method getWorldManager;
        final Method getWorldManagerIO;
        final Method getAutoRoot;
        final Method getAllWorlds;
        final Method getSets;
        final Method getWaypoints;
        final Method getPurpose;
        final Method removeAll;
        final Method saveWorld;
        final Object oldDeathPurpose;

        Api() throws ReflectiveOperationException {
            ClassLoader loader = DeathpointCleanup.class.getClassLoader();
            Class<?> session = Class.forName("xaero.common.XaeroMinimapSession", false, loader);
            Class<?> processor = Class.forName("xaero.common.minimap.MinimapProcessor", false, loader);
            Class<?> minimapSession = Class.forName("xaero.hud.minimap.module.MinimapSession", false, loader);
            Class<?> manager = Class.forName("xaero.hud.minimap.world.MinimapWorldManager", false, loader);
            Class<?> container = Class.forName("xaero.hud.minimap.world.container.MinimapWorldContainer", false, loader);
            Class<?> world = Class.forName("xaero.hud.minimap.world.MinimapWorld", false, loader);
            Class<?> set = Class.forName("xaero.hud.minimap.waypoint.set.WaypointSet", false, loader);
            Class<?> waypoint = Class.forName("xaero.common.minimap.waypoints.Waypoint", false, loader);
            Class<?> purpose = Class.forName("xaero.hud.minimap.waypoint.WaypointPurpose", false, loader);
            Class<?> io = Class.forName("xaero.hud.minimap.world.io.MinimapWorldManagerIO", false, loader);
            currentSession = session.getMethod("getCurrentSession");
            getProcessor = session.getMethod("getMinimapProcessor");
            getMinimapSession = processor.getMethod("getSession");
            getWorldManager = minimapSession.getMethod("getWorldManager");
            getWorldManagerIO = minimapSession.getMethod("getWorldManagerIO");
            getAutoRoot = manager.getMethod("getAutoRootContainer");
            getAllWorlds = container.getMethod("getAllWorldsIterable");
            getSets = world.getMethod("getIterableWaypointSets");
            getWaypoints = set.getMethod("getWaypoints");
            getPurpose = waypoint.getMethod("getPurpose");
            removeAll = set.getMethod("removeAll", Collection.class);
            saveWorld = io.getMethod("saveWorld", world);
            oldDeathPurpose = purpose.getField("OLD_DEATH").get(null);
        }
    }
}
