package net.michaelspack.menu.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Leave the immutable shared-core jar untouched and remove only its old small menu banner. */
@Pseudo
@Mixin(targets="net.michaelspack.ClientBranding", remap=false)
public final class LegacyBannerMixin {
    @Inject(method="render", at=@At("HEAD"), cancellable=true, remap=false, require=1)
    private static void noOldBanner(CallbackInfo ci) { ci.cancel(); }
}
