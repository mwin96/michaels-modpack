package net.michaelspack.menu.mixin;

import net.michaelspack.menu.MenuArtwork;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.LogoRenderer;
import net.minecraft.client.gui.components.SplashRenderer;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Replace only menu artwork. The original render method still renders every normal control. */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Component title) { super(title); }

    @Redirect(method="render", at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/components/LogoRenderer;renderLogo(Lnet/minecraft/client/gui/GuiGraphics;IF)V"))
    private void replaceLogo(LogoRenderer logo, GuiGraphics graphics, int screenWidth, float alpha) {
        MenuArtwork.draw(graphics, width, height, alpha);
    }

    @Redirect(method="render", at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/components/SplashRenderer;render(Lnet/minecraft/client/gui/GuiGraphics;ILnet/minecraft/client/gui/Font;I)V"))
    private void skipSplash(SplashRenderer splash, GuiGraphics graphics, int screenWidth, Font font, int alpha) {
        // Random vanilla splash text would obscure the custom title.
    }
}
