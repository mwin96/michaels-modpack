package net.michaelspack.menu;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** A small distance list using the same server-tracked positions as Xaero's map.
 * It sends no packets and never exposes coordinates. Reflection keeps this cosmetic
 * client mod optional if the minimap is absent. All calls run on the client thread.
 */
@Mod.EventBusSubscriber(modid="michaels_menu", value=Dist.CLIENT)
public final class FriendDistances {
    private static List<Row> rows=List.of();
    private static int ticks;
    private static final TrackerReader tracker=new TrackerReader();
    private record Position(double x,double y,double z,ResourceKey<Level> dimension) {}
    private record Row(String name,String distance,double order) {}

    private FriendDistances() {}

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase!=TickEvent.Phase.END) return;
        Minecraft mc=Minecraft.getInstance();
        if (mc.player==null || mc.level==null || mc.getConnection()==null) {
            rows=List.of(); ticks=0; return;
        }
        if (++ticks%10!=0) return;
        Map<UUID,Position> positions=tracker.positions();
        List<Row> next=new ArrayList<>();
        for (var info:mc.getConnection().getOnlinePlayers()) {
            UUID id=info.getProfile().getId();
            if (id.equals(mc.player.getUUID())) continue;
            String name=info.getProfile().getName();
            Position position=positions.get(id);
            // Loaded players have smoother/current positions than the global map packets.
            var nearby=mc.level.getPlayerByUUID(id);
            if (nearby!=null)
                position=new Position(nearby.getX(),nearby.getY(),nearby.getZ(),mc.level.dimension());
            String label="locating...";
            double distance=Double.POSITIVE_INFINITY;
            if (position!=null) {
                if (position.dimension.equals(mc.level.dimension())) {
                    double dx=position.x-mc.player.getX(), dy=position.y-mc.player.getY(), dz=position.z-mc.player.getZ();
                    distance=Math.sqrt(dx*dx+dy*dy+dz*dz);
                    if (Double.isFinite(distance)) label=Math.round(distance)+" m";
                } else if (position.dimension.equals(Level.NETHER)) label="Nether";
                else if (position.dimension.equals(Level.END)) label="The End";
                else label="elsewhere";
            }
            next.add(new Row(name,label,distance));
        }
        next.sort(Comparator.comparingDouble(Row::order).thenComparing(Row::name,String.CASE_INSENSITIVE_ORDER));
        rows=List.copyOf(next);
    }

    private static void render(ForgeGui gui,GuiGraphics g,float partialTick,int width,int height) {
        Minecraft mc=Minecraft.getInstance();
        if (mc.options.hideGui || mc.screen!=null || mc.player==null || rows.isEmpty()) return;
        int count=Math.min(5,rows.size());
        int panelWidth=0;
        List<String> labels=new ArrayList<>();
        for (int i=0;i<count;i++) {
            Row row=rows.get(i);
            String label=row.name+"  "+row.distance;
            labels.add(label);panelWidth=Math.max(panelWidth,mc.font.width(label));
        }
        int x=8;
        int y=Math.max(8,Math.min(height-count*12-42,Math.max(115,height/2-count*6)));
        g.fill(x-3,y-3,x+panelWidth+4,y+count*12-1,0x660A0C12);
        for (int i=0;i<count;i++) g.drawString(mc.font,labels.get(i),x,y+i*12,0xFFE4E5ED,true);
    }

    /** Read-only observation used by the private native multiplayer test harness. */
    public static List<String> observedRows() {
        return rows.stream().map(row->row.name+"  "+row.distance).toList();
    }

    @Mod.EventBusSubscriber(modid="michaels_menu", bus=Mod.EventBusSubscriber.Bus.MOD, value=Dist.CLIENT)
    public static final class Register {
        @SubscribeEvent
        public static void overlay(RegisterGuiOverlaysEvent event) {
            event.registerAboveAll("friend_distances",FriendDistances::render);
        }
    }

    private static final class TrackerReader {
        private boolean tried;
        private Method session,processor,manager,players,id,x,y,z,dimension;
        private void initialize() {
            if (tried) return;
            tried=true;
            try {
                Class<?> sessions=Class.forName("xaero.common.XaeroMinimapSession");
                Class<?> processors=Class.forName("xaero.common.minimap.MinimapProcessor");
                Class<?> managers=Class.forName("xaero.common.minimap.radar.tracker.synced.ClientSyncedTrackedPlayerManager");
                Class<?> tracked=Class.forName("xaero.common.server.radar.tracker.SyncedTrackedPlayer");
                session=sessions.getMethod("getCurrentSession");
                processor=sessions.getMethod("getMinimapProcessor");
                manager=processors.getMethod("getClientSyncedTrackedPlayerManager");
                players=managers.getMethod("getPlayers");
                id=tracked.getMethod("getId");x=tracked.getMethod("getX");
                y=tracked.getMethod("getY");z=tracked.getMethod("getZ");
                dimension=tracked.getMethod("getDimensionKey");
            } catch (ReflectiveOperationException | LinkageError unavailable) {
                session=null;
            }
        }
        @SuppressWarnings("unchecked")
        Map<UUID,Position> positions() {
            initialize();
            Map<UUID,Position> result=new HashMap<>();
            if (session==null) return result;
            try {
                Object current=session.invoke(null);
                if (current==null) return result;
                Object currentManager=manager.invoke(processor.invoke(current));
                for (Object player:(Iterable<?>)players.invoke(currentManager)) {
                    double px=(Double)x.invoke(player),py=(Double)y.invoke(player),pz=(Double)z.invoke(player);
                    ResourceKey<Level> dim=(ResourceKey<Level>)dimension.invoke(player);
                    if (dim!=null && Double.isFinite(px) && Double.isFinite(py) && Double.isFinite(pz))
                        result.put((UUID)id.invoke(player),new Position(px,py,pz,dim));
                }
            } catch (ReflectiveOperationException | RuntimeException unavailable) {
                // During a server/world transition, wait for the next normal sync.
                result.clear();
            }
            return result;
        }
    }
}
