package net.michaelspack.menu;

import net.minecraftforge.fml.common.Mod;

/** Optional client-only illustration; vanilla controls and keyboard navigation remain. */
@Mod("michaels_menu")
public final class Menu {
    public Menu() {}
}
