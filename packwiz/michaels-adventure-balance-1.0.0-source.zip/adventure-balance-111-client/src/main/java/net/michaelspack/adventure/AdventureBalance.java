package net.michaelspack.adventure;

import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** Narrow final-boss damage tuning; ordinary monsters, PvP, gear and loot are unchanged. */
@Mod(AdventureBalance.ID)
public final class AdventureBalance {
    public static final String ID="michaels_adventure_balance";
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue DRAGON_GUN,DRAGON_ATTACK;
    static {
        var builder=new ForgeConfigSpec.Builder();
        builder.push("dragon");
        DRAGON_GUN=builder.comment("Fraction of TaCZ bullet damage received by the adult Ender Dragon; all guns still damage it.").defineInRange("gunDamageMultiplier",0.4,0.05,1.0);
        DRAGON_ATTACK=builder.comment("Adult Dragon attacks against players in the End, before normal armor/enchantment mitigation.").defineInRange("attackDamageMultiplier",1.75,1.0,4.0);
        builder.pop();SPEC=builder.build();
    }
    public AdventureBalance(){
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON,SPEC,"michaels-adventure-balance-common.toml");
        MinecraftForge.EVENT_BUS.register(this);
    }
    public static boolean gunSource(net.minecraft.world.damagesource.DamageSource source){
        var type=source.typeHolder().unwrapKey();
        return type.isPresent()&&type.get().location().getNamespace().equals("tacz")&&type.get().location().getPath().startsWith("bullet");
    }
    @SubscribeEvent public void damage(LivingHurtEvent event){
        if(event.getEntity().level().isClientSide||event.getAmount()<=0)return;
        if(event.getEntity() instanceof EnderDragon&&gunSource(event.getSource()))event.setAmount((float)(event.getAmount()*DRAGON_GUN.get()));
        else if(event.getEntity() instanceof Player&&event.getEntity().level().dimension().equals(Level.END)&&event.getSource().getEntity() instanceof EnderDragon)
            event.setAmount((float)(event.getAmount()*DRAGON_ATTACK.get()));
    }
}
