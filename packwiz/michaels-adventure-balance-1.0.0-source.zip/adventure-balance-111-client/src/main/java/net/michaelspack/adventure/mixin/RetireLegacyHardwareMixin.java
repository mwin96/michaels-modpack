package net.michaelspack.adventure.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The first-install bootstrap now owns hardware defaults; old runtime promotion is retired. */
@Pseudo
@Mixin(targets="net.michaelspack.clientfixes.ClientFeatures109", remap=false)
public abstract class RetireLegacyHardwareMixin {
    @Shadow(remap=false) private static boolean hardwareDone;

    @Inject(method="hardware()V", at=@At("HEAD"), cancellable=true, require=1, remap=false)
    private static void michaels$retainExistingHardwareChoices(CallbackInfo ci) {
        hardwareDone=true;
        ci.cancel();
    }
}
