package net.michaelspack.adventure;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.common.ForgeHooks;

/** A bounded 3x3 plane using actual vanilla player mining, including tier, drops and durability. */
public final class DrillMining {
    private static final ThreadLocal<Boolean> MINING=ThreadLocal.withInitial(()->false);
    private DrillMining(){}
    public static void mine(LevelAccessor world,double x,double y,double z,Entity entity,ItemStack stack){
        if(MINING.get()||!(world instanceof ServerLevel level)||!(entity instanceof ServerPlayer player)||player.isSpectator()||player.isShiftKeyDown()||stack.isEmpty())return;
        BlockPos center=BlockPos.containing(x,y,z);
        Direction.Axis axis=Math.abs(player.getXRot())>45?Direction.Axis.Y:player.getDirection().getAxis();
        MINING.set(true);
        try {
            for(int a=-1;a<=1;a++)for(int b=-1;b<=1;b++){
                if(a==0&&b==0)continue;
                if(stack.isEmpty()||player.getMainHandItem()!=stack)return;
                BlockPos pos=switch(axis){case X->center.offset(0,a,b);case Y->center.offset(a,0,b);case Z->center.offset(a,b,0);};
                if(!level.hasChunkAt(pos)||!level.mayInteract(player,pos)||player.blockActionRestricted(level,pos,player.gameMode.getGameModeForPlayer()))continue;
                var state=level.getBlockState(pos);
                if(state.isAir()||!state.is(BlockTags.MINEABLE_WITH_PICKAXE)||state.getDestroySpeed(level,pos)<0)continue;
                if(state.requiresCorrectToolForDrops()&&!ForgeHooks.isCorrectToolForDrops(state,player))continue;
                // The native game-mode path posts Forge break events and applies the
                // held tool, enchantments, XP and damage for each extra block.
                player.gameMode.destroyBlock(pos);
            }
        } finally {MINING.remove();}
    }
}
