package net.michaelspack.adventure.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.client.Minecraft;

/** No old update path may restart an existing four/eight-GB client merely to force six GB. */
@Pseudo
@Mixin(targets="net.michaelspack.clientfixes.LauncherMemoryMigration", remap=false)
public abstract class RetireLegacyMemoryMixin {
    @Inject(method="mustFinishBeforeJoin(Lnet/minecraft/client/Minecraft;)Z", at=@At("HEAD"), cancellable=true, require=1, remap=false)
    private static void michaels$retainExistingHeap(Minecraft client, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
    }
}
