package net.michaelspack.adventure;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.entity.TheEndPortalBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.structure.*;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Optional, finite encounters. Never edits terrain, loads chunks or prevents portal use. */
@Mod.EventBusSubscriber(modid=AdventureBalance.ID)
public final class PortalRoomGuardian {
    public static final String TAG="MichaelsPortalSentinel111", ROOM="MichaelsPortalRoom111";
    private static final String STORE="michaels_portal_sentinels_111";
    private static final ResourceLocation TYPE=new ResourceLocation("cataclysm","ender_golem");
    private static final Map<UUID,Bar> BARS=new HashMap<>();
    private static final Map<String,Long> SCANNED=new HashMap<>();
    private static int playerCursor;
    private static long budgetTick=Long.MIN_VALUE;
    private static int blockReads;
    private PortalRoomGuardian(){}

    public static boolean tagged(Entity entity){return TYPE.equals(ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()))&&entity.getPersistentData().getBoolean(TAG);}
    public static Store store(MinecraftServer server){return server.overworld().getDataStorage().computeIfAbsent(Store::load,Store::new,STORE);}
    private static String key(ServerLevel level,BlockPos center){return level.dimension().location()+"@"+center.asLong();}
    private static void resetBudget(ServerLevel level){long tick=level.getServer().getTickCount()/20;if(tick!=budgetTick){budgetTick=tick;blockReads=0;}}
    private static BlockState read(ServerLevel level,BlockPos pos){
        resetBudget(level);
        if(blockReads>=4096||level.getChunkSource().getChunkNow(pos.getX()>>4,pos.getZ()>>4)==null)return null;
        blockReads++;return level.getBlockState(pos);
    }

    @SubscribeEvent public static void tick(TickEvent.ServerTickEvent event){
        if(event.phase!=TickEvent.Phase.END||event.getServer().getTickCount()%20!=0)return;
        MinecraftServer server=event.getServer();updateBars(server);
        var players=server.getPlayerList().getPlayers();if(players.isEmpty())return;
        if(playerCursor>=players.size())playerCursor=0;
        ServerPlayer player=players.get(playerCursor++);
        if(!player.isAlive()||player.isSpectator())return;
        inspectNearby(player);
    }

    /** Reads metadata already resident in loaded chunks, never asks StructureManager to load starts. */
    public static void inspectNearby(ServerPlayer player){
        ServerLevel level=player.serverLevel();resetBudget(level);
        LevelChunk current=level.getChunkSource().getChunkNow(player.blockPosition().getX()>>4,player.blockPosition().getZ()>>4);
        if(current==null)return;
        for(var reference:current.getAllReferences().entrySet()){
            if(!new ResourceLocation("minecraft","stronghold").equals(level.registryAccess().registryOrThrow(Registries.STRUCTURE).getKey(reference.getKey())))continue;
            for(long packed:reference.getValue()){
                ChunkPos pos=new ChunkPos(packed);LevelChunk owner=level.getChunkSource().getChunkNow(pos.x,pos.z);if(owner==null)continue;
                StructureStart start=owner.getAllStarts().get(reference.getKey());if(start==null)continue;
                for(StructurePiece piece:start.getPieces()){
                    if(piece.getType()!=StructurePieceType.STRONGHOLD_PORTAL_ROOM)continue;
                    BoundingBox box=piece.getBoundingBox();
                    if(!new AABB(box.minX(),box.minY(),box.minZ(),box.maxX()+1,box.maxY()+1,box.maxZ()+1).inflate(24).contains(player.position()))continue;
                    String id=level.dimension().location()+":"+box.toString();long now=level.getGameTime();
                    if(SCANNED.getOrDefault(id,Long.MIN_VALUE)>now)continue;
                    if(scanRoom(level,box,player))SCANNED.put(id,now+200);
                    if(SCANNED.size()>1024)SCANNED.clear();
                    if(blockReads>=4096)return;
                }
            }
        }
        // Active custom portals expose block entities. No general block-volume scan.
        ChunkPos cp=player.chunkPosition();int entityChecks=0;
        for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++){
            LevelChunk chunk=level.getChunkSource().getChunkNow(cp.x+dx,cp.z+dz);if(chunk==null)continue;
            for(var blockEntity:chunk.getBlockEntities().values()){
                if(++entityChecks>1024||blockReads>=4096)return;
                if(!(blockEntity instanceof TheEndPortalBlockEntity)||blockEntity.getBlockPos().distToCenterSqr(player.position())>24*24)continue;
                BlockPos portal=blockEntity.getBlockPos();
                for(Direction direction:Direction.Plane.HORIZONTAL)for(int distance=1;distance<=3;distance++){
                    BlockPos frame=portal.relative(direction,distance);BlockState state=read(level,frame);
                    if(state!=null&&state.is(Blocks.END_PORTAL_FRAME)&&tryFrame(level,frame,player))break;
                }
            }
        }
    }

    private static boolean scanRoom(ServerLevel level,BoundingBox box,ServerPlayer player){
        if((long)box.getXSpan()*box.getYSpan()*box.getZSpan()>4096)return true;
        for(int x=box.minX();x<=box.maxX();x++)for(int y=box.minY();y<=box.maxY();y++)for(int z=box.minZ();z<=box.maxZ();z++){
            BlockPos pos=new BlockPos(x,y,z);BlockState state=read(level,pos);if(state==null)return false;
            if(state.is(Blocks.END_PORTAL_FRAME)&&tryFrame(level,pos,player))return true;
        }
        return true;
    }

    @SubscribeEvent public static void frameClick(PlayerInteractEvent.RightClickBlock event){
        if(!(event.getEntity() instanceof ServerPlayer player)||player.isSpectator())return;
        ServerLevel level=player.serverLevel();BlockState state=read(level,event.getPos());
        if(state!=null&&state.is(Blocks.END_PORTAL_FRAME))tryFrame(level,event.getPos(),player);
        // Never cancels the interaction or changes Eyes/portal state.
    }

    /** The vanilla ring has twelve inward-facing frames; corners are not part of it. */
    public static boolean tryFrame(ServerLevel level,BlockPos frame,ServerPlayer player){
        BlockState state=read(level,frame);if(state==null||!state.is(Blocks.END_PORTAL_FRAME))return false;
        Direction inward=state.getValue(EndPortalFrameBlock.FACING);BlockPos approximate=frame.relative(inward,2);
        for(int offset=-1;offset<=1;offset++){
            BlockPos center=approximate.relative(inward.getClockWise(),offset);
            if(center.distToCenterSqr(player.position())>24*24||!ring(level,center))continue;
            String id=key(level,center);Store data=store(level.getServer());
            if(data.rooms.containsKey(id))return true;
            EntityType<?> type=ForgeRegistries.ENTITY_TYPES.getValue(TYPE);if(type==null)return false;
            Entity entity=type.create(level);if(!(entity instanceof Mob mob))return false;
            BlockPos safe=safeSpot(level,center,mob);if(safe==null)return false;
            mob.moveTo(safe.getX()+0.5,safe.getY(),safe.getZ()+0.5,0,0);
            mob.getPersistentData().putBoolean(TAG,true);mob.getPersistentData().putString(ROOM,id);
            mob.setCustomName(Component.literal("Stronghold Sentinel"));mob.setCustomNameVisible(true);
            mob.setPersistenceRequired();mob.restrictTo(safe,20);
            if(mob.getAttribute(Attributes.MAX_HEALTH)==null)return false;
            mob.getAttribute(Attributes.MAX_HEALTH).setBaseValue(240);mob.setHealth(240);
            // Reserve before joining. Missing/unloaded UUIDs never authorize another spawn.
            data.rooms.put(id,new Entry(level.dimension().location().toString(),center.asLong(),mob.getUUID(),false));data.setDirty();
            if(!level.addFreshEntity(mob)){data.rooms.remove(id);data.setDirty();return false;}
            watch(mob);return true;
        }
        return false;
    }

    private static boolean ring(ServerLevel level,BlockPos center){
        for(Direction side:Direction.Plane.HORIZONTAL)for(int offset=-1;offset<=1;offset++){
            BlockPos pos=center.relative(side,2).relative(side.getClockWise(),offset);BlockState state=read(level,pos);
            if(state==null||!state.is(Blocks.END_PORTAL_FRAME)||state.getValue(EndPortalFrameBlock.FACING)!=side.getOpposite())return false;
        }
        return true;
    }

    private static BlockPos safeSpot(ServerLevel level,BlockPos center,Mob mob){
        for(int radius=4;radius<=9;radius++)for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++){
            if(Math.max(Math.abs(dx),Math.abs(dz))!=radius)continue;
            for(int dy:new int[]{-2,-1,0,1,2}){
                BlockPos feet=center.offset(dx,dy,dz);boolean safe=true;
                for(int x=-1;x<=1&&safe;x++)for(int z=-1;z<=1&&safe;z++){
                    BlockPos floor=feet.offset(x,-1,z);BlockState support=read(level,floor);
                    if(support==null)return null;
                    if(!support.isFaceSturdy(level,floor,Direction.UP)||!support.getFluidState().isEmpty()||support.is(Blocks.MAGMA_BLOCK)||support.is(Blocks.CAMPFIRE)||support.is(Blocks.SOUL_CAMPFIRE)){safe=false;break;}
                    for(int y=0;y<4;y++){BlockState air=read(level,feet.offset(x,y,z));if(air==null)return null;if(!air.isAir()){safe=false;break;}}
                }
                if(!safe)continue;
                mob.moveTo(feet.getX()+0.5,feet.getY(),feet.getZ()+0.5,0,0);
                if(level.noCollision(mob)&&level.getEntities(mob,mob.getBoundingBox().inflate(0.5)).isEmpty())return feet;
            }
        }
        return null; // Never clears blocks to make room, including player builds.
    }

    @SubscribeEvent public static void joined(EntityJoinLevelEvent event){if(!event.getLevel().isClientSide&&tagged(event.getEntity())&&event.getEntity() instanceof Mob mob)watch(mob);}
    private static void watch(Mob mob){
        if(!(mob.level() instanceof ServerLevel level))return;
        BARS.computeIfAbsent(mob.getUUID(),id->new Bar(level.dimension(),new ServerBossEvent(Component.literal("Stronghold Sentinel"),BossEvent.BossBarColor.PURPLE,BossEvent.BossBarOverlay.PROGRESS)));
    }
    private static void updateBars(MinecraftServer server){
        var iterator=BARS.entrySet().iterator();
        while(iterator.hasNext()){
            var entry=iterator.next();Bar bar=entry.getValue();ServerLevel level=server.getLevel(bar.level);Entity entity=level==null?null:level.getEntity(entry.getKey());
            if(!(entity instanceof Mob mob)||!mob.isAlive()){bar.event.removeAllPlayers();iterator.remove();continue;}
            bar.event.setProgress(Math.max(0,Math.min(1,mob.getHealth()/mob.getMaxHealth())));
            for(ServerPlayer player:server.getPlayerList().getPlayers()){
                if(player.serverLevel()==level&&player.isAlive()&&!player.isSpectator()&&player.distanceToSqr(mob)<=32*32)bar.event.addPlayer(player);else bar.event.removePlayer(player);
            }
        }
    }
    @SubscribeEvent public static void protect(LivingDestroyBlockEvent event){if(tagged(event.getEntity()))event.setCanceled(true);}
    @SubscribeEvent public static void died(LivingDeathEvent event){
        if(!tagged(event.getEntity())||!(event.getEntity().level() instanceof ServerLevel level))return;
        String id=event.getEntity().getPersistentData().getString(ROOM);Store data=store(level.getServer());Entry previous=data.rooms.get(id);
        if(previous!=null){data.rooms.put(id,new Entry(previous.dimension,previous.center,previous.guardian,true));data.setDirty();}
        Bar bar=BARS.remove(event.getEntity().getUUID());if(bar!=null)bar.event.removeAllPlayers();
    }
    @SubscribeEvent public static void loot(LivingDropsEvent event){
        if(!tagged(event.getEntity())||event.getEntity().level().isClientSide)return;
        event.getDrops().clear();
        if(event.getEntity().level().getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT))event.getDrops().add(new ItemEntity(event.getEntity().level(),event.getEntity().getX(),event.getEntity().getY(),event.getEntity().getZ(),new ItemStack(Items.DIAMOND,2)));
    }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent event){if(event.getEntity() instanceof ServerPlayer player)for(Bar bar:BARS.values())bar.event.removePlayer(player);}
    @SubscribeEvent public static void stopped(ServerStoppedEvent event){for(Bar bar:BARS.values())bar.event.removeAllPlayers();BARS.clear();SCANNED.clear();playerCursor=0;budgetTick=Long.MIN_VALUE;blockReads=0;}
    private record Bar(ResourceKey<Level> level,ServerBossEvent event){}
    public record Entry(String dimension,long center,UUID guardian,boolean dead){}
    public static final class Store extends SavedData {
        public final Map<String,Entry> rooms=new LinkedHashMap<>();
        public Store(){}
        public static Store load(CompoundTag tag){
            Store data=new Store();for(Tag raw:tag.getList("rooms",Tag.TAG_COMPOUND)){
                CompoundTag row=(CompoundTag)raw;if(!row.hasUUID("guardian"))continue;
                data.rooms.put(row.getString("key"),new Entry(row.getString("dimension"),row.getLong("center"),row.getUUID("guardian"),row.getBoolean("dead")));
            }return data;
        }
        @Override public CompoundTag save(CompoundTag tag){
            ListTag rows=new ListTag();for(var pair:rooms.entrySet()){
                Entry value=pair.getValue();CompoundTag row=new CompoundTag();row.putString("key",pair.getKey());row.putString("dimension",value.dimension);row.putLong("center",value.center);row.putUUID("guardian",value.guardian);row.putBoolean("dead",value.dead);rows.add(row);
            }tag.put("rooms",rows);return tag;
        }
    }
}
