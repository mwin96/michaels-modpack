package net.michaelspack.adventure.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.michaelspack.adventure.DrillMining;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replace only the exact publisher area-mining procedure, preserving its nine items/recipes/models. */
@Pseudo
@Mixin(targets="net.mcreator.simpledrills.procedures.DrillProcedureProcedure",remap=false)
public abstract class SimpleDrillMiningMixin {
    @Inject(method="execute",at=@At("HEAD"),cancellable=true,remap=false,require=1)
    private static void balancedMining(LevelAccessor world,double x,double y,double z,Entity entity,ItemStack stack,CallbackInfo callback){
        callback.cancel();
        DrillMining.mine(world,x,y,z,entity,stack);
    }
}
