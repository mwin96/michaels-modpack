package net.michaelspack.belly.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.michaelspack.belly.BellyState;
import net.michaelspack.belly.BellyVisuals;

/** Three cached cuboids, using lower torso pixels from the player's normal64x64 skin. */
public final class BellyLayer extends RenderLayer<AbstractClientPlayer,PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation LAYER=new ModelLayerLocation(new ResourceLocation(BellyVisuals.MODID,"belly"),"main");
    private final ModelPart belly;
    public BellyLayer(PlayerRenderer renderer,ModelPart belly) {super(renderer);this.belly=belly;}
    public static LayerDefinition definition() {
        MeshDefinition mesh=new MeshDefinition();
        mesh.getRoot().addOrReplaceChild("upper",CubeListBuilder.create().texOffs(18,24).addBox(-4,6,-2,8,2,2),PartPose.ZERO);
        mesh.getRoot().addOrReplaceChild("middle",CubeListBuilder.create().texOffs(16,24).addBox(-4,8,-4,8,3,4),PartPose.ZERO);
        mesh.getRoot().addOrReplaceChild("lower",CubeListBuilder.create().texOffs(18,28).addBox(-3,11,-3,6,1,3),PartPose.ZERO);
        return LayerDefinition.create(mesh,64,64);
    }
    @Override public void render(PoseStack pose,MultiBufferSource buffers,int light,AbstractClientPlayer player,
            float limbSwing,float limbAmount,float partial,float age,float headYaw,float headPitch) {
        // Double the extra visual expansion, keeping the empty torso and synced meal state unchanged.
        float amount=2F*BellyClientData.rendered(player.getUUID(),partial)/BellyState.MAX_MEALS;
        if(amount<=0.0001F||player.isInvisible()||player.isSpectator())return;
        pose.pushPose();getParentModel().body.translateAndRotate(pose);
        pose.translate(0,0,-0.128D);pose.scale(1+amount*0.125F,1,amount);
        belly.render(pose,buffers.getBuffer(RenderType.entityCutoutNoCull(player.getSkinTextureLocation())),light,
            LivingEntityRenderer.getOverlayCoords(player,0),1,1,1,1);
        pose.popPose();
    }
}
