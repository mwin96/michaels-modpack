package net.michaelspack.equipment;

import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.ItemAttributeModifierEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.*;
import net.minecraftforge.registries.*;
import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;

/** Chest-only item qualities. No crafting, progression, item replacement or inventory scanning. */
public final class QualityModule {
 public static final String TAG="MichaelsLootQuality", PROJECTILE_TAG="MichaelsProjectileQuality";
 public static final String[] NAMES={"Common","Rare","Epic","Legendary"};
 private static final ChatFormatting[] COLORS={ChatFormatting.WHITE,ChatFormatting.BLUE,ChatFormatting.LIGHT_PURPLE,ChatFormatting.GOLD};
 public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> SERIALIZERS=DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS,CopperEquipment.ID);
 static { SERIALIZERS.register("equipment_quality",()->QualityLootModifier.CODEC); }
 public static void init(IEventBus bus){SERIALIZERS.register(bus);MinecraftForge.EVENT_BUS.register(QualityModule.class);}
 public static boolean gun(ItemStack stack){ResourceLocation id=ForgeRegistries.ITEMS.getKey(stack.getItem());return id!=null&&id.getNamespace().equals("tacz")&&stack.hasTag()&&stack.getTag().contains("GunId",Tag.TAG_STRING);}
 public static boolean eligible(ItemStack stack){
  if(stack.isEmpty())return false;
  ResourceLocation id=ForgeRegistries.ITEMS.getKey(stack.getItem());if(id==null)return false;
  if(gun(stack))return true;
  if(id.getNamespace().equals("simplyswords"))return id.getPath().matches("(iron|gold|diamond|netherite)_(longsword|twinblade|rapier|katana|sai|spear|glaive|warglaive|cutlass|claymore|greataxe|greathammer|chakram|scythe|halberd)");
  if(!id.getNamespace().equals("minecraft")&&!id.getNamespace().equals(CopperEquipment.ID))return false;
  Item i=stack.getItem();return i instanceof TieredItem||i instanceof ArmorItem||i instanceof BowItem||i instanceof CrossbowItem||i instanceof TridentItem;
 }
 public static int tier(ItemStack stack){if(!eligible(stack)||!stack.hasTag()||!stack.getTag().contains(TAG,Tag.TAG_INT))return -1;int t=stack.getTag().getInt(TAG);return t>=0&&t<=3?t:-1;}
 public static int roll(RandomSource random){int n=random.nextInt(100);return n<70?0:n<90?1:n<98?2:3;}
 public static double multiplier(int tier){return 1+Math.max(0,Math.min(3,tier))*.1;}
 private static Component originalName(ItemStack stack){
  if(gun(stack)&&!stack.hasCustomHoverName())try{
   var id=new ResourceLocation(stack.getTag().getString("GunId"));
   var api=Class.forName("com.tacz.guns.api.TimelessAPI");
   Object index=((java.util.Optional<?>)api.getMethod("getCommonGunIndex",ResourceLocation.class).invoke(null,id)).orElseThrow();
   Object pojo=index.getClass().getMethod("getPojo").invoke(index);
   String key=(String)pojo.getClass().getMethod("getName").invoke(pojo);
   if(key!=null&&!key.isBlank())return Component.translatable(key);
  }catch(ReflectiveOperationException|RuntimeException ignored){
   // Unknown third-party gun definitions still retain their original item name.
  }
  return stack.getHoverName().copy();
 }
 public static void assign(ItemStack stack,int tier){
  if(!eligible(stack)||tier<0||tier>3||stack.getOrCreateTag().contains(TAG))return;
  Component original=originalName(stack);stack.getOrCreateTag().putInt(TAG,tier);
  stack.setHoverName(Component.literal(NAMES[tier]+" ").withStyle(COLORS[tier]).append(original));
  CompoundTag display=stack.getOrCreateTagElement("display");ListTag lore=display.getList("Lore",Tag.TAG_STRING);
  String text=tier==0?"Chest quality: standard stats":stack.getItem() instanceof ArmorItem?"Chest quality: +"+(tier*.5)+" armor":stack.getItem() instanceof DiggerItem?"Chest quality: +"+(tier*10)+"% damage and mining speed":"Chest quality: +"+(tier*10)+"% weapon damage";
  lore.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(text).withStyle(ChatFormatting.GRAY))));display.put("Lore",lore);
 }
 @SubscribeEvent public static void projectile(EntityJoinLevelEvent e){
  if(e.getLevel().isClientSide()||e.loadedFromDisk()||!(e.getEntity() instanceof Projectile projectile)||!(projectile.getOwner() instanceof Player owner))return;
  if(projectile.getPersistentData().contains(PROJECTILE_TAG))return;
  ItemStack held=owner.getMainHandItem();
  if(projectile instanceof net.minecraft.world.entity.projectile.ThrownTrident){
   CompoundTag saved=new CompoundTag();projectile.saveWithoutId(saved);held=ItemStack.of(saved.getCompound("Trident"));
  }else if(!(held.getItem() instanceof BowItem)&&!(held.getItem() instanceof CrossbowItem)&&!gun(held))held=owner.getOffhandItem();
  int t=tier(held);
  ResourceLocation id=ForgeRegistries.ENTITY_TYPES.getKey(projectile.getType());
  boolean bullet=id!=null&&id.toString().equals("tacz:bullet");
  if((bullet&&gun(held))||(!bullet&&(held.getItem() instanceof BowItem||held.getItem() instanceof CrossbowItem||held.getItem() instanceof TridentItem)))projectile.getPersistentData().putInt(PROJECTILE_TAG,Math.max(0,t));
 }
 @SubscribeEvent(priority=EventPriority.LOW) public static void damage(LivingHurtEvent e){
  if(e.getEntity().level().isClientSide())return;
  Entity direct=e.getSource().getDirectEntity();int t=-1;
  if(direct instanceof Projectile&&direct.getPersistentData().contains(PROJECTILE_TAG,Tag.TAG_INT))t=direct.getPersistentData().getInt(PROJECTILE_TAG);
  else if(direct instanceof Player p&&e.getSource().getEntity()==p)t=tier(p.getMainHandItem());
  if(t>0&&t<=3)e.setAmount((float)(e.getAmount()*multiplier(t)));
 }
 @SubscribeEvent public static void mining(PlayerEvent.BreakSpeed e){ItemStack s=e.getEntity().getMainHandItem();int t=tier(s);if(t>0&&s.getItem() instanceof DiggerItem)e.setNewSpeed((float)(e.getNewSpeed()*multiplier(t)));}
 @SubscribeEvent public static void armor(ItemAttributeModifierEvent e){
  ItemStack stack=e.getItemStack();int t=tier(stack);
  if(t>0&&stack.getItem() instanceof ArmorItem item&&e.getSlotType()==item.getEquipmentSlot()){
   UUID id=UUID.nameUUIDFromBytes(("michaels_equipment:quality_armor_"+e.getSlotType().getName()).getBytes(java.nio.charset.StandardCharsets.UTF_8));
   e.addModifier(Attributes.ARMOR,new AttributeModifier(id,"Michael's loot quality armor",t*.5,AttributeModifier.Operation.ADDITION));
  }
 }
}
