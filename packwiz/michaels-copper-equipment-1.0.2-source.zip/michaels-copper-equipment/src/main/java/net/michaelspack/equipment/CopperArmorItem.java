package net.michaelspack.equipment;

import java.util.function.Consumer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** The same copper armor rules, with vanilla iron geometry and a copper finish. */
public final class CopperArmorItem extends ArmorItem {
    public CopperArmorItem(Type type) {
        super(CopperEquipment.ARMOR, type, CopperEquipment.props());
    }

    @Override
    public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
        return "minecraft:textures/models/armor/iron_layer_" + (slot == EquipmentSlot.LEGS ? 2 : 1) + ".png";
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(EquipmentVisuals.ARMOR);
    }
}
