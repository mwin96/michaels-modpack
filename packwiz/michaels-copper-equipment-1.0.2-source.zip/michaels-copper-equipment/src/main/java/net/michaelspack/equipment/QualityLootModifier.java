package net.michaelspack.equipment;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.ArrayList;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.*;
public final class QualityLootModifier extends LootModifier {
 public static final Codec<QualityLootModifier> CODEC=RecordCodecBuilder.create(i->codecStart(i).apply(i,QualityLootModifier::new));
 public QualityLootModifier(LootItemCondition[] conditions){super(conditions);}
 @Override public Codec<? extends IGlobalLootModifier> codec(){return CODEC;}
 @Override protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot,LootContext context){
  String path=context.getQueriedLootTableId().getPath();
  if(path.startsWith("chests/")||path.contains("/chests/")){
   // Small extra early-tier reward; existing generated entries and ammo bundles stay intact.
   String namespace=context.getQueriedLootTableId().getNamespace();
   boolean common=!namespace.equals("minecraft")||path.equals("chests/simple_dungeon")||path.startsWith("chests/stronghold_")||path.equals("chests/abandoned_mineshaft")||path.equals("chests/igloo_chest")||path.startsWith("chests/village/");
   if(common&&context.getRandom().nextInt(100)<18){
    int category=context.getRandom().nextInt(100);var choices=new ArrayList<net.minecraft.world.item.Item>();
    for(var entry:CopperEquipment.ALL.entrySet())if(entry.getKey().startsWith("copper_")){
     var item=entry.getValue().get();boolean armor=item instanceof ArmorItem,tool=item instanceof DiggerItem;
     if(category<70?!armor&&!tool:category<90?armor:tool)choices.add(item);
    }
    if(!choices.isEmpty())loot.add(new ItemStack(choices.get(context.getRandom().nextInt(choices.size()))));
   }
   for(ItemStack stack:loot)if(QualityModule.tier(stack)<0&&QualityModule.eligible(stack))QualityModule.assign(stack,QualityModule.roll(context.getRandom()));
  }
  return loot;
 }
}
