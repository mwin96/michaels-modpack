package net.michaelspack.equipment;
import com.google.gson.GsonBuilder;
import java.nio.file.*;
import java.util.*;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.loot.*;
import net.minecraft.world.level.storage.loot.parameters.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** Explicitly gated private regression fixture. Does not run in normal installations. */
@Mod.EventBusSubscriber(modid=CopperEquipment.ID)
public final class QualityRegression {
 @SubscribeEvent public static void commands(RegisterCommandsEvent e){if(Boolean.getBoolean("michaels_equipment.validation"))e.getDispatcher().register(Commands.literal("michaelsqualitycheck").requires(s->s.hasPermission(2)).executes(c->{run(c.getSource().getLevel());return 1;}));}
 private static void check(boolean b,String message){if(!b)throw new IllegalStateException(message);}
 public static void run(ServerLevel level){
  Map<String,Object> report=new LinkedHashMap<>();List<Object> rows=new ArrayList<>();report.put("tiers",rows);
  try{
   int[] counts=new int[4];RandomSource random=RandomSource.create(712310L);for(int n=0;n<100000;n++)counts[QualityModule.roll(random)]++;for(int n:counts)check(n>0,"unreachable tier");report.put("rollCounts",counts);
   ItemStack ordinary=new ItemStack(Items.IRON_SWORD);check(QualityModule.tier(ordinary)==-1&&(ordinary.getTag()==null||!ordinary.getTag().contains(QualityModule.TAG)),"crafted base altered");
   var player=FakePlayerFactory.getMinecraft(level);var original=player.getMainHandItem().copy();
   try{for(int t=0;t<4;t++){
    ItemStack sword=new ItemStack(Items.IRON_SWORD);QualityModule.assign(sword,t);var before=sword.getTag().copy();QualityModule.assign(sword,3);check(before.equals(sword.getTag()),"assignment not idempotent");
    player.setItemInHand(InteractionHand.MAIN_HAND,sword);LivingEntity target=net.minecraft.world.entity.EntityType.COW.create(level);target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);target.setHealth(100);target.hurt(level.damageSources().playerAttack(player),10);float loss=100-target.getHealth();check(Math.abs(loss-10*QualityModule.multiplier(t))<.001,"melee bonus");
    ItemStack pick=new ItemStack(Items.IRON_PICKAXE);QualityModule.assign(pick,t);player.setItemInHand(InteractionHand.MAIN_HAND,pick);var speed=new PlayerEvent.BreakSpeed(player,Blocks.STONE.defaultBlockState(),5,BlockPos.ZERO);MinecraftForge.EVENT_BUS.post(speed);check(Math.abs(speed.getNewSpeed()-5*QualityModule.multiplier(t))<.001,"mining bonus");
    ItemStack armor=new ItemStack(Items.IRON_CHESTPLATE);double base=armor.getAttributeModifiers(EquipmentSlot.CHEST).get(Attributes.ARMOR).stream().mapToDouble(a->a.getAmount()).sum();QualityModule.assign(armor,t);double value=armor.getAttributeModifiers(EquipmentSlot.CHEST).get(Attributes.ARMOR).stream().mapToDouble(a->a.getAmount()).sum();check(Math.abs(value-base-t*.5)<.001,"armor default loss");check(!armor.getTag().contains("AttributeModifiers"),"attributeNBT injected");
    ItemStack gun=new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacz:modern_kinetic_gun")));gun.getOrCreateTag().putString("GunId","tacz:ak47");gun.getOrCreateTag().putString("GunFireMode","AUTO");gun.getOrCreateTag().putInt("GunCurrentAmmoCount",17);QualityModule.assign(gun,t);check(gun.getTag().getString("GunId").equals("tacz:ak47")&&gun.getTag().getInt("GunCurrentAmmoCount")==17,"gunNBT changed");
    check(ComponentJson(gun).contains("tacz.gun.ak47.name"),"server gun name lost");
    rows.add(Map.of("tier",t,"meleeDamage",loss,"miningSpeed",speed.getNewSpeed(),"armor",value,"gunNBTpreserved",true,"gunName",ComponentJson(gun)));
   }}finally{player.setItemInHand(InteractionHand.MAIN_HAND,original);}
   var params=new LootParams.Builder(level).withParameter(LootContextParams.ORIGIN,net.minecraft.world.phys.Vec3.atCenterOf(level.getSharedSpawnPos())).create(LootContextParamSets.CHEST);
   int guns=0,qualified=0,unqualified=0,copper=0;Set<Integer> tiers=new HashSet<>();
   for(String id:List.of("minecraft:chests/simple_dungeon","minecraft:chests/stronghold_library","idas:chests/dread_citadel/dread_citadel")){
    var table=level.getServer().getLootData().getLootTable(new ResourceLocation(id));for(int k=0;k<150;k++)for(ItemStack stack:table.getRandomItems(params))if(QualityModule.eligible(stack)){int t=QualityModule.tier(stack);if(t<0)unqualified++;else{qualified++;tiers.add(t);}if(QualityModule.gun(stack))guns++;if(ForgeRegistries.ITEMS.getKey(stack.getItem()).getNamespace().equals(CopperEquipment.ID))copper++;}
   }
   report.put("generatedEligible",qualified);report.put("generatedGuns",guns);report.put("generatedCopper",copper);report.put("generatedUnqualified",unqualified);report.put("generatedTiers",tiers);check(qualified>0&&guns>0&&copper>0&&unqualified==0,"loot ordering/missing tags");
   report.put("passed",true);
  }catch(Throwable failure){report.put("passed",false);report.put("error",failure.toString());failure.printStackTrace();}
  try{Files.writeString(Path.of("equipment-quality-regression.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));}catch(Exception e){throw new RuntimeException(e);}
 }
 private static String ComponentJson(ItemStack stack){return net.minecraft.network.chat.Component.Serializer.toJson(stack.getHoverName());}
}


