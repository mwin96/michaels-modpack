package net.michaelspack.equipment;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.Map;
import java.util.IdentityHashMap;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** References existing runtime artwork; no duplicated textures or custom shader. */
@Mod.EventBusSubscriber(modid = CopperEquipment.ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class EquipmentVisuals {
    public static final int COPPER_COLOR = 0xF5A467;
    public static final int EMERALD_COLOR = 0x51DE88;

    @SubscribeEvent
    public static void colors(RegisterColorHandlersEvent.Item event) {
        CopperEquipment.ALL.forEach((name, item) -> {
            if (name.startsWith("copper_")) {
                event.register((stack, layer) -> layer == 0 ? COPPER_COLOR : -1, item.get());
            } else if (name.startsWith("emerald_")) {
                event.register((stack, layer) -> layer == 0 ? EMERALD_COLOR : -1, item.get());
            }
        });
    }

    public static final IClientItemExtensions ARMOR = new IClientItemExtensions() {
        private final Map<HumanoidModel<?>, Model> models = new IdentityHashMap<>();

        @Override
        public Model getGenericArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot,
                                          HumanoidModel<?> original) {
            // Forward the already posed vanilla model. Nothing is copied or reset between slots.
            return models.computeIfAbsent(original, source -> new Model(RenderType::entityCutoutNoCull) {
                @Override
                public void renderToBuffer(PoseStack pose, VertexConsumer vertices, int light, int overlay,
                                           float red, float green, float blue, float alpha) {
                    source.renderToBuffer(pose, vertices, light, overlay,
                            red * 245.0F / 255.0F, green * 164.0F / 255.0F,
                            blue * 103.0F / 255.0F, alpha);
                }
            });
        }
    };

    private EquipmentVisuals() {}
}
