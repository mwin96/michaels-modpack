package net.michaelspack.equipment;
import java.util.*;
import java.nio.file.*;
import com.google.gson.GsonBuilder;
import net.minecraft.commands.Commands;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.util.FakePlayerFactory;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid=CopperEquipment.ID)
public final class QualityFlightRegression {
 @SubscribeEvent public static void command(RegisterCommandsEvent e){if(Boolean.getBoolean("michaels_equipment.validation"))e.getDispatcher().register(Commands.literal("michaelsqualityflight").requires(s->s.hasPermission(2)).executes(c->{run(c.getSource().getLevel());return 1;}));}
 public static void run(ServerLevel level){
  var report=new LinkedHashMap<String,Object>();var rows=new ArrayList<Map<String,Object>>();report.put("shots",rows);
  var owner=FakePlayerFactory.getMinecraft(level);var previous=owner.getMainHandItem().copy();var position=owner.position();
  try{
   var gunId=new ResourceLocation("tacz:ak47");var ammoId=new ResourceLocation("tacz:762x39");
   Class<?> api=Class.forName("com.tacz.guns.api.TimelessAPI");Object index=((Optional<?>)api.getMethod("getCommonGunIndex",ResourceLocation.class).invoke(null,gunId)).orElseThrow();
   Object data=index.getClass().getMethod("getGunData").invoke(index),bulletData=index.getClass().getMethod("getBulletData").invoke(index);
   Class<?> cacheClass=Class.forName("com.tacz.guns.resource.modifier.AttachmentCacheProperty"),operatorClass=Class.forName("com.tacz.guns.api.entity.IGunOperator"),bulletClass=Class.forName("com.tacz.guns.entity.EntityKineticBullet");
   var constructor=bulletClass.getConstructor(Level.class,LivingEntity.class,ItemStack.class,ResourceLocation.class,ResourceLocation.class,boolean.class,data.getClass(),bulletData.getClass());
   float base=0;level.getChunk(2,2);
   for(int t=-1;t<=3;t++){
    ItemStack gun=new ItemStack(ForgeRegistries.ITEMS.getValue(new ResourceLocation("tacz:modern_kinetic_gun")));gun.getOrCreateTag().putString("GunId",gunId.toString());gun.getOrCreateTag().putString("GunFireMode","AUTO");if(t>=0)QualityModule.assign(gun,t);
    owner.setItemInHand(InteractionHand.MAIN_HAND,gun);owner.setPos(20,250,32);
    Object cache=cacheClass.getConstructor().newInstance();cacheClass.getMethod("eval",ItemStack.class,data.getClass()).invoke(cache,gun,data);Object operator=operatorClass.getMethod("fromLivingEntity",LivingEntity.class).invoke(null,owner);operatorClass.getMethod("updateCacheProperty",cacheClass).invoke(operator,cache);
    LivingEntity target=EntityType.COW.create(level);target.setPos(32,250,32);target.xo=32;target.yo=250;target.zo=32;target.xOld=32;target.yOld=250;target.zOld=32;target.setNoGravity(true);((net.minecraft.world.entity.Mob)target).setNoAi(true);target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);target.setHealth(100);level.addFreshEntity(target);
    Projectile bullet=(Projectile)constructor.newInstance(level,owner,gun,ammoId,gunId,false,data,bulletData);bullet.setPos(24,250.6,32);float speed=((Number)bulletData.getClass().getMethod("getSpeed").invoke(bulletData)).floatValue()/20F;bullet.setDeltaMovement(speed,0,0);level.addFreshEntity(bullet);
    // Switch away after launch: the bonus must remain tied to the fired weapon.
    owner.setItemInHand(InteractionHand.MAIN_HAND,ItemStack.EMPTY);
    int candidates=level.getEntities(bullet,target.getBoundingBox().inflate(1)).size();
    int ticks=0;for(;ticks<12&&!bullet.isRemoved();ticks++)bullet.tick();float damage=100-target.getHealth();if(t==-1)base=damage;
    boolean pass=base>0&&Math.abs(damage-base*QualityModule.multiplier(t))<.02;
    rows.add(Map.of("tier",t,"damage",damage,"snapshot",bullet.getPersistentData().getInt(QualityModule.PROJECTILE_TAG),"flightTicks",ticks,"switchedHandAfterLaunch",true,"pass",pass,"candidates",candidates,"end",bullet.position().toString()));bullet.discard();target.discard();
   }
   report.put("passed",rows.stream().allMatch(r->Boolean.TRUE.equals(r.get("pass"))));
  }catch(Throwable e){report.put("passed",false);report.put("error",e.toString());e.printStackTrace();}
  finally{owner.setItemInHand(InteractionHand.MAIN_HAND,previous);owner.setPos(position.x,position.y,position.z);}
  try{Files.writeString(Path.of("equipment-quality-flight.json"),new GsonBuilder().setPrettyPrinting().create().toJson(report));}catch(Exception e){throw new RuntimeException(e);}
 }
}
