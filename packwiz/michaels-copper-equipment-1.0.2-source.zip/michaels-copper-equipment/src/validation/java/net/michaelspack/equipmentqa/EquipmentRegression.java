package net.michaelspack.equipmentqa;
import java.nio.file.*;
import java.util.*;
import net.michaelspack.equipment.CopperEquipment;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.crafting.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.*;
import net.minecraft.core.Direction;
import net.minecraftforge.registries.ForgeRegistries;
import com.google.gson.GsonBuilder;

/** External disposable fixture; compiled only into the separate regression JAR. */
public final class EquipmentRegression {
 public static void lootr(MinecraftServer server,String output)throws Exception{
  if(!Boolean.getBoolean("michaelspack.validation"))throw new IllegalStateException("Private validation server only");
  var level=server.overworld();var player=net.minecraftforge.common.util.FakePlayerFactory.getMinecraft(level);var type=Class.forName("noobanidus.mods.lootr.block.entities.LootrChestBlockEntity");var block=ForgeRegistries.BLOCKS.getValue(new ResourceLocation("lootr","lootr_chest"));var chest=type.getConstructor(BlockPos.class,net.minecraft.world.level.block.state.BlockState.class).newInstance(new BlockPos(28,250,28),block.defaultBlockState());((net.minecraft.world.level.block.entity.BlockEntity)chest).setLevel(level);var method=type.getMethod("unpackLootTable",net.minecraft.world.entity.player.Player.class,net.minecraft.world.Container.class,ResourceLocation.class,long.class);int eligible=0,quality=0,copper=0,guns=0;
  for(int seed=1;seed<=50;seed++){var inventory=new SimpleContainer(27);((net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity)chest).setLootTable(new ResourceLocation("minecraft","chests/simple_dungeon"),(long)seed);method.invoke(chest,player,inventory,new ResourceLocation("minecraft","chests/simple_dungeon"),(long)seed);for(int i=0;i<27;i++){ItemStack stack=inventory.getItem(i);if(net.michaelspack.equipment.QualityModule.eligible(stack)){eligible++;if(net.michaelspack.equipment.QualityModule.tier(stack)>=0)quality++;if(ForgeRegistries.ITEMS.getKey(stack.getItem()).getNamespace().equals(CopperEquipment.ID))copper++;if(net.michaelspack.equipment.QualityModule.gun(stack))guns++;}}}
  Files.writeString(Path.of(output),new GsonBuilder().setPrettyPrinting().create().toJson(Map.of("actualLootrUnpackCalls",50,"eligibleEquipment",eligible,"qualifiedEquipment",quality,"copper",copper,"guns",guns,"passed",eligible>0&&eligible==quality&&copper>0&&guns>0)));
 }
 public static void combat(MinecraftServer server,String output){
  if(!Boolean.getBoolean("michaelspack.validation"))throw new IllegalStateException("Private validation server only");
  Thread t=new Thread(()->{var result=new LinkedHashMap<String,Object>();List<Object> rows=new ArrayList<>();try{
   for(var entry:CopperEquipment.ALL.entrySet())if(entry.getKey().equals("copper_sword")||entry.getValue().get() instanceof CopperEquipment.ReachSword){
    var prepared=new java.util.concurrent.CompletableFuture<net.minecraft.world.entity.LivingEntity>();
    server.execute(()->{try{ServerPlayer p=server.getPlayerList().getPlayerByName("PackStackFix");p.setItemInHand(InteractionHand.MAIN_HAND,new ItemStack(entry.getValue().get()));var target=net.minecraft.world.entity.EntityType.COW.create(p.serverLevel());target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);target.setHealth(100);target.setNoAi(true);target.setNoGravity(true);target.setPos(p.getX(),p.getY(),p.getZ()+2);p.serverLevel().addFreshEntity(target);prepared.complete(target);}catch(Throwable e){prepared.completeExceptionally(e);}});
    var target=prepared.get();Thread.sleep(1400);var done=new java.util.concurrent.CompletableFuture<Void>();server.execute(()->{try{ServerPlayer p=server.getPlayerList().getPlayerByName("PackStackFix");float hp=target.getHealth();int before=target.invulnerableTime;p.attack(target);float damage=hp-target.getHealth();var row=new LinkedHashMap<String,Object>();row.put("id",entry.getKey());row.put("nativePlayerAttackDamage",damage);row.put("invulnerabilityBefore",before);row.put("attackAttribute",p.getAttributeValue(Attributes.ATTACK_DAMAGE));row.put("attackSpeed",p.getAttributeValue(Attributes.ATTACK_SPEED));row.put("entityReach",p.getAttributeValue(net.minecraftforge.common.ForgeMod.ENTITY_REACH.get()));row.put("pass",damage>1&&before==0);rows.add(row);target.discard();done.complete(null);}catch(Throwable e){done.completeExceptionally(e);}});done.get();
   }
   result.put("passed",rows.size()==16&&rows.stream().allMatch(o->Boolean.TRUE.equals(((Map<?,?>)o).get("pass"))));
  }catch(Throwable e){result.put("error",e.toString());result.put("passed",false);}result.put("attacks",rows);try{Files.writeString(Path.of(output),new GsonBuilder().setPrettyPrinting().create().toJson(result));}catch(Exception ignored){}} ,"private-equipment-native-combat");t.setDaemon(true);t.start();
 }
 public static void run(MinecraftServer server,String output)throws Exception{
  if(!Boolean.getBoolean("michaelspack.validation"))throw new IllegalStateException("Private validation server only");
  ServerPlayer p=server.getPlayerList().getPlayerByName("PackStackFix");if(p==null)throw new IllegalStateException("Private client not joined");
  var result=new LinkedHashMap<String,Object>();List<Object> recipes=new ArrayList<>(),stats=new ArrayList<>(),paxels=new ArrayList<>();boolean passed=true;
  var level=p.serverLevel();BlockPos bench=new BlockPos(20,250,20);level.setBlockAndUpdate(bench,Blocks.CRAFTING_TABLE.defaultBlockState());
  for(var e:CopperEquipment.ALL.entrySet()){
   String name=e.getKey();Item item=e.getValue().get();var row=new LinkedHashMap<String,Object>();row.put("id",name);boolean ok=true;
   try{
    Recipe<?> recipe=server.getRecipeManager().byKey(new ResourceLocation(CopperEquipment.ID,name)).orElseThrow();
    if(recipe instanceof ShapedRecipe shaped){
     CraftingMenu menu=new CraftingMenu(92,p.getInventory(),ContainerLevelAccess.create(level,bench));
     List<Ingredient> ingredients=shaped.getIngredients();int used=0;
     for(int y=0;y<shaped.getHeight();y++)for(int x=0;x<shaped.getWidth();x++){ItemStack[] choices=ingredients.get(y*shaped.getWidth()+x).getItems();if(choices.length>0){ItemStack in=choices[0].copy();in.setCount(1);menu.getSlot(1+y*3+x).set(in);used++;}}
     menu.slotsChanged(menu.getSlot(1).container);
     ItemStack before=menu.getSlot(0).getItem().copy();row.put("outputBeforeClick",before.toString());
     menu.clicked(0,0,ClickType.PICKUP,p);ItemStack made=menu.getCarried();
     int remaining=0;for(int i=1;i<=9;i++)remaining+=menu.getSlot(i).getItem().getCount();
     ok=made.is(item)&&made.getCount()==1&&remaining==0;
     row.put("nativeMenuCrafted",ok);row.put("consumedSlots",used);row.put("remainingIngredientCount",remaining);row.put("craftedHasQuality",made.hasTag()&&made.getTag().contains("MichaelsLootQuality"));if(made.hasTag()&&made.getTag().contains("MichaelsLootQuality"))ok=false;
     menu.setCarried(ItemStack.EMPTY);
    } else if(recipe instanceof SmithingTransformRecipe){
     SmithingMenu menu=new SmithingMenu(93,p.getInventory(),ContainerLevelAccess.create(level,bench));
     menu.getSlot(0).set(new ItemStack(Items.NETHERITE_UPGRADE_SMITHING_TEMPLATE));ItemStack diamond=new ItemStack(CopperEquipment.ALL.get("diamond_paxel").get());diamond.getOrCreateTag().putString("QaMeaningful","preserve_me");menu.getSlot(1).set(diamond);menu.getSlot(2).set(new ItemStack(Items.NETHERITE_INGOT));menu.slotsChanged(menu.getSlot(1).container);
     menu.clicked(3,0,ClickType.PICKUP,p);ItemStack made=menu.getCarried();ok=made.is(item)&&made.getCount()==1&&made.hasTag()&&"preserve_me".equals(made.getTag().getString("QaMeaningful"));for(int i=0;i<3;i++)ok&=menu.getSlot(i).getItem().isEmpty();row.put("nativeSmithingCrafted",ok);row.put("meaningfulNbtRetained",made.hasTag()&&"preserve_me".equals(made.getTag().getString("QaMeaningful")));menu.setCarried(ItemStack.EMPTY);
    } else ok=false;
   }catch(Throwable ex){row.put("error",ex.toString());ok=false;}
   row.put("passed",ok);passed&=ok;recipes.add(row);
   ItemStack stack=new ItemStack(item);var stat=new LinkedHashMap<String,Object>();stat.put("id",name);stat.put("durability",stack.getMaxDamage());stat.put("enchantability",item.getEnchantmentValue(stack));stat.put("translation",stack.getHoverName().getString());
   if(item instanceof TieredItem ti){stat.put("tierLevel",ti.getTier().getLevel());stat.put("miningSpeed",ti.getTier().getSpeed());stat.put("repairCopper",item.isValidRepairItem(stack,new ItemStack(Items.COPPER_INGOT)));}
   if(item instanceof ArmorItem ai){stat.put("armor",ai.getDefense());stat.put("slot",ai.getEquipmentSlot().toString());stat.put("repairCopper",item.isValidRepairItem(stack,new ItemStack(Items.COPPER_INGOT)));}
   var attack=item.getDefaultAttributeModifiers(EquipmentSlot.MAINHAND);stat.put("attackModifiers",attack.toString());stats.add(stat);
   if(name.endsWith("paxel")){
    var q=new LinkedHashMap<String,Object>();q.put("id",name);q.put("stoneSpeed",item.getDestroySpeed(stack,Blocks.STONE.defaultBlockState()));q.put("woodSpeed",item.getDestroySpeed(stack,Blocks.OAK_LOG.defaultBlockState()));q.put("dirtSpeed",item.getDestroySpeed(stack,Blocks.DIRT.defaultBlockState()));q.put("ironOre",item.isCorrectToolForDrops(stack,Blocks.IRON_ORE.defaultBlockState()));q.put("diamondOre",item.isCorrectToolForDrops(stack,Blocks.DIAMOND_ORE.defaultBlockState()));q.put("obsidian",item.isCorrectToolForDrops(stack,Blocks.OBSIDIAN.defaultBlockState()));
    p.setItemInHand(InteractionHand.MAIN_HAND,stack);BlockPos use=bench.offset(2,0,0);level.setBlockAndUpdate(use,Blocks.OAK_LOG.defaultBlockState());UseOnContext context=new UseOnContext(p,InteractionHand.MAIN_HAND,new BlockHitResult(Vec3.atCenterOf(use),Direction.UP,use,false));InteractionResult strip=item.useOn(context);boolean stripped=level.getBlockState(use).is(Blocks.STRIPPED_OAK_LOG);level.setBlockAndUpdate(use,Blocks.GRASS_BLOCK.defaultBlockState());level.setBlockAndUpdate(use.above(),Blocks.AIR.defaultBlockState());InteractionResult flatten=item.useOn(context);boolean path=level.getBlockState(use).is(Blocks.DIRT_PATH);q.put("strippedLog",stripped);q.put("flattenedPath",path);q.put("usedDurability",stack.getDamageValue());boolean toolOk=stripped&&path&&((Number)q.get("stoneSpeed")).doubleValue()>1&&((Number)q.get("woodSpeed")).doubleValue()>1&&((Number)q.get("dirtSpeed")).doubleValue()>1;boolean copper=name.startsWith("copper");toolOk&=Boolean.TRUE.equals(q.get("ironOre"))&&Boolean.valueOf(!copper).equals(q.get("diamondOre"))&&Boolean.valueOf(name.startsWith("diamond")||name.startsWith("netherite")).equals(q.get("obsidian"));q.put("passed",toolOk);passed&=toolOk;paxels.add(q);
   }
  }
  result.put("recipes",recipes);result.put("itemStats",stats);result.put("paxels",paxels);result.put("registeredItems",CopperEquipment.ALL.size());result.put("passed",passed);
  // Leave a bounded visual inventory of all28 originals, plus worn copper armor, for private screenshots.
  p.getInventory().clearContent();int i=0;for(var item:CopperEquipment.ALL.values())p.getInventory().setItem(i++,new ItemStack(item.get()));
  p.setItemSlot(EquipmentSlot.HEAD,new ItemStack(CopperEquipment.ALL.get("copper_helmet").get()));p.setItemSlot(EquipmentSlot.CHEST,new ItemStack(CopperEquipment.ALL.get("copper_chestplate").get()));p.setItemSlot(EquipmentSlot.LEGS,new ItemStack(CopperEquipment.ALL.get("copper_leggings").get()));p.setItemSlot(EquipmentSlot.FEET,new ItemStack(CopperEquipment.ALL.get("copper_boots").get()));p.inventoryMenu.broadcastChanges();
  Files.writeString(Path.of(output),new GsonBuilder().setPrettyPrinting().create().toJson(result));
 }
}
