"""Reproducible noncommercial Quark4.0-462 adaptation: omit only wooden posts."""
from pathlib import Path
import copy
import argparse
import hashlib
import io
import json
import struct
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
ORIGINAL=WORK/'downloads/Quark-4.0-462.jar'
ORIGINAL_SHA='c90b96f049d92825c4a103721988c80d72e5ad380d17be46a0f53e114874c478'
ORIGINAL_URL='https://cdn.modrinth.com/data/qnQsVE2z/versions/DijQLauD/Quark-4.0-462.jar'
ART=ROOT/'artifacts'
NAME='michaels-quark-4.0-462-no-posts.jar'
SOURCE='michaels-quark-4.0-462-no-posts-source.zip'
MODULE='org/violetmoon/quark/content/building/module/WoodenPostsModule.class'
HANDLER='org/violetmoon/quark/base/handler/WoodSetHandler.class'
U2=lambda b,p:struct.unpack_from('>H',b,p)[0]
U4=lambda b,p:struct.unpack_from('>I',b,p)[0]
SHA=lambda b:hashlib.sha256(b).hexdigest()

def class_info(raw):
    assert raw[:4]==b'\xca\xfe\xba\xbe'
    cp={};p=10;i=1
    while i<U2(raw,8):
        tag=raw[p];p+=1
        if tag==1:
            n=U2(raw,p);p+=2;value=raw[p:p+n].decode('utf-8');p+=n
        elif tag in (3,4):value=raw[p:p+4];p+=4
        elif tag in (5,6):value=raw[p:p+8];p+=8
        elif tag in (7,8,16,19,20):value=U2(raw,p);p+=2
        elif tag in (9,10,11,12,17,18):value=(U2(raw,p),U2(raw,p+2));p+=4
        elif tag==15:value=(raw[p],U2(raw,p+1));p+=3
        else:raise AssertionError(('Unknown CP tag',tag))
        cp[i]=(tag,value)
        i+=2 if tag in (5,6) else 1
    utf=lambda n:cp[n][1]
    p+=6;p+=2+U2(raw,p)*2
    def member(p):
        start=p;name=utf(U2(raw,p+2));desc=utf(U2(raw,p+4));count=U2(raw,p+6);p+=8;attrs=[]
        for _ in range(count):
            start_attr=p;name_attr=utf(U2(raw,p));size=U4(raw,p+2);p+=6
            attrs.append((name_attr,start_attr,p,size));p+=size
        return p,{'start':start,'end':p,'name':name,'desc':desc,'attrs':attrs}
    count=U2(raw,p);p+=2
    for _ in range(count):p,_=member(p)
    count=U2(raw,p);p+=2;methods=[]
    for _ in range(count):p,m=member(p);methods.append(m)
    return cp,methods

def code_attribute(raw,name,desc=None):
    cp,methods=class_info(raw)
    found=[(m,a) for m in methods if m['name']==name and (desc is None or m['desc']==desc) for a in m['attrs'] if a[0]=='Code']
    assert len(found)==1,(name,desc)
    return cp,found[0]

def patch_module(raw):
    _,(_,(_,start,p,size))=code_attribute(raw,'register','(Lorg/violetmoon/zeta/event/load/ZRegister;)V')
    replacement=struct.pack('>HHI',0,2,1)+b'\xb1'+struct.pack('>HH',0,0)
    return raw[:start+2]+struct.pack('>I',len(replacement))+replacement+raw[p+size:]

def field_ref(cp,name):
    owner='org/violetmoon/quark/base/handler/WoodSetHandler$WoodSet'
    result=[]
    for i,(tag,value) in cp.items():
        if tag!=9:continue
        cls,nt=value
        if cp[cp[cls][1]][1]==owner and cp[cp[nt][1][0]][1]==name:result.append(i)
    assert len(result)==1,(name,result)
    return result[0]

def patch_custom_posts(raw):
    cp,(_,(_,_,p,_))=code_attribute(raw,'addWoodSet')
    code_start=p+8;length=U4(raw,p+4);code=raw[code_start:code_start+length]
    # This exact pinned branch-free construction span has no stack-map or jump target inside it.
    start,end=891,953
    assert code[start:start+2]==b'\x19\x09' and code[end:end+1]==b'\x2b'
    post,stripped=field_ref(cp,'post'),field_ref(cp,'strippedPost')
    log,stripped_log=field_ref(cp,'log'),field_ref(cp,'strippedLog')
    old=code[start:end]
    assert old[2]==0xbb and old[33]==0xbb
    assert old[28:31]==b'\xb5'+struct.pack('>H',post)
    assert old[59:62]==b'\xb5'+struct.pack('>H',stripped)
    # Preserve native WoodSet references without constructing/registering any post. Existing
    # Zeta registerInteraction uses Map.put; the later duplicate log->stripped-log entry is identical.
    replacement=(b'\x19\x09\x59\xb4'+struct.pack('>H',log)+b'\xb5'+struct.pack('>H',post)
                +b'\x19\x09\x59\xb4'+struct.pack('>H',stripped_log)+b'\xb5'+struct.pack('>H',stripped))
    replacement+=b'\x00'*((end-start)-len(replacement))
    assert len(replacement)==62
    changed=raw[:code_start+start]+replacement+raw[code_start+end:]
    assert len(changed)==len(raw) and changed[:code_start+start]==raw[:code_start+start] and changed[code_start+end:]==raw[code_start+end:]
    return changed,{'method':'addWoodSet','codeSpan':[start,end],'replacedBytes':62,
        'replacement':'woodSet.post=woodSet.log; woodSet.strippedPost=woodSet.strippedLog; NOP padding',
        'allOtherMethodBytesAndClassAttributesPreserved':True,'originalSpanSha256':SHA(old),'replacementSpanSha256':SHA(replacement)}

NOTICE='''Michael's noncommercial Quark4.0-462 no-posts adaptation

Original work: Quark, by Vazkii, WireSegal, MCVinnyq, Sully and the Violet Moon contributors.
https://quarkmod.net/  https://github.com/VazkiiMods/Quark
Original license and this adaptation: CC BY-NC-SA3.0 Unported.
https://creativecommons.org/licenses/by-nc-sa/3.0/

Changes by Michael's friend modpack,2026-11-06: omit WoodenPostsModule registrations;
omit the shared WoodSetHandler's six custom post registrations while retaining every other
custom-wood construction; remove only28 post recipes,28 post loot tables and post entries in5 tags.
Inert original post artwork remains unchanged. The original mod ID/version and all other
archive entry contents remain. This is an independently modified build, not endorsed by the
original authors. This free friend pack is noncommercial; the derivative retains NC/SA terms.
Reproducible patch source accompanies the modified file.
'''

def build(input_path=ORIGINAL):
    ART.mkdir(parents=True,exist_ok=True)
    original=input_path.read_bytes()
    assert SHA(original)==ORIGINAL_SHA
    license_path=ROOT/'LICENSE-Quark-CC-BY-NC-SA-3.0.md'
    if not license_path.exists():
        request=urllib.request.Request('https://raw.githubusercontent.com/VazkiiMods/Quark/master/LICENSE.md',headers={'User-Agent':'MichaelsNoncommercialQuarkPatch/1.0.7'})
        license_path.write_bytes(urllib.request.urlopen(request,timeout=20).read())
    license_raw=license_path.read_bytes()
    assert b'Attribution-NonCommercial-ShareAlike 3.0' in license_raw
    with zipfile.ZipFile(io.BytesIO(original)) as source:
        assert not any(n.startswith('META-INF/') and n.upper().endswith(('.RSA','.DSA','.SF')) for n in source.namelist())
        ids={'quark:'+Path(n).stem for n in source.namelist() if n.startswith('assets/quark/blockstates/') and n.endswith('_post.json')}
        assert len(ids)==28
        module=patch_module(source.read(MODULE))
        assert patch_module(module)==module
        handler,proof=patch_custom_posts(source.read(HANDLER))
        removed=[];modified=[];same=[];out=io.BytesIO()
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as target:
            for entry in source.infolist():
                name=entry.filename;data=source.read(entry)
                if name==MODULE:data=module;modified.append(name)
                elif name==HANDLER:data=handler;modified.append(name)
                elif name.startswith('data/') and name.endswith('.json') and any(('"'+i+'"').encode() in data for i in ids):
                    parsed=json.loads(data)
                    if '/tags/' in name:
                        parsed['values']=[v for v in parsed['values'] if (v if isinstance(v,str) else v.get('id')) not in ids]
                        data=(json.dumps(parsed,indent=2)+'\n').encode();modified.append(name)
                    elif '/recipes/' in name or '/loot_tables/blocks/' in name:
                        removed.append(name);continue
                    else:raise AssertionError(('Unexpected post data use',name))
                else:same.append(name)
                target.writestr(copy.copy(entry),data)
            for name,raw in [('META-INF/MICHAELS-NO-POSTS-NOTICE.txt',NOTICE.encode()),('META-INF/LICENSE-Quark-CC-BY-NC-SA-3.0.md',license_raw)]:
                entry=zipfile.ZipInfo(name,(2026,11,5,17,36,32));entry.compress_type=zipfile.ZIP_DEFLATED
                entry.external_attr=0o600<<16
                target.writestr(entry,raw,compresslevel=1)
        data=out.getvalue()
        with zipfile.ZipFile(io.BytesIO(data)) as check:
            assert check.testzip() is None
            assert len(modified)==7 and len(removed)==56
            assert all(source.read(n)==check.read(n) for n in same)
            assert all(not any(('"'+i+'"').encode() in check.read(n) for i in ids) for n in check.namelist() if n.startswith('data/') and n.endswith('.json'))
    target=ART/NAME;target.write_bytes(data)
    (ROOT/'MODIFICATION-NOTICE.txt').write_text(NOTICE,encoding='utf-8')
    source_notes={'inputJar':input_path.name,'inputSha256':SHA(original),'upstreamLicense':'CC BY-NC-SA3.0 Unported',
        'upstreamAuthors':'Vazkii, WireSegal, MCVinnyq, Sully and Violet Moon contributors',
        'sourceScope':'Complete original patch source, exact binary input pin and reproducible transformations. No claim that current upstream branch is byte-identical corresponding source.',
        'run':'Download the exact original from originalDownload, then python patch_quark_no_posts.py --input Quark-4.0-462.jar. Output appears in artifacts beside this script. No JVM/Gradle compilation required.',
        'originalDownload':ORIGINAL_URL}
    (ROOT/'SOURCE-NOTES.json').write_text(json.dumps(source_notes,indent=2)+'\n')
    archive=ART/SOURCE
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for p in [Path(__file__),license_path,ROOT/'MODIFICATION-NOTICE.txt',ROOT/'SOURCE-NOTES.json']:
            entry=zipfile.ZipInfo(p.name,(2026,11,6,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,p.read_bytes())
    report={'status':'PRIVATE_PATCH_BUILT_NATIVE_PENDING','nativePassed':False,'releaseApproved':False,
        'jar':str(target.resolve()),'jarSha256':SHA(data),'source':str(archive.resolve()),'sourceSha256':SHA(archive.read_bytes()),
        'originalJarSha256':SHA(original),'license':'CC BY-NC-SA3.0 Unported','modifiedOriginalEntries':modified,'removedOriginalEntries':removed,
        'allOtherOriginalEntryBytesPreserved':True,'sameOriginalEntries':len(same),'removedPostIds':sorted(ids),'customWoodPatch':proof,
        'constructionCrossReferences':'Only WoodSetHandler and its WoodSet record reference post/strippedPost fields in the exact Quark jar.',
        'strippingCompatibility':'Pinned Zeta1.0-31 registerInteraction uses Map.put; existing duplicated log->stripped-log assignment retains the identical mapping.',
        'expectedAdditionalNativeStatesRemoved':26244,'texturesModifiedOrBundled':0,'originalAuthorsCredited':True,'upstreamEndorsementClaimed':False}
    (ROOT/'candidate-artifacts.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['jar','jarSha256','source','sourceSha256','expectedAdditionalNativeStatesRemoved','nativePassed']},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ORIGINAL)
    build(parser.parse_args().input)
