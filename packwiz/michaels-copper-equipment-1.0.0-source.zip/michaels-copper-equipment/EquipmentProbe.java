import java.lang.instrument.Instrumentation;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import com.sun.tools.attach.VirtualMachine;
public class EquipmentProbe {
 public static void agentmain(String args,Instrumentation inst)throws Exception{
  if(!Boolean.getBoolean("michaelspack.validation"))throw new IllegalStateException("Private validation process only");
  String[] a=args.split("\\|",3);Class<?> hooks=Arrays.stream(inst.getAllLoadedClasses()).filter(c->c.getName().equals("net.minecraftforge.server.ServerLifecycleHooks")).findFirst().orElseThrow();ClassLoader game=hooks.getClassLoader();Object server=hooks.getMethod("getCurrentServer").invoke(null);URLClassLoader fixture=new URLClassLoader(new URL[]{Path.of(a[0]).toUri().toURL()},game);String mode=a.length>2?a[2]:"run";Class<?> test=Class.forName(mode.equals("quality")?"net.michaelspack.equipment.QualityRegression":mode.equals("flight")?"net.michaelspack.equipment.QualityFlightRegression":"net.michaelspack.equipmentqa.EquipmentRegression",true,fixture);
  server.getClass().getMethod("execute",Runnable.class).invoke(server,(Runnable)()->{try{if(mode.equals("quality")||mode.equals("flight"))test.getMethod("run",Class.forName("net.minecraft.server.level.ServerLevel",true,game)).invoke(null,server.getClass().getMethod("m_129783_").invoke(server));else test.getMethod(mode,Class.forName("net.minecraft.server.MinecraftServer",true,game),String.class).invoke(null,server,a[1]);}catch(Throwable e){try{Files.writeString(Path.of(a[1]),"ERROR "+e+" cause="+e.getCause());}catch(Exception ignored){}}finally{try{fixture.close();}catch(Exception ignored){}}});
 }
 public static void main(String[] a)throws Exception{var vm=VirtualMachine.attach(a[0]);try{vm.loadAgent(a[1],a[2]);}finally{vm.detach();}}
}
