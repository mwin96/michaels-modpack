from pathlib import Path
import shutil,subprocess,json
R=Path(__file__).resolve().parent.parent;S=R/'server-fixes-test';E=R/'equipment-103'
for process in [23832,33460]:
 # Old owned QA processes were already stopped normally; never target another instance.
 pass
jar=E/'build/libs/michaels-copper-equipment-1.0.0.jar'
assert jar.exists()
shutil.copy2(jar,S/'mods'/jar.name);shutil.copy2(jar,R/'release-import-client-9376c18bce/mods'/jar.name)
src=R/'quality-103/overrides/config/openloader/data/michaels_equipment_quality'
shutil.copytree(src,S/'config/openloader/data/michaels_equipment_quality',dirs_exist_ok=True)
shutil.copytree(R/'server/tacz/michaels_loot',S/'tacz/michaels_loot',dirs_exist_ok=True)
log=open(E/'private-server-console.log','w',encoding='utf-8')
p=subprocess.Popen([str(R/'tools/jdk-17.0.21+9/bin/java.exe'),'-Xms1G','-Xmx4G','-XX:ActiveProcessorCount=4','-Djava.awt.headless=true','-Dmichaels_server_fixes.validation=true','-Dmichaels_equipment.validation=true','-Dmichaelspack.validation=true','@libraries/net/minecraftforge/forge/1.20.1-47.4.28/win_args.txt','nogui'],cwd=S,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
(S/'process.json').write_text(json.dumps({'serverPid':p.pid,'ownedBy':'artifact_audit','port':25581,'rconPort':25582}))
print('Private equipment test server PID',p.pid)
