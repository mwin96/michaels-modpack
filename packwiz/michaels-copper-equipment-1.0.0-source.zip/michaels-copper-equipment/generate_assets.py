"""Original pixel artwork, models, recipes and tags; no upstream textures copied."""
from pathlib import Path
from PIL import Image,ImageDraw
import json
R=Path(__file__).resolve().parent/'src/main/resources';NS='michaels_equipment'
def js(p,d):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
families=['cutlass','rapier','glaive','warglaive','spear','sai','katana','claymore','longsword','twinblade','greathammer','greataxe','chakram','scythe','halberd']
armor=['helmet','chestplate','leggings','boots'];tools=['sword','pickaxe','axe','shovel','hoe']
names=['copper_'+n for n in armor+tools+families]+[n+'_paxel' for n in ['copper','iron','diamond','netherite']]
js(Path('pack.mcmeta'),{'pack':{'pack_format':15,'description':'Original copper equipment assets'}})
js(Path('assets')/NS/'lang/en_us.json',{'item.'+NS+'.'+n:n.replace('_',' ').title() for n in names})
for n in names:js(Path('assets')/NS/'models/item'/f'{n}.json',{'parent':'minecraft:item/generated' if n.split('_',1)[1] in armor else 'minecraft:item/handheld','textures':{'layer0':NS+':item/'+n}})
patterns={'helmet':['CCC','C C'],'chestplate':['C C','CCC','CCC'],'leggings':['CCC','C C','C C'],'boots':['C C','C C'],'sword':['C','C','S'],'pickaxe':['CCC',' S ',' S '],'axe':['CC','CS',' S'],'shovel':['C','S','S'],'hoe':['CC',' S',' S'],'cutlass':[' CC',' C ',' S '],'rapier':['  C',' C ','S  '],'glaive':['  C',' SC','S  '],'warglaive':['C C',' C ',' S '],'spear':[' C ','CSC',' S '],'sai':['CCC',' S '],'katana':['  C',' C ',' S '],'claymore':['CCC',' C ',' S '],'longsword':[' C ','CCC',' S '],'twinblade':[' C ',' S ',' C '],'greathammer':['CCC','CSC',' S '],'greataxe':['CCC','CS ',' S '],'chakram':['CCC','C C','CCC'],'scythe':['CCC','  S','  S'],'halberd':[' CC',' CS',' S ']}
def canonical(p):
 rows=[r.rstrip() for r in p];left=min(len(r)-len(r.lstrip()) for r in rows if r.strip());rows=[r[left:] for r in rows];width=max(map(len,rows));rows=[r.ljust(width) for r in rows];return min(tuple(rows),tuple(r[::-1] for r in rows))
from collections import defaultdict
collisions=defaultdict(list)
for k,v in patterns.items():collisions[canonical(v)].append(k)
assert len(collisions)==len(patterns),str([v for v in collisions.values() if len(v)>1])
for n,p in patterns.items():
 key={'C':{'item':'minecraft:copper_ingot'}}
 if any('S' in row for row in p):key['S']={'item':'minecraft:stick'}
 js(Path('data')/NS/'recipes'/f'copper_{n}.json',{'type':'minecraft:crafting_shaped','category':'equipment','pattern':p,'key':key,'result':{'item':NS+':copper_'+n}})
for tier in ['copper','iron','diamond']:
 toolns=NS if tier=='copper' else 'minecraft'
 js(Path('data')/NS/'recipes'/f'{tier}_paxel.json',{'type':'minecraft:crafting_shaped','category':'equipment','pattern':['APS',' T ',' T '],'key':{'A':{'item':toolns+':'+tier+'_axe'},'P':{'item':toolns+':'+tier+'_pickaxe'},'S':{'item':toolns+':'+tier+'_shovel'},'T':{'item':'minecraft:stick'}},'result':{'item':NS+':'+tier+'_paxel'}})
js(Path('data')/NS/'recipes/netherite_paxel.json',{'type':'minecraft:smithing_transform','template':{'item':'minecraft:netherite_upgrade_smithing_template'},'base':{'item':NS+':diamond_paxel'},'addition':{'item':'minecraft:netherite_ingot'},'result':{'item':NS+':netherite_paxel'}})
for tag,vals in {'swords':['copper_sword']+['copper_'+n for n in families],'pickaxes':['copper_pickaxe']+[n+'_paxel' for n in ['copper','iron','diamond','netherite']],'axes':['copper_axe']+[n+'_paxel' for n in ['copper','iron','diamond','netherite']],'shovels':['copper_shovel']+[n+'_paxel' for n in ['copper','iron','diamond','netherite']],'hoes':['copper_hoe'],'trim_materials':[]}.items():
 if vals:js(Path('data/minecraft/tags/items')/f'{tag}.json',{'replace':False,'values':[NS+':'+n for n in vals]})
for tag,vals in {'armors':['copper_'+n for n in armor],'tools':['copper_'+n for n in tools]+[n+'_paxel' for n in ['copper','iron','diamond','netherite']],'tools/swords':['copper_sword']+['copper_'+n for n in families]}.items():js(Path('data/forge/tags/items')/f'{tag}.json',{'replace':False,'values':[NS+':'+n for n in vals]})
for part in armor:js(Path('data/forge/tags/items/armors')/f'{part if part in ("leggings","boots") else part+"s"}.json',{'replace':False,'values':[NS+':copper_'+part]})
# Recipe-book unlocks; recipes remain available in ordinary crafting/JEI.
for n in names:
 req='minecraft:diamond' if n.startswith(('diamond','netherite')) else 'minecraft:iron_ingot' if n.startswith('iron') else 'minecraft:copper_ingot'
 js(Path('data')/NS/'advancements/recipes'/f'{n}.json',{'parent':'minecraft:recipes/root','criteria':{'has_material':{'trigger':'minecraft:inventory_changed','conditions':{'items':[{'items':[req]}]}},'has_the_recipe':{'trigger':'minecraft:recipe_unlocked','conditions':{'recipe':NS+':'+n}}},'requirements':[['has_material','has_the_recipe']],'rewards':{'recipes':[NS+':'+n]}})
copper=('#2f211c','#aa542e','#da884d','#ffd28b');wood='#664728';woodlight='#a97c42'
def art(n):
 im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im);out,base,light,shine=copper
 if n.startswith('iron'):out,base,light,shine='#25272c','#8b929e','#cbd3db','#f1f6ff'
 if n.startswith('diamond'):out,base,light,shine='#173936','#239f9c','#5ce5d4','#c5fff4'
 if n.startswith('netherite'):out,base,light,shine='#181319','#403746','#766475','#b49f9d'
 kind=n.split('_',1)[1]
 def poly(points):
  d.polygon(points,fill=base,outline=out);d.line(points[:-1],fill=light,width=1)
 if kind in armor:
  if kind=='helmet':poly([(6,7),(10,3),(22,3),(26,7),(26,23),(21,23),(21,13),(11,13),(11,23),(6,23)]);d.rectangle((8,7,23,10),fill=light);d.rectangle((12,5,19,7),fill=shine)
  if kind=='chestplate':poly([(3,5),(10,3),(12,8),(20,8),(22,3),(29,5),(29,16),(24,16),(24,28),(8,28),(8,16),(3,16)]);d.rectangle((11,11,20,22),fill=light);d.line((12,11,12,21),fill=shine,width=2)
  if kind=='leggings':poly([(7,3),(25,3),(25,28),(18,28),(18,15),(14,15),(14,28),(7,28)]);d.line((9,7,23,7),fill=shine,width=2);d.line((10,11,10,25),fill=light,width=2);d.line((21,11,21,25),fill=light,width=2)
  if kind=='boots':poly([(6,7),(14,7),(14,27),(3,27),(3,21),(6,21)]);poly([(19,7),(27,7),(27,21),(30,21),(30,27),(19,27)]);d.line((8,10,11,10),fill=shine,width=2);d.line((21,10,24,10),fill=shine,width=2)
  return im
 d.line((15,28,15,14),fill=out,width=5);d.line((15,27,15,14),fill=wood,width=3);d.line((14,25,14,15),fill=woodlight,width=1)
 if kind in ['axe','greataxe','paxel']:
  poly([(5,4),(12,3),(18,7),(19,16),(12,17),(5,14)]);d.rectangle((15,5,20,9),fill=light)
  if kind=='paxel':poly([(17,5),(25,6),(29,11),(25,10),(20,9),(18,12)])
 elif kind in ['pickaxe','hoe']:
  poly([(4,5),(14,3),(23,5),(28,11),(22,8),(12,7),(6,10)])
  if kind=='hoe':d.rectangle((21,7,25,12),fill=base)
 elif kind=='shovel':poly([(11,3),(19,3),(21,10),(17,15),(13,15),(9,10)])
 elif kind=='greathammer':poly([(4,3),(27,3),(27,12),(4,12)]);d.rectangle((8,5,22,7),fill=light);d.point((8,5),fill=shine)
 elif kind=='chakram':
  im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im);d.ellipse((4,4,27,27),fill=base,outline=out,width=2);d.ellipse((9,9,22,22),fill=(0,0,0,0),outline=light,width=2);d.arc((6,6,25,25),190,290,fill=shine,width=2);return im
 elif kind=='scythe':poly([(2,3),(22,3),(26,7),(26,16),(22,10),(15,8),(3,7)])
 elif kind in ['glaive','halberd','spear']:
  poly([(15,0),(19,6),(18,13),(15,17),(12,13),(11,6)]);
  if kind=='halberd':poly([(17,6),(25,5),(25,13),(18,13)])
  if kind=='glaive':poly([(16,0),(23,5),(20,13),(16,17),(14,12)])
 elif kind=='warglaive':poly([(4,3),(11,5),(16,10),(21,5),(28,3),(24,12),(16,17),(8,12)])
 elif kind=='sai':poly([(15,1),(17,14),(23,9),(23,17),(16,20),(8,17),(8,9),(13,14)])
 elif kind=='twinblade':poly([(15,0),(18,4),(18,12),(15,16),(12,12),(12,4)]);poly([(15,20),(18,24),(18,29),(15,31),(12,29),(12,24)])
 else:
  width=1 if kind=='rapier' else 3 if kind in ['claymore','longsword'] else 2
  tip=0 if kind in ['longsword','claymore'] else 2
  poly([(15,tip),(15+width,tip+4),(15+width,17),(15-width,17),(15-width,tip+4)])
  if kind=='katana':d.line((17,4,18,14),fill=light,width=2)
  if kind=='cutlass':poly([(15,2),(20,6),(19,15),(16,18),(13,16),(14,6)])
  d.rectangle((9,17,21,19),fill=out);d.rectangle((10,17,20,18),fill=light)
 return im.rotate(-40,resample=Image.Resampling.NEAREST)
out=R/'assets'/NS/'textures/item';out.mkdir(parents=True,exist_ok=True)
sheet=Image.new('RGBA',(7*144,4*164),(30,32,37,255));sd=ImageDraw.Draw(sheet)
for i,n in enumerate(names):
 im=art(n);im.save(out/(n+'.png'));x=(i%7)*144;y=(i//7)*164;sheet.alpha_composite(im.resize((112,112),Image.Resampling.NEAREST),(x+16,y));sd.text((x+4,y+119),n.replace('_','\n',1),fill='white')
sheet.save(Path(__file__).resolve().parent/'original-art-contact-sheet.png')
# Native armor UV: all standard cuboid faces are textured, with simple rivets/banding.
out=R/'assets'/NS/'textures/models/armor';out.mkdir(parents=True,exist_ok=True)
for layer in [1,2]:
 im=Image.new('RGBA',(64,32),copper[1]);d=ImageDraw.Draw(im)
 for y in range(32):d.line((0,y,63,y),fill=copper[2] if y%8 in (1,2) else copper[0] if y%8==7 else copper[1])
 for x in range(0,64,8):
  for y in range(0,32,8):d.point((x+1,y+1),fill=copper[3]);d.line((x,y+7,x+7,y+7),fill=copper[0])
 im.save(out/f'copper_layer_{layer}.png')
print(f'Generated{len(names)} original item textures/models,28 recipes+advancements,2armor layers')

