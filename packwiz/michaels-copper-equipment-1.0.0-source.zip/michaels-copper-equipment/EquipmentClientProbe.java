import java.lang.instrument.Instrumentation;
import java.nio.file.*;
import java.util.*;
import com.sun.tools.attach.VirtualMachine;
public class EquipmentClientProbe {
 static ClassLoader l;
 static Class<?> c(String s)throws Exception{return Class.forName(s,true,l);}
 static Object call(Object o,String n,Object...a)throws Exception{Class<?> t=o instanceof Class<?>?(Class<?>)o:o.getClass();for(var m:t.getMethods())if(m.getName().equals(n)&&m.getParameterCount()==a.length){boolean ok=true;for(int i=0;i<a.length;i++){Class<?> p=m.getParameterTypes()[i];if(p==int.class)p=Integer.class;if(p==boolean.class)p=Boolean.class;if(a[i]!=null&&!p.isInstance(a[i]))ok=false;}if(ok){m.setAccessible(true);return m.invoke(o instanceof Class<?>?null:o,a);}}throw new NoSuchMethodException(n);}
 public static void agentmain(String out,Instrumentation inst)throws Exception{
  if(!Boolean.getBoolean("michaelspack.validation"))throw new IllegalStateException("Private validation only");Class<?> mc=Arrays.stream(inst.getAllLoadedClasses()).filter(x->x.getName().equals("net.minecraft.client.Minecraft")).findFirst().orElseThrow();l=mc.getClassLoader();Object g=call(mc,"m_91087_");call(g,"execute",(Runnable)()->{var r=new LinkedHashMap<String,Object>();try{
   Object player=mc.getField("f_91074_").get(g),level=mc.getField("f_91073_").get(g);Object renderer=call(g,"m_91291_"),missing=call(call(g,"m_91304_"),"m_119409_");Map<?,?> all=(Map<?,?>)c("net.michaelspack.equipment.CopperEquipment").getField("ALL").get(null);var models=new ArrayList<Object>();boolean pass=true;
   for(var e:all.entrySet()){Object item=call(e.getValue(),"get");Object stack=c("net.minecraft.world.item.ItemStack").getConstructor(c("net.minecraft.world.level.ItemLike")).newInstance(item);Object model=call(renderer,"m_174264_",stack,level,player,0);String sprite=String.valueOf(call(call(call(model,"m_6160_"),"m_245424_"),"m_246162_"));boolean good=model!=missing&&!sprite.contains("missingno");models.add(Map.of("id",e.getKey(),"sprite",sprite,"notMissingModel",good));pass&=good;}
   r.put("models",models);r.put("passed",pass&&models.size()==28);Object screen=c("net.minecraft.client.gui.screens.inventory.InventoryScreen").getConstructor(c("net.minecraft.world.entity.player.Player")).newInstance(player);call(g,"m_91152_",screen);
  }catch(Throwable e){r.put("error",e.toString()+" cause="+e.getCause());r.put("passed",false);}try{Object b=c("com.google.gson.GsonBuilder").getConstructor().newInstance();Files.writeString(Path.of(out),(String)call(call(call(b,"setPrettyPrinting"),"create"),"toJson",r));}catch(Exception ignored){}});
 }
 public static void main(String[] a)throws Exception{var vm=VirtualMachine.attach(a[0]);try{vm.loadAgent(a[1],a[2]);}finally{vm.detach();}}
}
