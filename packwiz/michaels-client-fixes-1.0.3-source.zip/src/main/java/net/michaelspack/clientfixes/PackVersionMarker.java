package net.michaelspack.clientfixes;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
/** Optional Forge metadata only. No messages, codecs, receivers or sends are registered. */
public final class PackVersionMarker {
    public static final String VERSION = "1.0.3";
    private static final SimpleChannel CHANNEL = NetworkRegistry.ChannelBuilder
        .named(new ResourceLocation("michaels_client_fixes", "pack_version"))
        .networkProtocolVersion(() -> VERSION)
        .clientAcceptedVersions(ignored -> true)
        .serverAcceptedVersions(ignored -> true)
        .simpleChannel();
    private PackVersionMarker() {}
    public static void install() { /* Force metadata registration during client mod initialization. */ }
}
