package net.michaelspack.clientfixes;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.michaelspack.clientfixes.memory.MemoryConfig;
import net.michaelspack.clientfixes.memory.MemoryRestartHelper;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Properties;

/** One bounded pre-world restart for the exact supported Prism bundle. Never reads account data or process arguments. */
public final class LauncherMemoryMigration {
    private static final long SIX_GIB = 6144L * 1024 * 1024;
    private static boolean checked, manual, started, stopping, sixHeapRecorded, completionChecked, migrationCompleted;
    private static Path directory, plan;
    private static Process helper;
    private static long helperStarted;
    private static String result="NOT_CHECKED";
    private LauncherMemoryMigration() {}
    public static void install(){MinecraftForge.EVENT_BUS.register(new LauncherMemoryMigration());}
    public static boolean currentHeapIsSixGiB(){return Math.abs(Runtime.getRuntime().maxMemory()-SIX_GIB)<=8L*1024*1024;}
    public static boolean mustFinishBeforeJoin(Minecraft client){
        Path completion=client.gameDirectory.toPath().resolve("config/michaels-memory-106/completed.enabled");
        if(!completionChecked){completionChecked=true;migrationCompleted=Files.isRegularFile(completion);}
        if(migrationCompleted){result="ALREADY_COMPLETED_USER_MEMORY_CHOICE_RETAINED";return false;}
        if(currentHeapIsSixGiB()){
            migrationCompleted=true;
            try{Files.createDirectories(completion.getParent());Files.writeString(completion,"Completed one-time1.0.6 memory default. Later manual changes remain yours.\n",StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING);}
            catch(Exception ignored){ /* A correctly configured6GB client remains usable if diagnostics cannot persist. */ }
            if(!sixHeapRecorded){
                sixHeapRecorded=true;result="NO_RESTART_NEEDED";
                Path attempt=client.gameDirectory.toPath().resolve("config/michaels-memory-106/attempt.properties");
                if(Files.isRegularFile(attempt)){
                    try{
                        Properties proof=new Properties();proof.setProperty("actualMaxHeapBytes",Long.toString(Runtime.getRuntime().maxMemory()));
                        proof.setProperty("gamePid",Long.toString(ProcessHandle.current().pid()));
                        proof.setProperty("parentPid",Long.toString(ProcessHandle.current().parent().map(ProcessHandle::pid).orElse(-1L)));
                        try(OutputStream output=Files.newOutputStream(attempt.resolveSibling("running-six-gib.properties"))){proof.store(output,"Successful one-time pack memory update");}
                        result="RESTART_COMPLETE_SIX_GIB";
                    }catch(Exception ignored){ /* Diagnostics never block a correctly configured client. */ }
                }
            }
            return false;
        }
        if(client.level!=null)return false; // Never stop an existing player world.
        prepare(client);
        client.tell(()->{if(client.level==null && !(client.screen instanceof MemoryUpdateScreen))client.setScreen(new MemoryUpdateScreen(manual));});
        return true;
    }
    private static void prepare(Minecraft client){
        if(checked)return;
        checked=true;
        try{
            if(!System.getProperty("os.name","").startsWith("Windows"))throw new IllegalStateException("Supported launcher not detected");
            String instanceValue=System.getenv("INST_DIR"), gameValue=System.getenv("INST_MC_DIR"),id=System.getenv("INST_ID");
            if(instanceValue==null||gameValue==null||!"michaels-modpack".equals(id))throw new IllegalStateException("Pack launcher identity absent");
            Path instance=Path.of(instanceValue).toRealPath(), game=client.gameDirectory.toPath().toRealPath();
            Path data=instance.getParent().getParent();
            if(!Path.of(gameValue).toRealPath().equals(game)||!instance.getFileName().toString().equals(id)
                ||!instance.getParent().getFileName().toString().equals("instances")||!instance.resolve("minecraft").toRealPath().equals(game)
                ||!Files.isRegularFile(data.resolve("prismlauncher.cfg")))throw new IllegalStateException("Unrecognized pack instance");
            ProcessHandle prism=ProcessHandle.current().parent().orElseThrow();
            Path executable=Path.of(prism.info().command().orElseThrow()).toRealPath();
            if(!executable.getFileName().toString().equalsIgnoreCase("prismlauncher.exe")||!MemoryRestartHelper.sha(executable).equals(MemoryRestartHelper.PRISM_SHA256))
                throw new IllegalStateException("Supported Prism version not detected");
            String cfg=Files.readString(instance.resolve("instance.cfg"),StandardCharsets.UTF_8);
            if(!cfg.contains("packwiz-installer-bootstrap.jar")||!cfg.contains("mwin96/michaels-modpack/main/packwiz/pack.toml"))throw new IllegalStateException("Known pack hook absent");
            MemoryConfig.apply(cfg);
            directory=game.resolve("config/michaels-memory-106");Files.createDirectories(directory);
            plan=directory.resolve("attempt.properties");
            if(Files.exists(plan))throw new IllegalStateException("One restart was already attempted");
            Properties values=new Properties();
            values.setProperty("instance",instance.toString());values.setProperty("game",game.toString());values.setProperty("data",data.toString());
            values.setProperty("launcher",executable.toString());values.setProperty("id",id);
            values.setProperty("gamePid",Long.toString(ProcessHandle.current().pid()));values.setProperty("prismPid",Long.toString(prism.pid()));
            values.setProperty("startingMaxHeapBytes",Long.toString(Runtime.getRuntime().maxMemory()));
            try(OutputStream output=Files.newOutputStream(plan,StandardOpenOption.CREATE_NEW)){values.store(output,"One-time pack memory update; no account data");}
            result="READY_FOR_ONE_RESTART";
        }catch(Exception failure){manual=true;result="MANUAL_UPDATE_REQUIRED: "+failure.getClass().getSimpleName();}
    }
    @SubscribeEvent public void tick(TickEvent.ClientTickEvent event){
        if(event.phase!=TickEvent.Phase.START||migrationCompleted||currentHeapIsSixGiB())return;
        Minecraft client=Minecraft.getInstance();
        if(client.level!=null||!(client.screen instanceof MemoryUpdateScreen))return;
        if(manual||stopping)return;
        try{
            if(!started){
                Path jar=ModList.get().getModContainerById("michaels_client_fixes").orElseThrow().getModInfo().getOwningFile().getFile().getFilePath().toRealPath();
                Path expected=client.gameDirectory.toPath().toRealPath().resolve("mods/michaels-client-fixes-1.0.3.jar");
                if(!jar.equals(expected))throw new IllegalStateException("Pack jar path not recognized");
                Path javaExecutable=Path.of(System.getProperty("java.home"),"bin","javaw.exe");
                helper=new ProcessBuilder(javaExecutable.toString(),"-cp",jar.toString(),"net.michaelspack.clientfixes.memory.MemoryRestartHelper",plan.toString())
                    .redirectErrorStream(true).redirectOutput(directory.resolve("helper.log").toFile()).start();
                started=true;helperStarted=System.nanoTime();
            }
            if(Files.exists(directory.resolve("helper-ready"))&&helper.isAlive()&&System.nanoTime()-helperStarted>java.util.concurrent.TimeUnit.SECONDS.toNanos(1)){
                stopping=true;result="RESTARTING_ONCE";client.stop();
            }else if(!helper.isAlive()||System.nanoTime()-helperStarted>java.util.concurrent.TimeUnit.SECONDS.toNanos(8)){
                throw new IllegalStateException("Restart helper not ready");
            }
        }catch(Exception failure){manual=true;result="MANUAL_UPDATE_REQUIRED: "+failure.getClass().getSimpleName();client.setScreen(new MemoryUpdateScreen(true));}
    }
    public static String diagnostics(){return result+";heapBytes="+Runtime.getRuntime().maxMemory()+";checked="+checked+";manual="+manual+";stopping="+stopping;}
}
