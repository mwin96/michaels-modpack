"""Preserve the immutable baseline binary and append this source extension only.

First run gradlew build (Forge47.4.28, Java17), then pass its reobfuscated JAR
and the pinned original public JAR. No upstream/vendor binary is shipped here.
"""
from pathlib import Path
import argparse,copy,hashlib,json,zipfile
BASE='2fbfc115ce1683c3f0a6436d4561dcdb28423b39ae71178fc58d272c35f9d49c'
NEW=['net/michaelspack/SilverfishBody112.class','net/michaelspack/mixin/NaturalMonsterCapacity112Mixin.class']
KEY='net/michaelspack/mixin/NaturalMonsterCapacity112Mixin'
def merge(original,compiled,destination):
    original=Path(original);compiled=Path(compiled);destination=Path(destination)
    assert hashlib.sha256(original.read_bytes()).hexdigest()==BASE
    with zipfile.ZipFile(original) as old,zipfile.ZipFile(compiled) as built:
        files={n:old.read(n) for n in old.namelist()}
        for name in NEW:assert name not in files;files[name]=built.read(name)
        config=json.loads(files['michaelspack.mixins.json']);assert 'NaturalMonsterCapacity112Mixin' not in config['mixins'];config['mixins'].append('NaturalMonsterCapacity112Mixin')
        files['michaelspack.mixins.json']=(json.dumps(config,indent=2)+'\n').encode()
        previous=json.loads(files['zombie_tactics.refmap.json']);ref=copy.deepcopy(previous);new=json.loads(built.read('zombie_tactics.refmap.json'))
        # Annotation processors represent class keys with dots in this Forge build.
        key=next(k for k in new['mappings'] if k.replace('.','/')==KEY)
        assert key not in ref['mappings'];ref['mappings'][key]=new['mappings'][key]
        for env,values in new.get('data',{}).items():
            if key in values:ref.setdefault('data',{}).setdefault(env,{})[key]=values[key]
        for k,v in previous['mappings'].items():assert ref['mappings'][k]==v
        for env,values in previous.get('data',{}).items():
            for k,v in values.items():assert ref['data'][env][k]==v
        files['zombie_tactics.refmap.json']=(json.dumps(ref,indent=2)+'\n').encode()
        destination.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as result:
            for info in old.infolist():result.writestr(info,files[info.filename])
            for name in NEW:result.writestr(name,files[name])
    with zipfile.ZipFile(original) as old,zipfile.ZipFile(destination) as result:
        changed=[n for n in old.namelist() if old.read(n)!=result.read(n)]
        assert set(changed)=={'michaelspack.mixins.json','zombie_tactics.refmap.json'}
        assert set(result.namelist())-set(old.namelist())==set(NEW)
        assert all(old.read(n)==result.read(n) for n in old.namelist() if n.endswith('.class'))
    return {'changedExistingEntries':changed,'addedEntries':NEW,'allExistingClassBytesExact':True,'allOtherAssetsRecipesResourcesAndMetadataExact':True,'allOldRefmapMappingsExact':True}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input-original',required=True);p.add_argument('--compiled-jar',required=True);p.add_argument('--output',required=True);a=p.parse_args();print(json.dumps(merge(a.input_original,a.compiled_jar,a.output),indent=2))
