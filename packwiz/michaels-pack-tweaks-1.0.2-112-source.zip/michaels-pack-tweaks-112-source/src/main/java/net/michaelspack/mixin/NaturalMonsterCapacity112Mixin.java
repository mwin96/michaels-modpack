package net.michaelspack.mixin;

import net.minecraft.world.entity.MobCategory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Increase natural hostile capacity, retaining EC2's existing multiplier hooks. */
@Mixin(MobCategory.class)
public abstract class NaturalMonsterCapacity112Mixin {
    @Inject(method = "getMaxInstancesPerChunk", at = @At("HEAD"), cancellable = true, require = 1)
    private void michaels$naturalMonsterCapacity(CallbackInfoReturnable<Integer> result) {
        if ((Object) this == MobCategory.MONSTER) result.setReturnValue(84);
    }
}
