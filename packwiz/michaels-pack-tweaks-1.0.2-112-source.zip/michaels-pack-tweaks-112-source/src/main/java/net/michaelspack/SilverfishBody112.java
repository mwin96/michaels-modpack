package net.michaelspack;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.entity.EntityEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Match this pack's humanoid silverfish while retaining safe crawling in low spaces. */
@Mod.EventBusSubscriber(modid = "michaelspack")
public final class SilverfishBody112 {
    private static final EntityDimensions BODY = EntityDimensions.scalable(0.60F, 1.80F);
    private static final float EYE = 1.55F;

    private SilverfishBody112() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void size(EntityEvent.Size event) {
        Entity entity = event.getEntity();
        // Size is also fired inside Entity's constructor; leave that phase untouched.
        if (entity.getType() != EntityType.SILVERFISH || !entity.isAddedToWorld()) return;
        if (canStand(entity)) {
            event.setNewSize(BODY);
            event.setNewEyeHeight(EYE);
        }
        // Otherwise retain Forge/vanilla's original crawling size and eye height.
    }

    @SubscribeEvent
    public static void tick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.getType() != EntityType.SILVERFISH || !entity.isAddedToWorld() || !entity.isAlive()) return;
        if (entity.tickCount > 1 && entity.tickCount % 10 != 0) return;
        boolean standing = canStand(entity);
        EntityDimensions wanted = standing ? BODY : entity.getDimensions(entity.getPose());
        if (Math.abs(entity.getBbWidth() - wanted.width) > 0.0001F
                || Math.abs(entity.getBbHeight() - wanted.height) > 0.0001F
                || standing && Math.abs(entity.getEyeHeight() - EYE) > 0.0001F) {
            // No refresh is performed inside Size, so this cannot recursively refresh itself.
            entity.refreshDimensions();
        }
    }

    private static boolean canStand(Entity entity) {
        double half = BODY.width / 2.0;
        AABB box = new AABB(entity.getX() - half, entity.getY(), entity.getZ() - half,
                entity.getX() + half, entity.getY() + BODY.height, entity.getZ() + half).deflate(0.00001);
        int minX = Mth.floor(box.minX) >> 4, maxX = Mth.floor(box.maxX) >> 4;
        int minZ = Mth.floor(box.minZ) >> 4, maxZ = Mth.floor(box.maxZ) >> 4;
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                if (!entity.level().hasChunk(x, z)) return false;
            }
        }
        // Deliberately ignore other entities: an approaching player must not shrink the hitbox.
        return !entity.level().getBlockCollisions(entity, box).iterator().hasNext();
    }
}
