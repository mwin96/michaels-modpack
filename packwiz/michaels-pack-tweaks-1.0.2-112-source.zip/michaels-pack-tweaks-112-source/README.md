# Michael's Pack Tweaks and Zombie Tactics backport

Minecraft 1.20.1 / Forge 47.4.28. Build with Java 17: `./gradlew build` (Windows: `gradlew.bat build`).
The matching binary is `michaels-pack-tweaks-1.0.2.jar`.

Zombie Tactics is by n643064: https://github.com/n643064/ZombieTactics
Original source revision: 6f62bf477fe15c2310517443cba5d7acba5e9fbd. Original declared license: GNU GPL 3.0.
This modified Forge backport retains vanilla AI, fixes marker placement/server spawning, and reduces marker range and mining aggressiveness.
Other pack additions fix loading, paired chest loot, pause configuration refresh, wild Tremorzilla targeting and configurable Dragon health (default 400 HP).
Validation probes are operator-only and extra test behavior requires `-Dmichaelspack.validation=true`; that flag is absent from release launch settings.

The combined Java mod is distributed under GPL version 3; see LICENSE.txt. Third-party Minecraft/Forge APIs retain their own licenses.
Resource overrides adapted from other mods remain governed by their respective original licenses; see the release mod list for authors and project links.

The 1.0.2 playability patch preserves normal Backrooms respawn settings, adds deliberate portal access, and corrects shared Knocker timer scaling. See the pack validation report for the exact tested scope.

The 1.0.1 playability patch preserves normal Backrooms respawn settings, adds deliberate portal access, and corrects shared Knocker timer scaling. See the pack validation report for the exact tested scope.


## Release112 extension

Adds only SilverfishBody112 and NaturalMonsterCapacity112Mixin. EntityEvent.Size is active in pinned Forge47.4.28. The silverfish uses0.60x1.80/eye1.55 with space; vanilla crawling under low ceilings. Only block collision is checked, every10ticks for silverfish only. Natural MONSTER base capacity70to84; all other categories and EC2 multiplier/local40 config remain unchanged. No forced spawns or AI/world edits.

Reproduce: Java17, run gradlew build, then python build-extension.py --input-original ORIGINAL.jar --compiled-jar build/libs/michaels-pack-tweaks-1.0.2.jar --output patched.jar. Original SHA256:2fbfc115ce1683c3f0a6436d4561dcdb28423b39ae71178fc58d272c35f9d49c. Immutable public original: https://raw.githubusercontent.com/mwin96/michaels-modpack/7a737b194cfda6933c280f3b6ab3a10ce356a6ba/packwiz/mods/michaels-pack-tweaks-1.0.2.jar . Complete original source is retained here. Merge preserves every original class/resource byte, adding only two production classes and Mixin metadata/refmap mapping. This source archive excludes binaries except the unmodified Gradle wrapper with its LICENSE/NOTICE.
